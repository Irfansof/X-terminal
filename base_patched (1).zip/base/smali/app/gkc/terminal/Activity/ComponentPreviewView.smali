.class public Lapp/gkc/terminal/Activity/ComponentPreviewView;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final b:Landroid/graphics/Paint;

.field public c:I

.field public d:[I

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b:Landroid/graphics/Paint;

    const/4 p1, 0x0

    iput p1, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->c:I

    const/high16 p1, -0x10000

    const p2, -0x2b50c9

    const v0, -0xff0100

    const v1, -0xffff01

    filled-new-array {v0, v1, p1, p2}, [I

    move-result-object p1

    iput-object p1, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->d:[I

    const-string p1, "102"

    iput-object p1, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->e:Ljava/lang/String;

    const-string p1, "1 kOhm"

    iput-object p1, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->f:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Canvas;FFFFLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 27

    move-object/from16 v6, p1

    move/from16 v0, p2

    move/from16 v1, p3

    move/from16 v2, p4

    move/from16 v7, p5

    move/from16 v3, p9

    new-instance v4, Landroid/graphics/RectF;

    invoke-direct {v4, v0, v1, v2, v7}, Landroid/graphics/RectF;-><init>(FFFF)V

    move-object/from16 v8, p0

    iget-object v9, v8, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b:Landroid/graphics/Paint;

    sget-object v10, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v9, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v11, -0xeee7d9

    invoke-virtual {v9, v11}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v12, 0x41600000    # 14.0f

    invoke-virtual {v6, v4, v12, v12, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    sget-object v13, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v9, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v5, 0x3fc00000    # 1.5f

    invoke-virtual {v9, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const v5, -0xd9cdbf

    invoke-virtual {v9, v5}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v6, v4, v12, v12, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    add-float/2addr v0, v2

    const/high16 v14, 0x3f000000    # 0.5f

    mul-float v15, v0, v14

    sub-float v16, v7, v1

    const v0, 0x3edc28f6    # 0.43f

    mul-float v0, v0, v16

    add-float v17, v0, v1

    const/high16 v5, 0x41300000    # 11.0f

    const/4 v4, -0x1

    const v2, -0x87caf1

    const/high16 v1, 0x40000000    # 2.0f

    const/high16 v0, 0x40e00000    # 7.0f

    const/high16 v18, 0x41000000    # 8.0f

    const/high16 v12, 0x40600000    # 3.5f

    const v21, 0x3e3851ec    # 0.18f

    const v11, -0x1a1815

    const v22, 0x3e8f5c29    # 0.28f

    if-nez v3, :cond_0

    mul-float v22, v22, v16

    const v23, 0x3eae147b    # 0.34f

    mul-float v24, v16, v23

    .line 1
    invoke-virtual {v9, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v9, v12}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {v9, v11}, Landroid/graphics/Paint;->setColor(I)V

    mul-float v21, v21, v22

    sub-float v3, v15, v21

    const v11, 0x3ed70a3d    # 0.42f

    mul-float v11, v11, v24

    add-float v11, v11, v17

    const v12, 0x3eeb851f    # 0.46f

    mul-float v12, v12, v22

    sub-float v25, v15, v12

    add-float v26, v17, v24

    move v14, v0

    move-object/from16 v0, p1

    move v1, v3

    move v3, v2

    move v2, v11

    move/from16 v3, v25

    move/from16 v4, v26

    move-object v5, v9

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-float v1, v15, v21

    add-float v3, v15, v12

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    new-instance v0, Landroid/graphics/RectF;

    const/high16 v1, 0x3f000000    # 0.5f

    mul-float v22, v22, v1

    sub-float v2, v15, v22

    mul-float v1, v1, v24

    sub-float v3, v17, v1

    add-float v4, v15, v22

    add-float v1, v17, v1

    invoke-direct {v0, v2, v3, v4, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v9, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v1, -0x533eb

    invoke-virtual {v9, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v6, v0, v9}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    const v1, 0x55ffffff    # 3.518437E13f

    invoke-virtual {v9, v1}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v1, Landroid/graphics/RectF;

    iget v2, v0, Landroid/graphics/RectF;->left:F

    add-float v2, v2, v18

    iget v3, v0, Landroid/graphics/RectF;->top:F

    add-float v4, v3, v14

    iget v5, v0, Landroid/graphics/RectF;->right:F

    sub-float v5, v5, v18

    mul-float v24, v24, v23

    add-float v3, v24, v3

    invoke-direct {v1, v2, v4, v5, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v6, v1, v9}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    invoke-virtual {v9, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v1, 0x40000000    # 2.0f

    invoke-virtual {v9, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const v2, -0x87caf1

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v6, v0, v9}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    invoke-virtual {v9, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v0, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    const/4 v0, 0x1

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    const v0, -0xeee7d9

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x3e051eb8    # 0.13f

    mul-float v0, v0, v16

    const/high16 v1, 0x41600000    # 14.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v0, 0x40a00000    # 5.0f

    add-float v0, v17, v0

    const-string v1, "104"

    invoke-virtual {v6, v1, v15, v0, v9}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    goto/16 :goto_0

    :cond_0
    move v14, v0

    const v19, 0x3eb851ec    # 0.36f

    const/4 v0, 0x1

    if-ne v3, v0, :cond_1

    const/high16 v0, 0x3e800000    # 0.25f

    mul-float v14, v16, v0

    const v0, 0x3ef5c28f    # 0.48f

    mul-float v20, v16, v0

    .line 2
    new-instance v5, Landroid/graphics/RectF;

    const/high16 v0, 0x3f000000    # 0.5f

    mul-float v1, v14, v0

    sub-float v2, v15, v1

    mul-float v0, v0, v20

    sub-float v3, v17, v0

    add-float/2addr v1, v15

    add-float v0, v17, v0

    invoke-direct {v5, v2, v3, v1, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v9, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v0, -0xda9c15

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v0, 0x41200000    # 10.0f

    invoke-virtual {v6, v5, v0, v0, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const v0, -0xf0e8d6

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    iget v1, v5, Landroid/graphics/RectF;->left:F

    iget v2, v5, Landroid/graphics/RectF;->top:F

    const v0, 0x3e75c28f    # 0.24f

    mul-float/2addr v0, v14

    add-float v3, v0, v1

    iget v4, v5, Landroid/graphics/RectF;->bottom:F

    move-object/from16 v0, p1

    move-object v11, v5

    move-object v5, v9

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    const v0, -0x6c3a03

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v0, Landroid/graphics/RectF;

    iget v1, v11, Landroid/graphics/RectF;->left:F

    const v2, 0x3eb33333    # 0.35f

    mul-float/2addr v2, v14

    add-float/2addr v2, v1

    iget v1, v11, Landroid/graphics/RectF;->top:F

    add-float v3, v1, v18

    iget v4, v11, Landroid/graphics/RectF;->right:F

    sub-float v4, v4, v18

    const v5, 0x3e4ccccd    # 0.2f

    mul-float v20, v20, v5

    add-float v1, v20, v1

    invoke-direct {v0, v2, v3, v4, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v1, 0x40a00000    # 5.0f

    invoke-virtual {v6, v0, v1, v1, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual {v9, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v9, v12}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const v0, -0x1a1815

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    mul-float v21, v21, v14

    sub-float v1, v15, v21

    iget v2, v11, Landroid/graphics/RectF;->bottom:F

    mul-float v14, v14, v22

    sub-float v3, v15, v14

    mul-float v19, v19, v16

    add-float v12, v19, v17

    move-object/from16 v0, p1

    move v4, v12

    move-object v5, v9

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-float v1, v15, v21

    iget v2, v11, Landroid/graphics/RectF;->bottom:F

    add-float v3, v15, v14

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {v9, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v0, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    const/4 v0, 0x1

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    const/4 v0, -0x1

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v1, 0x3dd70a3d    # 0.105f

    mul-float v1, v1, v16

    const/high16 v3, 0x41300000    # 11.0f

    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual {v9, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v1, 0x40a00000    # 5.0f

    add-float v1, v17, v1

    const-string v2, "10uF"

    invoke-virtual {v6, v2, v15, v1, v9}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    goto/16 :goto_0

    :cond_1
    const/4 v0, -0x1

    const/high16 v3, 0x41300000    # 11.0f

    const v4, 0x3ee147ae    # 0.44f

    mul-float v4, v4, v16

    const v5, 0x3e6147ae    # 0.22f

    mul-float v11, v16, v5

    mul-float v21, v21, v4

    .line 3
    invoke-virtual {v9, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v12, -0x1a1815

    invoke-virtual {v9, v12}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v12, Landroid/graphics/RectF;

    const/high16 v18, 0x3f000000    # 0.5f

    mul-float v20, v4, v18

    sub-float v3, v15, v20

    mul-float v18, v18, v11

    sub-float v0, v17, v18

    add-float v2, v3, v21

    add-float v1, v17, v18

    invoke-direct {v12, v3, v0, v2, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v2, 0x40a00000    # 5.0f

    invoke-virtual {v6, v12, v2, v2, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    new-instance v3, Landroid/graphics/RectF;

    add-float v12, v15, v20

    sub-float v5, v12, v21

    invoke-direct {v3, v5, v0, v12, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v6, v3, v2, v2, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const v2, -0x294e86

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v2, Landroid/graphics/RectF;

    mul-float v19, v19, v4

    sub-float v3, v15, v19

    add-float v5, v15, v19

    invoke-direct {v2, v3, v0, v5, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v6, v2, v14, v14, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const v2, 0x66ffffff

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v2, Landroid/graphics/RectF;

    const v12, 0x3e6147ae    # 0.22f

    mul-float/2addr v4, v12

    sub-float v12, v15, v4

    mul-float v22, v22, v11

    sub-float v14, v17, v22

    add-float/2addr v4, v15

    const v18, 0x3dcccccd    # 0.1f

    mul-float v11, v11, v18

    sub-float v11, v17, v11

    invoke-direct {v2, v12, v14, v4, v11}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v4, 0x40800000    # 4.0f

    invoke-virtual {v6, v2, v4, v4, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual {v9, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v2, 0x40000000    # 2.0f

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const v2, -0x87caf1

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2, v3, v0, v5, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v0, 0x40e00000    # 7.0f

    invoke-virtual {v6, v2, v0, v0, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 4
    :goto_0
    invoke-virtual {v9, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v0, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    const/4 v0, 0x1

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    const/4 v0, -0x1

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x3dc28f5c    # 0.095f

    mul-float v0, v0, v16

    const/high16 v1, 0x41400000    # 12.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v0, 0x42080000    # 34.0f

    sub-float v0, v7, v0

    move-object/from16 v1, p6

    invoke-virtual {v6, v1, v15, v0, v9}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const v0, -0xcb2c67

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x3dae147b    # 0.085f

    mul-float v0, v0, v16

    const/high16 v1, 0x41300000    # 11.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v1, p7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "  "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v1, p8

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/high16 v1, 0x41500000    # 13.0f

    sub-float v1, v7, v1

    invoke-virtual {v6, v0, v15, v1, v9}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final b(Landroid/graphics/Canvas;Ljava/lang/String;FF)V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v1, -0xcb2c67

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x41900000    # 18.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    invoke-virtual {p1, p2, p3, p4, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    return-void
.end method

.method public final c(Landroid/graphics/Canvas;FFFF)V
    .locals 13

    .line 1
    sub-float v0, p4, p2

    const/4 v1, 0x6

    int-to-float v2, v1

    div-float/2addr v0, v2

    move-object v6, p0

    iget-object v5, v6, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v2, 0x40800000    # 4.0f

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const v2, -0xc74208

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v2, 0x1

    move v8, p2

    move/from16 v9, p3

    :goto_0
    if-gt v2, v1, :cond_1

    int-to-float v3, v2

    mul-float/2addr v3, v0

    add-float/2addr v3, p2

    rem-int/lit8 v4, v2, 0x2

    const/high16 v7, 0x41200000    # 10.0f

    if-nez v4, :cond_0

    sub-float v4, p3, v7

    goto :goto_1

    :cond_0
    add-float v4, p3, v7

    :goto_1
    move-object v7, p1

    move v10, v3

    move v11, v4

    move-object v12, v5

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-int/lit8 v2, v2, 0x1

    move v8, v3

    move v9, v4

    goto :goto_0

    :cond_1
    move-object v0, p1

    move v1, v8

    move v2, v9

    move/from16 v3, p4

    move/from16 v4, p5

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final d(Landroid/graphics/Canvas;FFFF)V
    .locals 12

    .line 1
    sub-float v0, p5, p3

    const/4 v1, 0x6

    int-to-float v2, v1

    div-float/2addr v0, v2

    const/4 v2, 0x1

    move-object v9, p0

    move v4, p2

    move v5, p3

    :goto_0
    iget-object v8, v9, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b:Landroid/graphics/Paint;

    if-gt v2, v1, :cond_1

    rem-int/lit8 v3, v2, 0x2

    const/high16 v6, 0x41400000    # 12.0f

    if-nez v3, :cond_0

    sub-float v3, p2, v6

    :goto_1
    move v10, v3

    goto :goto_2

    :cond_0
    add-float v3, p2, v6

    goto :goto_1

    :goto_2
    int-to-float v3, v2

    mul-float/2addr v3, v0

    add-float v11, v3, p3

    move-object v3, p1

    move v6, v10

    move v7, v11

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-int/lit8 v2, v2, 0x1

    move v4, v10

    move v5, v11

    goto :goto_0

    :cond_1
    move-object v0, p1

    move v1, v4

    move v2, v5

    move/from16 v3, p4

    move/from16 v4, p5

    move-object v5, v8

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final e(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_0

    const-string p1, "---"

    :cond_0
    iput-object p1, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->e:Ljava/lang/String;

    if-eqz p2, :cond_1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p1

    if-nez p1, :cond_2

    :cond_1
    const-string p2, "Ready"

    :cond_2
    iput-object p2, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->f:Ljava/lang/String;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 25

    .line 1
    move-object/from16 v10, p0

    .line 2
    .line 3
    move-object/from16 v11, p1

    .line 4
    .line 5
    invoke-super/range {p0 .. p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 6
    .line 7
    .line 8
    iget-object v12, v10, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b:Landroid/graphics/Paint;

    .line 9
    .line 10
    sget-object v0, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    .line 11
    .line 12
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 13
    .line 14
    .line 15
    iget v0, v10, Lapp/gkc/terminal/Activity/ComponentPreviewView;->c:I

    .line 16
    .line 17
    const v7, 0x3e4ccccd    # 0.2f

    .line 18
    .line 19
    .line 20
    const/high16 v8, 0x41000000    # 8.0f

    .line 21
    .line 22
    const v3, -0xf4ede0

    .line 23
    .line 24
    .line 25
    const/high16 v14, 0x41900000    # 18.0f

    .line 26
    .line 27
    const/4 v5, 0x4

    .line 28
    if-ne v0, v5, :cond_0

    .line 29
    .line 30
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    int-to-float v0, v0

    .line 35
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    int-to-float v5, v5

    .line 40
    const v16, 0x3e23d70a    # 0.16f

    .line 41
    .line 42
    .line 43
    mul-float v15, v0, v16

    .line 44
    .line 45
    const v16, 0x3f570a3d    # 0.84f

    .line 46
    .line 47
    .line 48
    mul-float v9, v0, v16

    .line 49
    .line 50
    mul-float/2addr v7, v5

    .line 51
    const v16, 0x3f2e147b    # 0.68f

    .line 52
    .line 53
    .line 54
    mul-float v2, v5, v16

    .line 55
    .line 56
    const v16, 0x3db851ec    # 0.09f

    .line 57
    .line 58
    .line 59
    mul-float v4, v0, v16

    .line 60
    .line 61
    invoke-static {v14, v4}, Ljava/lang/Math;->max(FF)F

    .line 62
    .line 63
    .line 64
    move-result v4

    .line 65
    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 66
    .line 67
    invoke-virtual {v12, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 71
    .line 72
    .line 73
    new-instance v3, Landroid/graphics/RectF;

    .line 74
    .line 75
    sub-float v6, v0, v8

    .line 76
    .line 77
    sub-float v13, v5, v8

    .line 78
    .line 79
    invoke-direct {v3, v8, v8, v6, v13}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v11, v3, v14, v14, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 83
    .line 84
    .line 85
    const v3, -0x342a1f

    .line 86
    .line 87
    .line 88
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 89
    .line 90
    .line 91
    new-instance v3, Landroid/graphics/RectF;

    .line 92
    .line 93
    sub-float v6, v15, v4

    .line 94
    .line 95
    const v13, 0x3d75c28f    # 0.06f

    .line 96
    .line 97
    .line 98
    mul-float/2addr v13, v5

    .line 99
    add-float v14, v7, v13

    .line 100
    .line 101
    move/from16 v21, v0

    .line 102
    .line 103
    add-float v0, v15, v8

    .line 104
    .line 105
    sub-float v13, v2, v13

    .line 106
    .line 107
    invoke-direct {v3, v6, v14, v0, v13}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v11, v3, v8, v8, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 111
    .line 112
    .line 113
    new-instance v0, Landroid/graphics/RectF;

    .line 114
    .line 115
    sub-float v3, v9, v8

    .line 116
    .line 117
    add-float/2addr v4, v9

    .line 118
    invoke-direct {v0, v3, v14, v4, v13}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v11, v0, v8, v8, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 122
    .line 123
    .line 124
    const v0, -0xeee7d9

    .line 125
    .line 126
    .line 127
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 128
    .line 129
    .line 130
    new-instance v0, Landroid/graphics/RectF;

    .line 131
    .line 132
    invoke-direct {v0, v15, v7, v9, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 133
    .line 134
    .line 135
    const/high16 v3, 0x41800000    # 16.0f

    .line 136
    .line 137
    invoke-virtual {v11, v0, v3, v3, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 138
    .line 139
    .line 140
    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 141
    .line 142
    invoke-virtual {v12, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 143
    .line 144
    .line 145
    const/high16 v4, 0x40200000    # 2.5f

    .line 146
    .line 147
    invoke-virtual {v12, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 148
    .line 149
    .line 150
    const v4, -0xc74208

    .line 151
    .line 152
    .line 153
    invoke-virtual {v12, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v11, v0, v3, v3, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v12, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 160
    .line 161
    .line 162
    sget-object v0, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    .line 163
    .line 164
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 165
    .line 166
    .line 167
    const/4 v0, 0x1

    .line 168
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 169
    .line 170
    .line 171
    const/4 v0, -0x1

    .line 172
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 173
    .line 174
    .line 175
    const v0, 0x3e75c28f    # 0.24f

    .line 176
    .line 177
    .line 178
    mul-float/2addr v0, v5

    .line 179
    const/high16 v1, 0x41e00000    # 28.0f

    .line 180
    .line 181
    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    .line 182
    .line 183
    .line 184
    move-result v0

    .line 185
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 186
    .line 187
    .line 188
    iget-object v0, v10, Lapp/gkc/terminal/Activity/ComponentPreviewView;->e:Ljava/lang/String;

    .line 189
    .line 190
    const/high16 v1, 0x3f000000    # 0.5f

    .line 191
    .line 192
    mul-float v1, v1, v21

    .line 193
    .line 194
    sub-float/2addr v2, v7

    .line 195
    const v3, 0x3f19999a    # 0.6f

    .line 196
    .line 197
    .line 198
    mul-float/2addr v2, v3

    .line 199
    add-float/2addr v2, v7

    .line 200
    invoke-virtual {v11, v0, v1, v2, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 201
    .line 202
    .line 203
    const/4 v0, 0x0

    .line 204
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 205
    .line 206
    .line 207
    const v0, -0xcb2c67

    .line 208
    .line 209
    .line 210
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 211
    .line 212
    .line 213
    const v0, 0x3e0f5c29    # 0.14f

    .line 214
    .line 215
    .line 216
    mul-float/2addr v0, v5

    .line 217
    const/high16 v2, 0x41900000    # 18.0f

    .line 218
    .line 219
    invoke-static {v2, v0}, Ljava/lang/Math;->max(FF)F

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 224
    .line 225
    .line 226
    iget-object v0, v10, Lapp/gkc/terminal/Activity/ComponentPreviewView;->f:Ljava/lang/String;

    .line 227
    .line 228
    const v2, 0x3f6147ae    # 0.88f

    .line 229
    .line 230
    .line 231
    mul-float/2addr v5, v2

    .line 232
    invoke-virtual {v11, v0, v1, v5, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 233
    .line 234
    .line 235
    sget-object v0, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    .line 236
    .line 237
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 238
    .line 239
    .line 240
    :goto_0
    move-object v6, v10

    .line 241
    goto/16 :goto_7

    .line 242
    .line 243
    :cond_0
    const/4 v1, 0x5

    .line 244
    const-string v6, "R"

    .line 245
    .line 246
    const v9, 0x3e8f5c29    # 0.28f

    .line 247
    .line 248
    .line 249
    const v13, 0x3da3d70a    # 0.08f

    .line 250
    .line 251
    .line 252
    const/high16 v14, 0x40800000    # 4.0f

    .line 253
    .line 254
    if-ne v0, v1, :cond_2

    .line 255
    .line 256
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 257
    .line 258
    .line 259
    move-result v0

    .line 260
    int-to-float v7, v0

    .line 261
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 262
    .line 263
    .line 264
    move-result v0

    .line 265
    int-to-float v15, v0

    .line 266
    const/high16 v0, 0x3f000000    # 0.5f

    .line 267
    .line 268
    mul-float v16, v15, v0

    .line 269
    .line 270
    mul-float/2addr v13, v7

    .line 271
    const v0, 0x3f6b851f    # 0.92f

    .line 272
    .line 273
    .line 274
    mul-float v4, v7, v0

    .line 275
    .line 276
    sub-float v0, v4, v13

    .line 277
    .line 278
    div-float v19, v0, v14

    .line 279
    .line 280
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 281
    .line 282
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 286
    .line 287
    .line 288
    new-instance v0, Landroid/graphics/RectF;

    .line 289
    .line 290
    sub-float v1, v7, v8

    .line 291
    .line 292
    sub-float v2, v15, v8

    .line 293
    .line 294
    invoke-direct {v0, v8, v8, v1, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 295
    .line 296
    .line 297
    const/high16 v1, 0x41900000    # 18.0f

    .line 298
    .line 299
    invoke-virtual {v11, v0, v1, v1, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 300
    .line 301
    .line 302
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 303
    .line 304
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 305
    .line 306
    .line 307
    invoke-virtual {v12, v14}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 308
    .line 309
    .line 310
    const v0, -0x1a1815

    .line 311
    .line 312
    .line 313
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 314
    .line 315
    .line 316
    move-object/from16 v0, p1

    .line 317
    .line 318
    move v1, v13

    .line 319
    move/from16 v2, v16

    .line 320
    .line 321
    move v3, v4

    .line 322
    move/from16 v4, v16

    .line 323
    .line 324
    move v8, v5

    .line 325
    move-object v5, v12

    .line 326
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 327
    .line 328
    .line 329
    const/4 v12, 0x0

    .line 330
    :goto_1
    if-ge v12, v8, :cond_1

    .line 331
    .line 332
    int-to-float v0, v12

    .line 333
    const/high16 v1, 0x3f000000    # 0.5f

    .line 334
    .line 335
    add-float/2addr v0, v1

    .line 336
    mul-float v0, v0, v19

    .line 337
    .line 338
    add-float v14, v0, v13

    .line 339
    .line 340
    mul-float v0, v19, v9

    .line 341
    .line 342
    sub-float v2, v14, v0

    .line 343
    .line 344
    add-float v4, v14, v0

    .line 345
    .line 346
    move-object/from16 v0, p0

    .line 347
    .line 348
    move-object/from16 v1, p1

    .line 349
    .line 350
    move/from16 v3, v16

    .line 351
    .line 352
    move/from16 v5, v16

    .line 353
    .line 354
    invoke-virtual/range {v0 .. v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->c(Landroid/graphics/Canvas;FFFF)V

    .line 355
    .line 356
    .line 357
    new-instance v0, Ljava/lang/StringBuilder;

    .line 358
    .line 359
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 360
    .line 361
    .line 362
    add-int/lit8 v12, v12, 0x1

    .line 363
    .line 364
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 365
    .line 366
    .line 367
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 368
    .line 369
    .line 370
    move-result-object v0

    .line 371
    const/high16 v1, 0x41600000    # 14.0f

    .line 372
    .line 373
    sub-float/2addr v14, v1

    .line 374
    const/high16 v1, 0x41d00000    # 26.0f

    .line 375
    .line 376
    sub-float v1, v16, v1

    .line 377
    .line 378
    invoke-virtual {v10, v11, v0, v14, v1}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b(Landroid/graphics/Canvas;Ljava/lang/String;FF)V

    .line 379
    .line 380
    .line 381
    goto :goto_1

    .line 382
    :cond_1
    const v0, 0x3ed70a3d    # 0.42f

    .line 383
    .line 384
    .line 385
    mul-float/2addr v7, v0

    .line 386
    const v0, 0x3f5c28f6    # 0.86f

    .line 387
    .line 388
    .line 389
    mul-float/2addr v15, v0

    .line 390
    const-string v0, "SERIES"

    .line 391
    .line 392
    invoke-virtual {v10, v11, v0, v7, v15}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b(Landroid/graphics/Canvas;Ljava/lang/String;FF)V

    .line 393
    .line 394
    .line 395
    goto/16 :goto_0

    .line 396
    .line 397
    :cond_2
    move v15, v5

    .line 398
    const/4 v1, 0x6

    .line 399
    const/high16 v22, 0x3e800000    # 0.25f

    .line 400
    .line 401
    const/high16 v5, 0x40400000    # 3.0f

    .line 402
    .line 403
    const v23, 0x3e3851ec    # 0.18f

    .line 404
    .line 405
    .line 406
    const v24, 0x3f47ae14    # 0.78f

    .line 407
    .line 408
    .line 409
    if-ne v0, v1, :cond_4

    .line 410
    .line 411
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 412
    .line 413
    .line 414
    move-result v0

    .line 415
    int-to-float v7, v0

    .line 416
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 417
    .line 418
    .line 419
    move-result v0

    .line 420
    int-to-float v9, v0

    .line 421
    mul-float v23, v23, v7

    .line 422
    .line 423
    const v0, 0x3f51eb85    # 0.82f

    .line 424
    .line 425
    .line 426
    mul-float v13, v7, v0

    .line 427
    .line 428
    const v0, 0x3e6147ae    # 0.22f

    .line 429
    .line 430
    .line 431
    mul-float v16, v9, v0

    .line 432
    .line 433
    mul-float v24, v24, v9

    .line 434
    .line 435
    sub-float v0, v24, v16

    .line 436
    .line 437
    div-float v19, v0, v5

    .line 438
    .line 439
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 440
    .line 441
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 442
    .line 443
    .line 444
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 445
    .line 446
    .line 447
    new-instance v0, Landroid/graphics/RectF;

    .line 448
    .line 449
    sub-float v1, v7, v8

    .line 450
    .line 451
    sub-float v2, v9, v8

    .line 452
    .line 453
    invoke-direct {v0, v8, v8, v1, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 454
    .line 455
    .line 456
    const/high16 v1, 0x41900000    # 18.0f

    .line 457
    .line 458
    invoke-virtual {v11, v0, v1, v1, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 459
    .line 460
    .line 461
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 462
    .line 463
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 464
    .line 465
    .line 466
    invoke-virtual {v12, v14}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 467
    .line 468
    .line 469
    const v0, -0x1a1815

    .line 470
    .line 471
    .line 472
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 473
    .line 474
    .line 475
    move-object/from16 v0, p1

    .line 476
    .line 477
    move/from16 v1, v23

    .line 478
    .line 479
    move/from16 v2, v16

    .line 480
    .line 481
    move/from16 v3, v23

    .line 482
    .line 483
    move/from16 v4, v24

    .line 484
    .line 485
    move-object v5, v12

    .line 486
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 487
    .line 488
    .line 489
    move v1, v13

    .line 490
    move v3, v13

    .line 491
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 492
    .line 493
    .line 494
    const/high16 v14, 0x41e00000    # 28.0f

    .line 495
    .line 496
    sub-float v1, v23, v14

    .line 497
    .line 498
    add-float v24, v16, v24

    .line 499
    .line 500
    const/high16 v0, 0x3f000000    # 0.5f

    .line 501
    .line 502
    mul-float v18, v24, v0

    .line 503
    .line 504
    move-object/from16 v0, p1

    .line 505
    .line 506
    move/from16 v2, v18

    .line 507
    .line 508
    move/from16 v3, v23

    .line 509
    .line 510
    move/from16 v4, v18

    .line 511
    .line 512
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 513
    .line 514
    .line 515
    add-float v3, v13, v14

    .line 516
    .line 517
    move v1, v13

    .line 518
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 519
    .line 520
    .line 521
    const/4 v14, 0x0

    .line 522
    :goto_2
    const v17, 0x3ec28f5c    # 0.38f

    .line 523
    .line 524
    .line 525
    if-ge v14, v15, :cond_3

    .line 526
    .line 527
    int-to-float v0, v14

    .line 528
    mul-float v0, v0, v19

    .line 529
    .line 530
    add-float v18, v0, v16

    .line 531
    .line 532
    move-object/from16 v0, p1

    .line 533
    .line 534
    move/from16 v1, v23

    .line 535
    .line 536
    move/from16 v2, v18

    .line 537
    .line 538
    move v3, v13

    .line 539
    move/from16 v4, v18

    .line 540
    .line 541
    move-object v5, v12

    .line 542
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 543
    .line 544
    .line 545
    mul-float v2, v7, v17

    .line 546
    .line 547
    const v0, 0x3f1eb852    # 0.62f

    .line 548
    .line 549
    .line 550
    mul-float v4, v7, v0

    .line 551
    .line 552
    move-object/from16 v0, p0

    .line 553
    .line 554
    move-object/from16 v1, p1

    .line 555
    .line 556
    move/from16 v3, v18

    .line 557
    .line 558
    move/from16 v5, v18

    .line 559
    .line 560
    invoke-virtual/range {v0 .. v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->c(Landroid/graphics/Canvas;FFFF)V

    .line 561
    .line 562
    .line 563
    new-instance v0, Ljava/lang/StringBuilder;

    .line 564
    .line 565
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 566
    .line 567
    .line 568
    add-int/lit8 v14, v14, 0x1

    .line 569
    .line 570
    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 571
    .line 572
    .line 573
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 574
    .line 575
    .line 576
    move-result-object v0

    .line 577
    mul-float v1, v7, v22

    .line 578
    .line 579
    add-float v2, v18, v8

    .line 580
    .line 581
    invoke-virtual {v10, v11, v0, v1, v2}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b(Landroid/graphics/Canvas;Ljava/lang/String;FF)V

    .line 582
    .line 583
    .line 584
    goto :goto_2

    .line 585
    :cond_3
    mul-float v7, v7, v17

    .line 586
    .line 587
    const v0, 0x3f70a3d7    # 0.94f

    .line 588
    .line 589
    .line 590
    mul-float/2addr v9, v0

    .line 591
    const-string v0, "PARALLEL"

    .line 592
    .line 593
    invoke-virtual {v10, v11, v0, v7, v9}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->b(Landroid/graphics/Canvas;Ljava/lang/String;FF)V

    .line 594
    .line 595
    .line 596
    goto/16 :goto_0

    .line 597
    .line 598
    :cond_4
    const/4 v1, 0x7

    .line 599
    const/high16 v15, 0x41200000    # 10.0f

    .line 600
    .line 601
    if-ne v0, v1, :cond_5

    .line 602
    .line 603
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 604
    .line 605
    .line 606
    move-result v0

    .line 607
    int-to-float v13, v0

    .line 608
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 609
    .line 610
    .line 611
    move-result v0

    .line 612
    int-to-float v14, v0

    .line 613
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 614
    .line 615
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 616
    .line 617
    .line 618
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 619
    .line 620
    .line 621
    new-instance v1, Landroid/graphics/RectF;

    .line 622
    .line 623
    sub-float v2, v13, v8

    .line 624
    .line 625
    sub-float v3, v14, v8

    .line 626
    .line 627
    invoke-direct {v1, v8, v8, v2, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 628
    .line 629
    .line 630
    const/high16 v2, 0x41900000    # 18.0f

    .line 631
    .line 632
    invoke-virtual {v11, v1, v2, v2, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 633
    .line 634
    .line 635
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 636
    .line 637
    invoke-virtual {v12, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 638
    .line 639
    .line 640
    const/high16 v1, 0x40200000    # 2.5f

    .line 641
    .line 642
    invoke-virtual {v12, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 643
    .line 644
    .line 645
    const v1, -0xe2b128

    .line 646
    .line 647
    .line 648
    invoke-virtual {v12, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 649
    .line 650
    .line 651
    new-instance v1, Landroid/graphics/RectF;

    .line 652
    .line 653
    sub-float v3, v13, v15

    .line 654
    .line 655
    sub-float v4, v14, v15

    .line 656
    .line 657
    invoke-direct {v1, v15, v15, v3, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 658
    .line 659
    .line 660
    invoke-virtual {v11, v1, v2, v2, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 661
    .line 662
    .line 663
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 664
    .line 665
    .line 666
    sget-object v0, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    .line 667
    .line 668
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 669
    .line 670
    .line 671
    const/4 v0, 0x1

    .line 672
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 673
    .line 674
    .line 675
    const v0, -0x9f5a06

    .line 676
    .line 677
    .line 678
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 679
    .line 680
    .line 681
    const v0, 0x3de147ae    # 0.11f

    .line 682
    .line 683
    .line 684
    mul-float/2addr v0, v14

    .line 685
    const/high16 v1, 0x41a00000    # 20.0f

    .line 686
    .line 687
    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    .line 688
    .line 689
    .line 690
    move-result v0

    .line 691
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 692
    .line 693
    .line 694
    const/high16 v0, 0x3f000000    # 0.5f

    .line 695
    .line 696
    mul-float v15, v13, v0

    .line 697
    .line 698
    const v0, 0x3e19999a    # 0.15f

    .line 699
    .line 700
    .line 701
    mul-float/2addr v0, v14

    .line 702
    const-string v1, "CAPACITOR TYPES"

    .line 703
    .line 704
    invoke-virtual {v11, v1, v15, v0, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 705
    .line 706
    .line 707
    const v0, 0x3e6b851f    # 0.23f

    .line 708
    .line 709
    .line 710
    mul-float v16, v14, v0

    .line 711
    .line 712
    mul-float v18, v14, v24

    .line 713
    .line 714
    const/high16 v0, 0x42500000    # 52.0f

    .line 715
    .line 716
    sub-float v0, v13, v0

    .line 717
    .line 718
    div-float v19, v0, v5

    .line 719
    .line 720
    const/high16 v2, 0x41900000    # 18.0f

    .line 721
    .line 722
    const/high16 v0, 0x41900000    # 18.0f

    .line 723
    .line 724
    add-float v4, v19, v0

    .line 725
    .line 726
    const-string v6, "CERAMIC"

    .line 727
    .line 728
    const-string v7, "104"

    .line 729
    .line 730
    const-string v8, "100nF"

    .line 731
    .line 732
    const/4 v9, 0x0

    .line 733
    move-object/from16 v0, p0

    .line 734
    .line 735
    move-object/from16 v1, p1

    .line 736
    .line 737
    move/from16 v3, v16

    .line 738
    .line 739
    move/from16 v5, v18

    .line 740
    .line 741
    invoke-virtual/range {v0 .. v9}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->a(Landroid/graphics/Canvas;FFFFLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 742
    .line 743
    .line 744
    const/high16 v0, 0x41d00000    # 26.0f

    .line 745
    .line 746
    add-float v2, v19, v0

    .line 747
    .line 748
    const/high16 v1, 0x40000000    # 2.0f

    .line 749
    .line 750
    mul-float v19, v19, v1

    .line 751
    .line 752
    add-float v4, v19, v0

    .line 753
    .line 754
    const-string v6, "E-CAP"

    .line 755
    .line 756
    const-string v7, "10uF"

    .line 757
    .line 758
    const-string v8, "Polar"

    .line 759
    .line 760
    const/4 v9, 0x1

    .line 761
    move-object/from16 v0, p0

    .line 762
    .line 763
    move-object/from16 v1, p1

    .line 764
    .line 765
    invoke-virtual/range {v0 .. v9}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->a(Landroid/graphics/Canvas;FFFFLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 766
    .line 767
    .line 768
    const/high16 v0, 0x42080000    # 34.0f

    .line 769
    .line 770
    add-float v2, v19, v0

    .line 771
    .line 772
    const/high16 v0, 0x41900000    # 18.0f

    .line 773
    .line 774
    sub-float v4, v13, v0

    .line 775
    .line 776
    const-string v6, "MLCC"

    .line 777
    .line 778
    const-string v7, "SMD"

    .line 779
    .line 780
    const-string v8, "No mark"

    .line 781
    .line 782
    const/4 v9, 0x2

    .line 783
    move-object/from16 v0, p0

    .line 784
    .line 785
    invoke-virtual/range {v0 .. v9}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->a(Landroid/graphics/Canvas;FFFFLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 786
    .line 787
    .line 788
    const/4 v8, 0x0

    .line 789
    invoke-virtual {v12, v8}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 790
    .line 791
    .line 792
    const v0, -0x6b5c48

    .line 793
    .line 794
    .line 795
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 796
    .line 797
    .line 798
    const v0, 0x3d75c28f    # 0.06f

    .line 799
    .line 800
    .line 801
    mul-float v13, v14, v0

    .line 802
    .line 803
    const/high16 v0, 0x41400000    # 12.0f

    .line 804
    .line 805
    invoke-static {v0, v13}, Ljava/lang/Math;->max(FF)F

    .line 806
    .line 807
    .line 808
    move-result v0

    .line 809
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 810
    .line 811
    .line 812
    const v0, 0x3f68f5c3    # 0.91f

    .line 813
    .line 814
    .line 815
    mul-float/2addr v14, v0

    .line 816
    const-string v0, "Enter code or value below"

    .line 817
    .line 818
    invoke-virtual {v11, v0, v15, v14, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 819
    .line 820
    .line 821
    sget-object v0, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    .line 822
    .line 823
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 824
    .line 825
    .line 826
    goto/16 :goto_0

    .line 827
    .line 828
    :cond_5
    const/4 v8, 0x0

    .line 829
    const/4 v1, 0x2

    .line 830
    if-ne v0, v1, :cond_6

    .line 831
    .line 832
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 833
    .line 834
    .line 835
    move-result v0

    .line 836
    int-to-float v6, v0

    .line 837
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 838
    .line 839
    .line 840
    move-result v0

    .line 841
    int-to-float v8, v0

    .line 842
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 843
    .line 844
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 845
    .line 846
    .line 847
    const/4 v0, -0x1

    .line 848
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 849
    .line 850
    .line 851
    invoke-virtual {v12, v14}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 852
    .line 853
    .line 854
    const v0, 0x3ef5c28f    # 0.48f

    .line 855
    .line 856
    .line 857
    mul-float v9, v6, v0

    .line 858
    .line 859
    const/high16 v2, 0x41900000    # 18.0f

    .line 860
    .line 861
    const/high16 v4, 0x41e00000    # 28.0f

    .line 862
    .line 863
    move-object/from16 v0, p1

    .line 864
    .line 865
    move v1, v9

    .line 866
    move v3, v9

    .line 867
    move-object v5, v12

    .line 868
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 869
    .line 870
    .line 871
    const/high16 v3, 0x41e00000    # 28.0f

    .line 872
    .line 873
    const v0, 0x3edc28f6    # 0.43f

    .line 874
    .line 875
    .line 876
    mul-float v5, v8, v0

    .line 877
    .line 878
    move-object/from16 v0, p0

    .line 879
    .line 880
    move-object/from16 v1, p1

    .line 881
    .line 882
    move v2, v9

    .line 883
    move v4, v9

    .line 884
    invoke-virtual/range {v0 .. v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->d(Landroid/graphics/Canvas;FFFF)V

    .line 885
    .line 886
    .line 887
    const/high16 v0, 0x3f000000    # 0.5f

    .line 888
    .line 889
    mul-float v13, v8, v0

    .line 890
    .line 891
    const/high16 v0, 0x40a00000    # 5.0f

    .line 892
    .line 893
    invoke-virtual {v11, v9, v13, v0, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 894
    .line 895
    .line 896
    const v0, 0x3f0f5c29    # 0.56f

    .line 897
    .line 898
    .line 899
    mul-float v3, v8, v0

    .line 900
    .line 901
    const/high16 v0, 0x42080000    # 34.0f

    .line 902
    .line 903
    sub-float v5, v8, v0

    .line 904
    .line 905
    move-object/from16 v0, p0

    .line 906
    .line 907
    invoke-virtual/range {v0 .. v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->d(Landroid/graphics/Canvas;FFFF)V

    .line 908
    .line 909
    .line 910
    const/high16 v0, 0x41f00000    # 30.0f

    .line 911
    .line 912
    sub-float v1, v9, v0

    .line 913
    .line 914
    const/high16 v5, 0x41c00000    # 24.0f

    .line 915
    .line 916
    sub-float v4, v8, v5

    .line 917
    .line 918
    add-float v3, v9, v0

    .line 919
    .line 920
    move-object/from16 v0, p1

    .line 921
    .line 922
    move v2, v4

    .line 923
    move v7, v5

    .line 924
    move-object v5, v12

    .line 925
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 926
    .line 927
    .line 928
    const/high16 v0, 0x41a00000    # 20.0f

    .line 929
    .line 930
    sub-float v1, v9, v0

    .line 931
    .line 932
    const/high16 v2, 0x41600000    # 14.0f

    .line 933
    .line 934
    sub-float v4, v8, v2

    .line 935
    .line 936
    add-float v3, v9, v0

    .line 937
    .line 938
    move-object/from16 v0, p1

    .line 939
    .line 940
    move v2, v4

    .line 941
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 942
    .line 943
    .line 944
    sub-float v1, v9, v15

    .line 945
    .line 946
    sub-float v4, v8, v14

    .line 947
    .line 948
    add-float v3, v9, v15

    .line 949
    .line 950
    move v2, v4

    .line 951
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 952
    .line 953
    .line 954
    mul-float v14, v6, v24

    .line 955
    .line 956
    move v1, v9

    .line 957
    move v2, v13

    .line 958
    move v3, v14

    .line 959
    move v4, v13

    .line 960
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 961
    .line 962
    .line 963
    const v0, 0x3ec7ae14    # 0.39f

    .line 964
    .line 965
    .line 966
    mul-float v9, v8, v0

    .line 967
    .line 968
    move-object/from16 v0, p1

    .line 969
    .line 970
    move v1, v14

    .line 971
    move v4, v9

    .line 972
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 973
    .line 974
    .line 975
    const v0, 0x3f547ae1    # 0.83f

    .line 976
    .line 977
    .line 978
    mul-float v3, v6, v0

    .line 979
    .line 980
    const v0, 0x3ee147ae    # 0.44f

    .line 981
    .line 982
    .line 983
    mul-float v4, v8, v0

    .line 984
    .line 985
    move-object/from16 v0, p1

    .line 986
    .line 987
    move v2, v9

    .line 988
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 989
    .line 990
    .line 991
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 992
    .line 993
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 994
    .line 995
    .line 996
    invoke-virtual {v12, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 997
    .line 998
    .line 999
    const v0, 0x3dcccccd    # 0.1f

    .line 1000
    .line 1001
    .line 1002
    mul-float/2addr v0, v6

    .line 1003
    const/high16 v1, 0x42000000    # 32.0f

    .line 1004
    .line 1005
    const-string v2, "Vin"

    .line 1006
    .line 1007
    invoke-virtual {v11, v2, v0, v1, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1008
    .line 1009
    .line 1010
    const v0, 0x3e4ccccd    # 0.2f

    .line 1011
    .line 1012
    .line 1013
    mul-float v7, v6, v0

    .line 1014
    .line 1015
    const v0, 0x3ea8f5c3    # 0.33f

    .line 1016
    .line 1017
    .line 1018
    mul-float/2addr v0, v8

    .line 1019
    const-string v1, "R1"

    .line 1020
    .line 1021
    invoke-virtual {v11, v1, v7, v0, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1022
    .line 1023
    .line 1024
    const v0, 0x3f4ccccd    # 0.8f

    .line 1025
    .line 1026
    .line 1027
    mul-float/2addr v6, v0

    .line 1028
    const v0, 0x3ee66666    # 0.45f

    .line 1029
    .line 1030
    .line 1031
    mul-float/2addr v0, v8

    .line 1032
    const-string v1, "Vout"

    .line 1033
    .line 1034
    invoke-virtual {v11, v1, v6, v0, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1035
    .line 1036
    .line 1037
    const/high16 v0, 0x3f400000    # 0.75f

    .line 1038
    .line 1039
    mul-float/2addr v8, v0

    .line 1040
    const-string v0, "R2"

    .line 1041
    .line 1042
    invoke-virtual {v11, v0, v7, v8, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1043
    .line 1044
    .line 1045
    goto/16 :goto_0

    .line 1046
    .line 1047
    :cond_6
    const/4 v1, 0x3

    .line 1048
    if-ne v0, v1, :cond_7

    .line 1049
    .line 1050
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 1051
    .line 1052
    .line 1053
    move-result v0

    .line 1054
    int-to-float v7, v0

    .line 1055
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 1056
    .line 1057
    .line 1058
    move-result v0

    .line 1059
    int-to-float v8, v0

    .line 1060
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 1061
    .line 1062
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1063
    .line 1064
    .line 1065
    const/4 v0, -0x1

    .line 1066
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 1067
    .line 1068
    .line 1069
    invoke-virtual {v12, v14}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1070
    .line 1071
    .line 1072
    mul-float/2addr v9, v7

    .line 1073
    const v0, 0x3f3851ec    # 0.72f

    .line 1074
    .line 1075
    .line 1076
    mul-float v14, v7, v0

    .line 1077
    .line 1078
    mul-float v16, v8, v22

    .line 1079
    .line 1080
    mul-float v17, v8, v0

    .line 1081
    .line 1082
    move-object/from16 v0, p1

    .line 1083
    .line 1084
    move v1, v9

    .line 1085
    move/from16 v2, v16

    .line 1086
    .line 1087
    move v3, v14

    .line 1088
    move/from16 v4, v16

    .line 1089
    .line 1090
    move-object v5, v12

    .line 1091
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1092
    .line 1093
    .line 1094
    move-object/from16 v0, p0

    .line 1095
    .line 1096
    move-object/from16 v1, p1

    .line 1097
    .line 1098
    move v2, v14

    .line 1099
    move/from16 v3, v16

    .line 1100
    .line 1101
    move v4, v14

    .line 1102
    move/from16 v5, v17

    .line 1103
    .line 1104
    invoke-virtual/range {v0 .. v5}, Lapp/gkc/terminal/Activity/ComponentPreviewView;->d(Landroid/graphics/Canvas;FFFF)V

    .line 1105
    .line 1106
    .line 1107
    move-object/from16 v0, p1

    .line 1108
    .line 1109
    move v1, v14

    .line 1110
    move/from16 v2, v17

    .line 1111
    .line 1112
    move v3, v9

    .line 1113
    move/from16 v4, v17

    .line 1114
    .line 1115
    move-object v5, v12

    .line 1116
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1117
    .line 1118
    .line 1119
    move v1, v9

    .line 1120
    move/from16 v4, v16

    .line 1121
    .line 1122
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1123
    .line 1124
    .line 1125
    const/high16 v0, 0x41900000    # 18.0f

    .line 1126
    .line 1127
    sub-float v1, v9, v0

    .line 1128
    .line 1129
    const v2, 0x3ee147ae    # 0.44f

    .line 1130
    .line 1131
    .line 1132
    mul-float v4, v8, v2

    .line 1133
    .line 1134
    add-float v3, v9, v0

    .line 1135
    .line 1136
    move-object/from16 v0, p1

    .line 1137
    .line 1138
    move v2, v4

    .line 1139
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1140
    .line 1141
    .line 1142
    sub-float v1, v9, v15

    .line 1143
    .line 1144
    const v0, 0x3f051eb8    # 0.52f

    .line 1145
    .line 1146
    .line 1147
    mul-float v14, v8, v0

    .line 1148
    .line 1149
    add-float v3, v9, v15

    .line 1150
    .line 1151
    move-object/from16 v0, p1

    .line 1152
    .line 1153
    move v2, v14

    .line 1154
    move v4, v14

    .line 1155
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1156
    .line 1157
    .line 1158
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 1159
    .line 1160
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1161
    .line 1162
    .line 1163
    const/high16 v0, 0x41c00000    # 24.0f

    .line 1164
    .line 1165
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1166
    .line 1167
    .line 1168
    mul-float/2addr v13, v7

    .line 1169
    const-string v0, "V"

    .line 1170
    .line 1171
    invoke-virtual {v11, v0, v13, v14, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1172
    .line 1173
    .line 1174
    const v0, 0x3ef0a3d7    # 0.47f

    .line 1175
    .line 1176
    .line 1177
    mul-float/2addr v0, v7

    .line 1178
    mul-float v8, v8, v23

    .line 1179
    .line 1180
    const-string v1, "I"

    .line 1181
    .line 1182
    invoke-virtual {v11, v1, v0, v8, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1183
    .line 1184
    .line 1185
    const v0, 0x3f4ccccd    # 0.8f

    .line 1186
    .line 1187
    .line 1188
    mul-float/2addr v7, v0

    .line 1189
    invoke-virtual {v11, v6, v7, v14, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1190
    .line 1191
    .line 1192
    goto/16 :goto_0

    .line 1193
    .line 1194
    :cond_7
    const/4 v1, 0x1

    .line 1195
    if-ne v0, v1, :cond_8

    .line 1196
    .line 1197
    move v6, v1

    .line 1198
    goto :goto_3

    .line 1199
    :cond_8
    move v6, v8

    .line 1200
    :goto_3
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 1201
    .line 1202
    .line 1203
    move-result v0

    .line 1204
    int-to-float v7, v0

    .line 1205
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 1206
    .line 1207
    .line 1208
    move-result v0

    .line 1209
    int-to-float v4, v0

    .line 1210
    const/high16 v0, 0x3f000000    # 0.5f

    .line 1211
    .line 1212
    mul-float v16, v4, v0

    .line 1213
    .line 1214
    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 1215
    .line 1216
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1217
    .line 1218
    .line 1219
    const v0, -0x473d2f

    .line 1220
    .line 1221
    .line 1222
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 1223
    .line 1224
    .line 1225
    const v0, 0x3d8f5c29    # 0.07f

    .line 1226
    .line 1227
    .line 1228
    mul-float/2addr v0, v4

    .line 1229
    invoke-static {v15, v0}, Ljava/lang/Math;->max(FF)F

    .line 1230
    .line 1231
    .line 1232
    move-result v0

    .line 1233
    invoke-virtual {v12, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1234
    .line 1235
    .line 1236
    const/high16 v1, 0x41800000    # 16.0f

    .line 1237
    .line 1238
    mul-float v15, v7, v22

    .line 1239
    .line 1240
    move-object/from16 v0, p1

    .line 1241
    .line 1242
    move/from16 v2, v16

    .line 1243
    .line 1244
    move-object v8, v3

    .line 1245
    move v3, v15

    .line 1246
    move v15, v4

    .line 1247
    move/from16 v4, v16

    .line 1248
    .line 1249
    move v14, v5

    .line 1250
    move-object v5, v12

    .line 1251
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1252
    .line 1253
    .line 1254
    const/high16 v0, 0x3f400000    # 0.75f

    .line 1255
    .line 1256
    mul-float v1, v7, v0

    .line 1257
    .line 1258
    const/high16 v0, 0x41800000    # 16.0f

    .line 1259
    .line 1260
    sub-float v3, v7, v0

    .line 1261
    .line 1262
    move-object/from16 v0, p1

    .line 1263
    .line 1264
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1265
    .line 1266
    .line 1267
    const v0, 0x3e6147ae    # 0.22f

    .line 1268
    .line 1269
    .line 1270
    mul-float v1, v7, v0

    .line 1271
    .line 1272
    mul-float v2, v7, v24

    .line 1273
    .line 1274
    mul-float v4, v15, v0

    .line 1275
    .line 1276
    mul-float v0, v15, v24

    .line 1277
    .line 1278
    new-instance v3, Landroid/graphics/RectF;

    .line 1279
    .line 1280
    add-float v5, v1, v14

    .line 1281
    .line 1282
    const/high16 v16, 0x40a00000    # 5.0f

    .line 1283
    .line 1284
    add-float v13, v4, v16

    .line 1285
    .line 1286
    add-float v9, v2, v14

    .line 1287
    .line 1288
    add-float v14, v0, v16

    .line 1289
    .line 1290
    invoke-direct {v3, v5, v13, v9, v14}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1291
    .line 1292
    .line 1293
    new-instance v5, Landroid/graphics/RectF;

    .line 1294
    .line 1295
    invoke-direct {v5, v1, v4, v2, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1296
    .line 1297
    .line 1298
    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 1299
    .line 1300
    invoke-virtual {v12, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1301
    .line 1302
    .line 1303
    const/high16 v13, 0x66000000

    .line 1304
    .line 1305
    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 1306
    .line 1307
    .line 1308
    const v14, 0x3e8f5c29    # 0.28f

    .line 1309
    .line 1310
    .line 1311
    mul-float/2addr v14, v15

    .line 1312
    invoke-virtual {v11, v3, v14, v14, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1313
    .line 1314
    .line 1315
    if-eqz v6, :cond_9

    .line 1316
    .line 1317
    const v3, -0x982e74

    .line 1318
    .line 1319
    .line 1320
    goto :goto_4

    .line 1321
    :cond_9
    const v3, -0x182852

    .line 1322
    .line 1323
    .line 1324
    :goto_4
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 1325
    .line 1326
    .line 1327
    invoke-virtual {v11, v5, v14, v14, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1328
    .line 1329
    .line 1330
    if-eqz v6, :cond_a

    .line 1331
    .line 1332
    const v3, -0xca57a1

    .line 1333
    .line 1334
    .line 1335
    goto :goto_5

    .line 1336
    :cond_a
    const v3, -0x2b4688

    .line 1337
    .line 1338
    .line 1339
    :goto_5
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 1340
    .line 1341
    .line 1342
    new-instance v3, Landroid/graphics/RectF;

    .line 1343
    .line 1344
    const/high16 v6, 0x40000000    # 2.0f

    .line 1345
    .line 1346
    sub-float v13, v1, v6

    .line 1347
    .line 1348
    const v20, 0x3eb33333    # 0.35f

    .line 1349
    .line 1350
    .line 1351
    mul-float v20, v20, v15

    .line 1352
    .line 1353
    add-float v6, v1, v20

    .line 1354
    .line 1355
    invoke-direct {v3, v13, v4, v6, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1356
    .line 1357
    .line 1358
    invoke-virtual {v11, v3, v12}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 1359
    .line 1360
    .line 1361
    new-instance v3, Landroid/graphics/RectF;

    .line 1362
    .line 1363
    sub-float v6, v2, v20

    .line 1364
    .line 1365
    const/high16 v13, 0x40000000    # 2.0f

    .line 1366
    .line 1367
    add-float v10, v2, v13

    .line 1368
    .line 1369
    invoke-direct {v3, v6, v4, v10, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1370
    .line 1371
    .line 1372
    invoke-virtual {v11, v3, v12}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 1373
    .line 1374
    .line 1375
    const v3, 0x55ffffff    # 3.518437E13f

    .line 1376
    .line 1377
    .line 1378
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 1379
    .line 1380
    .line 1381
    new-instance v3, Landroid/graphics/RectF;

    .line 1382
    .line 1383
    const v6, 0x3d75c28f    # 0.06f

    .line 1384
    .line 1385
    .line 1386
    mul-float/2addr v7, v6

    .line 1387
    add-float v6, v1, v7

    .line 1388
    .line 1389
    const v10, 0x3da3d70a    # 0.08f

    .line 1390
    .line 1391
    .line 1392
    mul-float/2addr v10, v15

    .line 1393
    add-float/2addr v10, v4

    .line 1394
    sub-float v7, v2, v7

    .line 1395
    .line 1396
    mul-float v13, v15, v23

    .line 1397
    .line 1398
    add-float/2addr v13, v4

    .line 1399
    invoke-direct {v3, v6, v10, v7, v13}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1400
    .line 1401
    .line 1402
    const v6, 0x3d4ccccd    # 0.05f

    .line 1403
    .line 1404
    .line 1405
    mul-float/2addr v6, v15

    .line 1406
    invoke-virtual {v11, v3, v6, v6, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1407
    .line 1408
    .line 1409
    invoke-virtual {v12, v8}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1410
    .line 1411
    .line 1412
    const v3, -0xf0e8d6

    .line 1413
    .line 1414
    .line 1415
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 1416
    .line 1417
    .line 1418
    const/high16 v3, 0x40400000    # 3.0f

    .line 1419
    .line 1420
    invoke-virtual {v12, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1421
    .line 1422
    .line 1423
    invoke-virtual {v11, v5, v14, v14, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1424
    .line 1425
    .line 1426
    invoke-virtual {v12, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1427
    .line 1428
    .line 1429
    sub-float/2addr v2, v1

    .line 1430
    const v3, 0x3d99999a    # 0.075f

    .line 1431
    .line 1432
    .line 1433
    mul-float/2addr v3, v2

    .line 1434
    const/high16 v5, 0x41800000    # 16.0f

    .line 1435
    .line 1436
    invoke-static {v5, v3}, Ljava/lang/Math;->max(FF)F

    .line 1437
    .line 1438
    .line 1439
    move-result v3

    .line 1440
    const v5, 0x3e6b851f    # 0.23f

    .line 1441
    .line 1442
    .line 1443
    mul-float/2addr v5, v2

    .line 1444
    add-float/2addr v5, v1

    .line 1445
    const v1, 0x3e0f5c29    # 0.14f

    .line 1446
    .line 1447
    .line 1448
    mul-float/2addr v2, v1

    .line 1449
    new-instance v1, Landroid/graphics/RectF;

    .line 1450
    .line 1451
    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    .line 1452
    .line 1453
    .line 1454
    const/4 v15, 0x0

    .line 1455
    move-object/from16 v6, p0

    .line 1456
    .line 1457
    :goto_6
    iget-object v7, v6, Lapp/gkc/terminal/Activity/ComponentPreviewView;->d:[I

    .line 1458
    .line 1459
    array-length v8, v7

    .line 1460
    if-ge v15, v8, :cond_b

    .line 1461
    .line 1462
    aget v7, v7, v15

    .line 1463
    .line 1464
    invoke-virtual {v12, v7}, Landroid/graphics/Paint;->setColor(I)V

    .line 1465
    .line 1466
    .line 1467
    int-to-float v7, v15

    .line 1468
    mul-float/2addr v7, v2

    .line 1469
    add-float/2addr v7, v5

    .line 1470
    const/high16 v8, 0x40000000    # 2.0f

    .line 1471
    .line 1472
    add-float v9, v4, v8

    .line 1473
    .line 1474
    add-float v10, v7, v3

    .line 1475
    .line 1476
    sub-float v13, v0, v8

    .line 1477
    .line 1478
    invoke-virtual {v1, v7, v9, v10, v13}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1479
    .line 1480
    .line 1481
    const/high16 v7, 0x40800000    # 4.0f

    .line 1482
    .line 1483
    invoke-virtual {v11, v1, v7, v7, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1484
    .line 1485
    .line 1486
    const/high16 v9, 0x66000000

    .line 1487
    .line 1488
    invoke-virtual {v12, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 1489
    .line 1490
    .line 1491
    sget-object v10, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 1492
    .line 1493
    invoke-virtual {v12, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1494
    .line 1495
    .line 1496
    const/high16 v10, 0x3fc00000    # 1.5f

    .line 1497
    .line 1498
    invoke-virtual {v12, v10}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1499
    .line 1500
    .line 1501
    invoke-virtual {v11, v1, v7, v7, v12}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1502
    .line 1503
    .line 1504
    sget-object v10, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 1505
    .line 1506
    invoke-virtual {v12, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1507
    .line 1508
    .line 1509
    add-int/lit8 v15, v15, 0x1

    .line 1510
    .line 1511
    goto :goto_6

    .line 1512
    :cond_b
    :goto_7
    return-void
.end method

.method public varargs setBands([I)V
    .locals 0

    iput-object p1, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->d:[I

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public setType(I)V
    .locals 0

    iput p1, p0, Lapp/gkc/terminal/Activity/ComponentPreviewView;->c:I

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method
