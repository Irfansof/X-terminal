.class public Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final synthetic O:I


# instance fields
.field public final B:Lg1/n;

.field public final C:[Lz0/q;

.field public final D:[Ljava/lang/String;

.field public E:Landroid/widget/TextView;

.field public F:Landroid/widget/TextView;

.field public G:Landroid/widget/TextView;

.field public H:Landroid/widget/TextView;

.field public I:Landroid/hardware/usb/UsbManager;

.field public J:Lz0/q;

.field public K:Ljava/lang/String;

.field public L:[B

.field public M:Z

.field public final N:Le/d0;


# direct methods
.method public constructor <init>()V
    .locals 17

    move-object/from16 v0, p0

    invoke-direct/range {p0 .. p0}, Le/m;-><init>()V

    new-instance v1, Lg1/n;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Lg1/n;-><init>(I)V

    iput-object v1, v0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->B:Lg1/n;

    new-instance v3, Lz0/q;

    const-string v1, "ST5461D13 (CSOT 4K)"

    const/4 v4, 0x4

    invoke-direct {v3, v2, v2, v4, v1}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v1, Lz0/q;

    const-string v5, "ST4251D01 (CSOT FHD)"

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v1, v6, v6, v7, v5}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v5, Lz0/q;

    const-string v8, "16Y_GH11 (Samsung 4K)"

    const/16 v9, 0x10

    invoke-direct {v5, v9, v2, v6, v8}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v8, Lz0/q;

    const-string v10, "LC550EQC (LG Display)"

    const/16 v11, 0x1b

    const/4 v12, -0x1

    invoke-direct {v8, v11, v2, v12, v10}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v10, Lz0/q;

    const-string v13, "HV550QUB (BOE UHD)"

    const/4 v14, 0x7

    const/4 v15, 0x3

    invoke-direct {v10, v14, v6, v15, v13}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v13, Lz0/q;

    const-string v11, "PT320AT02 (Panda HD)"

    invoke-direct {v13, v15, v2, v4, v11}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v11, Lz0/q;

    const-string v12, "AUO Universal"

    invoke-direct {v11, v14, v2, v6, v12}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v12, Lz0/q;

    const-string v14, "BOE Universal"

    invoke-direct {v12, v7, v6, v7, v14}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v14, Lz0/q;

    const-string v7, "INNOLUX Universal"

    invoke-direct {v14, v15, v2, v4, v7}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v15, Lz0/q;

    const-string v7, "SHARP (SDP Panel)"

    const/16 v6, 0x9

    invoke-direct {v15, v6, v2, v4, v7}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v7, Lz0/q;

    const-string v4, "SONY (Samsung Type)"

    const/4 v6, 0x1

    invoke-direct {v7, v9, v2, v6, v4}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v9, Lz0/q;

    const-string v4, "SONY (LG Type)"

    move-object/from16 v16, v7

    const/16 v6, 0x1b

    const/4 v7, -0x1

    invoke-direct {v9, v6, v2, v7, v4}, Lz0/q;-><init>(IIILjava/lang/String;)V

    new-instance v7, Lz0/q;

    const-string v4, "SKYWORTH / VIZIO Universal"

    const/4 v2, 0x2

    const/4 v6, 0x1

    invoke-direct {v7, v2, v6, v2, v4}, Lz0/q;-><init>(IIILjava/lang/String;)V

    move-object v4, v1

    move-object v6, v8

    move-object v2, v7

    move-object/from16 v1, v16

    move-object v7, v10

    move-object v8, v13

    move-object/from16 v16, v9

    move-object v9, v11

    move-object v10, v12

    move-object v11, v14

    move-object v12, v15

    move-object v13, v1

    move-object/from16 v14, v16

    move-object v15, v2

    filled-new-array/range {v3 .. v15}, [Lz0/q;

    move-result-object v1

    iput-object v1, v0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->C:[Lz0/q;

    const-string v2, "24C02"

    const-string v3, "24C04"

    const-string v4, "24C08"

    const-string v5, "24C16"

    const-string v6, "24C32"

    const-string v7, "24C64"

    const-string v8, "24C128"

    filled-new-array/range {v2 .. v8}, [Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->D:[Ljava/lang/String;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    iput-object v1, v0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    const-string v1, "24C32"

    iput-object v1, v0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->K:Ljava/lang/String;

    new-instance v1, Le/d0;

    const/4 v2, 0x6

    invoke-direct {v1, v2, v0}, Le/d0;-><init>(ILjava/lang/Object;)V

    iput-object v1, v0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->N:Le/d0;

    return-void
.end method


# virtual methods
.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 3

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/y;->onActivityResult(IILandroid/content/Intent;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, -0x1

    .line 5
    if-ne p2, v0, :cond_5

    .line 6
    .line 7
    if-nez p3, :cond_0

    .line 8
    .line 9
    goto/16 :goto_4

    .line 10
    .line 11
    :cond_0
    const/16 p2, 0x1f

    .line 12
    .line 13
    if-ne p1, p2, :cond_3

    .line 14
    .line 15
    :try_start_0
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->s(Landroid/net/Uri;)[B

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    iput-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    .line 24
    .line 25
    array-length p1, p1

    .line 26
    iget-object p2, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->D:[Ljava/lang/String;

    .line 27
    .line 28
    array-length p3, p2

    .line 29
    const/4 v0, 0x0

    .line 30
    :goto_0
    if-ge v0, p3, :cond_2

    .line 31
    .line 32
    aget-object v1, p2, v0

    .line 33
    .line 34
    invoke-static {v1}, Lg1/n;->a(Ljava/lang/String;)I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-ne v2, p1, :cond_1

    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_1
    add-int/lit8 v0, v0, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_2
    const-string v1, "24C32"

    .line 45
    .line 46
    :goto_1
    iput-object v1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->K:Ljava/lang/String;

    .line 47
    .line 48
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->t()V

    .line 49
    .line 50
    .line 51
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->E:Landroid/widget/TextView;

    .line 52
    .line 53
    new-instance p2, Ljava/lang/StringBuilder;

    .line 54
    .line 55
    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 56
    .line 57
    .line 58
    const-string p3, "BIN loaded: "

    .line 59
    .line 60
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    iget-object p3, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    .line 64
    .line 65
    array-length p3, p3

    .line 66
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    const-string p3, " bytes"

    .line 70
    .line 71
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p2

    .line 78
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 79
    .line 80
    .line 81
    const-string p1, "BIN loaded. Keep the original backup."

    .line 82
    .line 83
    :goto_2
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    goto :goto_4

    .line 87
    :cond_3
    const/16 p2, 0x20

    .line 88
    .line 89
    if-ne p1, p2, :cond_5

    .line 90
    .line 91
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 96
    .line 97
    .line 98
    move-result-object p2

    .line 99
    invoke-virtual {p1, p2}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    .line 100
    .line 101
    .line 102
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 103
    :try_start_1
    iget-object p2, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    .line 104
    .line 105
    invoke-virtual {p1, p2}, Ljava/io/OutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 106
    .line 107
    .line 108
    :try_start_2
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V

    .line 109
    .line 110
    .line 111
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->E:Landroid/widget/TextView;

    .line 112
    .line 113
    const-string p2, "Modified BIN saved"

    .line 114
    .line 115
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 116
    .line 117
    .line 118
    const-string p1, "Modified BIN saved."
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 119
    .line 120
    goto :goto_2

    .line 121
    :catchall_0
    move-exception p2

    .line 122
    if-eqz p1, :cond_4

    .line 123
    .line 124
    :try_start_3
    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 125
    .line 126
    .line 127
    goto :goto_3

    .line 128
    :catchall_1
    move-exception p1

    .line 129
    :try_start_4
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 130
    .line 131
    .line 132
    :cond_4
    :goto_3
    throw p2
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 133
    :catch_0
    const-string p1, "File operation failed"

    .line 134
    .line 135
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    const-string p1, "File operation failed."

    .line 139
    .line 140
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    :cond_5
    :goto_4
    return-void
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public onClick(Landroid/view/View;)V
    .locals 8

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->B:Lg1/n;

    .line 6
    .line 7
    const v1, 0x7f09030b

    .line 8
    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    if-ne p1, v1, :cond_7

    .line 12
    .line 13
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    .line 14
    .line 15
    if-eqz p1, :cond_0

    .line 16
    .line 17
    invoke-virtual {v0}, Lg1/n;->c()V

    .line 18
    .line 19
    .line 20
    iput-boolean v2, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    .line 21
    .line 22
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->y()V

    .line 23
    .line 24
    .line 25
    const-string p1, "CH341A disconnected."

    .line 26
    .line 27
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    goto/16 :goto_6

    .line 31
    .line 32
    :cond_0
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->I:Landroid/hardware/usb/UsbManager;

    .line 33
    .line 34
    if-nez p1, :cond_1

    .line 35
    .line 36
    const-string p1, "USB service not available on this device."

    .line 37
    .line 38
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    const-string p1, "USB service not available"

    .line 42
    .line 43
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    goto/16 :goto_6

    .line 47
    .line 48
    :cond_1
    :try_start_0
    invoke-virtual {p1}, Landroid/hardware/usb/UsbManager;->getDeviceList()Ljava/util/HashMap;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    invoke-virtual {p1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    :cond_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_4

    .line 65
    .line 66
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    check-cast v1, Landroid/hardware/usb/UsbDevice;

    .line 71
    .line 72
    invoke-virtual {v1}, Landroid/hardware/usb/UsbDevice;->getVendorId()I

    .line 73
    .line 74
    .line 75
    move-result v3

    .line 76
    const/16 v4, 0x1a86

    .line 77
    .line 78
    if-ne v3, v4, :cond_2

    .line 79
    .line 80
    invoke-virtual {v1}, Landroid/hardware/usb/UsbDevice;->getProductId()I

    .line 81
    .line 82
    .line 83
    move-result v3

    .line 84
    const/16 v4, 0x5512

    .line 85
    .line 86
    if-ne v3, v4, :cond_2

    .line 87
    .line 88
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->I:Landroid/hardware/usb/UsbManager;

    .line 89
    .line 90
    invoke-virtual {p1, v1}, Landroid/hardware/usb/UsbManager;->hasPermission(Landroid/hardware/usb/UsbDevice;)Z

    .line 91
    .line 92
    .line 93
    move-result p1

    .line 94
    if-eqz p1, :cond_3

    .line 95
    .line 96
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->q(Landroid/hardware/usb/UsbDevice;)V

    .line 97
    .line 98
    .line 99
    goto/16 :goto_6

    .line 100
    .line 101
    :catch_0
    move-exception p1

    .line 102
    goto :goto_0

    .line 103
    :cond_3
    new-instance p1, Landroid/content/Intent;

    .line 104
    .line 105
    const-string v3, "app.gkc.terminal.pro.PANEL_EEPROM_USB_PERMISSION"

    .line 106
    .line 107
    invoke-direct {p1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v3

    .line 114
    invoke-virtual {p1, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 115
    .line 116
    .line 117
    const/16 v3, 0x51

    .line 118
    .line 119
    const/high16 v4, 0x2000000

    .line 120
    .line 121
    invoke-static {p0, v3, p1, v4}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 122
    .line 123
    .line 124
    move-result-object p1

    .line 125
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->I:Landroid/hardware/usb/UsbManager;

    .line 126
    .line 127
    invoke-virtual {v3, v1, p1}, Landroid/hardware/usb/UsbManager;->requestPermission(Landroid/hardware/usb/UsbDevice;Landroid/app/PendingIntent;)V

    .line 128
    .line 129
    .line 130
    const-string p1, "Requesting USB permission..."

    .line 131
    .line 132
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 133
    .line 134
    .line 135
    goto/16 :goto_6

    .line 136
    .line 137
    :cond_4
    const-string p1, "CH341A not found."

    .line 138
    .line 139
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    const-string p1, "Connect CH341A"

    .line 143
    .line 144
    invoke-static {p0, p1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 149
    .line 150
    .line 151
    goto/16 :goto_6

    .line 152
    .line 153
    :goto_0
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object v1

    .line 157
    if-eqz v1, :cond_5

    .line 158
    .line 159
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v3

    .line 163
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    .line 164
    .line 165
    .line 166
    move-result v3

    .line 167
    if-eqz v3, :cond_6

    .line 168
    .line 169
    :cond_5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v1

    .line 177
    :cond_6
    const-string p1, "USB connect failed: "

    .line 178
    .line 179
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    const-string p1, "USB connect failed"

    .line 187
    .line 188
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v0}, Lg1/n;->c()V

    .line 192
    .line 193
    .line 194
    iput-boolean v2, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    .line 195
    .line 196
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->y()V

    .line 197
    .line 198
    .line 199
    goto/16 :goto_6

    .line 200
    .line 201
    :cond_7
    const v1, 0x7f090313

    .line 202
    .line 203
    .line 204
    const/4 v3, 0x1

    .line 205
    if-ne p1, v1, :cond_9

    .line 206
    .line 207
    new-instance p1, Landroid/widget/EditText;

    .line 208
    .line 209
    invoke-direct {p1, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 210
    .line 211
    .line 212
    const-string v0, "Search panel or board"

    .line 213
    .line 214
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 218
    .line 219
    .line 220
    new-instance v0, Landroid/widget/ListView;

    .line 221
    .line 222
    invoke-direct {v0, p0}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V

    .line 223
    .line 224
    .line 225
    new-instance v1, Ljava/util/ArrayList;

    .line 226
    .line 227
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 228
    .line 229
    .line 230
    iget-object v4, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->C:[Lz0/q;

    .line 231
    .line 232
    array-length v5, v4

    .line 233
    move v6, v2

    .line 234
    :goto_1
    if-ge v6, v5, :cond_8

    .line 235
    .line 236
    aget-object v7, v4, v6

    .line 237
    .line 238
    iget-object v7, v7, Lz0/q;->d:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v7, Ljava/lang/String;

    .line 241
    .line 242
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 243
    .line 244
    .line 245
    add-int/lit8 v6, v6, 0x1

    .line 246
    .line 247
    goto :goto_1

    .line 248
    :cond_8
    new-instance v4, Landroid/widget/ArrayAdapter;

    .line 249
    .line 250
    const v5, 0x1090003

    .line 251
    .line 252
    .line 253
    invoke-direct {v4, p0, v5, v1}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    .line 254
    .line 255
    .line 256
    invoke-virtual {v0, v4}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 257
    .line 258
    .line 259
    new-instance v1, Landroid/widget/LinearLayout;

    .line 260
    .line 261
    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 262
    .line 263
    .line 264
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 265
    .line 266
    .line 267
    const/16 v3, 0xc

    .line 268
    .line 269
    const/16 v5, 0x18

    .line 270
    .line 271
    invoke-virtual {v1, v5, v3, v5, v2}, Landroid/view/View;->setPadding(IIII)V

    .line 272
    .line 273
    .line 274
    invoke-virtual {v1, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 275
    .line 276
    .line 277
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 278
    .line 279
    const/4 v5, -0x1

    .line 280
    const/16 v6, 0x2bc

    .line 281
    .line 282
    invoke-direct {v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v1, v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 286
    .line 287
    .line 288
    new-instance v3, Landroid/app/AlertDialog$Builder;

    .line 289
    .line 290
    invoke-direct {v3, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 291
    .line 292
    .line 293
    const-string v5, "Select Panel Profile"

    .line 294
    .line 295
    invoke-virtual {v3, v5}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 296
    .line 297
    .line 298
    move-result-object v3

    .line 299
    invoke-virtual {v3, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 300
    .line 301
    .line 302
    move-result-object v1

    .line 303
    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    .line 304
    .line 305
    .line 306
    move-result-object v1

    .line 307
    new-instance v3, Lg1/j2;

    .line 308
    .line 309
    invoke-direct {v3, p0, v1, v2}, Lg1/j2;-><init>(Le/m;Landroid/app/AlertDialog;I)V

    .line 310
    .line 311
    .line 312
    invoke-virtual {v0, v3}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 313
    .line 314
    .line 315
    new-instance v0, Lg1/l2;

    .line 316
    .line 317
    invoke-direct {v0, v4, v2}, Lg1/l2;-><init>(Landroid/widget/ArrayAdapter;I)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    .line 324
    .line 325
    .line 326
    goto/16 :goto_6

    .line 327
    .line 328
    :cond_9
    const v1, 0x7f09030d

    .line 329
    .line 330
    .line 331
    if-ne p1, v1, :cond_a

    .line 332
    .line 333
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 334
    .line 335
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 336
    .line 337
    .line 338
    const-string v0, "Select EEPROM Size"

    .line 339
    .line 340
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 341
    .line 342
    .line 343
    move-result-object p1

    .line 344
    new-instance v0, Lg1/k2;

    .line 345
    .line 346
    invoke-direct {v0, p0, v2}, Lg1/k2;-><init>(Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;I)V

    .line 347
    .line 348
    .line 349
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->D:[Ljava/lang/String;

    .line 350
    .line 351
    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 352
    .line 353
    .line 354
    move-result-object p1

    .line 355
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 356
    .line 357
    .line 358
    goto/16 :goto_6

    .line 359
    .line 360
    :cond_a
    const v1, 0x7f090310

    .line 361
    .line 362
    .line 363
    const-string v4, "application/octet-stream"

    .line 364
    .line 365
    if-ne p1, v1, :cond_b

    .line 366
    .line 367
    new-instance p1, Landroid/content/Intent;

    .line 368
    .line 369
    const-string v0, "android.intent.action.OPEN_DOCUMENT"

    .line 370
    .line 371
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 372
    .line 373
    .line 374
    invoke-virtual {p1, v4}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 375
    .line 376
    .line 377
    move-result-object p1

    .line 378
    const-string v0, "android.intent.category.OPENABLE"

    .line 379
    .line 380
    invoke-virtual {p1, v0}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 381
    .line 382
    .line 383
    move-result-object p1

    .line 384
    const/16 v0, 0x1f

    .line 385
    .line 386
    invoke-virtual {p0, p1, v0}, Landroidx/activity/q;->startActivityForResult(Landroid/content/Intent;I)V

    .line 387
    .line 388
    .line 389
    goto/16 :goto_6

    .line 390
    .line 391
    :cond_b
    const v1, 0x7f090315

    .line 392
    .line 393
    .line 394
    const-string v5, "Connect CH341A first"

    .line 395
    .line 396
    if-ne p1, v1, :cond_e

    .line 397
    .line 398
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    .line 399
    .line 400
    if-eqz p1, :cond_d

    .line 401
    .line 402
    invoke-virtual {v0}, Lg1/n;->j()Z

    .line 403
    .line 404
    .line 405
    move-result p1

    .line 406
    if-nez p1, :cond_c

    .line 407
    .line 408
    goto :goto_2

    .line 409
    :cond_c
    new-instance p1, Ljava/lang/Thread;

    .line 410
    .line 411
    new-instance v0, Lg1/i2;

    .line 412
    .line 413
    invoke-direct {v0, p0, v2}, Lg1/i2;-><init>(Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;I)V

    .line 414
    .line 415
    .line 416
    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 417
    .line 418
    .line 419
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 420
    .line 421
    .line 422
    goto/16 :goto_6

    .line 423
    .line 424
    :cond_d
    :goto_2
    invoke-virtual {p0, v5}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    .line 425
    .line 426
    .line 427
    goto/16 :goto_6

    .line 428
    .line 429
    :cond_e
    const v1, 0x7f090317

    .line 430
    .line 431
    .line 432
    if-ne p1, v1, :cond_f

    .line 433
    .line 434
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->v()V

    .line 435
    .line 436
    .line 437
    goto/16 :goto_6

    .line 438
    .line 439
    :cond_f
    const v1, 0x7f090312

    .line 440
    .line 441
    .line 442
    if-ne p1, v1, :cond_10

    .line 443
    .line 444
    const-string p1, "MIRROR"

    .line 445
    .line 446
    :goto_3
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->w(Ljava/lang/String;)V

    .line 447
    .line 448
    .line 449
    goto/16 :goto_6

    .line 450
    .line 451
    :cond_10
    const v1, 0x7f090318

    .line 452
    .line 453
    .line 454
    if-ne p1, v1, :cond_11

    .line 455
    .line 456
    const-string p1, "VESA"

    .line 457
    .line 458
    goto :goto_3

    .line 459
    :cond_11
    const v1, 0x7f090316

    .line 460
    .line 461
    .line 462
    if-ne p1, v1, :cond_13

    .line 463
    .line 464
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    .line 465
    .line 466
    if-nez p1, :cond_12

    .line 467
    .line 468
    const-string p1, "Read or load EEPROM first"

    .line 469
    .line 470
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    .line 471
    .line 472
    .line 473
    goto/16 :goto_6

    .line 474
    .line 475
    :cond_12
    new-instance p1, Landroid/content/Intent;

    .line 476
    .line 477
    const-string v0, "android.intent.action.CREATE_DOCUMENT"

    .line 478
    .line 479
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 480
    .line 481
    .line 482
    invoke-virtual {p1, v4}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 483
    .line 484
    .line 485
    move-result-object p1

    .line 486
    const-string v0, "android.intent.extra.TITLE"

    .line 487
    .line 488
    const-string v1, "panel_repaired.bin"

    .line 489
    .line 490
    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 491
    .line 492
    .line 493
    move-result-object p1

    .line 494
    const/16 v0, 0x20

    .line 495
    .line 496
    invoke-virtual {p0, p1, v0}, Landroidx/activity/q;->startActivityForResult(Landroid/content/Intent;I)V

    .line 497
    .line 498
    .line 499
    goto :goto_6

    .line 500
    :cond_13
    const v1, 0x7f090319

    .line 501
    .line 502
    .line 503
    if-ne p1, v1, :cond_18

    .line 504
    .line 505
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    .line 506
    .line 507
    if-eqz p1, :cond_17

    .line 508
    .line 509
    invoke-virtual {v0}, Lg1/n;->j()Z

    .line 510
    .line 511
    .line 512
    move-result p1

    .line 513
    if-nez p1, :cond_14

    .line 514
    .line 515
    goto :goto_5

    .line 516
    :cond_14
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    .line 517
    .line 518
    if-eqz p1, :cond_16

    .line 519
    .line 520
    array-length p1, p1

    .line 521
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->K:Ljava/lang/String;

    .line 522
    .line 523
    invoke-static {v0}, Lg1/n;->a(Ljava/lang/String;)I

    .line 524
    .line 525
    .line 526
    move-result v0

    .line 527
    if-eq p1, v0, :cond_15

    .line 528
    .line 529
    goto :goto_4

    .line 530
    :cond_15
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 531
    .line 532
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 533
    .line 534
    .line 535
    const-string v0, "Write EEPROM?"

    .line 536
    .line 537
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 538
    .line 539
    .line 540
    move-result-object p1

    .line 541
    const-string v0, "Write the modified panel data and verify it by reading back?"

    .line 542
    .line 543
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 544
    .line 545
    .line 546
    move-result-object p1

    .line 547
    const-string v0, "CANCEL"

    .line 548
    .line 549
    const/4 v1, 0x0

    .line 550
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 551
    .line 552
    .line 553
    move-result-object p1

    .line 554
    new-instance v0, Lg1/k2;

    .line 555
    .line 556
    invoke-direct {v0, p0, v3}, Lg1/k2;-><init>(Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;I)V

    .line 557
    .line 558
    .line 559
    const-string v1, "WRITE"

    .line 560
    .line 561
    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 562
    .line 563
    .line 564
    move-result-object p1

    .line 565
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 566
    .line 567
    .line 568
    goto :goto_6

    .line 569
    :cond_16
    :goto_4
    const-string p1, "Load or read the selected EEPROM first"

    .line 570
    .line 571
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    .line 572
    .line 573
    .line 574
    goto :goto_6

    .line 575
    :cond_17
    :goto_5
    invoke-virtual {p0, v5}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    .line 576
    .line 577
    .line 578
    goto :goto_6

    .line 579
    :cond_18
    const v0, 0x7f09030a

    .line 580
    .line 581
    .line 582
    if-ne p1, v0, :cond_19

    .line 583
    .line 584
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->H:Landroid/widget/TextView;

    .line 585
    .line 586
    const-string v0, ""

    .line 587
    .line 588
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 589
    .line 590
    .line 591
    :cond_19
    :goto_6
    return-void
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c002e

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const-string p1, "usb"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/usb/UsbManager;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->I:Landroid/hardware/usb/UsbManager;

    const p1, 0x7f09030f

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->E:Landroid/widget/TextView;

    const p1, 0x7f090314

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->F:Landroid/widget/TextView;

    const p1, 0x7f09030c

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->G:Landroid/widget/TextView;

    const p1, 0x7f090311

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->H:Landroid/widget/TextView;

    const/16 p1, 0xb

    new-array v0, p1, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p1, :cond_0

    aget v2, v0, v1

    invoke-virtual {p0, v2}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance p1, Landroid/content/IntentFilter;

    const-string v0, "app.gkc.terminal.pro.PANEL_EEPROM_USB_PERMISSION"

    invoke-direct {p1, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->N:Le/d0;

    invoke-static {p0, v0, p1}, Le2/m;->e1(Landroid/content/Context;Le/d0;Landroid/content/IntentFilter;)V

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->t()V

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->y()V

    const-string p1, "Panel EEPROM repair ready."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    return-void

    nop

    :array_0
    .array-data 4
        0x7f09030b
        0x7f090313
        0x7f09030d
        0x7f090310
        0x7f090315
        0x7f090317
        0x7f090312
        0x7f090318
        0x7f090316
        0x7f090319
        0x7f09030a
    .end array-data
.end method

.method public final onDestroy()V
    .locals 1

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->B:Lg1/n;

    .line 2
    .line 3
    invoke-virtual {v0}, Lg1/n;->c()V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    .line 8
    .line 9
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->y()V

    .line 10
    .line 11
    .line 12
    :try_start_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->N:Le/d0;

    .line 13
    .line 14
    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    .line 16
    .line 17
    :catch_0
    invoke-super {p0}, Le/m;->onDestroy()V

    .line 18
    .line 19
    .line 20
    return-void
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final p(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->H:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\n"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final q(Landroid/hardware/usb/UsbDevice;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->B:Lg1/n;

    .line 2
    .line 3
    :try_start_0
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->I:Landroid/hardware/usb/UsbManager;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    .line 6
    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    iput-boolean p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    .line 10
    .line 11
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->y()V

    .line 12
    .line 13
    .line 14
    const-string p1, "CH341A connected."

    .line 15
    .line 16
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catch_0
    move-exception p1

    .line 21
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    if-eqz v1, :cond_0

    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    if-eqz v2, :cond_1

    .line 36
    .line 37
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    :cond_1
    const-string p1, "CH341A open failed: "

    .line 46
    .line 47
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const-string p1, "CH341A open failed"

    .line 55
    .line 56
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0}, Lg1/n;->c()V

    .line 60
    .line 61
    .line 62
    const/4 p1, 0x0

    .line 63
    iput-boolean p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    .line 64
    .line 65
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->y()V

    .line 66
    .line 67
    .line 68
    :goto_0
    return-void
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final r(Ljava/lang/String;Ljava/lang/Boolean;)V
    .locals 7

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    if-nez v0, :cond_0

    const-string p1, "Load or read EEPROM first"

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    return-void

    :cond_0
    const-string v0, "MIRROR"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    iget v0, v0, Lz0/q;->b:I

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    iget v0, v0, Lz0/q;->c:I

    :goto_0
    if-ltz v0, :cond_b

    iget-object v1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    iget v1, v1, Lz0/q;->a:I

    iget-object v2, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    array-length v3, v2

    if-lt v1, v3, :cond_2

    goto/16 :goto_4

    :cond_2
    aget-byte v1, v2, v1

    and-int/lit16 v1, v1, 0xff

    const/4 v2, 0x1

    shl-int v0, v2, v0

    and-int v3, v1, v0

    const/4 v4, 0x0

    if-eqz v3, :cond_3

    move v3, v2

    goto :goto_1

    :cond_3
    move v3, v4

    :goto_1
    if-nez p2, :cond_5

    if-nez v3, :cond_4

    goto :goto_2

    :cond_4
    move v2, v4

    goto :goto_2

    :cond_5
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    :goto_2
    const-string p2, "OFF"

    const-string v4, "ON"

    if-ne v3, v2, :cond_7

    if-eqz v2, :cond_6

    move-object p2, v4

    :cond_6
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " bit already "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ". No change made."

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->E:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_7
    if-eqz v2, :cond_8

    or-int/2addr v0, v1

    goto :goto_3

    :cond_8
    not-int v0, v0

    and-int/2addr v0, v1

    :goto_3
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    iget-object v5, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    iget v5, v5, Lz0/q;->a:I

    int-to-byte v0, v0

    aput-byte v0, v3, v5

    invoke-virtual {p0, v5, v1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->u(II)V

    iget-object v3, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    iget v3, v3, Lz0/q;->a:I

    add-int/lit16 v3, v3, 0x80

    iget-object v5, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    array-length v6, v5

    if-ge v3, v6, :cond_9

    aget-byte v6, v5, v3

    and-int/lit16 v6, v6, 0xff

    if-ne v6, v1, :cond_9

    aput-byte v0, v5, v3

    invoke-virtual {p0, v3, v1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->u(II)V

    const-string v0, "Mirrored panel data updated."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    :cond_9
    if-eqz v2, :cond_a

    move-object p2, v4

    :cond_a
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " bit set "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "."

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->E:Landroid/widget/TextView;

    const-string p2, "Modified in memory - save BIN or write EEPROM"

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_b
    :goto_4
    const-string p1, "Profile is not defined for this operation"

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    return-void
.end method

.method public final s(Landroid/net/Uri;)[B
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p1

    :try_start_0
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/16 v1, 0x2000

    :try_start_1
    new-array v1, v1, [B

    :goto_0
    invoke-virtual {p1, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    if-ltz v2, :cond_0

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V

    return-object v1

    :catchall_1
    move-exception v0

    goto :goto_3

    :goto_1
    :try_start_3
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    goto :goto_2

    :catchall_2
    move-exception v0

    :try_start_4
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :goto_3
    if-eqz p1, :cond_1

    :try_start_5
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    goto :goto_4

    :catchall_3
    move-exception p1

    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_1
    :goto_4
    throw v0
.end method

.method public final t()V
    .locals 3

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->F:Landroid/widget/TextView;

    .line 2
    .line 3
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    .line 4
    .line 5
    iget-object v1, v1, Lz0/q;->d:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->G:Landroid/widget/TextView;

    .line 13
    .line 14
    new-instance v1, Ljava/lang/StringBuilder;

    .line 15
    .line 16
    const-string v2, "EEPROM: "

    .line 17
    .line 18
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->K:Ljava/lang/String;

    .line 22
    .line 23
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    const-string v2, " ("

    .line 27
    .line 28
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    iget-object v2, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->K:Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {v2}, Lg1/n;->a(Ljava/lang/String;)I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string v2, " bytes)"

    .line 41
    .line 42
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 50
    .line 51
    .line 52
    return-void
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final u(II)V
    .locals 7

    .line 1
    div-int/lit8 v0, p1, 0x10

    mul-int/lit8 v0, v0, 0x10

    add-int/lit8 v1, v0, 0xf

    iget-object v2, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    array-length v2, v2

    if-lt v1, v2, :cond_0

    return-void

    :cond_0
    const/4 v2, 0x0

    move v3, v0

    move v4, v2

    :goto_0
    const/16 v5, 0xff

    if-ge v3, v1, :cond_2

    if-ne v3, p1, :cond_1

    move v6, p2

    goto :goto_1

    :cond_1
    iget-object v6, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    aget-byte v6, v6, v3

    and-int/2addr v6, v5

    :goto_1
    add-int/2addr v4, v6

    and-int/2addr v4, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    aget-byte p1, p1, v1

    and-int/2addr p1, v5

    if-eq p1, v4, :cond_3

    if-eqz p1, :cond_3

    if-ne p1, v5, :cond_5

    :cond_3
    :goto_2
    iget-object p1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    if-ge v0, v1, :cond_4

    aget-byte p1, p1, v0

    and-int/2addr p1, v5

    add-int/2addr v2, p1

    and-int/2addr v2, v5

    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_4
    int-to-byte p2, v2

    aput-byte p2, p1, v1

    const-string p1, "Panel data check updated."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    :cond_5
    return-void
.end method

.method public final v()V
    .locals 6

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    if-nez v0, :cond_0

    const-string v0, "Load or read EEPROM first"

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->x(Ljava/lang/String;)V

    return-void

    :cond_0
    iget-object v1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    iget v1, v1, Lz0/q;->a:I

    array-length v2, v0

    if-lt v1, v2, :cond_1

    const-string v0, "Selected profile is not compatible with this EEPROM size."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    return-void

    :cond_1
    aget-byte v2, v0, v1

    and-int/lit16 v3, v2, 0xff

    if-eqz v3, :cond_2

    const/16 v4, 0xff

    if-eq v3, v4, :cond_2

    const/16 v3, 0x32

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    :goto_0
    add-int/lit16 v4, v1, 0x80

    array-length v5, v0

    if-ge v4, v5, :cond_3

    add-int/lit16 v1, v1, 0x80

    aget-byte v0, v0, v1

    if-ne v2, v0, :cond_3

    add-int/lit8 v3, v3, 0x28

    :cond_3
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Profile scan complete. Data confidence: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "%."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->p(Ljava/lang/String;)V

    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 7

    .line 1
    const-string v0, "MIRROR"

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    move-object v1, v0

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const-string v1, "VESA"

    .line 12
    .line 13
    :goto_0
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-eqz v2, :cond_1

    .line 18
    .line 19
    const-string v2, "Mirror Options"

    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_1
    const-string v2, "VESA Options"

    .line 23
    .line 24
    :goto_1
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    .line 25
    .line 26
    const/4 v4, 0x1

    .line 27
    if-eqz v3, :cond_5

    .line 28
    .line 29
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_2

    .line 34
    .line 35
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    .line 36
    .line 37
    iget v0, v0, Lz0/q;->b:I

    .line 38
    .line 39
    goto :goto_2

    .line 40
    :cond_2
    iget-object v0, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    .line 41
    .line 42
    iget v0, v0, Lz0/q;->c:I

    .line 43
    .line 44
    :goto_2
    if-ltz v0, :cond_5

    .line 45
    .line 46
    iget-object v3, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->J:Lz0/q;

    .line 47
    .line 48
    iget v3, v3, Lz0/q;->a:I

    .line 49
    .line 50
    iget-object v5, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->L:[B

    .line 51
    .line 52
    array-length v6, v5

    .line 53
    if-ge v3, v6, :cond_5

    .line 54
    .line 55
    aget-byte v3, v5, v3

    .line 56
    .line 57
    and-int/lit16 v3, v3, 0xff

    .line 58
    .line 59
    shl-int v0, v4, v0

    .line 60
    .line 61
    and-int/2addr v0, v3

    .line 62
    if-eqz v0, :cond_3

    .line 63
    .line 64
    move v0, v4

    .line 65
    goto :goto_3

    .line 66
    :cond_3
    const/4 v0, 0x0

    .line 67
    :goto_3
    new-instance v3, Ljava/lang/StringBuilder;

    .line 68
    .line 69
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    const-string v2, " - bit currently "

    .line 76
    .line 77
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    if-eqz v0, :cond_4

    .line 81
    .line 82
    const-string v0, "ON"

    .line 83
    .line 84
    goto :goto_4

    .line 85
    :cond_4
    const-string v0, "OFF"

    .line 86
    .line 87
    :goto_4
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    :cond_5
    const-string v0, "SET "

    .line 95
    .line 96
    const-string v3, " BIT ON"

    .line 97
    .line 98
    invoke-static {v0, v1, v3}, Landroidx/fragment/app/e1;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v3

    .line 102
    const-string v5, " BIT OFF"

    .line 103
    .line 104
    invoke-static {v0, v1, v5}, Landroidx/fragment/app/e1;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    const-string v5, "TOGGLE "

    .line 109
    .line 110
    const-string v6, " BIT"

    .line 111
    .line 112
    invoke-static {v5, v1, v6}, Landroidx/fragment/app/e1;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    filled-new-array {v3, v0, v1}, [Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    new-instance v1, Landroid/app/AlertDialog$Builder;

    .line 121
    .line 122
    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 126
    .line 127
    .line 128
    move-result-object v1

    .line 129
    new-instance v2, Lg1/z1;

    .line 130
    .line 131
    invoke-direct {v2, p0, p1, v4}, Lg1/z1;-><init>(Le/m;Ljava/lang/Object;I)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1, v0, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 139
    .line 140
    .line 141
    return-void
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final x(Ljava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public final y()V
    .locals 2

    .line 1
    const v0, 0x7f09030b

    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iget-boolean v1, p0, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;->M:Z

    if-eqz v1, :cond_0

    const-string v1, "CONNECTED"

    goto :goto_0

    :cond_0
    const-string v1, "CONNECT CH341A"

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
