.class public Lapp/gkc/terminal/Activity/ProToolsActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lapp/gkc/terminal/Activity/ProToolsActivity$Esp32WifiScopeActivity;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Le/m;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const v0, 0x7f090136

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-ne p1, v0, :cond_0

    .line 10
    .line 11
    new-instance p1, Lapp/gkc/terminal/Activity/b;

    .line 12
    .line 13
    invoke-direct {p1, p0}, Lapp/gkc/terminal/Activity/b;-><init>(Landroid/content/Context;)V

    .line 14
    .line 15
    .line 16
    const v0, 0x7f080095

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1, v0}, Li/f0;->setImageResource(I)V

    .line 20
    .line 21
    .line 22
    const/high16 v0, -0x1000000

    .line 23
    .line 24
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0}, Le/m;->getResources()Landroid/content/res/Resources;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    const/4 v2, 0x1

    .line 36
    const/high16 v3, 0x43fa0000    # 500.0f

    .line 37
    .line 38
    invoke-static {v2, v3, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    float-to-int v0, v0

    .line 43
    invoke-virtual {p1, v0}, Landroid/view/View;->setMinimumHeight(I)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0}, Le/m;->getResources()Landroid/content/res/Resources;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    const/high16 v3, 0x41000000    # 8.0f

    .line 55
    .line 56
    invoke-static {v2, v3, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    float-to-int v0, v0

    .line 61
    invoke-virtual {p1, v0, v0, v0, v0}, Landroid/view/View;->setPadding(IIII)V

    .line 62
    .line 63
    .line 64
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 65
    .line 66
    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 67
    .line 68
    .line 69
    const-string v2, "CH341A 16-Pin ZIF Wiring Guide"

    .line 70
    .line 71
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    const-string v0, "CLOSE"

    .line 80
    .line 81
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 86
    .line 87
    .line 88
    goto/16 :goto_2

    .line 89
    .line 90
    :cond_0
    const v0, 0x7f090430

    .line 91
    .line 92
    .line 93
    if-ne p1, v0, :cond_1

    .line 94
    .line 95
    const-class p1, Lapp/gkc/terminal/Activity/UartConnectionDetailsActivity;

    .line 96
    .line 97
    :goto_0
    invoke-static {p0, p1}, Landroidx/fragment/app/e1;->l(Lapp/gkc/terminal/Activity/ProToolsActivity;Ljava/lang/Class;)V

    .line 98
    .line 99
    .line 100
    goto/16 :goto_2

    .line 101
    .line 102
    :cond_1
    const v0, 0x7f090386

    .line 103
    .line 104
    .line 105
    if-ne p1, v0, :cond_2

    .line 106
    .line 107
    const-class p1, Lapp/gkc/terminal/Activity/SamsungVghVglLiveActivity;

    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_2
    const v0, 0x7f0902d0

    .line 111
    .line 112
    .line 113
    if-ne p1, v0, :cond_3

    .line 114
    .line 115
    const-class p1, Lapp/gkc/terminal/Activity/PmicI2cActivity;

    .line 116
    .line 117
    goto :goto_0

    .line 118
    :cond_3
    const v0, 0x7f090221

    .line 119
    .line 120
    .line 121
    if-ne p1, v0, :cond_4

    .line 122
    .line 123
    const-class p1, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;

    .line 124
    .line 125
    goto :goto_0

    .line 126
    :cond_4
    const v0, 0x7f090385

    .line 127
    .line 128
    .line 129
    if-ne p1, v0, :cond_5

    .line 130
    .line 131
    const-class p1, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;

    .line 132
    .line 133
    goto :goto_0

    .line 134
    :cond_5
    const v0, 0x7f0903dc

    .line 135
    .line 136
    .line 137
    if-ne p1, v0, :cond_6

    .line 138
    .line 139
    const-class p1, Lapp/gkc/terminal/Activity/SpiI2cProgrammerActivity;

    .line 140
    .line 141
    goto :goto_0

    .line 142
    :cond_6
    const v0, 0x7f090193

    .line 143
    .line 144
    .line 145
    if-ne p1, v0, :cond_7

    .line 146
    .line 147
    const-class p1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;

    .line 148
    .line 149
    goto :goto_0

    .line 150
    :cond_7
    const v0, 0x7f09030e

    .line 151
    .line 152
    .line 153
    if-ne p1, v0, :cond_8

    .line 154
    .line 155
    const-class p1, Lapp/gkc/terminal/Activity/PanelEepromRepairActivity;

    .line 156
    .line 157
    goto :goto_0

    .line 158
    :cond_8
    const v0, 0x7f0901c6

    .line 159
    .line 160
    .line 161
    if-ne p1, v0, :cond_9

    .line 162
    .line 163
    const-class p1, Lapp/gkc/terminal/Activity/EmmcUserDumpActivity;

    .line 164
    .line 165
    goto :goto_0

    .line 166
    :cond_9
    const v0, 0x7f0902aa

    .line 167
    .line 168
    .line 169
    if-ne p1, v0, :cond_a

    .line 170
    .line 171
    const-class p1, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;

    .line 172
    .line 173
    goto :goto_0

    .line 174
    :cond_a
    const v0, 0x7f0901c4

    .line 175
    .line 176
    .line 177
    if-ne p1, v0, :cond_b

    .line 178
    .line 179
    const-class p1, Lapp/gkc/terminal/Activity/EmmcRpmbRepairActivity;

    .line 180
    .line 181
    goto :goto_0

    .line 182
    :cond_b
    const v0, 0x7f0901c0

    .line 183
    .line 184
    .line 185
    if-ne p1, v0, :cond_c

    .line 186
    .line 187
    const-class p1, Lapp/gkc/terminal/Activity/EmmcImageBrowserActivity;

    .line 188
    .line 189
    goto :goto_0

    .line 190
    :cond_c
    const v0, 0x7f0901dc

    .line 191
    .line 192
    .line 193
    if-ne p1, v0, :cond_d

    .line 194
    .line 195
    const-class p1, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;

    .line 196
    .line 197
    goto :goto_0

    .line 198
    :cond_d
    const v0, 0x7f09045a

    .line 199
    .line 200
    .line 201
    if-ne p1, v0, :cond_e

    .line 202
    .line 203
    const-class p1, Lapp/gkc/terminal/Activity/WebOsRepairPackageActivity;

    .line 204
    .line 205
    goto :goto_0

    .line 206
    :cond_e
    const v0, 0x7f0901a7

    .line 207
    .line 208
    .line 209
    if-ne p1, v0, :cond_f

    .line 210
    .line 211
    const-class p1, Lapp/gkc/terminal/Activity/DthLogoChangerActivity;

    .line 212
    .line 213
    goto :goto_0

    .line 214
    :cond_f
    const v0, 0x7f09036c

    .line 215
    .line 216
    .line 217
    if-ne p1, v0, :cond_10

    .line 218
    .line 219
    const-class p1, Lapp/gkc/terminal/Activity/ResistorToolsActivity;

    .line 220
    .line 221
    goto :goto_0

    .line 222
    :cond_10
    const v0, 0x7f09010f

    .line 223
    .line 224
    .line 225
    if-ne p1, v0, :cond_11

    .line 226
    .line 227
    const-class p1, Lapp/gkc/terminal/Activity/BacklightCalculatorActivity;

    .line 228
    .line 229
    goto/16 :goto_0

    .line 230
    .line 231
    :cond_11
    const v0, 0x7f090390

    .line 232
    .line 233
    .line 234
    if-ne p1, v0, :cond_12

    .line 235
    .line 236
    const-class p1, Lapp/gkc/terminal/Activity/ScreenTestActivity;

    .line 237
    .line 238
    goto/16 :goto_0

    .line 239
    .line 240
    :cond_12
    const v0, 0x7f0901d0

    .line 241
    .line 242
    .line 243
    if-ne p1, v0, :cond_13

    .line 244
    .line 245
    const-class p1, Lapp/gkc/terminal/Activity/ProToolsActivity$Esp32WifiScopeActivity;

    .line 246
    .line 247
    goto/16 :goto_0

    .line 248
    .line 249
    :cond_13
    const v0, 0x7f0901cf

    .line 250
    .line 251
    .line 252
    if-ne p1, v0, :cond_14

    .line 253
    .line 254
    const-class p1, Lapp/gkc/terminal/USB/Esp32FlashActivity;

    .line 255
    .line 256
    goto/16 :goto_0

    .line 257
    .line 258
    :cond_14
    const v0, 0x7f0903c1

    .line 259
    .line 260
    .line 261
    if-ne p1, v0, :cond_15

    .line 262
    .line 263
    const-class p1, Lapp/gkc/terminal/Activity/ServiceMenuActivity;

    .line 264
    .line 265
    goto/16 :goto_0

    .line 266
    .line 267
    :cond_15
    const v0, 0x7f09010b

    .line 268
    .line 269
    .line 270
    if-ne p1, v0, :cond_16

    .line 271
    .line 272
    const-class p1, Lapp/gkc/terminal/Activity/AutoSerialRecoveryActivity;

    .line 273
    .line 274
    goto/16 :goto_0

    .line 275
    .line 276
    :cond_16
    const v0, 0x7f09028c

    .line 277
    .line 278
    .line 279
    if-ne p1, v0, :cond_17

    .line 280
    .line 281
    const-class p1, Lapp/gkc/terminal/Activity/ManualSerialRecoveryActivity;

    .line 282
    .line 283
    goto/16 :goto_0

    .line 284
    .line 285
    :cond_17
    const v0, 0x7f0900ec

    .line 286
    .line 287
    .line 288
    if-ne p1, v0, :cond_18

    .line 289
    .line 290
    const-class p1, Lapp/gkc/terminal/Activity/AmlogicMiScreenRotateActivity;

    .line 291
    .line 292
    goto/16 :goto_0

    .line 293
    .line 294
    :cond_18
    const v0, 0x7f090206

    .line 295
    .line 296
    .line 297
    if-ne p1, v0, :cond_19

    .line 298
    .line 299
    const-class p1, Lapp/gkc/terminal/Activity/GkcTvAdbToolsActivity;

    .line 300
    .line 301
    goto/16 :goto_0

    .line 302
    .line 303
    :cond_19
    const v0, 0x7f09023d

    .line 304
    .line 305
    .line 306
    if-ne p1, v0, :cond_1a

    .line 307
    .line 308
    const-class p1, Lapp/gkc/terminal/Activity/HexEditorActivity;

    .line 309
    .line 310
    goto/16 :goto_0

    .line 311
    .line 312
    :cond_1a
    const v0, 0x7f090468

    .line 313
    .line 314
    .line 315
    if-ne p1, v0, :cond_1b

    .line 316
    .line 317
    new-instance p1, Landroid/content/Intent;

    .line 318
    .line 319
    const-string v0, "https://www.youtube.com/@gkctvrepair"

    .line 320
    .line 321
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 322
    .line 323
    .line 324
    move-result-object v1

    .line 325
    const-string v2, "android.intent.action.VIEW"

    .line 326
    .line 327
    invoke-direct {p1, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 328
    .line 329
    .line 330
    const-string v1, "com.google.android.youtube"

    .line 331
    .line 332
    invoke-virtual {p1, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 333
    .line 334
    .line 335
    :try_start_0
    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 336
    .line 337
    .line 338
    goto :goto_2

    .line 339
    :catch_0
    new-instance p1, Landroid/content/Intent;

    .line 340
    .line 341
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 342
    .line 343
    .line 344
    move-result-object v0

    .line 345
    invoke-direct {p1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 346
    .line 347
    .line 348
    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 349
    .line 350
    .line 351
    goto :goto_2

    .line 352
    :cond_1b
    const v0, 0x7f0900a6

    .line 353
    .line 354
    .line 355
    const-string v2, "OK"

    .line 356
    .line 357
    if-ne p1, v0, :cond_1c

    .line 358
    .line 359
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 360
    .line 361
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 362
    .line 363
    .line 364
    const-string v0, "About GKC Terminal Pro"

    .line 365
    .line 366
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 367
    .line 368
    .line 369
    move-result-object p1

    .line 370
    const-string v0, "Developed by Gururaj K Chandan from Karnataka, India.\n\nTechnology made easy.\n\nVersion 1.2.3 (26)"

    .line 371
    .line 372
    :goto_1
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 373
    .line 374
    .line 375
    move-result-object p1

    .line 376
    invoke-virtual {p1, v2, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 377
    .line 378
    .line 379
    move-result-object p1

    .line 380
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 381
    .line 382
    .line 383
    goto :goto_2

    .line 384
    :cond_1c
    const v0, 0x7f090405

    .line 385
    .line 386
    .line 387
    if-ne p1, v0, :cond_1d

    .line 388
    .line 389
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 390
    .line 391
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 392
    .line 393
    .line 394
    const-string v0, "Terms and Conditions"

    .line 395
    .line 396
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 397
    .line 398
    .line 399
    move-result-object p1

    .line 400
    const-string v0, "Please save your activation key in a safe place.\n\nIf you hard reset your phone or change mobile, you need the activation key again.\n\nIf you lose the key, we are not responsible."

    .line 401
    .line 402
    goto :goto_1

    .line 403
    :cond_1d
    :goto_2
    return-void
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0}, Lapp/gkc/terminal/Activity/ProActivationActivity;->r(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_0

    new-instance p1, Landroid/content/Intent;

    const-class v0, Lapp/gkc/terminal/Activity/ProActivationActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_0
    const p1, 0x7f0c0031

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const p1, 0x7f09041d

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    const/high16 v1, 0x41000000    # 8.0f

    invoke-virtual {p1, v1}, Landroid/view/View;->setTranslationY(F)V

    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {p1, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const-wide/16 v0, 0xdc

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    const p1, 0x7f09043c

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const-string v0, "Version 1.2.3 (26)"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 p1, 0x1b

    new-array v0, p1, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, p1, :cond_1

    aget v3, v0, v2

    invoke-virtual {p0, v3}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    invoke-virtual {v3, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const p1, 0x7f0900a6

    const v0, 0x7f090405

    const v2, 0x7f090468

    filled-new-array {v2, p1, v0}, [I

    move-result-object p1

    :goto_1
    const/4 v0, 0x3

    if-ge v1, v0, :cond_2

    aget v0, p1, v1

    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_2
    return-void

    :array_0
    .array-data 4
        0x7f090136
        0x7f090430
        0x7f090386
        0x7f0902d0
        0x7f090221
        0x7f090385
        0x7f0903dc
        0x7f090193
        0x7f09030e
        0x7f0901c6
        0x7f0902aa
        0x7f0901c4
        0x7f0901c0
        0x7f0901dc
        0x7f09045a
        0x7f0901a7
        0x7f09036c
        0x7f09010f
        0x7f090390
        0x7f0901d0
        0x7f0901cf
        0x7f0903c1
        0x7f09010b
        0x7f09028c
        0x7f0900ec
        0x7f090206
        0x7f09023d
    .end array-data
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method
