.class public Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final a0:Ljava/util/regex/Pattern;


# instance fields
.field public B:Landroid/widget/TextView;

.field public C:Landroid/widget/TextView;

.field public D:Landroid/widget/TextView;

.field public E:Landroid/widget/TextView;

.field public F:Landroid/widget/ListView;

.field public G:Landroid/widget/ListView;

.field public H:Landroid/widget/ArrayAdapter;

.field public I:Landroid/widget/ArrayAdapter;

.field public J:Lg1/c1;

.field public K:Lg1/c1;

.field public L:Lg1/c1;

.field public M:Lg1/h1;

.field public final N:Ljava/util/ArrayList;

.field public final O:Ljava/util/ArrayList;

.field public final P:Ljava/util/ArrayList;

.field public final Q:Ljava/util/ArrayList;

.field public final R:Ljava/util/ArrayList;

.field public S:Lg1/d1;

.field public T:Lg1/f1;

.field public final U:Lb/h;

.field public final V:Lb/h;

.field public final W:Lb/h;

.field public final X:Lb/h;

.field public final Y:Lb/h;

.field public final Z:Lb/h;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "->\\s*0x([0-9A-Fa-f]{6,16})\\s*\\(0x([0-9A-Fa-f]{1,16})\\)\\s*//\\s*([^\\r\\n]+)"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->a0:Ljava/util/regex/Pattern;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    invoke-direct {p0}, Le/m;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->O:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->Q:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->R:Ljava/util/ArrayList;

    new-instance v0, Lc/c;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lc/c;-><init>(I)V

    new-instance v2, Lg1/w0;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v3}, Lg1/w0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p0, v2, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U:Lb/h;

    new-instance v0, Lc/c;

    invoke-direct {v0, v1}, Lc/c;-><init>(I)V

    new-instance v2, Lg1/w0;

    invoke-direct {v2, p0, v1}, Lg1/w0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p0, v2, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V:Lb/h;

    new-instance v0, Lc/c;

    invoke-direct {v0, v1}, Lc/c;-><init>(I)V

    new-instance v2, Lg1/w0;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lg1/w0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p0, v2, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->W:Lb/h;

    new-instance v0, Lc/b;

    invoke-direct {v0}, Lc/b;-><init>()V

    new-instance v2, Lg1/w0;

    const/4 v3, 0x3

    invoke-direct {v2, p0, v3}, Lg1/w0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p0, v2, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->X:Lb/h;

    new-instance v0, Lc/c;

    invoke-direct {v0, v1}, Lc/c;-><init>(I)V

    new-instance v1, Lg1/w0;

    const/4 v2, 0x4

    invoke-direct {v1, p0, v2}, Lg1/w0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p0, v1, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->Y:Lb/h;

    new-instance v0, Lc/b;

    invoke-direct {v0}, Lc/b;-><init>()V

    new-instance v1, Lg1/w0;

    const/4 v2, 0x5

    invoke-direct {v1, p0, v2}, Lg1/w0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p0, v1, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->Z:Lb/h;

    return-void
.end method

.method public static varargs A(I[B[I)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    if-eqz p1, :cond_3

    if-ltz p0, :cond_3

    array-length v1, p1

    array-length v2, p2

    add-int/2addr v2, p0

    if-ge v1, v2, :cond_0

    goto :goto_1

    :cond_0
    move v1, v0

    :goto_0
    array-length v2, p2

    if-ge v1, v2, :cond_2

    add-int v2, p0, v1

    aget-byte v2, p1, v2

    and-int/lit16 v2, v2, 0xff

    aget v3, p2, v1

    and-int/lit16 v3, v3, 0xff

    if-eq v2, v3, :cond_1

    return v0

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x1

    return p0

    :cond_3
    :goto_1
    return v0
.end method

.method public static C([B)Ljava/lang/String;
    .locals 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    array-length v1, p0

    mul-int/lit8 v1, v1, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-byte v3, p0, v2

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    and-int/lit16 v3, v3, 0xff

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v5, "%02x"

    invoke-static {v4, v5, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static D([B)J
    .locals 4

    .line 1
    const/4 v0, 0x4

    invoke-static {p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    move-result-wide v0

    const/16 v2, 0x6c

    invoke-static {p0, v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    move-result-wide v2

    const/16 p0, 0x20

    shl-long/2addr v2, p0

    or-long/2addr v0, v2

    return-wide v0
.end method

.method public static J(Ljava/nio/channels/FileChannel;J)Lg1/g1;
    .locals 30

    .line 1
    move-wide/from16 v0, p1

    .line 2
    .line 3
    const-wide/32 v2, 0xa000000

    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->min(JJ)J

    .line 7
    .line 8
    .line 9
    move-result-wide v2

    .line 10
    const-wide/16 v6, 0x0

    .line 11
    .line 12
    :goto_0
    cmp-long v8, v6, v2

    .line 13
    .line 14
    if-gez v8, :cond_f

    .line 15
    .line 16
    const-wide/32 v8, 0x101000

    .line 17
    .line 18
    .line 19
    sub-long v10, v0, v6

    .line 20
    .line 21
    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->min(JJ)J

    .line 22
    .line 23
    .line 24
    move-result-wide v8

    .line 25
    long-to-int v8, v8

    .line 26
    const/16 v9, 0x200

    .line 27
    .line 28
    if-ge v8, v9, :cond_0

    .line 29
    .line 30
    goto/16 :goto_a

    .line 31
    .line 32
    :cond_0
    move-object/from16 v9, p0

    .line 33
    .line 34
    invoke-static {v9, v6, v7, v8}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;

    .line 35
    .line 36
    .line 37
    move-result-object v8

    .line 38
    invoke-virtual {v8}, Ljava/nio/ByteBuffer;->array()[B

    .line 39
    .line 40
    .line 41
    move-result-object v8

    .line 42
    const/4 v10, 0x0

    .line 43
    move v11, v10

    .line 44
    :goto_1
    add-int/lit16 v12, v11, 0x200

    .line 45
    .line 46
    array-length v13, v8

    .line 47
    if-gt v12, v13, :cond_e

    .line 48
    .line 49
    int-to-long v13, v11

    .line 50
    add-long/2addr v13, v6

    .line 51
    cmp-long v13, v13, v2

    .line 52
    .line 53
    if-gez v13, :cond_e

    .line 54
    .line 55
    const/16 v13, 0x54

    .line 56
    .line 57
    const/16 v14, 0x4d

    .line 58
    .line 59
    const/16 v15, 0x50

    .line 60
    .line 61
    filled-new-array {v14, v15, v13, v10}, [I

    .line 62
    .line 63
    .line 64
    move-result-object v13

    .line 65
    invoke-static {v11, v8, v13}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 66
    .line 67
    .line 68
    move-result v13

    .line 69
    if-eqz v13, :cond_1

    .line 70
    .line 71
    add-int/lit8 v13, v11, 0x4

    .line 72
    .line 73
    aget-byte v13, v8, v13

    .line 74
    .line 75
    const/16 v14, 0x30

    .line 76
    .line 77
    if-lt v13, v14, :cond_1

    .line 78
    .line 79
    const/16 v15, 0x39

    .line 80
    .line 81
    if-le v13, v15, :cond_2

    .line 82
    .line 83
    :cond_1
    :goto_2
    move-wide/from16 v21, v2

    .line 84
    .line 85
    move v2, v10

    .line 86
    move/from16 v23, v12

    .line 87
    .line 88
    const-wide/16 v17, 0x0

    .line 89
    .line 90
    goto/16 :goto_9

    .line 91
    .line 92
    :cond_2
    add-int/lit8 v13, v11, 0x10

    .line 93
    .line 94
    invoke-static {v8, v13}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->W([BI)J

    .line 95
    .line 96
    .line 97
    move-result-wide v4

    .line 98
    long-to-int v4, v4

    .line 99
    const/4 v5, 0x3

    .line 100
    if-lt v4, v5, :cond_1

    .line 101
    .line 102
    const/16 v13, 0x40

    .line 103
    .line 104
    if-le v4, v13, :cond_3

    .line 105
    .line 106
    goto :goto_2

    .line 107
    :cond_3
    const/16 v13, 0x28

    .line 108
    .line 109
    const/16 v15, 0x24

    .line 110
    .line 111
    filled-new-array {v13, v15, v14}, [I

    .line 112
    .line 113
    .line 114
    move-result-object v13

    .line 115
    move v14, v10

    .line 116
    :goto_3
    if-ge v14, v5, :cond_1

    .line 117
    .line 118
    aget v15, v13, v14

    .line 119
    .line 120
    add-int/lit8 v16, v11, 0x18

    .line 121
    .line 122
    mul-int v19, v4, v15

    .line 123
    .line 124
    add-int v10, v19, v16

    .line 125
    .line 126
    array-length v5, v8

    .line 127
    if-le v10, v5, :cond_4

    .line 128
    .line 129
    move-wide/from16 v21, v2

    .line 130
    .line 131
    move/from16 v20, v4

    .line 132
    .line 133
    move v4, v11

    .line 134
    move/from16 v23, v12

    .line 135
    .line 136
    const/4 v3, 0x3

    .line 137
    const-wide/16 v17, 0x0

    .line 138
    .line 139
    goto/16 :goto_8

    .line 140
    .line 141
    :cond_4
    new-instance v5, Ljava/util/ArrayList;

    .line 142
    .line 143
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 144
    .line 145
    .line 146
    const/4 v10, 0x0

    .line 147
    :goto_4
    if-ge v10, v4, :cond_c

    .line 148
    .line 149
    mul-int v20, v10, v15

    .line 150
    .line 151
    move-wide/from16 v21, v2

    .line 152
    .line 153
    add-int v2, v20, v16

    .line 154
    .line 155
    move/from16 v20, v4

    .line 156
    .line 157
    const/4 v3, 0x0

    .line 158
    :goto_5
    const/16 v4, 0x10

    .line 159
    .line 160
    if-ge v3, v4, :cond_5

    .line 161
    .line 162
    add-int v23, v2, v3

    .line 163
    .line 164
    aget-byte v23, v8, v23

    .line 165
    .line 166
    if-eqz v23, :cond_5

    .line 167
    .line 168
    add-int/lit8 v3, v3, 0x1

    .line 169
    .line 170
    goto :goto_5

    .line 171
    :cond_5
    if-eqz v3, :cond_a

    .line 172
    .line 173
    if-ne v3, v4, :cond_6

    .line 174
    .line 175
    goto/16 :goto_6

    .line 176
    .line 177
    :cond_6
    new-instance v4, Ljava/lang/String;

    .line 178
    .line 179
    const-string v9, "US-ASCII"

    .line 180
    .line 181
    invoke-direct {v4, v8, v2, v3, v9}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 182
    .line 183
    .line 184
    add-int/lit8 v3, v2, 0x10

    .line 185
    .line 186
    const/16 v9, 0x8

    .line 187
    .line 188
    invoke-static {v8, v3, v9}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    .line 189
    .line 190
    .line 191
    move-result-object v3

    .line 192
    sget-object v9, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 193
    .line 194
    invoke-virtual {v3, v9}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 195
    .line 196
    .line 197
    move-result-object v3

    .line 198
    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->getLong()J

    .line 199
    .line 200
    .line 201
    move-result-wide v24

    .line 202
    add-int/lit8 v2, v2, 0x18

    .line 203
    .line 204
    const/16 v3, 0x8

    .line 205
    .line 206
    invoke-static {v8, v2, v3}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    .line 207
    .line 208
    .line 209
    move-result-object v2

    .line 210
    invoke-virtual {v2, v9}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 211
    .line 212
    .line 213
    move-result-object v2

    .line 214
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getLong()J

    .line 215
    .line 216
    .line 217
    move-result-wide v2

    .line 218
    const-string v9, "[A-Za-z][A-Za-z0-9_-]*"

    .line 219
    .line 220
    invoke-virtual {v4, v9}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 221
    .line 222
    .line 223
    move-result v9

    .line 224
    if-eqz v9, :cond_a

    .line 225
    .line 226
    const-wide/16 v17, 0x0

    .line 227
    .line 228
    cmp-long v9, v24, v17

    .line 229
    .line 230
    if-lez v9, :cond_7

    .line 231
    .line 232
    cmp-long v9, v2, v17

    .line 233
    .line 234
    if-ltz v9, :cond_7

    .line 235
    .line 236
    const-wide/16 v26, 0x200

    .line 237
    .line 238
    rem-long v28, v24, v26

    .line 239
    .line 240
    cmp-long v9, v28, v17

    .line 241
    .line 242
    if-nez v9, :cond_7

    .line 243
    .line 244
    rem-long v28, v2, v26

    .line 245
    .line 246
    cmp-long v9, v28, v17

    .line 247
    .line 248
    if-eqz v9, :cond_8

    .line 249
    .line 250
    :cond_7
    move v4, v11

    .line 251
    move/from16 v23, v12

    .line 252
    .line 253
    goto :goto_7

    .line 254
    :cond_8
    new-instance v9, Lg1/h1;

    .line 255
    .line 256
    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    .line 257
    .line 258
    .line 259
    iput-object v4, v9, Lg1/h1;->a:Ljava/lang/String;

    .line 260
    .line 261
    div-long v2, v2, v26

    .line 262
    .line 263
    iput-wide v2, v9, Lg1/h1;->b:J

    .line 264
    .line 265
    div-long v24, v24, v26

    .line 266
    .line 267
    add-long v24, v24, v2

    .line 268
    .line 269
    const-wide/16 v26, 0x1

    .line 270
    .line 271
    move v4, v11

    .line 272
    move/from16 v23, v12

    .line 273
    .line 274
    sub-long v11, v24, v26

    .line 275
    .line 276
    iput-wide v11, v9, Lg1/h1;->c:J

    .line 277
    .line 278
    cmp-long v2, v11, v2

    .line 279
    .line 280
    if-ltz v2, :cond_b

    .line 281
    .line 282
    invoke-virtual {v9}, Lg1/h1;->b()J

    .line 283
    .line 284
    .line 285
    move-result-wide v2

    .line 286
    cmp-long v2, v2, v0

    .line 287
    .line 288
    if-ltz v2, :cond_9

    .line 289
    .line 290
    goto :goto_7

    .line 291
    :cond_9
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 292
    .line 293
    .line 294
    add-int/lit8 v10, v10, 0x1

    .line 295
    .line 296
    move-object/from16 v9, p0

    .line 297
    .line 298
    move v11, v4

    .line 299
    move/from16 v4, v20

    .line 300
    .line 301
    move-wide/from16 v2, v21

    .line 302
    .line 303
    move/from16 v12, v23

    .line 304
    .line 305
    goto/16 :goto_4

    .line 306
    .line 307
    :cond_a
    :goto_6
    move v4, v11

    .line 308
    move/from16 v23, v12

    .line 309
    .line 310
    const-wide/16 v17, 0x0

    .line 311
    .line 312
    :cond_b
    :goto_7
    const/4 v3, 0x3

    .line 313
    goto :goto_8

    .line 314
    :cond_c
    move-wide/from16 v21, v2

    .line 315
    .line 316
    move/from16 v20, v4

    .line 317
    .line 318
    move v4, v11

    .line 319
    move/from16 v23, v12

    .line 320
    .line 321
    const-wide/16 v17, 0x0

    .line 322
    .line 323
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 324
    .line 325
    .line 326
    move-result v2

    .line 327
    const/4 v3, 0x3

    .line 328
    if-ge v2, v3, :cond_d

    .line 329
    .line 330
    :goto_8
    add-int/lit8 v14, v14, 0x1

    .line 331
    .line 332
    move-object/from16 v9, p0

    .line 333
    .line 334
    move v5, v3

    .line 335
    move v11, v4

    .line 336
    move/from16 v4, v20

    .line 337
    .line 338
    move-wide/from16 v2, v21

    .line 339
    .line 340
    move/from16 v12, v23

    .line 341
    .line 342
    const/4 v10, 0x0

    .line 343
    goto/16 :goto_3

    .line 344
    .line 345
    :cond_d
    new-instance v0, Le0/b;

    .line 346
    .line 347
    invoke-direct {v0, v3}, Le0/b;-><init>(I)V

    .line 348
    .line 349
    .line 350
    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    .line 351
    .line 352
    .line 353
    new-instance v0, Lg1/g1;

    .line 354
    .line 355
    invoke-direct {v0}, Lg1/g1;-><init>()V

    .line 356
    .line 357
    .line 358
    const/4 v1, 0x1

    .line 359
    iput-boolean v1, v0, Lg1/g1;->a:Z

    .line 360
    .line 361
    iput-boolean v1, v0, Lg1/g1;->b:Z

    .line 362
    .line 363
    const/4 v2, 0x0

    .line 364
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object v2

    .line 368
    check-cast v2, Lg1/h1;

    .line 369
    .line 370
    iget-wide v2, v2, Lg1/h1;->b:J

    .line 371
    .line 372
    iput-wide v2, v0, Lg1/g1;->c:J

    .line 373
    .line 374
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 375
    .line 376
    .line 377
    move-result v2

    .line 378
    sub-int/2addr v2, v1

    .line 379
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 380
    .line 381
    .line 382
    move-result-object v1

    .line 383
    check-cast v1, Lg1/h1;

    .line 384
    .line 385
    iget-wide v1, v1, Lg1/h1;->c:J

    .line 386
    .line 387
    iput-wide v1, v0, Lg1/g1;->d:J

    .line 388
    .line 389
    iput-object v5, v0, Lg1/g1;->f:Ljava/util/ArrayList;

    .line 390
    .line 391
    return-object v0

    .line 392
    :goto_9
    move-object/from16 v9, p0

    .line 393
    .line 394
    move v10, v2

    .line 395
    move-wide/from16 v2, v21

    .line 396
    .line 397
    move/from16 v11, v23

    .line 398
    .line 399
    goto/16 :goto_1

    .line 400
    .line 401
    :cond_e
    move-wide/from16 v21, v2

    .line 402
    .line 403
    const-wide/16 v17, 0x0

    .line 404
    .line 405
    const-wide/32 v2, 0x100000

    .line 406
    .line 407
    .line 408
    add-long/2addr v6, v2

    .line 409
    move-wide/from16 v2, v21

    .line 410
    .line 411
    goto/16 :goto_0

    .line 412
    .line 413
    :cond_f
    :goto_a
    const/4 v0, 0x0

    .line 414
    return-object v0
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
.end method

.method public static K(Ljava/nio/channels/FileChannel;JJ)Lg1/g1;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-wide/from16 v1, p3

    .line 4
    .line 5
    const-wide/16 v3, 0x200

    .line 6
    .line 7
    add-long v5, v1, v3

    .line 8
    .line 9
    const-wide/16 v7, 0x400

    .line 10
    .line 11
    add-long/2addr v7, v1

    .line 12
    cmp-long v7, p1, v7

    .line 13
    .line 14
    const/4 v8, 0x0

    .line 15
    if-gez v7, :cond_0

    .line 16
    .line 17
    return-object v8

    .line 18
    :cond_0
    const/16 v7, 0x200

    .line 19
    .line 20
    invoke-static {v0, v5, v6, v7}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    const/16 v6, 0x8

    .line 25
    .line 26
    new-array v6, v6, [B

    .line 27
    .line 28
    const/4 v7, 0x0

    .line 29
    invoke-virtual {v5, v7}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v5, v6}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    .line 33
    .line 34
    .line 35
    new-instance v9, Ljava/lang/String;

    .line 36
    .line 37
    const-string v10, "US-ASCII"

    .line 38
    .line 39
    invoke-direct {v9, v6, v10}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    const-string v6, "EFI PART"

    .line 43
    .line 44
    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v6

    .line 48
    if-nez v6, :cond_1

    .line 49
    .line 50
    return-object v8

    .line 51
    :cond_1
    const/16 v6, 0xc

    .line 52
    .line 53
    invoke-virtual {v5, v6}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 54
    .line 55
    .line 56
    move-result v6

    .line 57
    int-to-long v9, v6

    .line 58
    const-wide v11, 0xffffffffL

    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    and-long/2addr v9, v11

    .line 64
    const/16 v6, 0x10

    .line 65
    .line 66
    invoke-virtual {v5, v6}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 67
    .line 68
    .line 69
    move-result v13

    .line 70
    int-to-long v13, v13

    .line 71
    and-long/2addr v13, v11

    .line 72
    const/16 v15, 0x18

    .line 73
    .line 74
    invoke-virtual {v5, v15}, Ljava/nio/ByteBuffer;->getLong(I)J

    .line 75
    .line 76
    .line 77
    const/16 v15, 0x28

    .line 78
    .line 79
    invoke-virtual {v5, v15}, Ljava/nio/ByteBuffer;->getLong(I)J

    .line 80
    .line 81
    .line 82
    move-result-wide v15

    .line 83
    const/16 v8, 0x30

    .line 84
    .line 85
    invoke-virtual {v5, v8}, Ljava/nio/ByteBuffer;->getLong(I)J

    .line 86
    .line 87
    .line 88
    move-result-wide v18

    .line 89
    const/16 v8, 0x48

    .line 90
    .line 91
    invoke-virtual {v5, v8}, Ljava/nio/ByteBuffer;->getLong(I)J

    .line 92
    .line 93
    .line 94
    move-result-wide v20

    .line 95
    const/16 v8, 0x50

    .line 96
    .line 97
    invoke-virtual {v5, v8}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 98
    .line 99
    .line 100
    move-result v8

    .line 101
    int-to-long v3, v8

    .line 102
    and-long/2addr v3, v11

    .line 103
    long-to-int v3, v3

    .line 104
    const/16 v4, 0x54

    .line 105
    .line 106
    invoke-virtual {v5, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 107
    .line 108
    .line 109
    move-result v4

    .line 110
    int-to-long v6, v4

    .line 111
    and-long/2addr v6, v11

    .line 112
    long-to-int v4, v6

    .line 113
    const/16 v6, 0x58

    .line 114
    .line 115
    invoke-virtual {v5, v6}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 116
    .line 117
    .line 118
    move-result v6

    .line 119
    int-to-long v6, v6

    .line 120
    and-long/2addr v6, v11

    .line 121
    const-wide/16 v11, 0x0

    .line 122
    .line 123
    cmp-long v24, v9, v11

    .line 124
    .line 125
    const/16 v25, 0x1

    .line 126
    .line 127
    if-lez v24, :cond_3

    .line 128
    .line 129
    invoke-virtual {v5}, Ljava/nio/Buffer;->capacity()I

    .line 130
    .line 131
    .line 132
    move-result v8

    .line 133
    int-to-long v11, v8

    .line 134
    cmp-long v8, v9, v11

    .line 135
    .line 136
    if-lez v8, :cond_2

    .line 137
    .line 138
    goto :goto_0

    .line 139
    :cond_2
    long-to-int v8, v9

    .line 140
    new-array v9, v8, [B

    .line 141
    .line 142
    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->array()[B

    .line 143
    .line 144
    .line 145
    move-result-object v5

    .line 146
    const/4 v10, 0x0

    .line 147
    invoke-static {v5, v10, v9, v10, v8}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 148
    .line 149
    .line 150
    const/16 v5, 0x10

    .line 151
    .line 152
    aput-byte v10, v9, v5

    .line 153
    .line 154
    const/16 v5, 0x11

    .line 155
    .line 156
    aput-byte v10, v9, v5

    .line 157
    .line 158
    const/16 v5, 0x12

    .line 159
    .line 160
    aput-byte v10, v9, v5

    .line 161
    .line 162
    const/16 v5, 0x13

    .line 163
    .line 164
    aput-byte v10, v9, v5

    .line 165
    .line 166
    new-instance v5, Ljava/util/zip/CRC32;

    .line 167
    .line 168
    invoke-direct {v5}, Ljava/util/zip/CRC32;-><init>()V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v5, v9}, Ljava/util/zip/CRC32;->update([B)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v5}, Ljava/util/zip/CRC32;->getValue()J

    .line 175
    .line 176
    .line 177
    move-result-wide v9

    .line 178
    cmp-long v5, v9, v13

    .line 179
    .line 180
    if-nez v5, :cond_3

    .line 181
    .line 182
    move/from16 v5, v25

    .line 183
    .line 184
    goto :goto_1

    .line 185
    :cond_3
    :goto_0
    const/4 v5, 0x0

    .line 186
    :goto_1
    int-to-long v9, v3

    .line 187
    int-to-long v11, v4

    .line 188
    mul-long/2addr v9, v11

    .line 189
    if-lez v3, :cond_4

    .line 190
    .line 191
    const/16 v11, 0x80

    .line 192
    .line 193
    if-lt v4, v11, :cond_4

    .line 194
    .line 195
    const-wide/16 v11, 0x0

    .line 196
    .line 197
    cmp-long v13, v9, v11

    .line 198
    .line 199
    if-lez v13, :cond_4

    .line 200
    .line 201
    const-wide/32 v13, 0x400000

    .line 202
    .line 203
    .line 204
    cmp-long v13, v9, v13

    .line 205
    .line 206
    if-lez v13, :cond_5

    .line 207
    .line 208
    :cond_4
    const/4 v0, 0x0

    .line 209
    goto/16 :goto_8

    .line 210
    .line 211
    :cond_5
    const-wide/16 v13, 0x200

    .line 212
    .line 213
    mul-long v20, v20, v13

    .line 214
    .line 215
    add-long v13, v20, v1

    .line 216
    .line 217
    cmp-long v20, v13, v11

    .line 218
    .line 219
    if-ltz v20, :cond_6

    .line 220
    .line 221
    add-long v11, v13, v9

    .line 222
    .line 223
    const-wide/16 v20, 0x200

    .line 224
    .line 225
    add-long v28, p1, v20

    .line 226
    .line 227
    cmp-long v11, v11, v28

    .line 228
    .line 229
    if-lez v11, :cond_7

    .line 230
    .line 231
    :cond_6
    const/4 v0, 0x0

    .line 232
    goto/16 :goto_8

    .line 233
    .line 234
    :cond_7
    long-to-int v9, v9

    .line 235
    invoke-static {v0, v13, v14, v9}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    new-instance v9, Ljava/util/zip/CRC32;

    .line 240
    .line 241
    invoke-direct {v9}, Ljava/util/zip/CRC32;-><init>()V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    .line 245
    .line 246
    .line 247
    move-result-object v10

    .line 248
    invoke-virtual {v0}, Ljava/nio/Buffer;->capacity()I

    .line 249
    .line 250
    .line 251
    move-result v11

    .line 252
    const/4 v8, 0x0

    .line 253
    invoke-virtual {v9, v10, v8, v11}, Ljava/util/zip/CRC32;->update([BII)V

    .line 254
    .line 255
    .line 256
    invoke-virtual {v9}, Ljava/util/zip/CRC32;->getValue()J

    .line 257
    .line 258
    .line 259
    move-result-wide v9

    .line 260
    cmp-long v6, v9, v6

    .line 261
    .line 262
    if-nez v6, :cond_8

    .line 263
    .line 264
    move/from16 v6, v25

    .line 265
    .line 266
    goto :goto_2

    .line 267
    :cond_8
    const/4 v6, 0x0

    .line 268
    :goto_2
    new-instance v7, Ljava/util/ArrayList;

    .line 269
    .line 270
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 271
    .line 272
    .line 273
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    .line 274
    .line 275
    .line 276
    move-result-object v9

    .line 277
    const/4 v10, 0x0

    .line 278
    :goto_3
    if-ge v10, v3, :cond_f

    .line 279
    .line 280
    mul-int v11, v10, v4

    .line 281
    .line 282
    const/4 v12, 0x0

    .line 283
    :goto_4
    const/16 v13, 0x10

    .line 284
    .line 285
    if-ge v12, v13, :cond_d

    .line 286
    .line 287
    add-int v14, v11, v12

    .line 288
    .line 289
    aget-byte v14, v9, v14

    .line 290
    .line 291
    if-eqz v14, :cond_c

    .line 292
    .line 293
    new-instance v12, Lg1/h1;

    .line 294
    .line 295
    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    .line 296
    .line 297
    .line 298
    add-int/lit8 v14, v11, 0x38

    .line 299
    .line 300
    add-int/lit8 v8, v4, -0x38

    .line 301
    .line 302
    const/16 v13, 0x48

    .line 303
    .line 304
    invoke-static {v13, v8}, Ljava/lang/Math;->min(II)I

    .line 305
    .line 306
    .line 307
    move-result v8

    .line 308
    add-int/2addr v8, v14

    .line 309
    move/from16 v17, v14

    .line 310
    .line 311
    :goto_5
    add-int/lit8 v13, v17, 0x1

    .line 312
    .line 313
    if-ge v13, v8, :cond_a

    .line 314
    .line 315
    aget-byte v20, v9, v17

    .line 316
    .line 317
    if-nez v20, :cond_9

    .line 318
    .line 319
    aget-byte v13, v9, v13

    .line 320
    .line 321
    if-nez v13, :cond_9

    .line 322
    .line 323
    goto :goto_6

    .line 324
    :cond_9
    add-int/lit8 v17, v17, 0x2

    .line 325
    .line 326
    const/16 v13, 0x48

    .line 327
    .line 328
    goto :goto_5

    .line 329
    :cond_a
    :goto_6
    new-instance v8, Ljava/lang/String;

    .line 330
    .line 331
    sub-int v13, v17, v14

    .line 332
    .line 333
    move/from16 v20, v3

    .line 334
    .line 335
    const/4 v3, 0x0

    .line 336
    invoke-static {v3, v13}, Ljava/lang/Math;->max(II)I

    .line 337
    .line 338
    .line 339
    move-result v13

    .line 340
    const-string v3, "UTF-16LE"

    .line 341
    .line 342
    invoke-direct {v8, v9, v14, v13, v3}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 343
    .line 344
    .line 345
    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 346
    .line 347
    .line 348
    move-result-object v3

    .line 349
    iput-object v3, v12, Lg1/h1;->a:Ljava/lang/String;

    .line 350
    .line 351
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 352
    .line 353
    .line 354
    move-result v3

    .line 355
    if-nez v3, :cond_b

    .line 356
    .line 357
    new-instance v3, Ljava/lang/StringBuilder;

    .line 358
    .line 359
    const-string v8, "partition_"

    .line 360
    .line 361
    invoke-direct {v3, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 362
    .line 363
    .line 364
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 365
    .line 366
    .line 367
    move-result v8

    .line 368
    add-int/lit8 v8, v8, 0x1

    .line 369
    .line 370
    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 371
    .line 372
    .line 373
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 374
    .line 375
    .line 376
    move-result-object v3

    .line 377
    iput-object v3, v12, Lg1/h1;->a:Ljava/lang/String;

    .line 378
    .line 379
    :cond_b
    add-int/lit8 v3, v11, 0x20

    .line 380
    .line 381
    invoke-virtual {v0, v3}, Ljava/nio/ByteBuffer;->getLong(I)J

    .line 382
    .line 383
    .line 384
    move-result-wide v13

    .line 385
    const-wide/16 v22, 0x200

    .line 386
    .line 387
    div-long v28, v1, v22

    .line 388
    .line 389
    add-long v13, v13, v28

    .line 390
    .line 391
    iput-wide v13, v12, Lg1/h1;->b:J

    .line 392
    .line 393
    add-int/lit8 v11, v11, 0x28

    .line 394
    .line 395
    invoke-virtual {v0, v11}, Ljava/nio/ByteBuffer;->getLong(I)J

    .line 396
    .line 397
    .line 398
    move-result-wide v13

    .line 399
    add-long v13, v13, v28

    .line 400
    .line 401
    iput-wide v13, v12, Lg1/h1;->c:J

    .line 402
    .line 403
    move v8, v4

    .line 404
    iget-wide v3, v12, Lg1/h1;->b:J

    .line 405
    .line 406
    const-wide/16 v26, 0x0

    .line 407
    .line 408
    cmp-long v11, v3, v26

    .line 409
    .line 410
    if-lez v11, :cond_e

    .line 411
    .line 412
    cmp-long v3, v13, v3

    .line 413
    .line 414
    if-ltz v3, :cond_e

    .line 415
    .line 416
    invoke-virtual {v12}, Lg1/h1;->b()J

    .line 417
    .line 418
    .line 419
    move-result-wide v3

    .line 420
    cmp-long v3, v3, p1

    .line 421
    .line 422
    if-gez v3, :cond_e

    .line 423
    .line 424
    invoke-virtual {v7, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 425
    .line 426
    .line 427
    goto :goto_7

    .line 428
    :cond_c
    move/from16 v20, v3

    .line 429
    .line 430
    move v8, v4

    .line 431
    const-wide/16 v26, 0x0

    .line 432
    .line 433
    add-int/lit8 v12, v12, 0x1

    .line 434
    .line 435
    goto/16 :goto_4

    .line 436
    .line 437
    :cond_d
    move/from16 v20, v3

    .line 438
    .line 439
    move v8, v4

    .line 440
    const-wide/16 v26, 0x0

    .line 441
    .line 442
    :cond_e
    :goto_7
    add-int/lit8 v10, v10, 0x1

    .line 443
    .line 444
    move v4, v8

    .line 445
    move/from16 v3, v20

    .line 446
    .line 447
    goto/16 :goto_3

    .line 448
    .line 449
    :cond_f
    new-instance v0, Lg1/g1;

    .line 450
    .line 451
    invoke-direct {v0}, Lg1/g1;-><init>()V

    .line 452
    .line 453
    .line 454
    iput-boolean v5, v0, Lg1/g1;->a:Z

    .line 455
    .line 456
    iput-boolean v6, v0, Lg1/g1;->b:Z

    .line 457
    .line 458
    const-wide/16 v3, 0x200

    .line 459
    .line 460
    div-long v3, v1, v3

    .line 461
    .line 462
    add-long v5, v15, v3

    .line 463
    .line 464
    iput-wide v5, v0, Lg1/g1;->c:J

    .line 465
    .line 466
    add-long v3, v18, v3

    .line 467
    .line 468
    iput-wide v3, v0, Lg1/g1;->d:J

    .line 469
    .line 470
    iput-wide v1, v0, Lg1/g1;->e:J

    .line 471
    .line 472
    iput-object v7, v0, Lg1/g1;->f:Ljava/util/ArrayList;

    .line 473
    .line 474
    :goto_8
    return-object v0
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public static L(Ljava/nio/channels/FileChannel;J)Lg1/g1;
    .locals 18

    .line 1
    const-wide/16 v0, 0x200

    .line 2
    .line 3
    cmp-long v2, p1, v0

    .line 4
    .line 5
    const/4 v3, 0x0

    .line 6
    if-gez v2, :cond_0

    .line 7
    .line 8
    return-object v3

    .line 9
    :cond_0
    const-wide/16 v4, 0x0

    .line 10
    .line 11
    const/16 v2, 0x200

    .line 12
    .line 13
    move-object/from16 v6, p0

    .line 14
    .line 15
    invoke-static {v6, v4, v5, v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->array()[B

    .line 20
    .line 21
    .line 22
    move-result-object v6

    .line 23
    const/16 v7, 0x1fe

    .line 24
    .line 25
    aget-byte v7, v6, v7

    .line 26
    .line 27
    and-int/lit16 v7, v7, 0xff

    .line 28
    .line 29
    const/16 v8, 0x55

    .line 30
    .line 31
    if-ne v7, v8, :cond_e

    .line 32
    .line 33
    const/16 v7, 0x1ff

    .line 34
    .line 35
    aget-byte v7, v6, v7

    .line 36
    .line 37
    and-int/lit16 v7, v7, 0xff

    .line 38
    .line 39
    const/16 v8, 0xaa

    .line 40
    .line 41
    if-eq v7, v8, :cond_1

    .line 42
    .line 43
    goto/16 :goto_3

    .line 44
    .line 45
    :cond_1
    new-instance v7, Ljava/util/ArrayList;

    .line 46
    .line 47
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 48
    .line 49
    .line 50
    const/4 v9, 0x0

    .line 51
    :goto_0
    const/4 v10, 0x4

    .line 52
    const/4 v11, 0x1

    .line 53
    if-ge v9, v10, :cond_c

    .line 54
    .line 55
    mul-int/lit8 v10, v9, 0x10

    .line 56
    .line 57
    add-int/lit16 v12, v10, 0x1c2

    .line 58
    .line 59
    aget-byte v12, v6, v12

    .line 60
    .line 61
    and-int/lit16 v12, v12, 0xff

    .line 62
    .line 63
    add-int/lit16 v13, v10, 0x1c6

    .line 64
    .line 65
    invoke-virtual {v2, v13}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 66
    .line 67
    .line 68
    move-result v13

    .line 69
    int-to-long v13, v13

    .line 70
    const-wide v15, 0xffffffffL

    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    and-long/2addr v13, v15

    .line 76
    add-int/lit16 v10, v10, 0x1ca

    .line 77
    .line 78
    invoke-virtual {v2, v10}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 79
    .line 80
    .line 81
    move-result v10

    .line 82
    move/from16 v17, v9

    .line 83
    .line 84
    int-to-long v8, v10

    .line 85
    and-long/2addr v8, v15

    .line 86
    if-eqz v12, :cond_b

    .line 87
    .line 88
    cmp-long v10, v13, v4

    .line 89
    .line 90
    if-eqz v10, :cond_b

    .line 91
    .line 92
    cmp-long v10, v8, v4

    .line 93
    .line 94
    if-nez v10, :cond_2

    .line 95
    .line 96
    goto/16 :goto_2

    .line 97
    .line 98
    :cond_2
    new-instance v10, Lg1/h1;

    .line 99
    .line 100
    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    .line 101
    .line 102
    .line 103
    new-instance v15, Ljava/lang/StringBuilder;

    .line 104
    .line 105
    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    .line 106
    .line 107
    .line 108
    const/4 v4, 0x5

    .line 109
    if-eq v12, v4, :cond_a

    .line 110
    .line 111
    const/4 v4, 0x7

    .line 112
    if-eq v12, v4, :cond_9

    .line 113
    .line 114
    const/16 v4, 0xf

    .line 115
    .line 116
    if-eq v12, v4, :cond_a

    .line 117
    .line 118
    const/16 v4, 0x27

    .line 119
    .line 120
    if-eq v12, v4, :cond_8

    .line 121
    .line 122
    const/16 v4, 0x85

    .line 123
    .line 124
    if-eq v12, v4, :cond_a

    .line 125
    .line 126
    const/16 v4, 0xa5

    .line 127
    .line 128
    if-eq v12, v4, :cond_7

    .line 129
    .line 130
    const/16 v4, 0xee

    .line 131
    .line 132
    if-eq v12, v4, :cond_6

    .line 133
    .line 134
    const/16 v4, 0xb

    .line 135
    .line 136
    if-eq v12, v4, :cond_5

    .line 137
    .line 138
    const/16 v4, 0xc

    .line 139
    .line 140
    if-eq v12, v4, :cond_5

    .line 141
    .line 142
    const/16 v4, 0x82

    .line 143
    .line 144
    if-eq v12, v4, :cond_4

    .line 145
    .line 146
    const/16 v4, 0x83

    .line 147
    .line 148
    if-eq v12, v4, :cond_3

    .line 149
    .line 150
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 151
    .line 152
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v5

    .line 160
    const-string v12, "partition_%02X"

    .line 161
    .line 162
    invoke-static {v4, v12, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v4

    .line 166
    goto :goto_1

    .line 167
    :cond_3
    const-string v4, "linux_data"

    .line 168
    .line 169
    goto :goto_1

    .line 170
    :cond_4
    const-string v4, "linux_swap"

    .line 171
    .line 172
    goto :goto_1

    .line 173
    :cond_5
    const-string v4, "data_fat32"

    .line 174
    .line 175
    goto :goto_1

    .line 176
    :cond_6
    const-string v4, "gpt_protective"

    .line 177
    .line 178
    goto :goto_1

    .line 179
    :cond_7
    const-string v4, "freebsd"

    .line 180
    .line 181
    goto :goto_1

    .line 182
    :cond_8
    const-string v4, "recovery"

    .line 183
    .line 184
    goto :goto_1

    .line 185
    :cond_9
    const-string v4, "data_ntfs"

    .line 186
    .line 187
    goto :goto_1

    .line 188
    :cond_a
    const-string v4, "extended"

    .line 189
    .line 190
    :goto_1
    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 191
    .line 192
    .line 193
    const-string v4, "_"

    .line 194
    .line 195
    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 196
    .line 197
    .line 198
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 199
    .line 200
    .line 201
    move-result v4

    .line 202
    add-int/2addr v4, v11

    .line 203
    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 204
    .line 205
    .line 206
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v4

    .line 210
    iput-object v4, v10, Lg1/h1;->a:Ljava/lang/String;

    .line 211
    .line 212
    iput-wide v13, v10, Lg1/h1;->b:J

    .line 213
    .line 214
    add-long/2addr v8, v13

    .line 215
    const-wide/16 v4, 0x1

    .line 216
    .line 217
    sub-long v4, v8, v4

    .line 218
    .line 219
    iput-wide v4, v10, Lg1/h1;->c:J

    .line 220
    .line 221
    mul-long/2addr v8, v0

    .line 222
    cmp-long v4, v4, v13

    .line 223
    .line 224
    if-ltz v4, :cond_b

    .line 225
    .line 226
    add-long v4, p1, v0

    .line 227
    .line 228
    cmp-long v4, v8, v4

    .line 229
    .line 230
    if-gtz v4, :cond_b

    .line 231
    .line 232
    invoke-virtual {v7, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 233
    .line 234
    .line 235
    :cond_b
    :goto_2
    add-int/lit8 v9, v17, 0x1

    .line 236
    .line 237
    const-wide/16 v4, 0x0

    .line 238
    .line 239
    goto/16 :goto_0

    .line 240
    .line 241
    :cond_c
    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    .line 242
    .line 243
    .line 244
    move-result v0

    .line 245
    if-eqz v0, :cond_d

    .line 246
    .line 247
    return-object v3

    .line 248
    :cond_d
    new-instance v0, Lg1/g1;

    .line 249
    .line 250
    invoke-direct {v0}, Lg1/g1;-><init>()V

    .line 251
    .line 252
    .line 253
    iput-boolean v11, v0, Lg1/g1;->a:Z

    .line 254
    .line 255
    iput-boolean v11, v0, Lg1/g1;->b:Z

    .line 256
    .line 257
    const/4 v1, 0x0

    .line 258
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v1

    .line 262
    check-cast v1, Lg1/h1;

    .line 263
    .line 264
    iget-wide v1, v1, Lg1/h1;->b:J

    .line 265
    .line 266
    iput-wide v1, v0, Lg1/g1;->c:J

    .line 267
    .line 268
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 269
    .line 270
    .line 271
    move-result v1

    .line 272
    sub-int/2addr v1, v11

    .line 273
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object v1

    .line 277
    check-cast v1, Lg1/h1;

    .line 278
    .line 279
    iget-wide v1, v1, Lg1/h1;->c:J

    .line 280
    .line 281
    iput-wide v1, v0, Lg1/g1;->d:J

    .line 282
    .line 283
    iput-object v7, v0, Lg1/g1;->f:Ljava/util/ArrayList;

    .line 284
    .line 285
    return-object v0

    .line 286
    :cond_e
    :goto_3
    return-object v3
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public static M(Ljava/nio/channels/FileChannel;J)Lg1/g1;
    .locals 18

    .line 1
    move-wide/from16 v0, p1

    .line 2
    .line 3
    const-wide/16 v2, 0x600

    .line 4
    .line 5
    cmp-long v2, v0, v2

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    if-gez v2, :cond_0

    .line 9
    .line 10
    return-object v3

    .line 11
    :cond_0
    const-wide/32 v4, 0x8000

    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1, v4, v5}, Ljava/lang/Math;->min(JJ)J

    .line 15
    .line 16
    .line 17
    move-result-wide v0

    .line 18
    long-to-int v0, v0

    .line 19
    const-wide/16 v1, 0x0

    .line 20
    .line 21
    move-object/from16 v4, p0

    .line 22
    .line 23
    invoke-static {v4, v1, v2, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    new-instance v4, Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 34
    .line 35
    .line 36
    const-wide/16 v6, -0x1

    .line 37
    .line 38
    const/4 v8, 0x1

    .line 39
    :goto_0
    const/16 v9, 0x3f

    .line 40
    .line 41
    const/4 v10, 0x2

    .line 42
    const-wide/16 v11, 0x1

    .line 43
    .line 44
    const/4 v13, 0x0

    .line 45
    if-gt v8, v9, :cond_1

    .line 46
    .line 47
    add-int/lit8 v9, v8, 0x1

    .line 48
    .line 49
    mul-int/lit16 v14, v9, 0x200

    .line 50
    .line 51
    array-length v15, v0

    .line 52
    if-gt v14, v15, :cond_1

    .line 53
    .line 54
    mul-int/lit16 v8, v8, 0x200

    .line 55
    .line 56
    aget-byte v14, v0, v8

    .line 57
    .line 58
    and-int/lit16 v14, v14, 0xff

    .line 59
    .line 60
    const/16 v15, 0x40

    .line 61
    .line 62
    if-ne v14, v15, :cond_1

    .line 63
    .line 64
    add-int/lit8 v14, v8, 0x1

    .line 65
    .line 66
    aget-byte v14, v0, v14

    .line 67
    .line 68
    and-int/lit16 v14, v14, 0xff

    .line 69
    .line 70
    const/16 v15, 0x58

    .line 71
    .line 72
    if-eq v14, v15, :cond_2

    .line 73
    .line 74
    :cond_1
    :goto_1
    move-object v5, v4

    .line 75
    goto :goto_3

    .line 76
    :cond_2
    add-int/lit8 v14, v8, 0x8

    .line 77
    .line 78
    invoke-static {v0, v14}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->W([BI)J

    .line 79
    .line 80
    .line 81
    move-result-wide v14

    .line 82
    add-int/lit8 v5, v8, 0xc

    .line 83
    .line 84
    invoke-static {v0, v5}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->W([BI)J

    .line 85
    .line 86
    .line 87
    move-result-wide v16

    .line 88
    cmp-long v5, v16, v1

    .line 89
    .line 90
    if-nez v5, :cond_3

    .line 91
    .line 92
    goto :goto_1

    .line 93
    :cond_3
    move v5, v13

    .line 94
    :goto_2
    const/16 v1, 0x10

    .line 95
    .line 96
    if-ge v5, v1, :cond_4

    .line 97
    .line 98
    add-int/lit8 v2, v8, 0x10

    .line 99
    .line 100
    add-int/2addr v2, v5

    .line 101
    aget-byte v2, v0, v2

    .line 102
    .line 103
    if-eqz v2, :cond_4

    .line 104
    .line 105
    add-int/lit8 v5, v5, 0x1

    .line 106
    .line 107
    goto :goto_2

    .line 108
    :cond_4
    if-lt v5, v10, :cond_1

    .line 109
    .line 110
    if-ne v5, v1, :cond_5

    .line 111
    .line 112
    goto :goto_1

    .line 113
    :cond_5
    new-instance v1, Ljava/lang/String;

    .line 114
    .line 115
    add-int/lit8 v8, v8, 0x10

    .line 116
    .line 117
    const-string v2, "US-ASCII"

    .line 118
    .line 119
    invoke-direct {v1, v0, v8, v5, v2}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 120
    .line 121
    .line 122
    const-string v2, "[A-Za-z][A-Za-z0-9_-]*"

    .line 123
    .line 124
    invoke-virtual {v1, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 125
    .line 126
    .line 127
    move-result v2

    .line 128
    if-nez v2, :cond_6

    .line 129
    .line 130
    goto :goto_1

    .line 131
    :cond_6
    add-long v16, v14, v16

    .line 132
    .line 133
    move-object v5, v4

    .line 134
    sub-long v3, v16, v11

    .line 135
    .line 136
    cmp-long v6, v14, v6

    .line 137
    .line 138
    if-gtz v6, :cond_7

    .line 139
    .line 140
    goto :goto_3

    .line 141
    :cond_7
    new-instance v6, Lg1/h1;

    .line 142
    .line 143
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 144
    .line 145
    .line 146
    iput-object v1, v6, Lg1/h1;->a:Ljava/lang/String;

    .line 147
    .line 148
    iput-wide v14, v6, Lg1/h1;->b:J

    .line 149
    .line 150
    iput-wide v3, v6, Lg1/h1;->c:J

    .line 151
    .line 152
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-wide v6, v3

    .line 156
    move-object v4, v5

    .line 157
    move v8, v9

    .line 158
    const-wide/16 v1, 0x0

    .line 159
    .line 160
    const/4 v3, 0x0

    .line 161
    goto :goto_0

    .line 162
    :goto_3
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    if-ge v0, v10, :cond_8

    .line 167
    .line 168
    const/4 v0, 0x0

    .line 169
    return-object v0

    .line 170
    :cond_8
    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    check-cast v0, Lg1/h1;

    .line 175
    .line 176
    iget-wide v0, v0, Lg1/h1;->b:J

    .line 177
    .line 178
    cmp-long v0, v0, v11

    .line 179
    .line 180
    if-lez v0, :cond_9

    .line 181
    .line 182
    new-instance v0, Lg1/h1;

    .line 183
    .line 184
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 185
    .line 186
    .line 187
    const-string v1, "Part_Map"

    .line 188
    .line 189
    iput-object v1, v0, Lg1/h1;->a:Ljava/lang/String;

    .line 190
    .line 191
    const-wide/16 v1, 0x0

    .line 192
    .line 193
    iput-wide v1, v0, Lg1/h1;->b:J

    .line 194
    .line 195
    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v1

    .line 199
    check-cast v1, Lg1/h1;

    .line 200
    .line 201
    iget-wide v1, v1, Lg1/h1;->b:J

    .line 202
    .line 203
    sub-long/2addr v1, v11

    .line 204
    iput-wide v1, v0, Lg1/h1;->c:J

    .line 205
    .line 206
    invoke-virtual {v5, v13, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 207
    .line 208
    .line 209
    :cond_9
    new-instance v0, Lg1/g1;

    .line 210
    .line 211
    invoke-direct {v0}, Lg1/g1;-><init>()V

    .line 212
    .line 213
    .line 214
    const/4 v1, 0x1

    .line 215
    iput-boolean v1, v0, Lg1/g1;->a:Z

    .line 216
    .line 217
    iput-boolean v1, v0, Lg1/g1;->b:Z

    .line 218
    .line 219
    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object v2

    .line 223
    check-cast v2, Lg1/h1;

    .line 224
    .line 225
    iget-wide v2, v2, Lg1/h1;->b:J

    .line 226
    .line 227
    iput-wide v2, v0, Lg1/g1;->c:J

    .line 228
    .line 229
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 230
    .line 231
    .line 232
    move-result v2

    .line 233
    sub-int/2addr v2, v1

    .line 234
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v1

    .line 238
    check-cast v1, Lg1/h1;

    .line 239
    .line 240
    iget-wide v1, v1, Lg1/h1;->c:J

    .line 241
    .line 242
    iput-wide v1, v0, Lg1/g1;->d:J

    .line 243
    .line 244
    iput-object v5, v0, Lg1/g1;->f:Ljava/util/ArrayList;

    .line 245
    .line 246
    return-object v0
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public static N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;
    .locals 1

    .line 1
    invoke-static {p3}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object p3

    sget-object v0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {p3, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object p3

    invoke-virtual {p0, p1, p2}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    :cond_0
    invoke-virtual {p3}, Ljava/nio/Buffer;->hasRemaining()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {p0, p3}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result p1

    if-gez p1, :cond_0

    :cond_1
    invoke-virtual {p3}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    return-object p3
.end method

.method public static U([BI)I
    .locals 2

    .line 1
    add-int/lit8 v0, p1, 0x1

    array-length v1, p0

    if-lt v0, v1, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    aget-byte p1, p0, p1

    and-int/lit16 p1, p1, 0xff

    aget-byte p0, p0, v0

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x8

    or-int/2addr p0, p1

    return p0
.end method

.method public static V([BI)J
    .locals 8

    .line 1
    add-int/lit8 v0, p1, 0x3

    array-length v1, p0

    if-lt v0, v1, :cond_0

    const-wide/16 p0, 0x0

    return-wide p0

    :cond_0
    aget-byte v1, p0, p1

    int-to-long v1, v1

    const-wide/16 v3, 0xff

    and-long/2addr v1, v3

    add-int/lit8 v5, p1, 0x1

    aget-byte v5, p0, v5

    int-to-long v5, v5

    and-long/2addr v5, v3

    const/16 v7, 0x8

    shl-long/2addr v5, v7

    or-long/2addr v1, v5

    add-int/lit8 p1, p1, 0x2

    aget-byte p1, p0, p1

    int-to-long v5, p1

    and-long/2addr v5, v3

    const/16 p1, 0x10

    shl-long/2addr v5, p1

    or-long/2addr v1, v5

    aget-byte p0, p0, v0

    int-to-long p0, p0

    and-long/2addr p0, v3

    const/16 v0, 0x18

    shl-long/2addr p0, v0

    or-long/2addr p0, v1

    return-wide p0
.end method

.method public static W([BI)J
    .locals 2

    .line 1
    const/4 v0, 0x4

    invoke-static {p0, p1, v0}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object p0

    sget-object p1, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result p0

    int-to-long p0, p0

    const-wide v0, 0xffffffffL

    and-long/2addr p0, v0

    return-wide p0
.end method

.method public static q(Lg1/h1;)Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lg1/h1;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\nStart LBA: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Lg1/h1;->b:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "\nEnd LBA: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Lg1/h1;->c:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "\nStart byte: 0x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lg1/h1;->b()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\nSize: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lg1/h1;->a()J

    move-result-wide v1

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->z(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static r(Lg1/c1;)Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "EMMC BACKUP ANALYZER\n\nFile: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lg1/c1;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\nSize: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Lg1/c1;->c:J

    invoke-static {v1, v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->z(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\nDetected: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lg1/c1;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lg1/c1;->f:Lg1/g1;

    if-nez v1, :cond_0

    const-string p0, "Partition table: NOT FOUND\nTip: This may be vendor raw, update/pkg/compressed, or encrypted firmware. Use hash/check first, or extract/convert if it is a package."

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-string v1, "Partition table: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lg1/c1;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\nValidation: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lg1/c1;->f:Lg1/g1;

    iget-boolean v2, v1, Lg1/g1;->a:Z

    if-eqz v2, :cond_1

    iget-boolean v1, v1, Lg1/g1;->b:Z

    if-eqz v1, :cond_1

    const-string v1, "OK"

    goto :goto_1

    :cond_1
    const-string v1, "CHECK"

    :goto_1
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\nPartitions: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lg1/c1;->f:Lg1/g1;

    iget-object v1, v1, Lg1/g1;->f:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\nUsable LBA: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lg1/c1;->f:Lg1/g1;

    iget-wide v1, v1, Lg1/g1;->c:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, " - "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lg1/c1;->f:Lg1/g1;

    iget-wide v1, p0, Lg1/g1;->d:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    goto :goto_0
.end method

.method public static v(Ljava/nio/channels/FileChannel;Ljava/lang/String;J)Ljava/lang/String;
    .locals 4

    .line 1
    if-nez p1, :cond_0

    const-string p1, ""

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const-wide/16 v0, 0x2000

    invoke-static {v0, v1, p2, p3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p2

    long-to-int p2, p2

    const-wide/16 v0, 0x0

    invoke-static {p0, v0, v1, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object p0

    const/16 p2, 0x3a

    const/16 p3, 0xff

    const/16 v0, 0x26

    const/16 v1, 0xed

    filled-new-array {p2, p3, v0, v1}, [I

    move-result-object p2

    const/4 p3, 0x0

    invoke-static {p3, p0, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p2

    if-eqz p2, :cond_1

    const-string p0, "Android sparse image. Convert/expand to raw before GPT partition view."

    return-object p0

    :cond_1
    const/16 p2, 0x8

    new-array p2, p2, [I

    fill-array-data p2, :array_0

    invoke-static {p3, p0, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p2

    if-eqz p2, :cond_2

    const-string p0, "Android boot/recovery image, not full eMMC dump."

    return-object p0

    :cond_2
    const/16 p2, 0x41

    const/16 v0, 0x56

    const/16 v1, 0x42

    const/16 v2, 0x30

    filled-new-array {p2, v0, v1, v2}, [I

    move-result-object p2

    invoke-static {p3, p0, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p2

    if-eqz p2, :cond_3

    const-string p0, "AVB/vbmeta image, not full eMMC dump."

    return-object p0

    :cond_3
    const/16 p2, 0x50

    const/16 v0, 0x4b

    const/4 v2, 0x3

    const/4 v3, 0x4

    filled-new-array {p2, v0, v2, v3}, [I

    move-result-object p2

    invoke-static {p3, p0, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p2

    if-eqz p2, :cond_4

    const-string p0, "ZIP/update package. Needs package extraction before GPT view."

    return-object p0

    :cond_4
    const/16 p2, 0x1f

    const/16 v0, 0x8b

    filled-new-array {p2, v0}, [I

    move-result-object p2

    invoke-static {p3, p0, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p2

    if-eqz p2, :cond_5

    const-string p0, "GZIP compressed firmware. Decompress first."

    return-object p0

    :cond_5
    const/16 p2, 0x89

    const/16 v0, 0x52

    filled-new-array {p2, v1, v0}, [I

    move-result-object p2

    invoke-static {p3, p0, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p0

    if-eqz p0, :cond_6

    const-string p0, "Brotli compressed data. Decompress first."

    return-object p0

    :cond_6
    const-string p0, ".pkg"

    invoke-virtual {p1, p0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_a

    const-string p0, "sony"

    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_a

    const-string p0, "netflix"

    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_7

    goto :goto_2

    :cond_7
    const-string p0, ".bin"

    invoke-virtual {p1, p0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_9

    const-string p0, ".img"

    invoke-virtual {p1, p0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_9

    const-string p0, ".dump"

    invoke-virtual {p1, p0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_8

    goto :goto_1

    :cond_8
    const-string p0, "Unknown firmware/container. GPT scan will confirm if it is raw."

    return-object p0

    :cond_9
    :goto_1
    const-string p0, "Raw image candidate. GPT scan will confirm partition table."

    return-object p0

    :cond_a
    :goto_2
    const-string p0, "Sony/Netflix package or encrypted firmware. Mobile can detect, raw partitions need unpack support."

    return-object p0

    nop

    :array_0
    .array-data 4
        0x41
        0x4e
        0x44
        0x52
        0x4f
        0x49
        0x44
        0x21
    .end array-data
.end method

.method public static x([BI)Ljava/lang/String;
    .locals 6

    .line 1
    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, "boot"

    return-object p0

    :cond_0
    const/16 v0, 0x41

    const/16 v1, 0x56

    const/16 v2, 0x42

    const/16 v3, 0x30

    filled-new-array {v0, v1, v2, v3}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p0, "vbmeta"

    return-object p0

    :cond_1
    const/16 v0, 0x1e

    const/16 v1, 0xab

    const/16 v3, 0xb7

    const/16 v4, 0xd7

    filled-new-array {v0, v1, v3, v4}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string p0, "dtbo"

    return-object p0

    :cond_2
    const/16 v0, 0x3a

    const/16 v1, 0xff

    const/16 v3, 0x26

    const/16 v4, 0xed

    filled-new-array {v0, v1, v3, v4}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_3

    const-string p0, "sparse"

    return-object p0

    :cond_3
    const/16 v0, 0x68

    const/16 v1, 0x73

    const/16 v3, 0x71

    filled-new-array {v0, v1, v3, v1}, [I

    move-result-object v4

    invoke-static {p1, p0, v4}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v4

    if-nez v4, :cond_c

    filled-new-array {v1, v3, v1, v0}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_4

    goto/16 :goto_0

    :cond_4
    const/16 v0, 0x23

    const/16 v1, 0x55

    const/16 v3, 0x49

    filled-new-array {v1, v2, v3, v0}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_5

    const-string p0, "ubi"

    return-object p0

    :cond_5
    const/16 v0, 0x7f

    const/16 v1, 0x45

    const/16 v2, 0x4c

    const/16 v3, 0x46

    filled-new-array {v0, v1, v2, v3}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_6

    const-string p0, "elf"

    return-object p0

    :cond_6
    const/16 v0, 0x50

    const/16 v1, 0x4b

    const/4 v2, 0x3

    const/4 v3, 0x4

    filled-new-array {v0, v1, v2, v3}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_7

    const-string p0, "zip"

    return-object p0

    :cond_7
    const/16 v0, 0x1f

    const/16 v1, 0x8b

    filled-new-array {v0, v1}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_8

    const-string p0, "gzip"

    return-object p0

    :cond_8
    add-int/lit16 v0, p1, 0x439

    array-length v1, p0

    if-ge v0, v1, :cond_9

    add-int/lit16 v0, p1, 0x438

    const/16 v1, 0x53

    const/16 v2, 0xef

    filled-new-array {v1, v2}, [I

    move-result-object v1

    invoke-static {v0, p0, v1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v0

    if-eqz v0, :cond_9

    const-string p0, "ext4"

    return-object p0

    :cond_9
    add-int/lit16 v0, p1, 0x403

    array-length v1, p0

    const/16 v2, 0xf5

    if-ge v0, v1, :cond_a

    add-int/lit16 v1, p1, 0x400

    const/16 v3, 0xf2

    const/16 v4, 0x10

    const/16 v5, 0x20

    filled-new-array {v4, v5, v2, v3}, [I

    move-result-object v3

    invoke-static {v1, p0, v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v1

    if-eqz v1, :cond_a

    const-string p0, "f2fs"

    return-object p0

    :cond_a
    array-length v1, p0

    if-ge v0, v1, :cond_b

    add-int/lit16 p1, p1, 0x400

    const/16 v0, 0xe0

    const/16 v1, 0xe2

    const/16 v3, 0xe1

    filled-new-array {v1, v3, v2, v0}, [I

    move-result-object v0

    invoke-static {p1, p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p0

    if-eqz p0, :cond_b

    const-string p0, "erofs"

    return-object p0

    :cond_b
    const/4 p0, 0x0

    return-object p0

    :cond_c
    :goto_0
    const-string p0, "squashfs"

    return-object p0

    :array_0
    .array-data 4
        0x41
        0x4e
        0x44
        0x52
        0x4f
        0x49
        0x44
        0x21
    .end array-data
.end method

.method public static z(J)Ljava/lang/String;
    .locals 3

    .line 1
    const-wide/32 v0, 0x40000000

    cmp-long v0, p0, v0

    if-ltz v0, :cond_0

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    long-to-double p0, p0

    const-wide/high16 v1, 0x41d0000000000000L    # 1.073741824E9

    div-double/2addr p0, v1

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%.2f GB"

    invoke-static {v0, p1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-wide/32 v0, 0x100000

    cmp-long v0, p0, v0

    if-ltz v0, :cond_1

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    long-to-double p0, p0

    const-wide/high16 v1, 0x4130000000000000L    # 1048576.0

    div-double/2addr p0, v1

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%.2f MB"

    invoke-static {v0, p1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    const-wide/16 v0, 0x400

    cmp-long v0, p0, v0

    if-ltz v0, :cond_2

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    long-to-double p0, p0

    const-wide/high16 v1, 0x4090000000000000L    # 1024.0

    div-double/2addr p0, v1

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%.2f KB"

    invoke-static {v0, p1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p0, " B"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final B(Landroid/net/Uri;JJ)Li/b0;
    .locals 7

    .line 1
    const-string v0, "MD5"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const-string v1, "SHA-256"

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "r"

    invoke-virtual {v2, p1, v3}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    move-result-object p1

    :try_start_0
    new-instance v2, Ljava/io/FileInputStream;

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-virtual {v2}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    invoke-virtual {v3, p2, p3}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    const/high16 p2, 0x100000

    new-array p3, p2, [B

    invoke-static {p3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v4

    :goto_0
    const-wide/16 v5, 0x0

    cmp-long v5, p4, v5

    if-lez v5, :cond_1

    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    int-to-long v5, p2

    invoke-static {v5, v6, p4, p5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v5

    long-to-int v5, v5

    invoke-virtual {v4, v5}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    invoke-virtual {v3, v4}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v5

    if-gtz v5, :cond_0

    goto :goto_1

    :cond_0
    const/4 v6, 0x0

    invoke-virtual {v0, p3, v6, v5}, Ljava/security/MessageDigest;->update([BII)V

    invoke-virtual {v1, p3, v6, v5}, Ljava/security/MessageDigest;->update([BII)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    int-to-long v5, v5

    sub-long/2addr p4, v5

    goto :goto_0

    :catchall_0
    move-exception p2

    goto :goto_2

    :cond_1
    :goto_1
    :try_start_3
    invoke-virtual {v3}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :try_start_4
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V

    new-instance p1, Li/b0;

    invoke-direct {p1}, Li/b0;-><init>()V

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p2

    invoke-static {p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->C([B)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Li/b0;->c:Ljava/lang/Object;

    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p2

    invoke-static {p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->C([B)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p1, Li/b0;->d:Ljava/lang/Object;

    return-object p1

    :catchall_1
    move-exception p2

    goto :goto_6

    :catchall_2
    move-exception p2

    goto :goto_4

    :goto_2
    if-eqz v3, :cond_2

    :try_start_5
    invoke-virtual {v3}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    goto :goto_3

    :catchall_3
    move-exception p3

    :try_start_6
    invoke-virtual {p2, p3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2
    :goto_3
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :goto_4
    :try_start_7
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    goto :goto_5

    :catchall_4
    move-exception p3

    :try_start_8
    invoke-virtual {p2, p3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_5
    throw p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :goto_6
    if-eqz p1, :cond_3

    :try_start_9
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    goto :goto_7

    :catchall_5
    move-exception p1

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_3
    :goto_7
    throw p2
.end method

.method public final E(ZLandroid/net/Uri;)Lg1/c1;
    .locals 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p2

    .line 4
    .line 5
    new-instance v2, Lg1/c1;

    .line 6
    .line 7
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    const-string v3, "NONE"

    .line 11
    .line 12
    iput-object v3, v2, Lg1/c1;->e:Ljava/lang/String;

    .line 13
    .line 14
    iput-object v0, v2, Lg1/c1;->a:Landroid/net/Uri;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->y(Landroid/net/Uri;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    iput-object v4, v2, Lg1/c1;->b:Ljava/lang/String;

    .line 21
    .line 22
    :try_start_0
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 23
    .line 24
    .line 25
    move-result-object v5

    .line 26
    const-string v6, "r"

    .line 27
    .line 28
    invoke-virtual {v5, v0, v6}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    .line 29
    .line 30
    .line 31
    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    :try_start_1
    new-instance v6, Ljava/io/FileInputStream;

    .line 33
    .line 34
    invoke-virtual {v5}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-direct {v6, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_8

    .line 39
    .line 40
    .line 41
    :try_start_2
    invoke-virtual {v6}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 42
    .line 43
    .line 44
    move-result-object v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_6

    .line 45
    :try_start_3
    invoke-virtual {v7}, Ljava/nio/channels/FileChannel;->size()J

    .line 46
    .line 47
    .line 48
    move-result-wide v8

    .line 49
    iput-wide v8, v2, Lg1/c1;->c:J

    .line 50
    .line 51
    iget-object v0, v2, Lg1/c1;->b:Ljava/lang/String;

    .line 52
    .line 53
    invoke-static {v7, v0, v8, v9}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->v(Ljava/nio/channels/FileChannel;Ljava/lang/String;J)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    iput-object v0, v2, Lg1/c1;->d:Ljava/lang/String;

    .line 58
    .line 59
    iget-wide v8, v2, Lg1/c1;->c:J

    .line 60
    .line 61
    const/4 v0, 0x4

    .line 62
    const-wide/16 v10, 0x0

    .line 63
    .line 64
    invoke-static {v7, v10, v11, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    const/4 v12, 0x0

    .line 69
    invoke-virtual {v0, v12}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    int-to-long v13, v0

    .line 74
    const-wide v15, 0xffffffffL

    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    and-long/2addr v13, v15

    .line 80
    const-wide v15, 0xed26ff3aL

    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    cmp-long v0, v13, v15

    .line 86
    .line 87
    if-nez v0, :cond_0

    .line 88
    .line 89
    const-string v0, "Android sparse image detected. Convert to raw image first for GPT parsing."

    .line 90
    .line 91
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    const/4 v0, 0x0

    .line 95
    goto :goto_0

    .line 96
    :cond_0
    invoke-static {v7, v8, v9, v10, v11}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->K(Ljava/nio/channels/FileChannel;JJ)Lg1/g1;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    :goto_0
    iput-object v0, v2, Lg1/c1;->f:Lg1/g1;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 101
    .line 102
    if-eqz v0, :cond_2

    .line 103
    .line 104
    :try_start_4
    const-string v0, "GPT"

    .line 105
    .line 106
    :goto_1
    iput-object v0, v2, Lg1/c1;->e:Ljava/lang/String;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 107
    .line 108
    :cond_1
    move-object/from16 p2, v5

    .line 109
    .line 110
    goto/16 :goto_5

    .line 111
    .line 112
    :catchall_0
    move-exception v0

    .line 113
    move-object v2, v0

    .line 114
    move-object/from16 p2, v5

    .line 115
    .line 116
    goto/16 :goto_a

    .line 117
    .line 118
    :cond_2
    :try_start_5
    iget-wide v8, v2, Lg1/c1;->c:J

    .line 119
    .line 120
    invoke-static {v7, v8, v9}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->M(Ljava/nio/channels/FileChannel;J)Lg1/g1;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    iput-object v0, v2, Lg1/c1;->f:Lg1/g1;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 125
    .line 126
    if-eqz v0, :cond_3

    .line 127
    .line 128
    :try_start_6
    const-string v0, "TV PARTITION TABLE (MStar)"
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 129
    .line 130
    goto :goto_1

    .line 131
    :cond_3
    :try_start_7
    iget-wide v8, v2, Lg1/c1;->c:J

    .line 132
    .line 133
    invoke-static {v7, v8, v9}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->J(Ljava/nio/channels/FileChannel;J)Lg1/g1;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    iput-object v0, v2, Lg1/c1;->f:Lg1/g1;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 138
    .line 139
    if-eqz v0, :cond_4

    .line 140
    .line 141
    :try_start_8
    const-string v0, "TV PARTITION TABLE (Amlogic / Mi)"
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 142
    .line 143
    goto :goto_1

    .line 144
    :cond_4
    :try_start_9
    iget-wide v8, v2, Lg1/c1;->c:J

    .line 145
    .line 146
    invoke-static {v7, v8, v9}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->L(Ljava/nio/channels/FileChannel;J)Lg1/g1;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    iput-object v0, v2, Lg1/c1;->f:Lg1/g1;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    .line 151
    .line 152
    if-eqz v0, :cond_5

    .line 153
    .line 154
    :try_start_a
    const-string v3, "MBR"
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    .line 155
    .line 156
    :cond_5
    :try_start_b
    iput-object v3, v2, Lg1/c1;->e:Ljava/lang/String;

    .line 157
    .line 158
    if-nez v0, :cond_1

    .line 159
    .line 160
    iget-wide v8, v2, Lg1/c1;->c:J
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    .line 161
    .line 162
    const-wide/16 v10, 0x200

    .line 163
    .line 164
    sub-long v13, v8, v10

    .line 165
    .line 166
    move-object/from16 p2, v5

    .line 167
    .line 168
    const-wide/32 v4, 0x10000000

    .line 169
    .line 170
    .line 171
    :try_start_c
    invoke-static {v13, v14, v4, v5}, Ljava/lang/Math;->min(JJ)J

    .line 172
    .line 173
    .line 174
    move-result-wide v4

    .line 175
    move-wide v13, v10

    .line 176
    :goto_2
    cmp-long v0, v13, v4

    .line 177
    .line 178
    if-gtz v0, :cond_8

    .line 179
    .line 180
    const/16 v0, 0x8

    .line 181
    .line 182
    invoke-static {v7, v13, v14, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N(Ljava/nio/channels/FileChannel;JI)Ljava/nio/ByteBuffer;

    .line 183
    .line 184
    .line 185
    move-result-object v15

    .line 186
    invoke-virtual {v15}, Ljava/nio/ByteBuffer;->array()[B

    .line 187
    .line 188
    .line 189
    move-result-object v15

    .line 190
    new-array v0, v0, [I

    .line 191
    .line 192
    fill-array-data v0, :array_0

    .line 193
    .line 194
    .line 195
    invoke-static {v12, v15, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    if-eqz v0, :cond_6

    .line 200
    .line 201
    move-wide/from16 v16, v4

    .line 202
    .line 203
    sub-long v3, v13, v10

    .line 204
    .line 205
    invoke-static {v7, v8, v9, v3, v4}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->K(Ljava/nio/channels/FileChannel;JJ)Lg1/g1;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    if-eqz v0, :cond_7

    .line 210
    .line 211
    iget-object v5, v0, Lg1/g1;->f:Ljava/util/ArrayList;

    .line 212
    .line 213
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    .line 214
    .line 215
    .line 216
    move-result v5

    .line 217
    if-nez v5, :cond_7

    .line 218
    .line 219
    iput-wide v3, v0, Lg1/g1;->e:J

    .line 220
    .line 221
    goto :goto_3

    .line 222
    :cond_6
    move-wide/from16 v16, v4

    .line 223
    .line 224
    :cond_7
    add-long/2addr v13, v10

    .line 225
    move-wide/from16 v4, v16

    .line 226
    .line 227
    goto :goto_2

    .line 228
    :cond_8
    const/4 v0, 0x0

    .line 229
    :goto_3
    iput-object v0, v2, Lg1/c1;->f:Lg1/g1;

    .line 230
    .line 231
    if-eqz v0, :cond_9

    .line 232
    .line 233
    new-instance v0, Ljava/lang/StringBuilder;

    .line 234
    .line 235
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 236
    .line 237
    .line 238
    const-string v3, "GPT @ 0x"

    .line 239
    .line 240
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 241
    .line 242
    .line 243
    iget-object v3, v2, Lg1/c1;->f:Lg1/g1;

    .line 244
    .line 245
    iget-wide v3, v3, Lg1/g1;->e:J

    .line 246
    .line 247
    invoke-static {v3, v4}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    .line 248
    .line 249
    .line 250
    move-result-object v3

    .line 251
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 252
    .line 253
    invoke-virtual {v3, v4}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object v3

    .line 257
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 258
    .line 259
    .line 260
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    iput-object v0, v2, Lg1/c1;->e:Ljava/lang/String;

    .line 265
    .line 266
    goto :goto_5

    .line 267
    :catchall_1
    move-exception v0

    .line 268
    :goto_4
    move-object v2, v0

    .line 269
    goto/16 :goto_a

    .line 270
    .line 271
    :catchall_2
    move-exception v0

    .line 272
    move-object/from16 p2, v5

    .line 273
    .line 274
    goto :goto_4

    .line 275
    :cond_9
    :goto_5
    if-eqz p1, :cond_b

    .line 276
    .line 277
    iget-object v0, v1, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->B:Landroid/widget/TextView;

    .line 278
    .line 279
    new-instance v3, Ljava/lang/StringBuilder;

    .line 280
    .line 281
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 282
    .line 283
    .line 284
    iget-object v4, v2, Lg1/c1;->b:Ljava/lang/String;

    .line 285
    .line 286
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 287
    .line 288
    .line 289
    const-string v4, " loaded, "

    .line 290
    .line 291
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 292
    .line 293
    .line 294
    iget-wide v4, v2, Lg1/c1;->c:J

    .line 295
    .line 296
    invoke-static {v4, v5}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->z(J)Ljava/lang/String;

    .line 297
    .line 298
    .line 299
    move-result-object v4

    .line 300
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 301
    .line 302
    .line 303
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v3

    .line 307
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 308
    .line 309
    .line 310
    iget-object v0, v1, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->C:Landroid/widget/TextView;

    .line 311
    .line 312
    invoke-static {v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->r(Lg1/c1;)Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v3

    .line 316
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 317
    .line 318
    .line 319
    iget-object v0, v2, Lg1/c1;->f:Lg1/g1;

    .line 320
    .line 321
    if-eqz v0, :cond_a

    .line 322
    .line 323
    new-instance v0, Ljava/lang/StringBuilder;

    .line 324
    .line 325
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 326
    .line 327
    .line 328
    iget-object v3, v2, Lg1/c1;->e:Ljava/lang/String;

    .line 329
    .line 330
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 331
    .line 332
    .line 333
    const-string v3, " partition table detected. Partitions: "

    .line 334
    .line 335
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 336
    .line 337
    .line 338
    iget-object v3, v2, Lg1/c1;->f:Lg1/g1;

    .line 339
    .line 340
    iget-object v3, v3, Lg1/g1;->f:Ljava/util/ArrayList;

    .line 341
    .line 342
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 343
    .line 344
    .line 345
    move-result v3

    .line 346
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 347
    .line 348
    .line 349
    :goto_6
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object v0

    .line 353
    goto :goto_7

    .line 354
    :cond_a
    new-instance v0, Ljava/lang/StringBuilder;

    .line 355
    .line 356
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 357
    .line 358
    .line 359
    const-string v3, "Partition table not detected. "

    .line 360
    .line 361
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 362
    .line 363
    .line 364
    iget-object v3, v2, Lg1/c1;->d:Ljava/lang/String;

    .line 365
    .line 366
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 367
    .line 368
    .line 369
    goto :goto_6

    .line 370
    :goto_7
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_1

    .line 371
    .line 372
    .line 373
    :cond_b
    :try_start_d
    invoke-virtual {v7}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    .line 374
    .line 375
    .line 376
    :try_start_e
    invoke-virtual {v6}, Ljava/io/FileInputStream;->close()V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_3

    .line 377
    .line 378
    .line 379
    :try_start_f
    invoke-virtual/range {p2 .. p2}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_0

    .line 380
    .line 381
    .line 382
    return-object v2

    .line 383
    :catch_0
    move-exception v0

    .line 384
    goto :goto_10

    .line 385
    :catchall_3
    move-exception v0

    .line 386
    :goto_8
    move-object v2, v0

    .line 387
    goto :goto_e

    .line 388
    :catchall_4
    move-exception v0

    .line 389
    :goto_9
    move-object v2, v0

    .line 390
    goto :goto_c

    .line 391
    :goto_a
    if-eqz v7, :cond_c

    .line 392
    .line 393
    :try_start_10
    invoke-virtual {v7}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_5

    .line 394
    .line 395
    .line 396
    goto :goto_b

    .line 397
    :catchall_5
    move-exception v0

    .line 398
    move-object v3, v0

    .line 399
    :try_start_11
    invoke-virtual {v2, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 400
    .line 401
    .line 402
    :cond_c
    :goto_b
    throw v2
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_4

    .line 403
    :catchall_6
    move-exception v0

    .line 404
    move-object/from16 p2, v5

    .line 405
    .line 406
    goto :goto_9

    .line 407
    :goto_c
    :try_start_12
    invoke-virtual {v6}, Ljava/io/FileInputStream;->close()V
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_7

    .line 408
    .line 409
    .line 410
    goto :goto_d

    .line 411
    :catchall_7
    move-exception v0

    .line 412
    move-object v3, v0

    .line 413
    :try_start_13
    invoke-virtual {v2, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 414
    .line 415
    .line 416
    :goto_d
    throw v2
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_3

    .line 417
    :catchall_8
    move-exception v0

    .line 418
    move-object/from16 p2, v5

    .line 419
    .line 420
    goto :goto_8

    .line 421
    :goto_e
    if-eqz p2, :cond_d

    .line 422
    .line 423
    :try_start_14
    invoke-virtual/range {p2 .. p2}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_9

    .line 424
    .line 425
    .line 426
    goto :goto_f

    .line 427
    :catchall_9
    move-exception v0

    .line 428
    move-object v3, v0

    .line 429
    :try_start_15
    invoke-virtual {v2, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 430
    .line 431
    .line 432
    :cond_d
    :goto_f
    throw v2
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_15} :catch_0

    .line 433
    :goto_10
    const-string v2, "File open failed"

    .line 434
    .line 435
    const/4 v3, 0x1

    .line 436
    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 437
    .line 438
    .line 439
    move-result-object v2

    .line 440
    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 441
    .line 442
    .line 443
    new-instance v2, Ljava/lang/StringBuilder;

    .line 444
    .line 445
    const-string v3, "File open failed: "

    .line 446
    .line 447
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 448
    .line 449
    .line 450
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 451
    .line 452
    .line 453
    move-result-object v0

    .line 454
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 455
    .line 456
    .line 457
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 458
    .line 459
    .line 460
    move-result-object v0

    .line 461
    invoke-virtual {v1, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V

    .line 462
    .line 463
    .line 464
    const/4 v2, 0x0

    .line 465
    return-object v2

    .line 466
    nop

    .line 467
    :array_0
    .array-data 4
        0x45
        0x46
        0x49
        0x20
        0x50
        0x41
        0x52
        0x54
    .end array-data
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
.end method

.method public final F(Landroid/net/Uri;Lg1/h1;)Le/c;
    .locals 16

    .line 1
    move-object/from16 v0, p2

    .line 2
    .line 3
    invoke-virtual/range {p2 .. p2}, Lg1/h1;->b()J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    const/high16 v3, 0x10000

    .line 8
    .line 9
    move-object/from16 v4, p0

    .line 10
    .line 11
    move-object/from16 v5, p1

    .line 12
    .line 13
    invoke-virtual {v4, v5, v1, v2, v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P(Landroid/net/Uri;JI)[B

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    new-instance v2, Le/c;

    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    invoke-direct {v2, v3}, Le/c;-><init>(I)V

    .line 21
    .line 22
    .line 23
    iget-object v5, v0, Lg1/h1;->a:Ljava/lang/String;

    .line 24
    .line 25
    const/16 v6, 0x8

    .line 26
    .line 27
    new-array v6, v6, [I

    .line 28
    .line 29
    fill-array-data v6, :array_0

    .line 30
    .line 31
    .line 32
    invoke-static {v3, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 33
    .line 34
    .line 35
    move-result v6

    .line 36
    const-string v7, "userdata"

    .line 37
    .line 38
    const-string v8, ""

    .line 39
    .line 40
    const/16 v9, 0x10

    .line 41
    .line 42
    const/16 v10, 0x20

    .line 43
    .line 44
    const/16 v11, 0xff

    .line 45
    .line 46
    if-eqz v6, :cond_0

    .line 47
    .line 48
    const-string v5, "Android boot/recovery image"

    .line 49
    .line 50
    goto/16 :goto_2

    .line 51
    .line 52
    :cond_0
    const/16 v6, 0x30

    .line 53
    .line 54
    const/16 v12, 0x41

    .line 55
    .line 56
    const/16 v13, 0x56

    .line 57
    .line 58
    const/16 v14, 0x42

    .line 59
    .line 60
    filled-new-array {v12, v13, v14, v6}, [I

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    invoke-static {v3, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 65
    .line 66
    .line 67
    move-result v6

    .line 68
    if-eqz v6, :cond_1

    .line 69
    .line 70
    const-string v5, "AVB/vbmeta image"

    .line 71
    .line 72
    goto/16 :goto_2

    .line 73
    .line 74
    :cond_1
    const/16 v6, 0xb7

    .line 75
    .line 76
    const/16 v12, 0xd7

    .line 77
    .line 78
    const/16 v13, 0x1e

    .line 79
    .line 80
    const/16 v15, 0xab

    .line 81
    .line 82
    filled-new-array {v13, v15, v6, v12}, [I

    .line 83
    .line 84
    .line 85
    move-result-object v6

    .line 86
    invoke-static {v3, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 87
    .line 88
    .line 89
    move-result v6

    .line 90
    if-eqz v6, :cond_2

    .line 91
    .line 92
    const-string v5, "Android DTBO image"

    .line 93
    .line 94
    goto/16 :goto_2

    .line 95
    .line 96
    :cond_2
    const/16 v6, 0x3a

    .line 97
    .line 98
    const/16 v12, 0x26

    .line 99
    .line 100
    const/16 v13, 0xed

    .line 101
    .line 102
    filled-new-array {v6, v11, v12, v13}, [I

    .line 103
    .line 104
    .line 105
    move-result-object v6

    .line 106
    invoke-static {v3, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 107
    .line 108
    .line 109
    move-result v6

    .line 110
    if-eqz v6, :cond_3

    .line 111
    .line 112
    const-string v5, "Android Sparse image"

    .line 113
    .line 114
    goto/16 :goto_2

    .line 115
    .line 116
    :cond_3
    const/16 v6, 0x68

    .line 117
    .line 118
    const/16 v12, 0x73

    .line 119
    .line 120
    const/16 v13, 0x71

    .line 121
    .line 122
    filled-new-array {v6, v12, v13, v12}, [I

    .line 123
    .line 124
    .line 125
    move-result-object v15

    .line 126
    invoke-static {v3, v1, v15}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 127
    .line 128
    .line 129
    move-result v15

    .line 130
    if-nez v15, :cond_d

    .line 131
    .line 132
    filled-new-array {v12, v13, v12, v6}, [I

    .line 133
    .line 134
    .line 135
    move-result-object v6

    .line 136
    invoke-static {v3, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 137
    .line 138
    .line 139
    move-result v6

    .line 140
    if-eqz v6, :cond_4

    .line 141
    .line 142
    goto/16 :goto_1

    .line 143
    .line 144
    :cond_4
    array-length v6, v1

    .line 145
    const/16 v12, 0x439

    .line 146
    .line 147
    if-le v6, v12, :cond_5

    .line 148
    .line 149
    const/16 v6, 0x438

    .line 150
    .line 151
    aget-byte v6, v1, v6

    .line 152
    .line 153
    and-int/2addr v6, v11

    .line 154
    const/16 v13, 0x53

    .line 155
    .line 156
    if-ne v6, v13, :cond_5

    .line 157
    .line 158
    aget-byte v6, v1, v12

    .line 159
    .line 160
    and-int/2addr v6, v11

    .line 161
    const/16 v12, 0xef

    .line 162
    .line 163
    if-ne v6, v12, :cond_5

    .line 164
    .line 165
    const-string v5, "EXT4 filesystem"

    .line 166
    .line 167
    goto/16 :goto_2

    .line 168
    .line 169
    :cond_5
    array-length v6, v1

    .line 170
    const/16 v12, 0xf5

    .line 171
    .line 172
    const/16 v13, 0x400

    .line 173
    .line 174
    const/16 v15, 0x403

    .line 175
    .line 176
    if-le v6, v15, :cond_6

    .line 177
    .line 178
    const/16 v6, 0xf2

    .line 179
    .line 180
    filled-new-array {v9, v10, v12, v6}, [I

    .line 181
    .line 182
    .line 183
    move-result-object v6

    .line 184
    invoke-static {v13, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 185
    .line 186
    .line 187
    move-result v6

    .line 188
    if-eqz v6, :cond_6

    .line 189
    .line 190
    const-string v5, "F2FS filesystem"

    .line 191
    .line 192
    goto/16 :goto_2

    .line 193
    .line 194
    :cond_6
    array-length v6, v1

    .line 195
    if-le v6, v15, :cond_7

    .line 196
    .line 197
    const/16 v6, 0xe2

    .line 198
    .line 199
    const/16 v15, 0xe1

    .line 200
    .line 201
    const/16 v11, 0xe0

    .line 202
    .line 203
    filled-new-array {v6, v15, v12, v11}, [I

    .line 204
    .line 205
    .line 206
    move-result-object v6

    .line 207
    invoke-static {v13, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 208
    .line 209
    .line 210
    move-result v6

    .line 211
    if-eqz v6, :cond_7

    .line 212
    .line 213
    const-string v5, "EROFS filesystem"

    .line 214
    .line 215
    goto :goto_2

    .line 216
    :cond_7
    const/16 v6, 0x55

    .line 217
    .line 218
    const/16 v11, 0x49

    .line 219
    .line 220
    const/16 v12, 0x23

    .line 221
    .line 222
    filled-new-array {v6, v14, v11, v12}, [I

    .line 223
    .line 224
    .line 225
    move-result-object v6

    .line 226
    invoke-static {v3, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 227
    .line 228
    .line 229
    move-result v6

    .line 230
    if-eqz v6, :cond_8

    .line 231
    .line 232
    const-string v5, "UBI/NAND image"

    .line 233
    .line 234
    goto :goto_2

    .line 235
    :cond_8
    const/16 v6, 0x4c

    .line 236
    .line 237
    const/16 v11, 0x46

    .line 238
    .line 239
    const/16 v12, 0x7f

    .line 240
    .line 241
    const/16 v13, 0x45

    .line 242
    .line 243
    filled-new-array {v12, v13, v6, v11}, [I

    .line 244
    .line 245
    .line 246
    move-result-object v6

    .line 247
    invoke-static {v3, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 248
    .line 249
    .line 250
    move-result v6

    .line 251
    if-eqz v6, :cond_9

    .line 252
    .line 253
    const-string v5, "ELF binary"

    .line 254
    .line 255
    goto :goto_2

    .line 256
    :cond_9
    const/4 v6, 0x3

    .line 257
    const/4 v11, 0x4

    .line 258
    const/16 v12, 0x50

    .line 259
    .line 260
    const/16 v13, 0x4b

    .line 261
    .line 262
    filled-new-array {v12, v13, v6, v11}, [I

    .line 263
    .line 264
    .line 265
    move-result-object v6

    .line 266
    invoke-static {v3, v1, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    .line 267
    .line 268
    .line 269
    move-result v6

    .line 270
    if-eqz v6, :cond_a

    .line 271
    .line 272
    const-string v5, "ZIP/package data"

    .line 273
    .line 274
    goto :goto_2

    .line 275
    :cond_a
    if-nez v5, :cond_b

    .line 276
    .line 277
    move-object v5, v8

    .line 278
    goto :goto_0

    .line 279
    :cond_b
    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 280
    .line 281
    invoke-virtual {v5, v6}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 282
    .line 283
    .line 284
    move-result-object v5

    .line 285
    :goto_0
    invoke-virtual {v5, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 286
    .line 287
    .line 288
    move-result v5

    .line 289
    if-eqz v5, :cond_c

    .line 290
    .line 291
    const-string v5, "Userdata/raw data"

    .line 292
    .line 293
    goto :goto_2

    .line 294
    :cond_c
    const-string v5, "Unknown/raw data"

    .line 295
    .line 296
    goto :goto_2

    .line 297
    :cond_d
    :goto_1
    const-string v5, "SquashFS filesystem"

    .line 298
    .line 299
    :goto_2
    iput-object v5, v2, Le/c;->b:Ljava/lang/Object;

    .line 300
    .line 301
    if-eqz v1, :cond_11

    .line 302
    .line 303
    array-length v5, v1

    .line 304
    if-nez v5, :cond_e

    .line 305
    .line 306
    goto :goto_4

    .line 307
    :cond_e
    new-instance v5, Ljava/lang/StringBuilder;

    .line 308
    .line 309
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 310
    .line 311
    .line 312
    array-length v6, v1

    .line 313
    invoke-static {v6, v9}, Ljava/lang/Math;->min(II)I

    .line 314
    .line 315
    .line 316
    move-result v6

    .line 317
    :goto_3
    if-ge v3, v6, :cond_10

    .line 318
    .line 319
    if-lez v3, :cond_f

    .line 320
    .line 321
    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 322
    .line 323
    .line 324
    :cond_f
    sget-object v9, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 325
    .line 326
    aget-byte v11, v1, v3

    .line 327
    .line 328
    const/16 v12, 0xff

    .line 329
    .line 330
    and-int/2addr v11, v12

    .line 331
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 332
    .line 333
    .line 334
    move-result-object v11

    .line 335
    filled-new-array {v11}, [Ljava/lang/Object;

    .line 336
    .line 337
    .line 338
    move-result-object v11

    .line 339
    const-string v13, "%02X"

    .line 340
    .line 341
    invoke-static {v9, v13, v11}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object v9

    .line 345
    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 346
    .line 347
    .line 348
    add-int/lit8 v3, v3, 0x1

    .line 349
    .line 350
    goto :goto_3

    .line 351
    :cond_10
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 352
    .line 353
    .line 354
    move-result-object v1

    .line 355
    goto :goto_5

    .line 356
    :cond_11
    :goto_4
    const-string v1, "empty"

    .line 357
    .line 358
    :goto_5
    iput-object v1, v2, Le/c;->c:Ljava/lang/Object;

    .line 359
    .line 360
    iget-object v1, v2, Le/c;->b:Ljava/lang/Object;

    .line 361
    .line 362
    check-cast v1, Ljava/lang/String;

    .line 363
    .line 364
    iget-object v0, v0, Lg1/h1;->a:Ljava/lang/String;

    .line 365
    .line 366
    if-nez v0, :cond_12

    .line 367
    .line 368
    goto :goto_6

    .line 369
    :cond_12
    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 370
    .line 371
    invoke-virtual {v0, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v8

    .line 375
    :goto_6
    const-string v0, "EXT4"

    .line 376
    .line 377
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 378
    .line 379
    .line 380
    move-result v0

    .line 381
    if-nez v0, :cond_1a

    .line 382
    .line 383
    const-string v0, "EROFS"

    .line 384
    .line 385
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 386
    .line 387
    .line 388
    move-result v0

    .line 389
    if-nez v0, :cond_1a

    .line 390
    .line 391
    const-string v0, "SquashFS"

    .line 392
    .line 393
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 394
    .line 395
    .line 396
    move-result v0

    .line 397
    if-nez v0, :cond_1a

    .line 398
    .line 399
    const-string v0, "F2FS"

    .line 400
    .line 401
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 402
    .line 403
    .line 404
    move-result v0

    .line 405
    if-eqz v0, :cond_13

    .line 406
    .line 407
    goto :goto_7

    .line 408
    :cond_13
    const-string v0, "Android boot"

    .line 409
    .line 410
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 411
    .line 412
    .line 413
    move-result v0

    .line 414
    if-eqz v0, :cond_14

    .line 415
    .line 416
    const-string v0, "Boot/recovery image detected. Can be extracted and compared."

    .line 417
    .line 418
    goto :goto_8

    .line 419
    :cond_14
    const-string v0, "AVB/vbmeta"

    .line 420
    .line 421
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 422
    .line 423
    .line 424
    move-result v0

    .line 425
    if-eqz v0, :cond_15

    .line 426
    .line 427
    const-string v0, "Verified boot metadata detected."

    .line 428
    .line 429
    goto :goto_8

    .line 430
    :cond_15
    const-string v0, "DTBO"

    .line 431
    .line 432
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 433
    .line 434
    .line 435
    move-result v0

    .line 436
    if-eqz v0, :cond_16

    .line 437
    .line 438
    const-string v0, "Device-tree overlay image detected."

    .line 439
    .line 440
    goto :goto_8

    .line 441
    :cond_16
    const-string v0, "Sparse"

    .line 442
    .line 443
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 444
    .line 445
    .line 446
    move-result v0

    .line 447
    if-eqz v0, :cond_17

    .line 448
    .line 449
    const-string v0, "Android sparse image detected. Convert to raw before filesystem parsing."

    .line 450
    .line 451
    goto :goto_8

    .line 452
    :cond_17
    invoke-virtual {v8, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 453
    .line 454
    .line 455
    move-result v0

    .line 456
    if-eqz v0, :cond_18

    .line 457
    .line 458
    const-string v0, "Userdata may be encrypted. Extraction works, but contents may not open."

    .line 459
    .line 460
    goto :goto_8

    .line 461
    :cond_18
    const-string v0, "raw_"

    .line 462
    .line 463
    invoke-virtual {v8, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 464
    .line 465
    .line 466
    move-result v0

    .line 467
    if-eqz v0, :cond_19

    .line 468
    .line 469
    const-string v0, "Raw scan block detected. App can extract/check this range. Use OPEN FILES IN SELECTED PARTITION for EXT4 folders."

    .line 470
    .line 471
    goto :goto_8

    .line 472
    :cond_19
    const-string v0, "Raw or unknown partition. Extraction and compare still work."

    .line 473
    .line 474
    goto :goto_8

    .line 475
    :cond_1a
    :goto_7
    const-string v0, "Linux/Android filesystem detected. Good for system/vendor/product extraction."

    .line 476
    .line 477
    :goto_8
    iput-object v0, v2, Le/c;->d:Ljava/lang/Object;

    .line 478
    .line 479
    return-object v2

    .line 480
    nop

    .line 481
    :array_0
    .array-data 4
        0x41
        0x4e
        0x44
        0x52
        0x4f
        0x49
        0x44
        0x21
    .end array-data
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
.end method

.method public final G(Lg1/d1;J)Ljava/util/ArrayList;
    .locals 11

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->O(Lg1/d1;J)[B

    .line 2
    .line 3
    .line 4
    move-result-object v2

    .line 5
    invoke-static {v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->D([B)J

    .line 6
    .line 7
    .line 8
    move-result-wide p2

    .line 9
    const-wide/32 v0, 0x800000

    .line 10
    .line 11
    .line 12
    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 13
    .line 14
    .line 15
    move-result-wide v4

    .line 16
    new-instance p2, Ljava/io/ByteArrayOutputStream;

    .line 17
    .line 18
    const-wide/32 v0, 0x100000

    .line 19
    .line 20
    .line 21
    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 22
    .line 23
    .line 24
    move-result-wide v0

    .line 25
    long-to-int p3, v0

    .line 26
    invoke-direct {p2, p3}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 27
    .line 28
    .line 29
    move-object v0, p0

    .line 30
    move-object v1, p1

    .line 31
    move-object v3, p2

    .line 32
    invoke-virtual/range {v0 .. v5}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->u(Lg1/d1;[BLjava/io/OutputStream;J)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    new-instance p3, Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    .line 42
    .line 43
    .line 44
    const/4 v0, 0x0

    .line 45
    move v1, v0

    .line 46
    :cond_0
    :goto_0
    add-int/lit8 v2, v1, 0x8

    .line 47
    .line 48
    array-length v3, p2

    .line 49
    if-gt v2, v3, :cond_5

    .line 50
    .line 51
    invoke-static {p2, v1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    .line 52
    .line 53
    .line 54
    move-result-wide v3

    .line 55
    add-int/lit8 v5, v1, 0x4

    .line 56
    .line 57
    invoke-static {p2, v5}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 58
    .line 59
    .line 60
    move-result v5

    .line 61
    add-int/lit8 v6, v1, 0x6

    .line 62
    .line 63
    aget-byte v6, p2, v6

    .line 64
    .line 65
    and-int/lit16 v6, v6, 0xff

    .line 66
    .line 67
    add-int/lit8 v7, v1, 0x7

    .line 68
    .line 69
    aget-byte v7, p2, v7

    .line 70
    .line 71
    and-int/lit16 v7, v7, 0xff

    .line 72
    .line 73
    const/16 v8, 0x8

    .line 74
    .line 75
    if-lt v5, v8, :cond_5

    .line 76
    .line 77
    add-int/2addr v1, v5

    .line 78
    array-length v8, p2

    .line 79
    if-le v1, v8, :cond_1

    .line 80
    .line 81
    goto :goto_4

    .line 82
    :cond_1
    const-wide/16 v8, 0x0

    .line 83
    .line 84
    cmp-long v10, v3, v8

    .line 85
    .line 86
    if-lez v10, :cond_0

    .line 87
    .line 88
    if-lez v6, :cond_0

    .line 89
    .line 90
    add-int/lit8 v5, v5, -0x8

    .line 91
    .line 92
    if-gt v6, v5, :cond_0

    .line 93
    .line 94
    new-instance v5, Ljava/lang/String;

    .line 95
    .line 96
    const-string v10, "UTF-8"

    .line 97
    .line 98
    invoke-static {v10}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 99
    .line 100
    .line 101
    move-result-object v10

    .line 102
    invoke-direct {v5, p2, v2, v6, v10}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 103
    .line 104
    .line 105
    const-string v2, "."

    .line 106
    .line 107
    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v2

    .line 111
    if-nez v2, :cond_0

    .line 112
    .line 113
    const-string v2, ".."

    .line 114
    .line 115
    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    if-nez v2, :cond_0

    .line 120
    .line 121
    new-instance v2, Lg1/f1;

    .line 122
    .line 123
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 124
    .line 125
    .line 126
    iput-object v5, v2, Lg1/f1;->a:Ljava/lang/String;

    .line 127
    .line 128
    iput-wide v3, v2, Lg1/f1;->b:J

    .line 129
    .line 130
    const/4 v5, 0x2

    .line 131
    const/4 v6, 0x1

    .line 132
    if-ne v7, v5, :cond_2

    .line 133
    .line 134
    move v5, v6

    .line 135
    goto :goto_1

    .line 136
    :cond_2
    move v5, v0

    .line 137
    :goto_1
    iput-boolean v5, v2, Lg1/f1;->d:Z

    .line 138
    .line 139
    :try_start_0
    invoke-virtual {p0, p1, v3, v4}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->O(Lg1/d1;J)[B

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    invoke-static {v3, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 144
    .line 145
    .line 146
    move-result v4

    .line 147
    const v5, 0xf000

    .line 148
    .line 149
    .line 150
    and-int/2addr v4, v5

    .line 151
    iget-boolean v5, v2, Lg1/f1;->d:Z

    .line 152
    .line 153
    if-nez v5, :cond_4

    .line 154
    .line 155
    const/16 v5, 0x4000

    .line 156
    .line 157
    if-ne v4, v5, :cond_3

    .line 158
    .line 159
    goto :goto_2

    .line 160
    :cond_3
    move v6, v0

    .line 161
    :cond_4
    :goto_2
    iput-boolean v6, v2, Lg1/f1;->d:Z

    .line 162
    .line 163
    invoke-static {v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->D([B)J

    .line 164
    .line 165
    .line 166
    move-result-wide v3

    .line 167
    iput-wide v3, v2, Lg1/f1;->c:J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 168
    .line 169
    goto :goto_3

    .line 170
    :catch_0
    iput-wide v8, v2, Lg1/f1;->c:J

    .line 171
    .line 172
    :goto_3
    invoke-virtual {p3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    goto/16 :goto_0

    .line 176
    .line 177
    :cond_5
    :goto_4
    return-object p3
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public final H(Landroid/net/Uri;J)Lg1/d1;
    .locals 5

    .line 1
    const-wide/16 v0, 0x400

    .line 2
    .line 3
    add-long/2addr v0, p2

    .line 4
    const/16 v2, 0x400

    .line 5
    .line 6
    invoke-virtual {p0, p1, v0, v1, v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P(Landroid/net/Uri;JI)[B

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const/16 v1, 0x38

    .line 11
    .line 12
    invoke-static {v0, v1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const v3, 0xef53

    .line 17
    .line 18
    .line 19
    if-ne v1, v3, :cond_4

    .line 20
    .line 21
    new-instance v1, Lg1/d1;

    .line 22
    .line 23
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object p1, v1, Lg1/d1;->a:Landroid/net/Uri;

    .line 27
    .line 28
    iput-wide p2, v1, Lg1/d1;->b:J

    .line 29
    .line 30
    const/16 p1, 0x18

    .line 31
    .line 32
    invoke-static {v0, p1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    .line 33
    .line 34
    .line 35
    move-result-wide v3

    .line 36
    long-to-int p1, v3

    .line 37
    shl-int p1, v2, p1

    .line 38
    .line 39
    iput p1, v1, Lg1/d1;->c:I

    .line 40
    .line 41
    const/16 p1, 0x20

    .line 42
    .line 43
    invoke-static {v0, p1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    .line 44
    .line 45
    .line 46
    move-result-wide v3

    .line 47
    iput-wide v3, v1, Lg1/d1;->d:J

    .line 48
    .line 49
    const/16 v3, 0x28

    .line 50
    .line 51
    invoke-static {v0, v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    .line 52
    .line 53
    .line 54
    move-result-wide v3

    .line 55
    iput-wide v3, v1, Lg1/d1;->e:J

    .line 56
    .line 57
    const/16 v3, 0x58

    .line 58
    .line 59
    invoke-static {v0, v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    if-lez v3, :cond_0

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_0
    const/16 v3, 0x80

    .line 67
    .line 68
    :goto_0
    iput v3, v1, Lg1/d1;->f:I

    .line 69
    .line 70
    const/16 v3, 0xfe

    .line 71
    .line 72
    invoke-static {v0, v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-lt v0, p1, :cond_1

    .line 77
    .line 78
    move p1, v0

    .line 79
    :cond_1
    iput p1, v1, Lg1/d1;->g:I

    .line 80
    .line 81
    iget p1, v1, Lg1/d1;->c:I

    .line 82
    .line 83
    if-ne p1, v2, :cond_2

    .line 84
    .line 85
    const-wide/16 v2, 0x800

    .line 86
    .line 87
    goto :goto_1

    .line 88
    :cond_2
    int-to-long v2, p1

    .line 89
    :goto_1
    add-long/2addr p2, v2

    .line 90
    iput-wide p2, v1, Lg1/d1;->h:J

    .line 91
    .line 92
    if-lez p1, :cond_3

    .line 93
    .line 94
    iget-wide p1, v1, Lg1/d1;->e:J

    .line 95
    .line 96
    const-wide/16 v2, 0x0

    .line 97
    .line 98
    cmp-long p1, p1, v2

    .line 99
    .line 100
    if-lez p1, :cond_3

    .line 101
    .line 102
    iget-wide p1, v1, Lg1/d1;->d:J

    .line 103
    .line 104
    cmp-long p1, p1, v2

    .line 105
    .line 106
    if-lez p1, :cond_3

    .line 107
    .line 108
    return-object v1

    .line 109
    :cond_3
    new-instance p1, Ljava/lang/Exception;

    .line 110
    .line 111
    const-string p2, "EXT4 layout values invalid"

    .line 112
    .line 113
    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    throw p1

    .line 117
    :cond_4
    new-instance p1, Ljava/lang/Exception;

    .line 118
    .line 119
    const-string p2, "EXT4 magic not found"

    .line 120
    .line 121
    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    throw p1
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public final I(Landroid/net/Uri;JLjava/lang/String;)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->S:Lg1/d1;

    .line 3
    .line 4
    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->T:Lg1/f1;

    .line 5
    .line 6
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P:Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->Q:Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->R:Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->I:Landroid/widget/ArrayAdapter;

    .line 22
    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    invoke-virtual {v0}, Landroid/widget/ArrayAdapter;->notifyDataSetChanged()V

    .line 26
    .line 27
    .line 28
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 29
    .line 30
    const-string v1, "Opening filesystem: "

    .line 31
    .line 32
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    new-instance v0, Ljava/lang/Thread;

    .line 46
    .line 47
    new-instance v7, Lg1/q0;

    .line 48
    .line 49
    move-object v1, v7

    .line 50
    move-object v2, p0

    .line 51
    move-object v3, p1

    .line 52
    move-wide v4, p2

    .line 53
    move-object v6, p4

    .line 54
    invoke-direct/range {v1 .. v6}, Lg1/q0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;Landroid/net/Uri;JLjava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-direct {v0, v7}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 61
    .line 62
    .line 63
    return-void
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public final O(Lg1/d1;J)[B
    .locals 8

    .line 1
    const-wide/16 v0, 0x1

    sub-long/2addr p2, v0

    iget-wide v0, p1, Lg1/d1;->e:J

    div-long v2, p2, v0

    rem-long/2addr p2, v0

    iget-object v0, p1, Lg1/d1;->a:Landroid/net/Uri;

    iget-wide v4, p1, Lg1/d1;->h:J

    iget v1, p1, Lg1/d1;->g:I

    int-to-long v6, v1

    mul-long/2addr v2, v6

    add-long/2addr v2, v4

    invoke-virtual {p0, v0, v2, v3, v1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P(Landroid/net/Uri;JI)[B

    move-result-object v0

    const/16 v1, 0x8

    invoke-static {v0, v1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    move-result-wide v1

    iget v3, p1, Lg1/d1;->g:I

    const/16 v4, 0x40

    if-lt v3, v4, :cond_0

    const/16 v3, 0x28

    invoke-static {v0, v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    move-result-wide v3

    const/16 v0, 0x20

    shl-long/2addr v3, v0

    or-long/2addr v1, v3

    :cond_0
    iget-wide v3, p1, Lg1/d1;->b:J

    iget v0, p1, Lg1/d1;->c:I

    int-to-long v5, v0

    mul-long/2addr v1, v5

    add-long/2addr v1, v3

    iget v0, p1, Lg1/d1;->f:I

    int-to-long v3, v0

    mul-long/2addr p2, v3

    add-long/2addr p2, v1

    iget-object p1, p1, Lg1/d1;->a:Landroid/net/Uri;

    invoke-virtual {p0, p1, p2, p3, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P(Landroid/net/Uri;JI)[B

    move-result-object p1

    return-object p1
.end method

.method public final P(Landroid/net/Uri;JI)[B
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "r"

    invoke-virtual {v0, p1, v1}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    move-result-object p1

    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-virtual {v0}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    invoke-static {p4}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object p4

    invoke-virtual {v1, p2, p3}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    :cond_0
    invoke-virtual {p4}, Ljava/nio/Buffer;->hasRemaining()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-virtual {v1, p4}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result p2

    if-gez p2, :cond_0

    goto :goto_0

    :catchall_0
    move-exception p2

    goto :goto_1

    :cond_1
    :goto_0
    invoke-virtual {p4}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    invoke-virtual {v1}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :try_start_4
    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V

    return-object p2

    :catchall_1
    move-exception p2

    goto :goto_5

    :catchall_2
    move-exception p2

    goto :goto_3

    :goto_1
    if-eqz v1, :cond_2

    :try_start_5
    invoke-virtual {v1}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    goto :goto_2

    :catchall_3
    move-exception p3

    :try_start_6
    invoke-virtual {p2, p3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2
    :goto_2
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :goto_3
    :try_start_7
    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    goto :goto_4

    :catchall_4
    move-exception p3

    :try_start_8
    invoke-virtual {p2, p3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :goto_5
    if-eqz p1, :cond_3

    :try_start_9
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    goto :goto_6

    :catchall_5
    move-exception p1

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_3
    :goto_6
    throw p2
.end method

.method public final Q(Ljava/util/List;)V
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->T:Lg1/f1;

    .line 3
    .line 4
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 7
    .line 8
    .line 9
    iget-object v1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->Q:Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 12
    .line 13
    .line 14
    iget-object v2, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->R:Ljava/util/ArrayList;

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-nez v2, :cond_0

    .line 21
    .line 22
    new-instance v2, Lg1/f1;

    .line 23
    .line 24
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 25
    .line 26
    .line 27
    const-string v3, ".."

    .line 28
    .line 29
    iput-object v3, v2, Lg1/f1;->a:Ljava/lang/String;

    .line 30
    .line 31
    const/4 v3, 0x1

    .line 32
    iput-boolean v3, v2, Lg1/f1;->d:Z

    .line 33
    .line 34
    iput-boolean v3, v2, Lg1/f1;->e:Z

    .line 35
    .line 36
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    const-string v2, "[..]\nParent folder"

    .line 40
    .line 41
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    :cond_0
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    if-eqz v3, :cond_2

    .line 53
    .line 54
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    check-cast v3, Lg1/f1;

    .line 59
    .line 60
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    new-instance v4, Ljava/lang/StringBuilder;

    .line 64
    .line 65
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 66
    .line 67
    .line 68
    iget-boolean v5, v3, Lg1/f1;->d:Z

    .line 69
    .line 70
    if-eqz v5, :cond_1

    .line 71
    .line 72
    const-string v5, "[DIR] "

    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_1
    const-string v5, "[FILE] "

    .line 76
    .line 77
    :goto_1
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    iget-object v5, v3, Lg1/f1;->a:Ljava/lang/String;

    .line 81
    .line 82
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    const-string v5, "\n"

    .line 86
    .line 87
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    iget-wide v5, v3, Lg1/f1;->c:J

    .line 91
    .line 92
    invoke-static {v5, v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->z(J)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    goto :goto_0

    .line 107
    :cond_2
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->I:Landroid/widget/ArrayAdapter;

    .line 108
    .line 109
    invoke-virtual {v0}, Landroid/widget/ArrayAdapter;->notifyDataSetChanged()V

    .line 110
    .line 111
    .line 112
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->D:Landroid/widget/TextView;

    .line 113
    .line 114
    new-instance v1, Ljava/lang/StringBuilder;

    .line 115
    .line 116
    const-string v2, "EXT4 folder loaded\nEntries: "

    .line 117
    .line 118
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 122
    .line 123
    .line 124
    move-result p1

    .line 125
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    const-string p1, "\nTap folder to open or file to extract."

    .line 129
    .line 130
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 138
    .line 139
    .line 140
    return-void
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final R(Ljava/util/ArrayList;)V
    .locals 5

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->N:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->O:Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_2

    .line 23
    .line 24
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    check-cast v0, Lg1/h1;

    .line 29
    .line 30
    new-instance v2, Ljava/lang/StringBuilder;

    .line 31
    .line 32
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 33
    .line 34
    .line 35
    iget-object v3, v0, Lg1/h1;->a:Ljava/lang/String;

    .line 36
    .line 37
    if-eqz v3, :cond_1

    .line 38
    .line 39
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    if-eqz v4, :cond_0

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_0
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    goto :goto_2

    .line 55
    :cond_1
    :goto_1
    const-string v3, "partition"

    .line 56
    .line 57
    :goto_2
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    const-string v3, "\nStart LBA: "

    .line 61
    .line 62
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    iget-wide v3, v0, Lg1/h1;->b:J

    .line 66
    .line 67
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    const-string v3, "   Size: "

    .line 71
    .line 72
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-virtual {v0}, Lg1/h1;->a()J

    .line 76
    .line 77
    .line 78
    move-result-wide v3

    .line 79
    invoke-static {v3, v4}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->z(J)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_2
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->H:Landroid/widget/ArrayAdapter;

    .line 95
    .line 96
    invoke-virtual {p1}, Landroid/widget/ArrayAdapter;->notifyDataSetChanged()V

    .line 97
    .line 98
    .line 99
    return-void
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final S(Landroid/net/Uri;J)Lg1/g1;
    .locals 18

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v2, "r"

    .line 11
    .line 12
    move-object/from16 v3, p1

    .line 13
    .line 14
    invoke-virtual {v1, v3, v2}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    :try_start_0
    new-instance v2, Ljava/io/FileInputStream;

    .line 19
    .line 20
    invoke-virtual {v1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    invoke-direct {v2, v3}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 25
    .line 26
    .line 27
    :try_start_1
    invoke-virtual {v2}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 28
    .line 29
    .line 30
    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 31
    const-wide/16 v4, 0x0

    .line 32
    .line 33
    :cond_0
    cmp-long v6, v4, p2

    .line 34
    .line 35
    const/4 v7, 0x0

    .line 36
    if-gez v6, :cond_8

    .line 37
    .line 38
    :try_start_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 39
    .line 40
    .line 41
    move-result v6

    .line 42
    const/16 v8, 0x50

    .line 43
    .line 44
    if-ge v6, v8, :cond_8

    .line 45
    .line 46
    const-wide/32 v9, 0x402000

    .line 47
    .line 48
    .line 49
    sub-long v11, p2, v4

    .line 50
    .line 51
    invoke-static {v9, v10, v11, v12}, Ljava/lang/Math;->min(JJ)J

    .line 52
    .line 53
    .line 54
    move-result-wide v9

    .line 55
    long-to-int v6, v9

    .line 56
    invoke-static {v6}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 57
    .line 58
    .line 59
    move-result-object v6

    .line 60
    invoke-virtual {v3, v4, v5}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    .line 61
    .line 62
    .line 63
    :cond_1
    invoke-virtual {v6}, Ljava/nio/Buffer;->hasRemaining()Z

    .line 64
    .line 65
    .line 66
    move-result v9

    .line 67
    if-eqz v9, :cond_2

    .line 68
    .line 69
    invoke-virtual {v3, v6}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    .line 70
    .line 71
    .line 72
    move-result v9

    .line 73
    if-gez v9, :cond_1

    .line 74
    .line 75
    goto :goto_0

    .line 76
    :catchall_0
    move-exception v0

    .line 77
    move-object v4, v0

    .line 78
    goto :goto_3

    .line 79
    :cond_2
    :goto_0
    invoke-virtual {v6}, Ljava/nio/ByteBuffer;->array()[B

    .line 80
    .line 81
    .line 82
    move-result-object v6

    .line 83
    move v9, v7

    .line 84
    :goto_1
    add-int/lit8 v10, v9, 0x8

    .line 85
    .line 86
    array-length v11, v6

    .line 87
    if-ge v10, v11, :cond_6

    .line 88
    .line 89
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 90
    .line 91
    .line 92
    move-result v10

    .line 93
    if-ge v10, v8, :cond_6

    .line 94
    .line 95
    invoke-static {v6, v9}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->x([BI)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v10

    .line 99
    if-eqz v10, :cond_5

    .line 100
    .line 101
    int-to-long v11, v9

    .line 102
    add-long/2addr v11, v4

    .line 103
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 104
    .line 105
    .line 106
    move-result-object v13

    .line 107
    :cond_3
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 108
    .line 109
    .line 110
    move-result v14

    .line 111
    if-eqz v14, :cond_4

    .line 112
    .line 113
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v14

    .line 117
    check-cast v14, Lg1/i1;

    .line 118
    .line 119
    iget-wide v14, v14, Lg1/i1;->a:J

    .line 120
    .line 121
    sub-long/2addr v14, v11

    .line 122
    invoke-static {v14, v15}, Ljava/lang/Math;->abs(J)J

    .line 123
    .line 124
    .line 125
    move-result-wide v14

    .line 126
    const-wide/16 v16, 0x2000

    .line 127
    .line 128
    cmp-long v14, v14, v16

    .line 129
    .line 130
    if-gez v14, :cond_3

    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_4
    new-instance v13, Lg1/i1;

    .line 134
    .line 135
    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    .line 136
    .line 137
    .line 138
    iput-wide v11, v13, Lg1/i1;->a:J

    .line 139
    .line 140
    iput-object v10, v13, Lg1/i1;->b:Ljava/lang/String;

    .line 141
    .line 142
    invoke-virtual {v0, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 143
    .line 144
    .line 145
    :cond_5
    :goto_2
    add-int/lit16 v9, v9, 0x200

    .line 146
    .line 147
    goto :goto_1

    .line 148
    :cond_6
    const-wide/32 v8, 0x400000

    .line 149
    .line 150
    .line 151
    add-long/2addr v4, v8

    .line 152
    cmp-long v6, v4, p2

    .line 153
    .line 154
    if-ltz v6, :cond_0

    .line 155
    .line 156
    goto :goto_5

    .line 157
    :goto_3
    if-eqz v3, :cond_7

    .line 158
    .line 159
    :try_start_3
    invoke-virtual {v3}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 160
    .line 161
    .line 162
    goto :goto_4

    .line 163
    :catchall_1
    move-exception v0

    .line 164
    move-object v3, v0

    .line 165
    :try_start_4
    invoke-virtual {v4, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 166
    .line 167
    .line 168
    goto :goto_4

    .line 169
    :catchall_2
    move-exception v0

    .line 170
    move-object v3, v0

    .line 171
    goto/16 :goto_8

    .line 172
    .line 173
    :cond_7
    :goto_4
    throw v4

    .line 174
    :cond_8
    :goto_5
    if-eqz v3, :cond_9

    .line 175
    .line 176
    invoke-virtual {v3}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 177
    .line 178
    .line 179
    :cond_9
    :try_start_5
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 180
    .line 181
    .line 182
    invoke-virtual {v1}, Landroid/os/ParcelFileDescriptor;->close()V

    .line 183
    .line 184
    .line 185
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 186
    .line 187
    .line 188
    move-result v1

    .line 189
    const/4 v2, 0x0

    .line 190
    if-eqz v1, :cond_a

    .line 191
    .line 192
    return-object v2

    .line 193
    :cond_a
    new-instance v1, Ljava/util/ArrayList;

    .line 194
    .line 195
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 196
    .line 197
    .line 198
    move v3, v7

    .line 199
    :goto_6
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 200
    .line 201
    .line 202
    move-result v4

    .line 203
    const/4 v5, 0x1

    .line 204
    if-ge v3, v4, :cond_d

    .line 205
    .line 206
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v4

    .line 210
    check-cast v4, Lg1/i1;

    .line 211
    .line 212
    add-int/lit8 v3, v3, 0x1

    .line 213
    .line 214
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 215
    .line 216
    .line 217
    move-result v6

    .line 218
    if-ge v3, v6, :cond_b

    .line 219
    .line 220
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v6

    .line 224
    check-cast v6, Lg1/i1;

    .line 225
    .line 226
    iget-wide v8, v6, Lg1/i1;->a:J

    .line 227
    .line 228
    goto :goto_7

    .line 229
    :cond_b
    move-wide/from16 v8, p2

    .line 230
    .line 231
    :goto_7
    iget-wide v10, v4, Lg1/i1;->a:J

    .line 232
    .line 233
    const-wide/16 v12, 0x200

    .line 234
    .line 235
    add-long/2addr v10, v12

    .line 236
    cmp-long v6, v8, v10

    .line 237
    .line 238
    if-gtz v6, :cond_c

    .line 239
    .line 240
    goto :goto_6

    .line 241
    :cond_c
    new-instance v6, Lg1/h1;

    .line 242
    .line 243
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 244
    .line 245
    .line 246
    new-instance v10, Ljava/lang/StringBuilder;

    .line 247
    .line 248
    const-string v11, "raw_"

    .line 249
    .line 250
    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 251
    .line 252
    .line 253
    iget-object v11, v4, Lg1/i1;->b:Ljava/lang/String;

    .line 254
    .line 255
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 256
    .line 257
    .line 258
    const-string v11, "_"

    .line 259
    .line 260
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 261
    .line 262
    .line 263
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 264
    .line 265
    .line 266
    move-result v11

    .line 267
    add-int/2addr v11, v5

    .line 268
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 269
    .line 270
    .line 271
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 272
    .line 273
    .line 274
    move-result-object v5

    .line 275
    iput-object v5, v6, Lg1/h1;->a:Ljava/lang/String;

    .line 276
    .line 277
    iget-wide v4, v4, Lg1/i1;->a:J

    .line 278
    .line 279
    div-long/2addr v4, v12

    .line 280
    iput-wide v4, v6, Lg1/h1;->b:J

    .line 281
    .line 282
    const-wide/16 v10, 0x1

    .line 283
    .line 284
    sub-long/2addr v8, v10

    .line 285
    div-long/2addr v8, v12

    .line 286
    invoke-static {v4, v5, v8, v9}, Ljava/lang/Math;->max(JJ)J

    .line 287
    .line 288
    .line 289
    move-result-wide v4

    .line 290
    iput-wide v4, v6, Lg1/h1;->c:J

    .line 291
    .line 292
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    goto :goto_6

    .line 296
    :cond_d
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 297
    .line 298
    .line 299
    move-result v0

    .line 300
    if-eqz v0, :cond_e

    .line 301
    .line 302
    return-object v2

    .line 303
    :cond_e
    new-instance v0, Lg1/g1;

    .line 304
    .line 305
    invoke-direct {v0}, Lg1/g1;-><init>()V

    .line 306
    .line 307
    .line 308
    iput-boolean v5, v0, Lg1/g1;->a:Z

    .line 309
    .line 310
    iput-boolean v5, v0, Lg1/g1;->b:Z

    .line 311
    .line 312
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 313
    .line 314
    .line 315
    move-result-object v2

    .line 316
    check-cast v2, Lg1/h1;

    .line 317
    .line 318
    iget-wide v2, v2, Lg1/h1;->b:J

    .line 319
    .line 320
    iput-wide v2, v0, Lg1/g1;->c:J

    .line 321
    .line 322
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 323
    .line 324
    .line 325
    move-result v2

    .line 326
    sub-int/2addr v2, v5

    .line 327
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 328
    .line 329
    .line 330
    move-result-object v2

    .line 331
    check-cast v2, Lg1/h1;

    .line 332
    .line 333
    iget-wide v2, v2, Lg1/h1;->c:J

    .line 334
    .line 335
    iput-wide v2, v0, Lg1/g1;->d:J

    .line 336
    .line 337
    iput-object v1, v0, Lg1/g1;->f:Ljava/util/ArrayList;

    .line 338
    .line 339
    return-object v0

    .line 340
    :catchall_3
    move-exception v0

    .line 341
    move-object v2, v0

    .line 342
    goto :goto_a

    .line 343
    :goto_8
    :try_start_6
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 344
    .line 345
    .line 346
    goto :goto_9

    .line 347
    :catchall_4
    move-exception v0

    .line 348
    move-object v2, v0

    .line 349
    :try_start_7
    invoke-virtual {v3, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 350
    .line 351
    .line 352
    :goto_9
    throw v3
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 353
    :goto_a
    if-eqz v1, :cond_f

    .line 354
    .line 355
    :try_start_8
    invoke-virtual {v1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    .line 356
    .line 357
    .line 358
    goto :goto_b

    .line 359
    :catchall_5
    move-exception v0

    .line 360
    move-object v1, v0

    .line 361
    invoke-virtual {v2, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 362
    .line 363
    .line 364
    :cond_f
    :goto_b
    throw v2
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
.end method

.method public final T(Landroid/net/Uri;J)Lg1/g1;
    .locals 18

    .line 1
    move-wide/from16 v0, p2

    .line 2
    .line 3
    const-wide/32 v2, 0x2000000

    .line 4
    .line 5
    .line 6
    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 7
    .line 8
    .line 9
    move-result-wide v2

    .line 10
    long-to-int v2, v2

    .line 11
    const-wide/16 v3, 0x0

    .line 12
    .line 13
    move-object/from16 v5, p0

    .line 14
    .line 15
    move-object/from16 v6, p1

    .line 16
    .line 17
    invoke-virtual {v5, v6, v3, v4, v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P(Landroid/net/Uri;JI)[B

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    new-instance v6, Ljava/lang/String;

    .line 22
    .line 23
    const-string v7, "ISO-8859-1"

    .line 24
    .line 25
    invoke-static {v7}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 26
    .line 27
    .line 28
    move-result-object v7

    .line 29
    invoke-direct {v6, v2, v7}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 30
    .line 31
    .line 32
    sget-object v2, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->a0:Ljava/util/regex/Pattern;

    .line 33
    .line 34
    invoke-virtual {v2, v6}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    new-instance v6, Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 41
    .line 42
    .line 43
    :cond_0
    :goto_0
    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    .line 44
    .line 45
    .line 46
    move-result v7

    .line 47
    const/4 v8, 0x1

    .line 48
    const/4 v9, 0x0

    .line 49
    if-eqz v7, :cond_9

    .line 50
    .line 51
    :try_start_0
    invoke-virtual {v2, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v7

    .line 55
    invoke-static {v7}, Landroidx/fragment/app/e1;->c(Ljava/lang/String;)J

    .line 56
    .line 57
    .line 58
    move-result-wide v7

    .line 59
    const/4 v10, 0x2

    .line 60
    invoke-virtual {v2, v10}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v10

    .line 64
    invoke-static {v10}, Landroidx/fragment/app/e1;->c(Ljava/lang/String;)J

    .line 65
    .line 66
    .line 67
    move-result-wide v10
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 68
    cmp-long v12, v7, v3

    .line 69
    .line 70
    if-ltz v12, :cond_0

    .line 71
    .line 72
    cmp-long v12, v10, v3

    .line 73
    .line 74
    if-lez v12, :cond_0

    .line 75
    .line 76
    cmp-long v12, v7, v0

    .line 77
    .line 78
    if-ltz v12, :cond_1

    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_1
    add-long/2addr v10, v7

    .line 82
    invoke-static {v0, v1, v10, v11}, Ljava/lang/Math;->min(JJ)J

    .line 83
    .line 84
    .line 85
    move-result-wide v10

    .line 86
    const-wide/16 v12, 0x200

    .line 87
    .line 88
    add-long v14, v7, v12

    .line 89
    .line 90
    cmp-long v14, v10, v14

    .line 91
    .line 92
    if-gtz v14, :cond_2

    .line 93
    .line 94
    goto :goto_0

    .line 95
    :cond_2
    new-instance v14, Lg1/h1;

    .line 96
    .line 97
    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    .line 98
    .line 99
    .line 100
    const/4 v15, 0x3

    .line 101
    invoke-virtual {v2, v15}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v15

    .line 105
    if-nez v15, :cond_3

    .line 106
    .line 107
    const-string v15, ""

    .line 108
    .line 109
    goto :goto_1

    .line 110
    :cond_3
    invoke-virtual {v15}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v15

    .line 114
    :goto_1
    invoke-virtual {v15}, Ljava/lang/String;->length()I

    .line 115
    .line 116
    .line 117
    move-result v16

    .line 118
    move v3, v9

    .line 119
    :goto_2
    invoke-virtual {v15}, Ljava/lang/String;->length()I

    .line 120
    .line 121
    .line 122
    move-result v4

    .line 123
    if-ge v3, v4, :cond_5

    .line 124
    .line 125
    invoke-virtual {v15, v3}, Ljava/lang/String;->charAt(I)C

    .line 126
    .line 127
    .line 128
    move-result v4

    .line 129
    invoke-static {v4}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    .line 130
    .line 131
    .line 132
    move-result v17

    .line 133
    if-nez v17, :cond_4

    .line 134
    .line 135
    const/16 v12, 0x5f

    .line 136
    .line 137
    if-eq v4, v12, :cond_4

    .line 138
    .line 139
    const/16 v12, 0x2d

    .line 140
    .line 141
    if-eq v4, v12, :cond_4

    .line 142
    .line 143
    const/16 v12, 0x2e

    .line 144
    .line 145
    if-eq v4, v12, :cond_4

    .line 146
    .line 147
    goto :goto_3

    .line 148
    :cond_4
    add-int/lit8 v3, v3, 0x1

    .line 149
    .line 150
    const-wide/16 v12, 0x200

    .line 151
    .line 152
    goto :goto_2

    .line 153
    :cond_5
    move/from16 v3, v16

    .line 154
    .line 155
    :goto_3
    invoke-virtual {v15, v9, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v3

    .line 159
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v3

    .line 163
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    .line 164
    .line 165
    .line 166
    move-result v4

    .line 167
    if-eqz v4, :cond_6

    .line 168
    .line 169
    const-string v3, "partition"

    .line 170
    .line 171
    :cond_6
    iput-object v3, v14, Lg1/h1;->a:Ljava/lang/String;

    .line 172
    .line 173
    const-wide/16 v3, 0x200

    .line 174
    .line 175
    div-long/2addr v7, v3

    .line 176
    iput-wide v7, v14, Lg1/h1;->b:J

    .line 177
    .line 178
    const-wide/16 v12, 0x1

    .line 179
    .line 180
    sub-long/2addr v10, v12

    .line 181
    div-long/2addr v10, v3

    .line 182
    invoke-static {v7, v8, v10, v11}, Ljava/lang/Math;->max(JJ)J

    .line 183
    .line 184
    .line 185
    move-result-wide v3

    .line 186
    iput-wide v3, v14, Lg1/h1;->c:J

    .line 187
    .line 188
    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 189
    .line 190
    .line 191
    move-result-object v3

    .line 192
    :cond_7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 193
    .line 194
    .line 195
    move-result v4

    .line 196
    if-eqz v4, :cond_8

    .line 197
    .line 198
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v4

    .line 202
    check-cast v4, Lg1/h1;

    .line 203
    .line 204
    iget-wide v7, v4, Lg1/h1;->b:J

    .line 205
    .line 206
    iget-wide v9, v14, Lg1/h1;->b:J

    .line 207
    .line 208
    cmp-long v7, v7, v9

    .line 209
    .line 210
    if-nez v7, :cond_7

    .line 211
    .line 212
    iget-wide v7, v4, Lg1/h1;->c:J

    .line 213
    .line 214
    iget-wide v9, v14, Lg1/h1;->c:J

    .line 215
    .line 216
    cmp-long v4, v7, v9

    .line 217
    .line 218
    if-nez v4, :cond_7

    .line 219
    .line 220
    goto :goto_4

    .line 221
    :cond_8
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    :catch_0
    :goto_4
    const-wide/16 v3, 0x0

    .line 225
    .line 226
    goto/16 :goto_0

    .line 227
    .line 228
    :cond_9
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    .line 229
    .line 230
    .line 231
    move-result v0

    .line 232
    if-eqz v0, :cond_a

    .line 233
    .line 234
    const/4 v0, 0x0

    .line 235
    return-object v0

    .line 236
    :cond_a
    new-instance v0, Le0/b;

    .line 237
    .line 238
    const/4 v1, 0x4

    .line 239
    invoke-direct {v0, v1}, Le0/b;-><init>(I)V

    .line 240
    .line 241
    .line 242
    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    .line 243
    .line 244
    .line 245
    new-instance v0, Lg1/g1;

    .line 246
    .line 247
    invoke-direct {v0}, Lg1/g1;-><init>()V

    .line 248
    .line 249
    .line 250
    iput-boolean v8, v0, Lg1/g1;->a:Z

    .line 251
    .line 252
    iput-boolean v8, v0, Lg1/g1;->b:Z

    .line 253
    .line 254
    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    check-cast v1, Lg1/h1;

    .line 259
    .line 260
    iget-wide v1, v1, Lg1/h1;->b:J

    .line 261
    .line 262
    iput-wide v1, v0, Lg1/g1;->c:J

    .line 263
    .line 264
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 265
    .line 266
    .line 267
    move-result v1

    .line 268
    sub-int/2addr v1, v8

    .line 269
    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v1

    .line 273
    check-cast v1, Lg1/h1;

    .line 274
    .line 275
    iget-wide v1, v1, Lg1/h1;->c:J

    .line 276
    .line 277
    iput-wide v1, v0, Lg1/g1;->d:J

    .line 278
    .line 279
    iput-object v6, v0, Lg1/g1;->f:Ljava/util/ArrayList;

    .line 280
    .line 281
    return-object v0
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public onClick(Landroid/view/View;)V
    .locals 8

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const v0, 0x7f090210

    .line 6
    .line 7
    .line 8
    const-string v1, "*/*"

    .line 9
    .line 10
    const-string v2, "application/x-img"

    .line 11
    .line 12
    const-string v3, "application/octet-stream"

    .line 13
    .line 14
    if-ne p1, v0, :cond_0

    .line 15
    .line 16
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U:Lb/h;

    .line 17
    .line 18
    filled-new-array {v3, v2, v1}, [Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    goto/16 :goto_4

    .line 26
    .line 27
    :cond_0
    const v0, 0x7f09020f

    .line 28
    .line 29
    .line 30
    const/4 v4, 0x0

    .line 31
    if-ne p1, v0, :cond_2

    .line 32
    .line 33
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->J:Lg1/c1;

    .line 34
    .line 35
    if-nez p1, :cond_1

    .line 36
    .line 37
    const-string p1, "Load dump first"

    .line 38
    .line 39
    invoke-static {p0, p1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 44
    .line 45
    .line 46
    goto/16 :goto_4

    .line 47
    .line 48
    :cond_1
    const-string p1, "Hash calculation started. Large dumps may take time."

    .line 49
    .line 50
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    new-instance p1, Ljava/lang/Thread;

    .line 54
    .line 55
    new-instance v0, Lg1/v0;

    .line 56
    .line 57
    const/4 v1, 0x1

    .line 58
    invoke-direct {v0, p0, v1}, Lg1/v0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    .line 59
    .line 60
    .line 61
    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 65
    .line 66
    .line 67
    goto/16 :goto_4

    .line 68
    .line 69
    :cond_2
    const v0, 0x7f09020c

    .line 70
    .line 71
    .line 72
    const-string v5, "Select partition first"

    .line 73
    .line 74
    const-string v6, "_"

    .line 75
    .line 76
    const-string v7, "[^A-Za-z0-9._-]+"

    .line 77
    .line 78
    if-ne p1, v0, :cond_5

    .line 79
    .line 80
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->J:Lg1/c1;

    .line 81
    .line 82
    if-eqz p1, :cond_4

    .line 83
    .line 84
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->M:Lg1/h1;

    .line 85
    .line 86
    if-nez p1, :cond_3

    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_3
    iget-object p1, p1, Lg1/h1;->a:Ljava/lang/String;

    .line 90
    .line 91
    invoke-virtual {p1, v7, v6}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    new-instance v0, Ljava/lang/StringBuilder;

    .line 96
    .line 97
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    const-string p1, ".img"

    .line 104
    .line 105
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object p1

    .line 112
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->X:Lb/h;

    .line 113
    .line 114
    invoke-virtual {v0, p1}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    goto/16 :goto_4

    .line 118
    .line 119
    :cond_4
    :goto_0
    invoke-static {p0, v5, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 124
    .line 125
    .line 126
    goto/16 :goto_4

    .line 127
    .line 128
    :cond_5
    const v0, 0x7f09020a

    .line 129
    .line 130
    .line 131
    if-ne p1, v0, :cond_6

    .line 132
    .line 133
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->s()V

    .line 134
    .line 135
    .line 136
    goto/16 :goto_4

    .line 137
    .line 138
    :cond_6
    const v0, 0x7f090213

    .line 139
    .line 140
    .line 141
    if-ne p1, v0, :cond_7

    .line 142
    .line 143
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V:Lb/h;

    .line 144
    .line 145
    filled-new-array {v3, v2, v1}, [Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    goto/16 :goto_4

    .line 153
    .line 154
    :cond_7
    const v0, 0x7f090215

    .line 155
    .line 156
    .line 157
    if-ne p1, v0, :cond_8

    .line 158
    .line 159
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->W:Lb/h;

    .line 160
    .line 161
    filled-new-array {v3, v2, v1}, [Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    goto/16 :goto_4

    .line 169
    .line 170
    :cond_8
    const v0, 0x7f09020b

    .line 171
    .line 172
    .line 173
    if-ne p1, v0, :cond_b

    .line 174
    .line 175
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->K:Lg1/c1;

    .line 176
    .line 177
    if-eqz p1, :cond_a

    .line 178
    .line 179
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->L:Lg1/c1;

    .line 180
    .line 181
    if-nez p1, :cond_9

    .line 182
    .line 183
    goto :goto_1

    .line 184
    :cond_9
    const-string p1, "Compare started. Large partitions may take time."

    .line 185
    .line 186
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    new-instance p1, Ljava/lang/Thread;

    .line 190
    .line 191
    new-instance v0, Lg1/v0;

    .line 192
    .line 193
    invoke-direct {v0, p0, v4}, Lg1/v0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    .line 194
    .line 195
    .line 196
    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 200
    .line 201
    .line 202
    goto/16 :goto_4

    .line 203
    .line 204
    :cond_a
    :goto_1
    const-string p1, "Load original and repaired first"

    .line 205
    .line 206
    invoke-static {p0, p1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 207
    .line 208
    .line 209
    move-result-object p1

    .line 210
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 211
    .line 212
    .line 213
    const-string p1, "Load ORIGINAL and REPAIRED dump first."

    .line 214
    .line 215
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V

    .line 216
    .line 217
    .line 218
    goto :goto_4

    .line 219
    :cond_b
    const v0, 0x7f090209

    .line 220
    .line 221
    .line 222
    if-ne p1, v0, :cond_e

    .line 223
    .line 224
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->J:Lg1/c1;

    .line 225
    .line 226
    if-eqz p1, :cond_d

    .line 227
    .line 228
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->M:Lg1/h1;

    .line 229
    .line 230
    if-nez v0, :cond_c

    .line 231
    .line 232
    goto :goto_2

    .line 233
    :cond_c
    iget-object p1, p1, Lg1/c1;->a:Landroid/net/Uri;

    .line 234
    .line 235
    invoke-virtual {v0}, Lg1/h1;->b()J

    .line 236
    .line 237
    .line 238
    move-result-wide v0

    .line 239
    iget-object v2, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->M:Lg1/h1;

    .line 240
    .line 241
    iget-object v2, v2, Lg1/h1;->a:Ljava/lang/String;

    .line 242
    .line 243
    invoke-virtual {p0, p1, v0, v1, v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->I(Landroid/net/Uri;JLjava/lang/String;)V

    .line 244
    .line 245
    .line 246
    goto :goto_4

    .line 247
    :cond_d
    :goto_2
    invoke-static {p0, v5, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 248
    .line 249
    .line 250
    move-result-object p1

    .line 251
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 252
    .line 253
    .line 254
    goto :goto_4

    .line 255
    :cond_e
    const v0, 0x7f090212

    .line 256
    .line 257
    .line 258
    if-ne p1, v0, :cond_f

    .line 259
    .line 260
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->Y:Lb/h;

    .line 261
    .line 262
    filled-new-array {v3, v2, v1}, [Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 267
    .line 268
    .line 269
    goto :goto_4

    .line 270
    :cond_f
    const v0, 0x7f09020d

    .line 271
    .line 272
    .line 273
    if-ne p1, v0, :cond_13

    .line 274
    .line 275
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->S:Lg1/d1;

    .line 276
    .line 277
    if-eqz p1, :cond_12

    .line 278
    .line 279
    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->T:Lg1/f1;

    .line 280
    .line 281
    if-eqz p1, :cond_12

    .line 282
    .line 283
    iget-boolean v0, p1, Lg1/f1;->d:Z

    .line 284
    .line 285
    if-nez v0, :cond_12

    .line 286
    .line 287
    iget-boolean v0, p1, Lg1/f1;->e:Z

    .line 288
    .line 289
    if-eqz v0, :cond_10

    .line 290
    .line 291
    goto :goto_3

    .line 292
    :cond_10
    iget-object p1, p1, Lg1/f1;->a:Ljava/lang/String;

    .line 293
    .line 294
    invoke-virtual {p1, v7, v6}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object p1

    .line 298
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 299
    .line 300
    .line 301
    move-result v0

    .line 302
    if-nez v0, :cond_11

    .line 303
    .line 304
    const-string p1, "extracted_file.bin"

    .line 305
    .line 306
    :cond_11
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->Z:Lb/h;

    .line 307
    .line 308
    invoke-virtual {v0, p1}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 309
    .line 310
    .line 311
    goto :goto_4

    .line 312
    :cond_12
    :goto_3
    const-string p1, "Select a file first"

    .line 313
    .line 314
    invoke-static {p0, p1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 315
    .line 316
    .line 317
    move-result-object p1

    .line 318
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 319
    .line 320
    .line 321
    :cond_13
    :goto_4
    return-void
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0026

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const p1, 0x7f090217

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->B:Landroid/widget/TextView;

    const p1, 0x7f090218

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->C:Landroid/widget/TextView;

    const p1, 0x7f090216

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->D:Landroid/widget/TextView;

    const p1, 0x7f090211

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->E:Landroid/widget/TextView;

    const p1, 0x7f090214

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->F:Landroid/widget/ListView;

    const p1, 0x7f09020e

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ListView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->G:Landroid/widget/ListView;

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->E:Landroid/widget/TextView;

    invoke-static {}, Landroid/text/method/ScrollingMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->E:Landroid/widget/TextView;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setVerticalScrollBarEnabled(Z)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->D:Landroid/widget/TextView;

    invoke-static {}, Landroid/text/method/ScrollingMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->D:Landroid/widget/TextView;

    invoke-virtual {p1, v0}, Landroid/view/View;->setVerticalScrollBarEnabled(Z)V

    new-instance p1, Landroid/widget/ArrayAdapter;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->O:Ljava/util/ArrayList;

    const v2, 0x7f0c0096

    invoke-direct {p1, p0, v2, v1}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    iput-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->H:Landroid/widget/ArrayAdapter;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->F:Landroid/widget/ListView;

    invoke-virtual {v1, p1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->F:Landroid/widget/ListView;

    new-instance v1, Lg1/t0;

    const/4 v3, 0x0

    invoke-direct {v1, v3}, Lg1/t0;-><init>(I)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->F:Landroid/widget/ListView;

    new-instance v1, Lg1/u0;

    invoke-direct {v1, p0, v3}, Lg1/u0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p1, v1}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    new-instance p1, Landroid/widget/ArrayAdapter;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->Q:Ljava/util/ArrayList;

    invoke-direct {p1, p0, v2, v1}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    iput-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->I:Landroid/widget/ArrayAdapter;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->G:Landroid/widget/ListView;

    invoke-virtual {v1, p1}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->G:Landroid/widget/ListView;

    new-instance v1, Lg1/t0;

    invoke-direct {v1, v0}, Lg1/t0;-><init>(I)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->G:Landroid/widget/ListView;

    new-instance v1, Lg1/u0;

    invoke-direct {v1, p0, v0}, Lg1/u0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p1, v1}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const/16 p1, 0xa

    new-array v0, p1, [I

    fill-array-data v0, :array_0

    :goto_0
    if-ge v3, p1, :cond_0

    aget v1, v0, v3

    invoke-virtual {p0, v1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    const-string p1, "Firmware analyzer ready. Use full eMMC/disk images with GPT."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V

    return-void

    nop

    :array_0
    .array-data 4
        0x7f090210
        0x7f09020f
        0x7f09020c
        0x7f09020a
        0x7f090213
        0x7f090215
        0x7f09020b
        0x7f090209
        0x7f090212
        0x7f09020d
    .end array-data
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final p(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->E:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\n"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->E:Landroid/widget/TextView;

    new-instance v0, Lg1/v0;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lg1/v0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final s()V
    .locals 3

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->J:Lg1/c1;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->M:Lg1/h1;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Checking partition: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->M:Lg1/h1;

    iget-object v1, v1, Lg1/h1;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->p(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lg1/v0;

    const/4 v2, 0x2

    invoke-direct {v1, p0, v2}, Lg1/v0;-><init>(Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;I)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    :cond_1
    :goto_0
    const-string v0, "Select partition first"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public final t(Lg1/d1;[BILjava/util/ArrayList;I)V
    .locals 16

    .line 1
    move-object/from16 v6, p1

    .line 2
    .line 3
    move-object/from16 v7, p2

    .line 4
    .line 5
    move/from16 v8, p5

    .line 6
    .line 7
    const/4 v0, 0x4

    .line 8
    if-gt v8, v0, :cond_4

    .line 9
    .line 10
    add-int/lit8 v9, p3, 0xc

    .line 11
    .line 12
    array-length v0, v7

    .line 13
    if-gt v9, v0, :cond_4

    .line 14
    .line 15
    invoke-static/range {p2 .. p3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const v1, 0xf30a

    .line 20
    .line 21
    .line 22
    if-ne v0, v1, :cond_4

    .line 23
    .line 24
    add-int/lit8 v0, p3, 0x2

    .line 25
    .line 26
    invoke-static {v7, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 27
    .line 28
    .line 29
    move-result v10

    .line 30
    add-int/lit8 v0, p3, 0x6

    .line 31
    .line 32
    invoke-static {v7, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 33
    .line 34
    .line 35
    move-result v11

    .line 36
    const/4 v0, 0x0

    .line 37
    move v12, v0

    .line 38
    :goto_0
    if-ge v12, v10, :cond_0

    .line 39
    .line 40
    mul-int/lit8 v0, v12, 0xc

    .line 41
    .line 42
    add-int/2addr v0, v9

    .line 43
    add-int/lit8 v1, v0, 0xc

    .line 44
    .line 45
    array-length v2, v7

    .line 46
    if-le v1, v2, :cond_1

    .line 47
    .line 48
    :cond_0
    move-object/from16 v14, p0

    .line 49
    .line 50
    goto :goto_2

    .line 51
    :cond_1
    const/16 v1, 0x20

    .line 52
    .line 53
    if-nez v11, :cond_3

    .line 54
    .line 55
    new-instance v2, Lg1/e1;

    .line 56
    .line 57
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 58
    .line 59
    .line 60
    add-int/lit8 v3, v0, 0x4

    .line 61
    .line 62
    invoke-static {v7, v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    and-int/lit16 v3, v3, 0x7fff

    .line 67
    .line 68
    iput v3, v2, Lg1/e1;->b:I

    .line 69
    .line 70
    add-int/lit8 v3, v0, 0x8

    .line 71
    .line 72
    invoke-static {v7, v3}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    .line 73
    .line 74
    .line 75
    move-result-wide v3

    .line 76
    add-int/lit8 v0, v0, 0x6

    .line 77
    .line 78
    invoke-static {v7, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    int-to-long v13, v0

    .line 83
    shl-long v0, v13, v1

    .line 84
    .line 85
    or-long/2addr v0, v3

    .line 86
    iput-wide v0, v2, Lg1/e1;->a:J

    .line 87
    .line 88
    iget v0, v2, Lg1/e1;->b:I

    .line 89
    .line 90
    move-object/from16 v13, p4

    .line 91
    .line 92
    if-lez v0, :cond_2

    .line 93
    .line 94
    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    :cond_2
    move-object/from16 v14, p0

    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_3
    move-object/from16 v13, p4

    .line 101
    .line 102
    add-int/lit8 v2, v0, 0x4

    .line 103
    .line 104
    invoke-static {v7, v2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->V([BI)J

    .line 105
    .line 106
    .line 107
    move-result-wide v2

    .line 108
    add-int/lit8 v0, v0, 0x8

    .line 109
    .line 110
    invoke-static {v7, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->U([BI)I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    int-to-long v4, v0

    .line 115
    shl-long v0, v4, v1

    .line 116
    .line 117
    or-long/2addr v0, v2

    .line 118
    iget-object v2, v6, Lg1/d1;->a:Landroid/net/Uri;

    .line 119
    .line 120
    iget-wide v3, v6, Lg1/d1;->b:J

    .line 121
    .line 122
    iget v5, v6, Lg1/d1;->c:I

    .line 123
    .line 124
    int-to-long v14, v5

    .line 125
    mul-long/2addr v0, v14

    .line 126
    add-long/2addr v0, v3

    .line 127
    move-object/from16 v14, p0

    .line 128
    .line 129
    invoke-virtual {v14, v2, v0, v1, v5}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P(Landroid/net/Uri;JI)[B

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    const/4 v3, 0x0

    .line 134
    add-int/lit8 v5, v8, 0x1

    .line 135
    .line 136
    move-object/from16 v0, p0

    .line 137
    .line 138
    move-object/from16 v1, p1

    .line 139
    .line 140
    move-object/from16 v4, p4

    .line 141
    .line 142
    invoke-virtual/range {v0 .. v5}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->t(Lg1/d1;[BILjava/util/ArrayList;I)V

    .line 143
    .line 144
    .line 145
    :goto_1
    add-int/lit8 v12, v12, 0x1

    .line 146
    .line 147
    goto :goto_0

    .line 148
    :goto_2
    return-void

    .line 149
    :cond_4
    move-object/from16 v14, p0

    .line 150
    .line 151
    new-instance v0, Ljava/lang/Exception;

    .line 152
    .line 153
    const-string v1, "Only EXT4 extent files are supported"

    .line 154
    .line 155
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    throw v0
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
.end method

.method public final u(Lg1/d1;[BLjava/io/OutputStream;J)V
    .locals 16

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    new-instance v7, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 6
    .line 7
    .line 8
    const/16 v4, 0x28

    .line 9
    .line 10
    const/4 v6, 0x0

    .line 11
    move-object/from16 v1, p0

    .line 12
    .line 13
    move-object/from16 v2, p1

    .line 14
    .line 15
    move-object/from16 v3, p2

    .line 16
    .line 17
    move-object v5, v7

    .line 18
    invoke-virtual/range {v1 .. v6}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->t(Lg1/d1;[BILjava/util/ArrayList;I)V

    .line 19
    .line 20
    .line 21
    invoke-static/range {p2 .. p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->D([B)J

    .line 22
    .line 23
    .line 24
    move-result-wide v1

    .line 25
    move-wide/from16 v3, p4

    .line 26
    .line 27
    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->min(JJ)J

    .line 28
    .line 29
    .line 30
    move-result-wide v1

    .line 31
    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-eqz v4, :cond_5

    .line 40
    .line 41
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v4

    .line 45
    check-cast v4, Lg1/e1;

    .line 46
    .line 47
    const-wide/16 v5, 0x0

    .line 48
    .line 49
    cmp-long v7, v1, v5

    .line 50
    .line 51
    if-gtz v7, :cond_0

    .line 52
    .line 53
    goto/16 :goto_9

    .line 54
    .line 55
    :cond_0
    iget v7, v4, Lg1/e1;->b:I

    .line 56
    .line 57
    int-to-long v7, v7

    .line 58
    iget v9, v0, Lg1/d1;->c:I

    .line 59
    .line 60
    int-to-long v9, v9

    .line 61
    mul-long/2addr v7, v9

    .line 62
    invoke-static {v7, v8, v1, v2}, Ljava/lang/Math;->min(JJ)J

    .line 63
    .line 64
    .line 65
    move-result-wide v7

    .line 66
    iget-wide v9, v0, Lg1/d1;->b:J

    .line 67
    .line 68
    iget-wide v11, v4, Lg1/e1;->a:J

    .line 69
    .line 70
    iget v4, v0, Lg1/d1;->c:I

    .line 71
    .line 72
    int-to-long v13, v4

    .line 73
    mul-long/2addr v11, v13

    .line 74
    add-long/2addr v11, v9

    .line 75
    iget-object v4, v0, Lg1/d1;->a:Landroid/net/Uri;

    .line 76
    .line 77
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 78
    .line 79
    .line 80
    move-result-object v9

    .line 81
    const-string v10, "r"

    .line 82
    .line 83
    invoke-virtual {v9, v4, v10}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    :try_start_0
    new-instance v9, Ljava/io/FileInputStream;

    .line 88
    .line 89
    invoke-virtual {v4}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    .line 90
    .line 91
    .line 92
    move-result-object v10

    .line 93
    invoke-direct {v9, v10}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 94
    .line 95
    .line 96
    :try_start_1
    invoke-virtual {v9}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 97
    .line 98
    .line 99
    move-result-object v10
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 100
    :try_start_2
    invoke-virtual {v10, v11, v12}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    .line 101
    .line 102
    .line 103
    const/high16 v11, 0x100000

    .line 104
    .line 105
    invoke-static {v11}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 106
    .line 107
    .line 108
    move-result-object v11

    .line 109
    move-wide v12, v7

    .line 110
    :goto_1
    cmp-long v14, v12, v5

    .line 111
    .line 112
    if-lez v14, :cond_1

    .line 113
    .line 114
    invoke-virtual {v11}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v11}, Ljava/nio/Buffer;->capacity()I

    .line 118
    .line 119
    .line 120
    move-result v14

    .line 121
    int-to-long v14, v14

    .line 122
    invoke-static {v14, v15, v12, v13}, Ljava/lang/Math;->min(JJ)J

    .line 123
    .line 124
    .line 125
    move-result-wide v14

    .line 126
    long-to-int v14, v14

    .line 127
    invoke-virtual {v11, v14}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    .line 128
    .line 129
    .line 130
    invoke-virtual {v10, v11}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    .line 131
    .line 132
    .line 133
    move-result v14

    .line 134
    if-gtz v14, :cond_2

    .line 135
    .line 136
    :cond_1
    move-object/from16 v6, p3

    .line 137
    .line 138
    goto :goto_2

    .line 139
    :cond_2
    invoke-virtual {v11}, Ljava/nio/ByteBuffer;->array()[B

    .line 140
    .line 141
    .line 142
    move-result-object v15

    .line 143
    const/4 v5, 0x0

    .line 144
    move-object/from16 v6, p3

    .line 145
    .line 146
    invoke-virtual {v6, v15, v5, v14}, Ljava/io/OutputStream;->write([BII)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 147
    .line 148
    .line 149
    int-to-long v14, v14

    .line 150
    sub-long/2addr v12, v14

    .line 151
    const-wide/16 v5, 0x0

    .line 152
    .line 153
    goto :goto_1

    .line 154
    :catchall_0
    move-exception v0

    .line 155
    move-object v1, v0

    .line 156
    goto :goto_3

    .line 157
    :goto_2
    :try_start_3
    invoke-virtual {v10}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 158
    .line 159
    .line 160
    :try_start_4
    invoke-virtual {v9}, Ljava/io/FileInputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 161
    .line 162
    .line 163
    invoke-virtual {v4}, Landroid/os/ParcelFileDescriptor;->close()V

    .line 164
    .line 165
    .line 166
    sub-long/2addr v1, v7

    .line 167
    goto/16 :goto_0

    .line 168
    .line 169
    :catchall_1
    move-exception v0

    .line 170
    move-object v1, v0

    .line 171
    goto :goto_7

    .line 172
    :catchall_2
    move-exception v0

    .line 173
    move-object v1, v0

    .line 174
    goto :goto_5

    .line 175
    :goto_3
    if-eqz v10, :cond_3

    .line 176
    .line 177
    :try_start_5
    invoke-virtual {v10}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 178
    .line 179
    .line 180
    goto :goto_4

    .line 181
    :catchall_3
    move-exception v0

    .line 182
    move-object v2, v0

    .line 183
    :try_start_6
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 184
    .line 185
    .line 186
    :cond_3
    :goto_4
    throw v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 187
    :goto_5
    :try_start_7
    invoke-virtual {v9}, Ljava/io/FileInputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 188
    .line 189
    .line 190
    goto :goto_6

    .line 191
    :catchall_4
    move-exception v0

    .line 192
    move-object v2, v0

    .line 193
    :try_start_8
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 194
    .line 195
    .line 196
    :goto_6
    throw v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    .line 197
    :goto_7
    if-eqz v4, :cond_4

    .line 198
    .line 199
    :try_start_9
    invoke-virtual {v4}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 200
    .line 201
    .line 202
    goto :goto_8

    .line 203
    :catchall_5
    move-exception v0

    .line 204
    move-object v2, v0

    .line 205
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 206
    .line 207
    .line 208
    :cond_4
    :goto_8
    throw v1

    .line 209
    :cond_5
    :goto_9
    return-void
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
.end method

.method public final w(Landroid/net/Uri;J)Ljava/lang/String;
    .locals 4

    .line 1
    const/16 v0, 0x2000

    invoke-virtual {p0, p1, p2, p3, v0}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->P(Landroid/net/Uri;JI)[B

    move-result-object p1

    array-length p2, p1

    const/16 p3, 0x439

    if-le p2, p3, :cond_0

    const/16 p2, 0x438

    aget-byte p2, p1, p2

    and-int/lit16 p2, p2, 0xff

    const/16 v0, 0x53

    if-ne p2, v0, :cond_0

    aget-byte p2, p1, p3

    and-int/lit16 p2, p2, 0xff

    const/16 p3, 0xef

    if-ne p2, p3, :cond_0

    const-string p1, "EXT4"

    return-object p1

    :cond_0
    array-length p2, p1

    const/16 p3, 0xf5

    const/16 v0, 0x400

    const/16 v1, 0x403

    if-le p2, v1, :cond_1

    const/16 p2, 0xe0

    const/16 v2, 0xe2

    const/16 v3, 0xe1

    filled-new-array {v2, v3, p3, p2}, [I

    move-result-object p2

    invoke-static {v0, p1, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p2

    if-eqz p2, :cond_1

    const-string p1, "EROFS"

    return-object p1

    :cond_1
    array-length p2, p1

    if-le p2, v1, :cond_2

    const/16 p2, 0xf2

    const/16 v1, 0x10

    const/16 v2, 0x20

    filled-new-array {v1, v2, p3, p2}, [I

    move-result-object p2

    invoke-static {v0, p1, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p2

    if-eqz p2, :cond_2

    const-string p1, "F2FS"

    return-object p1

    :cond_2
    const/16 p2, 0x68

    const/16 p3, 0x73

    const/16 v0, 0x71

    filled-new-array {p2, p3, v0, p3}, [I

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v2, p1, v1}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result v1

    if-nez v1, :cond_4

    filled-new-array {p3, v0, p3, p2}, [I

    move-result-object p2

    invoke-static {v2, p1, p2}, Lapp/gkc/terminal/Activity/FirmwareGptAnalyzerActivity;->A(I[B[I)Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_0

    :cond_3
    const-string p1, "Unknown/raw"

    return-object p1

    :cond_4
    :goto_0
    const-string p1, "SquashFS"

    return-object p1
.end method

.method public final y(Landroid/net/Uri;)Ljava/lang/String;
    .locals 6

    .line 1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v1, p1

    invoke-virtual/range {v0 .. v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_0

    :try_start_1
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "_display_name"

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v1

    if-ltz v1, :cond_0

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-lez v2, :cond_0

    :try_start_2
    invoke-interface {v0}, Landroid/database/Cursor;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    return-object v1

    :catchall_0
    move-exception v1

    :try_start_3
    invoke-interface {v0}, Landroid/database/Cursor;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_0

    :catchall_1
    move-exception v0

    :try_start_4
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_0
    throw v1

    :cond_0
    if-eqz v0, :cond_1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    :cond_1
    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_2

    const-string p1, "firmware.bin"

    :cond_2
    return-object p1
.end method
