.class public Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final synthetic O:I


# instance fields
.field public B:Landroid/hardware/usb/UsbManager;

.field public C:Landroid/hardware/usb/UsbDevice;

.field public D:Z

.field public E:Z

.field public F:[B

.field public G:[B

.field public final H:Lg1/n;

.field public I:Landroid/widget/ScrollView;

.field public J:Landroid/widget/TextView;

.field public K:Landroid/widget/TextView;

.field public L:Landroid/widget/TextView;

.field public M:Landroid/widget/Button;

.field public final N:Le/d0;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Le/m;-><init>()V

    new-instance v0, Lg1/n;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lg1/n;-><init>(I)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->H:Lg1/n;

    new-instance v0, Le/d0;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p0}, Le/d0;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->N:Le/d0;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 10

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const v0, 0x7f090220

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x1

    .line 11
    if-ne p1, v0, :cond_5

    .line 12
    .line 13
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->D:Z

    .line 14
    .line 15
    if-eqz p1, :cond_0

    .line 16
    .line 17
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->r()V

    .line 18
    .line 19
    .line 20
    goto/16 :goto_7

    .line 21
    .line 22
    :cond_0
    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->B:Landroid/hardware/usb/UsbManager;

    .line 23
    .line 24
    invoke-virtual {p1}, Landroid/hardware/usb/UsbManager;->getDeviceList()Ljava/util/HashMap;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {p1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    :cond_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_2

    .line 41
    .line 42
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    check-cast v0, Landroid/hardware/usb/UsbDevice;

    .line 47
    .line 48
    invoke-virtual {v0}, Landroid/hardware/usb/UsbDevice;->getVendorId()I

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    const/16 v5, 0x1a86

    .line 53
    .line 54
    if-ne v4, v5, :cond_1

    .line 55
    .line 56
    move-object v1, v0

    .line 57
    :cond_2
    if-nez v1, :cond_3

    .line 58
    .line 59
    const-string p1, "CH341A not found. Connect programmer and allow USB."

    .line 60
    .line 61
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    const-string p1, "CH341A not found"

    .line 65
    .line 66
    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 71
    .line 72
    .line 73
    goto/16 :goto_7

    .line 74
    .line 75
    :cond_3
    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->B:Landroid/hardware/usb/UsbManager;

    .line 76
    .line 77
    invoke-virtual {p1, v1}, Landroid/hardware/usb/UsbManager;->hasPermission(Landroid/hardware/usb/UsbDevice;)Z

    .line 78
    .line 79
    .line 80
    move-result p1

    .line 81
    if-nez p1, :cond_4

    .line 82
    .line 83
    new-instance p1, Landroid/content/Intent;

    .line 84
    .line 85
    const-string v0, "app.gkc.terminal.pro.HDMI_EDID_USB_PERMISSION"

    .line 86
    .line 87
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    const/high16 v0, 0xa000000

    .line 91
    .line 92
    invoke-static {p0, v2, p1, v0}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->B:Landroid/hardware/usb/UsbManager;

    .line 97
    .line 98
    invoke-virtual {v0, v1, p1}, Landroid/hardware/usb/UsbManager;->requestPermission(Landroid/hardware/usb/UsbDevice;Landroid/app/PendingIntent;)V

    .line 99
    .line 100
    .line 101
    goto/16 :goto_7

    .line 102
    .line 103
    :cond_4
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->t(Landroid/hardware/usb/UsbDevice;)V

    .line 104
    .line 105
    .line 106
    goto/16 :goto_7

    .line 107
    .line 108
    :cond_5
    const v0, 0x7f090224

    .line 109
    .line 110
    .line 111
    if-ne p1, v0, :cond_7

    .line 112
    .line 113
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->s()Z

    .line 114
    .line 115
    .line 116
    move-result p1

    .line 117
    if-nez p1, :cond_6

    .line 118
    .line 119
    goto/16 :goto_7

    .line 120
    .line 121
    :cond_6
    invoke-virtual {p0, v3}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->v(Z)V

    .line 122
    .line 123
    .line 124
    const-string p1, "Reading HDMI EDID 24C02 at 0x50..."

    .line 125
    .line 126
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    new-instance p1, Ljava/lang/Thread;

    .line 130
    .line 131
    new-instance v0, Lg1/r1;

    .line 132
    .line 133
    invoke-direct {v0, p0, v3}, Lg1/r1;-><init>(Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;I)V

    .line 134
    .line 135
    .line 136
    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 140
    .line 141
    .line 142
    goto/16 :goto_7

    .line 143
    .line 144
    :cond_7
    const v0, 0x7f09021e

    .line 145
    .line 146
    .line 147
    const-string v4, "720p 60Hz"

    .line 148
    .line 149
    const/4 v5, 0x2

    .line 150
    if-ne p1, v0, :cond_e

    .line 151
    .line 152
    const-string p1, "Recommended rescue template: "

    .line 153
    .line 154
    const-string v0, "Panel size approx: "

    .line 155
    .line 156
    const-string v1, "Manufacturer: "

    .line 157
    .line 158
    iget-object v3, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    .line 159
    .line 160
    if-nez v3, :cond_8

    .line 161
    .line 162
    const-string p1, "No EDID data. Read chip or apply a template first."

    .line 163
    .line 164
    goto/16 :goto_4

    .line 165
    .line 166
    :cond_8
    array-length v6, v3

    .line 167
    const/16 v7, 0x80

    .line 168
    .line 169
    if-ge v6, v7, :cond_9

    .line 170
    .line 171
    const-string p1, "EDID data is too short."

    .line 172
    .line 173
    goto/16 :goto_4

    .line 174
    .line 175
    :cond_9
    const/16 v6, 0x8

    .line 176
    .line 177
    :try_start_0
    aget-byte v6, v3, v6

    .line 178
    .line 179
    and-int/lit16 v7, v6, 0xff

    .line 180
    .line 181
    const/16 v8, 0x9

    .line 182
    .line 183
    aget-byte v8, v3, v8

    .line 184
    .line 185
    and-int/lit16 v9, v8, 0xff

    .line 186
    .line 187
    shr-int/lit8 v5, v7, 0x2

    .line 188
    .line 189
    and-int/lit8 v5, v5, 0x1f

    .line 190
    .line 191
    add-int/lit8 v5, v5, 0x40

    .line 192
    .line 193
    int-to-char v5, v5

    .line 194
    and-int/lit8 v6, v6, 0x3

    .line 195
    .line 196
    shl-int/lit8 v6, v6, 0x3

    .line 197
    .line 198
    shr-int/lit8 v7, v9, 0x5

    .line 199
    .line 200
    or-int/2addr v6, v7

    .line 201
    add-int/lit8 v6, v6, 0x40

    .line 202
    .line 203
    int-to-char v6, v6

    .line 204
    and-int/lit8 v7, v8, 0x1f

    .line 205
    .line 206
    add-int/lit8 v7, v7, 0x40

    .line 207
    .line 208
    int-to-char v7, v7

    .line 209
    const/16 v8, 0x15

    .line 210
    .line 211
    aget-byte v8, v3, v8

    .line 212
    .line 213
    and-int/lit16 v8, v8, 0xff

    .line 214
    .line 215
    const/16 v9, 0x16

    .line 216
    .line 217
    aget-byte v3, v3, v9

    .line 218
    .line 219
    and-int/lit16 v3, v3, 0xff

    .line 220
    .line 221
    if-lez v8, :cond_a

    .line 222
    .line 223
    if-lez v3, :cond_a

    .line 224
    .line 225
    mul-int/2addr v8, v8

    .line 226
    mul-int/2addr v3, v3

    .line 227
    add-int/2addr v3, v8

    .line 228
    int-to-double v2, v3

    .line 229
    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    .line 230
    .line 231
    .line 232
    move-result-wide v2

    .line 233
    const-wide v8, 0x400451eb851eb852L    # 2.54

    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    div-double/2addr v2, v8

    .line 239
    double-to-int v2, v2

    .line 240
    goto :goto_0

    .line 241
    :catch_0
    move-exception p1

    .line 242
    goto :goto_3

    .line 243
    :cond_a
    :goto_0
    const/16 v3, 0x2d

    .line 244
    .line 245
    if-lt v2, v3, :cond_b

    .line 246
    .line 247
    const-string v4, "4K 60Hz"

    .line 248
    .line 249
    goto :goto_1

    .line 250
    :cond_b
    const/16 v3, 0x1e

    .line 251
    .line 252
    if-lt v2, v3, :cond_c

    .line 253
    .line 254
    const-string v4, "1080p 60Hz"

    .line 255
    .line 256
    :cond_c
    :goto_1
    new-instance v3, Ljava/lang/StringBuilder;

    .line 257
    .line 258
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 262
    .line 263
    .line 264
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 265
    .line 266
    .line 267
    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 268
    .line 269
    .line 270
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    move-result-object v1

    .line 274
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    if-lez v2, :cond_d

    .line 278
    .line 279
    new-instance v1, Ljava/lang/StringBuilder;

    .line 280
    .line 281
    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 282
    .line 283
    .line 284
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 285
    .line 286
    .line 287
    const-string v0, " inch"

    .line 288
    .line 289
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 290
    .line 291
    .line 292
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    goto :goto_2

    .line 297
    :cond_d
    const-string v0, "Panel size not defined."

    .line 298
    .line 299
    :goto_2
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    invoke-virtual {p1, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    move-result-object p1

    .line 306
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 307
    .line 308
    .line 309
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->w()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 310
    .line 311
    .line 312
    goto/16 :goto_7

    .line 313
    .line 314
    :goto_3
    new-instance v0, Ljava/lang/StringBuilder;

    .line 315
    .line 316
    const-string v1, "Analyze failed: "

    .line 317
    .line 318
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 319
    .line 320
    .line 321
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object p1

    .line 325
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 326
    .line 327
    .line 328
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 329
    .line 330
    .line 331
    move-result-object p1

    .line 332
    :goto_4
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    goto/16 :goto_7

    .line 336
    .line 337
    :cond_e
    const v0, 0x7f090223

    .line 338
    .line 339
    .line 340
    if-ne p1, v0, :cond_10

    .line 341
    .line 342
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->s()Z

    .line 343
    .line 344
    .line 345
    move-result p1

    .line 346
    if-nez p1, :cond_f

    .line 347
    .line 348
    goto/16 :goto_7

    .line 349
    .line 350
    :cond_f
    invoke-virtual {p0, v3}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->v(Z)V

    .line 351
    .line 352
    .line 353
    const-string p1, "Scanning I2C bus 0x01-0x7F..."

    .line 354
    .line 355
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 356
    .line 357
    .line 358
    new-instance p1, Ljava/lang/Thread;

    .line 359
    .line 360
    new-instance v0, Lg1/r1;

    .line 361
    .line 362
    invoke-direct {v0, p0, v2}, Lg1/r1;-><init>(Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;I)V

    .line 363
    .line 364
    .line 365
    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 369
    .line 370
    .line 371
    goto/16 :goto_7

    .line 372
    .line 373
    :cond_10
    const v0, 0x7f090227

    .line 374
    .line 375
    .line 376
    if-ne p1, v0, :cond_12

    .line 377
    .line 378
    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->G:[B

    .line 379
    .line 380
    if-nez p1, :cond_11

    .line 381
    .line 382
    const-string p1, "No original backup in memory. Read chip first."

    .line 383
    .line 384
    :goto_5
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 385
    .line 386
    .line 387
    goto/16 :goto_7

    .line 388
    .line 389
    :cond_11
    invoke-virtual {p1}, [B->clone()Ljava/lang/Object;

    .line 390
    .line 391
    .line 392
    move-result-object p1

    .line 393
    check-cast p1, [B

    .line 394
    .line 395
    iput-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    .line 396
    .line 397
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->w()V

    .line 398
    .line 399
    .line 400
    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->J:Landroid/widget/TextView;

    .line 401
    .line 402
    const-string v0, "Original EDID restored in buffer."

    .line 403
    .line 404
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 405
    .line 406
    .line 407
    const-string p1, "Buffer restored from original read."

    .line 408
    .line 409
    goto :goto_5

    .line 410
    :cond_12
    const v0, 0x7f090228

    .line 411
    .line 412
    .line 413
    if-ne p1, v0, :cond_14

    .line 414
    .line 415
    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    .line 416
    .line 417
    if-nez p1, :cond_13

    .line 418
    .line 419
    const-string p1, "No EDID buffer to save."

    .line 420
    .line 421
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 422
    .line 423
    .line 424
    goto/16 :goto_7

    .line 425
    .line 426
    :cond_13
    invoke-virtual {p0, v3}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->v(Z)V

    .line 427
    .line 428
    .line 429
    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    .line 430
    .line 431
    invoke-virtual {p1}, [B->clone()Ljava/lang/Object;

    .line 432
    .line 433
    .line 434
    move-result-object p1

    .line 435
    check-cast p1, [B

    .line 436
    .line 437
    new-instance v0, Ljava/lang/Thread;

    .line 438
    .line 439
    new-instance v1, Lg1/s1;

    .line 440
    .line 441
    invoke-direct {v1, p0, p1, v2}, Lg1/s1;-><init>(Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;[BI)V

    .line 442
    .line 443
    .line 444
    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 445
    .line 446
    .line 447
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 448
    .line 449
    .line 450
    goto :goto_7

    .line 451
    :cond_14
    const v0, 0x7f09022d

    .line 452
    .line 453
    .line 454
    if-ne p1, v0, :cond_17

    .line 455
    .line 456
    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    .line 457
    .line 458
    if-nez p1, :cond_15

    .line 459
    .line 460
    const-string p1, "No EDID buffer. Read or apply a template first."

    .line 461
    .line 462
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 463
    .line 464
    .line 465
    goto :goto_7

    .line 466
    :cond_15
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->s()Z

    .line 467
    .line 468
    .line 469
    move-result p1

    .line 470
    if-nez p1, :cond_16

    .line 471
    .line 472
    goto :goto_7

    .line 473
    :cond_16
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 474
    .line 475
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 476
    .line 477
    .line 478
    const-string v0, "Write HDMI EDID?"

    .line 479
    .line 480
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 481
    .line 482
    .line 483
    move-result-object p1

    .line 484
    const-string v0, "Check HDMI EDID EEPROM write protect pin before writing. This writes the current EDID buffer and verifies it."

    .line 485
    .line 486
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 487
    .line 488
    .line 489
    move-result-object p1

    .line 490
    new-instance v0, Lg1/b;

    .line 491
    .line 492
    invoke-direct {v0, p0, v5}, Lg1/b;-><init>(Le/m;I)V

    .line 493
    .line 494
    .line 495
    const-string v2, "WRITE"

    .line 496
    .line 497
    invoke-virtual {p1, v2, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 498
    .line 499
    .line 500
    move-result-object p1

    .line 501
    const-string v0, "CANCEL"

    .line 502
    .line 503
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 504
    .line 505
    .line 506
    move-result-object p1

    .line 507
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 508
    .line 509
    .line 510
    goto :goto_7

    .line 511
    :cond_17
    const v0, 0x7f090225

    .line 512
    .line 513
    .line 514
    if-ne p1, v0, :cond_18

    .line 515
    .line 516
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->u()V

    .line 517
    .line 518
    .line 519
    goto :goto_7

    .line 520
    :cond_18
    const v0, 0x7f09022a

    .line 521
    .line 522
    .line 523
    if-ne p1, v0, :cond_19

    .line 524
    .line 525
    const-string p1, "1080p 60Hz universal"

    .line 526
    .line 527
    const-string v0, "00FFFFFFFFFFFF004C2D0B09010000002A150103805932780AEE91A3544C99260F5054BDEF80714F81C0810081809500A9C0B3000101023A801871382D40582C4500A05A0000001E662156AA51001E30468F3300A05A0000001E000000FD00184B0F5117000A202020202020000000FC0053414D53554E470A2020202020019B"

    .line 528
    .line 529
    :goto_6
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->q(Ljava/lang/String;Ljava/lang/String;)V

    .line 530
    .line 531
    .line 532
    goto :goto_7

    .line 533
    :cond_19
    const v0, 0x7f09022c

    .line 534
    .line 535
    .line 536
    if-ne p1, v0, :cond_1a

    .line 537
    .line 538
    const-string p1, "00FFFFFFFFFFFF001E6D0100010101010114010380301B78EAA8E5A2574FA2280F5054BFEF8031404540454C6140714F810081408180A940662150B051001B3040703600DD0C1100001E000000FD00323C1E5011000A202020202020000000FC0056533232380A20202020202020000000FF00444C4D5446413036353831310A"

    .line 539
    .line 540
    invoke-virtual {p0, v4, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->q(Ljava/lang/String;Ljava/lang/String;)V

    .line 541
    .line 542
    .line 543
    goto :goto_7

    .line 544
    :cond_1a
    const v0, 0x7f09022b

    .line 545
    .line 546
    .line 547
    if-ne p1, v0, :cond_1b

    .line 548
    .line 549
    const-string p1, "4K 60Hz generic"

    .line 550
    .line 551
    const-string v0, "00FFFFFFFFFFFF001CAE010001010101011B0103806E3E782AEE91A3544C99260F50542108008180A940D1C00101010101010101010108E80030F2705A80B0588A00501D2100001E000000FD003A3E1E5310000A202020202020000000FC0048444D4920344B0A20202020202000000010000000000000000000000000000001"

    .line 552
    .line 553
    goto :goto_6

    .line 554
    :cond_1b
    :goto_7
    return-void
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0028

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const-string p1, "usb"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/usb/UsbManager;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->B:Landroid/hardware/usb/UsbManager;

    const p1, 0x7f090226

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ScrollView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->I:Landroid/widget/ScrollView;

    const p1, 0x7f090229

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->J:Landroid/widget/TextView;

    const p1, 0x7f09021f

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->K:Landroid/widget/TextView;

    const p1, 0x7f090222

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->L:Landroid/widget/TextView;

    const p1, 0x7f090220

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->M:Landroid/widget/Button;

    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->L:Landroid/widget/TextView;

    invoke-static {}, Landroid/text/method/ScrollingMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->L:Landroid/widget/TextView;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setVerticalScrollBarEnabled(Z)V

    const/16 p1, 0xb

    new-array v0, p1, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p1, :cond_0

    aget v2, v0, v1

    invoke-virtual {p0, v2}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance p1, Landroid/content/IntentFilter;

    const-string v0, "app.gkc.terminal.pro.HDMI_EDID_USB_PERMISSION"

    invoke-direct {p1, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    iget-object v2, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->N:Le/d0;

    if-lt v0, v1, :cond_1

    invoke-static {p0, v2, p1}, Lb2/b;->o(Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;Le/d0;Landroid/content/IntentFilter;)V

    goto :goto_1

    :cond_1
    invoke-virtual {p0, v2, p1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    :goto_1
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->w()V

    return-void

    nop

    :array_0
    .array-data 4
        0x7f090220
        0x7f090224
        0x7f09021e
        0x7f090223
        0x7f090227
        0x7f090228
        0x7f09022d
        0x7f090225
        0x7f09022a
        0x7f09022c
        0x7f09022b
    .end array-data
.end method

.method public final onDestroy()V
    .locals 1

    :try_start_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->N:Le/d0;

    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->H:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->c()V

    invoke-super {p0}, Le/m;->onDestroy()V

    return-void
.end method

.method public final p(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->L:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\n"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->L:Landroid/widget/TextView;

    new-instance v0, Lg1/r1;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lg1/r1;-><init>(Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;I)V

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final q(Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    .line 1
    :try_start_0
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    rem-int/lit8 v0, v0, 0x2

    .line 6
    .line 7
    if-nez v0, :cond_2

    .line 8
    .line 9
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    div-int/lit8 v0, v0, 0x2

    .line 14
    .line 15
    new-array v1, v0, [B

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    :goto_0
    if-ge v2, v0, :cond_0

    .line 19
    .line 20
    mul-int/lit8 v3, v2, 0x2

    .line 21
    .line 22
    add-int/lit8 v4, v3, 0x2

    .line 23
    .line 24
    invoke-virtual {p2, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    const/16 v4, 0x10

    .line 29
    .line 30
    invoke-static {v3, v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    int-to-byte v3, v3

    .line 35
    aput-byte v3, v1, v2

    .line 36
    .line 37
    add-int/lit8 v2, v2, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    const/16 p2, 0x80

    .line 41
    .line 42
    if-eq v0, p2, :cond_1

    .line 43
    .line 44
    new-instance p1, Ljava/lang/StringBuilder;

    .line 45
    .line 46
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 47
    .line 48
    .line 49
    const-string p2, "Template size invalid: "

    .line 50
    .line 51
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string p2, " bytes."

    .line 58
    .line 59
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :catch_0
    move-exception p1

    .line 71
    goto :goto_1

    .line 72
    :cond_1
    iput-object v1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    .line 73
    .line 74
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->u()V

    .line 75
    .line 76
    .line 77
    iget-object p2, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->J:Landroid/widget/TextView;

    .line 78
    .line 79
    new-instance v0, Ljava/lang/StringBuilder;

    .line 80
    .line 81
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 82
    .line 83
    .line 84
    const-string v1, "Template loaded: "

    .line 85
    .line 86
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 97
    .line 98
    .line 99
    new-instance p2, Ljava/lang/StringBuilder;

    .line 100
    .line 101
    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 102
    .line 103
    .line 104
    const-string v0, "Template applied: "

    .line 105
    .line 106
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 121
    .line 122
    const-string p2, "bad hex"

    .line 123
    .line 124
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 128
    :goto_1
    new-instance p2, Ljava/lang/StringBuilder;

    .line 129
    .line 130
    const-string v0, "Template failed: "

    .line 131
    .line 132
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 140
    .line 141
    .line 142
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    :goto_2
    return-void
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public final r()V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->H:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->c()V

    const/4 v0, 0x0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->C:Landroid/hardware/usb/UsbDevice;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->D:Z

    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->M:Landroid/widget/Button;

    const-string v1, "CONNECT"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->J:Landroid/widget/TextView;

    const-string v1, "Disconnected."

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    return-void
.end method

.method public final s()Z
    .locals 2

    .line 1
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->D:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->C:Landroid/hardware/usb/UsbDevice;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->H:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->j()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->E:Z

    if-eqz v0, :cond_1

    const-string v0, "Tool busy. Wait for current operation."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    return v1

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    :goto_0
    const-string v0, "Connect CH341A first."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    const-string v0, "Connect CH341A first"

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return v1
.end method

.method public final t(Landroid/hardware/usb/UsbDevice;)V
    .locals 3

    .line 1
    const/4 v0, 0x1

    :try_start_0
    iget-object v1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->H:Lg1/n;

    iget-object v2, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->B:Landroid/hardware/usb/UsbManager;

    invoke-virtual {v1, v2, p1}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    iput-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->C:Landroid/hardware/usb/UsbDevice;

    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->D:Z

    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->M:Landroid/widget/Button;

    const-string v1, "DISCONNECT"

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->J:Landroid/widget/TextView;

    const-string v1, "CH341A I2C ready. EDID address 0x50."

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string p1, "CH341A connected in I2C mode."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->r()V

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Open failed: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    const-string p1, "Open failed"

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method public final u()V
    .locals 4

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    if-eqz v0, :cond_2

    array-length v0, v0

    const/16 v1, 0x80

    if-ge v0, v1, :cond_0

    goto :goto_2

    :cond_0
    const/4 v0, 0x0

    move v1, v0

    :goto_0
    const/16 v2, 0x7f

    if-ge v0, v2, :cond_1

    iget-object v2, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    aget-byte v2, v2, v0

    and-int/lit16 v2, v2, 0xff

    add-int/2addr v1, v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    rem-int/lit16 v1, v1, 0x100

    rsub-int v0, v1, 0x100

    rem-int/lit16 v0, v0, 0x100

    iget-object v1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    int-to-byte v3, v0

    aput-byte v3, v1, v2

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->w()V

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Checksum corrected to 0x"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v3, "%02X"

    invoke-static {v2, v3, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_1
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->p(Ljava/lang/String;)V

    return-void

    :cond_2
    :goto_2
    const-string v0, "No EDID data to repair."

    goto :goto_1
.end method

.method public final v(Z)V
    .locals 1

    .line 1
    iput-boolean p1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->E:Z

    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->J:Landroid/widget/TextView;

    if-eqz p1, :cond_0

    const-string p1, "Working..."

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    :goto_0
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final w()V
    .locals 5

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    if-eqz v0, :cond_5

    array-length v0, v0

    const/16 v1, 0x80

    if-ge v0, v1, :cond_0

    goto :goto_3

    :cond_0
    const/4 v0, 0x0

    move v2, v0

    move v3, v2

    :goto_0
    if-ge v2, v1, :cond_1

    iget-object v4, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->F:[B

    aget-byte v4, v4, v2

    and-int/lit16 v4, v4, 0xff

    add-int/2addr v3, v4

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    and-int/lit16 v1, v3, 0xff

    if-nez v1, :cond_2

    const/4 v0, 0x1

    :cond_2
    iget-object v1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->K:Landroid/widget/TextView;

    if-eqz v0, :cond_3

    const-string v2, "Checksum OK"

    goto :goto_1

    :cond_3
    const-string v2, "Checksum error. Tap REPAIR CHECKSUM before write."

    :goto_1
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->K:Landroid/widget/TextView;

    if-eqz v0, :cond_4

    const v0, -0xcb2c67

    goto :goto_2

    :cond_4
    const v0, -0x78e8f

    :goto_2
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    return-void

    :cond_5
    :goto_3
    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->K:Landroid/widget/TextView;

    const-string v1, "Checksum: no EDID loaded"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/HdmiEdidRepairActivity;->K:Landroid/widget/TextView;

    const v1, -0x9f5a06

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method
