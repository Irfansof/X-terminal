.class public Lapp/gkc/terminal/Activity/DivisionRepairActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final R:[I


# instance fields
.field public B:Landroid/widget/TextView;

.field public C:Landroid/widget/TextView;

.field public D:Landroid/widget/TextView;

.field public E:Landroid/widget/TextView;

.field public F:Landroid/widget/ScrollView;

.field public G:Landroid/widget/Button;

.field public H:Landroid/hardware/usb/UsbManager;

.field public final I:Lg1/n;

.field public J:Z

.field public K:Landroid/hardware/usb/UsbDevice;

.field public L:[B

.field public M:[B

.field public N:Ljava/lang/String;

.field public final O:[Lg1/w;

.field public final P:Lb/h;

.field public final Q:Le/d0;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/high16 v0, 0x200000

    const/high16 v1, 0x400000

    const/high16 v2, 0x40000

    const/high16 v3, 0x80000

    const/high16 v4, 0x100000

    filled-new-array {v2, v3, v4, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->R:[I

    return-void
.end method

.method public constructor <init>()V
    .locals 149

    move-object/from16 v0, p0

    invoke-direct/range {p0 .. p0}, Le/m;-><init>()V

    new-instance v1, Lg1/n;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Lg1/n;-><init>(I)V

    iput-object v1, v0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->I:Lg1/n;

    const-string v1, ""

    iput-object v1, v0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->N:Ljava/lang/String;

    new-instance v1, Lg1/w;

    move-object v3, v1

    new-instance v4, Le/i;

    const/4 v15, 0x0

    filled-new-array {v15}, [I

    move-result-object v5

    const/16 v6, 0x4e7

    invoke-direct {v4, v5, v6}, Le/i;-><init>([II)V

    filled-new-array {v4}, [Le/i;

    move-result-object v4

    const-string v5, "EXACT 24C128 WDX DCBDC-1260E 06 P2 EK76603Q 1S division repair"

    const/16 v7, 0x4000

    const-string v8, "11b7ec4beed7596d3410f7f21c8b78126dc31a4e11e3c7539127a5c632ba66e5"

    invoke-direct {v1, v5, v7, v8, v4}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v1, Lg1/w;

    move-object v4, v1

    new-instance v5, Le/i;

    move-object/from16 v16, v5

    const/16 v84, 0x48

    filled-new-array/range {v84 .. v84}, [I

    move-result-object v9

    const/16 v10, 0x8b

    invoke-direct {v5, v9, v10}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v17, v5

    const/16 v9, 0x90

    filled-new-array {v15, v9}, [I

    move-result-object v10

    const/16 v11, 0x92

    invoke-direct {v5, v10, v11}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v18, v5

    const/16 v10, 0xba

    filled-new-array {v15}, [I

    move-result-object v12

    invoke-direct {v5, v12, v10}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v19, v5

    const/16 v10, 0x80

    filled-new-array {v10}, [I

    move-result-object v12

    const/16 v13, 0xbd

    invoke-direct {v5, v12, v13}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v20, v5

    const/16 v12, 0x88

    const/16 v14, 0x8

    filled-new-array {v12, v14}, [I

    move-result-object v12

    const/16 v13, 0xc2

    invoke-direct {v5, v12, v13}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v21, v5

    const/16 v12, 0xc6

    filled-new-array {v14}, [I

    move-result-object v7

    invoke-direct {v5, v7, v12}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v22, v5

    const/16 v7, 0xc8

    filled-new-array {v2}, [I

    move-result-object v12

    invoke-direct {v5, v12, v7}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v23, v5

    const/4 v7, 0x4

    const/16 v12, 0x9

    filled-new-array {v12, v7, v9}, [I

    move-result-object v7

    const/16 v9, 0xca

    invoke-direct {v5, v7, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v24, v5

    const/4 v7, 0x7

    new-array v9, v7, [I

    fill-array-data v9, :array_0

    const/16 v12, 0xdc

    invoke-direct {v5, v9, v12}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v25, v5

    const/16 v9, 0x12

    filled-new-array {v9}, [I

    move-result-object v9

    const/16 v12, 0x113

    invoke-direct {v5, v9, v12}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v26, v5

    const/16 v12, 0x41

    filled-new-array {v12}, [I

    move-result-object v9

    const/16 v13, 0x139

    invoke-direct {v5, v9, v13}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v27, v5

    const/16 v9, 0x18

    filled-new-array {v9}, [I

    move-result-object v9

    const/16 v13, 0x169

    invoke-direct {v5, v9, v13}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v28, v5

    const/16 v9, 0x43

    filled-new-array {v9}, [I

    move-result-object v9

    const/16 v13, 0x16b

    invoke-direct {v5, v9, v13}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v29, v5

    const/16 v13, 0x60

    const/4 v9, 0x3

    filled-new-array {v13, v9}, [I

    move-result-object v12

    const/16 v9, 0x16f

    invoke-direct {v5, v12, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v30, v5

    const/16 v9, 0x176

    filled-new-array {v14}, [I

    move-result-object v12

    invoke-direct {v5, v12, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v31, v5

    const/16 v9, 0x178

    filled-new-array {v14}, [I

    move-result-object v12

    invoke-direct {v5, v12, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v32, v5

    const/16 v9, 0x17a

    filled-new-array {v15}, [I

    move-result-object v12

    invoke-direct {v5, v12, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v33, v5

    filled-new-array {v10}, [I

    move-result-object v9

    const/16 v10, 0x1b8

    invoke-direct {v5, v9, v10}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v34, v5

    const/16 v9, 0x1bc

    filled-new-array {v2, v2, v2, v2}, [I

    move-result-object v10

    invoke-direct {v5, v10, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v35, v5

    filled-new-array {v15}, [I

    move-result-object v9

    invoke-direct {v5, v9, v6}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v36, v5

    const/16 v12, 0xd0

    filled-new-array {v12}, [I

    move-result-object v6

    const/16 v9, 0x1051

    invoke-direct {v5, v6, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v37, v5

    const/16 v6, 0xb5

    filled-new-array {v6}, [I

    move-result-object v9

    const/16 v10, 0x120f

    invoke-direct {v5, v9, v10}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v38, v5

    new-array v7, v7, [I

    fill-array-data v7, :array_1

    const/16 v9, 0x16c1

    invoke-direct {v5, v7, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v39, v5

    const/16 v7, 0xf1

    const/16 v9, 0x1d

    const/16 v10, 0xc5

    const/16 v13, 0xf5

    const/16 v15, 0x91

    filled-new-array {v10, v7, v9, v13, v15}, [I

    move-result-object v7

    const/16 v9, 0x16c9

    invoke-direct {v5, v7, v9}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v40, v5

    const/16 v7, 0x19

    const/16 v9, 0x82

    filled-new-array {v7, v9}, [I

    move-result-object v7

    const/16 v10, 0x16cf

    invoke-direct {v5, v7, v10}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v41, v5

    const/16 v7, 0x52

    filled-new-array {v7}, [I

    move-result-object v10

    const/16 v13, 0x16d3

    invoke-direct {v5, v10, v13}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v42, v5

    const/16 v10, 0xe2

    filled-new-array {v7, v10}, [I

    move-result-object v10

    const/16 v13, 0x16d5

    invoke-direct {v5, v10, v13}, Le/i;-><init>([II)V

    new-instance v5, Le/i;

    move-object/from16 v43, v5

    const/16 v10, 0x69

    const/16 v13, 0x27

    const/16 v2, 0xf2

    filled-new-array {v10, v7, v13, v9, v2}, [I

    move-result-object v2

    const/16 v7, 0x16d8

    invoke-direct {v5, v2, v7}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v44, v2

    const/16 v5, 0x16

    new-array v5, v5, [I

    fill-array-data v5, :array_2

    const/16 v7, 0x16de

    invoke-direct {v2, v5, v7}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v45, v2

    const/16 v13, 0x21

    new-array v5, v13, [I

    fill-array-data v5, :array_3

    const/16 v7, 0x16f5

    invoke-direct {v2, v5, v7}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v46, v2

    const/16 v5, 0x55

    new-array v5, v5, [I

    fill-array-data v5, :array_4

    const/16 v7, 0x1717

    invoke-direct {v2, v5, v7}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v47, v2

    const/16 v5, 0x78

    const/16 v7, 0x47

    const/16 v9, 0x7a

    filled-new-array {v5, v11, v7, v9, v6}, [I

    move-result-object v5

    const/16 v6, 0x176d

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v48, v2

    const/16 v5, 0xd8

    const/16 v6, 0x97

    const/16 v7, 0x7c

    const/16 v9, 0x7e

    const/16 v10, 0xfb

    filled-new-array {v7, v5, v6, v9, v10}, [I

    move-result-object v5

    const/16 v6, 0x1773

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v49, v2

    const/16 v5, 0x2f

    new-array v5, v5, [I

    fill-array-data v5, :array_5

    const/16 v6, 0x1779

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v50, v2

    const/16 v5, 0x74

    new-array v5, v5, [I

    fill-array-data v5, :array_6

    const/16 v6, 0x17a9

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v51, v2

    const/16 v5, 0x20

    new-array v6, v5, [I

    fill-array-data v6, :array_7

    const/16 v7, 0x181e

    invoke-direct {v2, v6, v7}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v52, v2

    const/16 v6, 0xff

    filled-new-array {v6}, [I

    move-result-object v7

    const/16 v11, 0x1840

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v53, v2

    const/16 v11, 0x15

    new-array v7, v11, [I

    fill-array-data v7, :array_8

    const/16 v11, 0x1844

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v54, v2

    const/4 v7, 0x6

    new-array v7, v7, [I

    fill-array-data v7, :array_9

    const/16 v11, 0x185a

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v55, v2

    new-array v7, v14, [I

    fill-array-data v7, :array_a

    const/16 v11, 0x1861

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v56, v2

    new-array v7, v14, [I

    fill-array-data v7, :array_b

    const/16 v11, 0x186a

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v57, v2

    new-array v7, v5, [I

    fill-array-data v7, :array_c

    const/16 v11, 0x1873

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v58, v2

    const/16 v7, 0xa7

    filled-new-array {v7}, [I

    move-result-object v7

    const/16 v11, 0x1894

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v59, v2

    const/16 v7, 0x41

    new-array v11, v7, [I

    fill-array-data v11, :array_d

    const/16 v7, 0x1896

    invoke-direct {v2, v11, v7}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v60, v2

    const/16 v7, 0x9c

    new-array v7, v7, [I

    fill-array-data v7, :array_e

    const/16 v11, 0x18d8

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v61, v2

    const/16 v7, 0x96

    const/16 v11, 0x4c

    filled-new-array {v7, v11}, [I

    move-result-object v7

    const/16 v11, 0x1975

    invoke-direct {v2, v7, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v62, v2

    const/16 v7, 0xb3

    const/16 v11, 0x2c

    const/16 v13, 0xcc

    const/16 v15, 0xec

    filled-new-array {v7, v11, v13, v12, v15}, [I

    move-result-object v13

    const/16 v15, 0x1978

    invoke-direct {v2, v13, v15}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v63, v2

    const/16 v13, 0xed

    filled-new-array {v13}, [I

    move-result-object v13

    const/16 v15, 0x197e

    invoke-direct {v2, v13, v15}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v64, v2

    const/16 v13, 0xb

    new-array v13, v13, [I

    fill-array-data v13, :array_f

    const/16 v15, 0x1980

    invoke-direct {v2, v13, v15}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v65, v2

    new-array v11, v11, [I

    fill-array-data v11, :array_10

    const/16 v13, 0x198c

    invoke-direct {v2, v11, v13}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v66, v2

    const/16 v11, 0xf6

    const/16 v13, 0x3f

    const/16 v15, 0xf9

    const/16 v12, 0xa9

    filled-new-array {v11, v9, v13, v15, v12}, [I

    move-result-object v9

    const/16 v11, 0x19b9

    invoke-direct {v2, v9, v11}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v67, v2

    const/16 v9, 0xd6

    filled-new-array {v10, v9}, [I

    move-result-object v9

    const/16 v10, 0x19bf

    invoke-direct {v2, v9, v10}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v68, v2

    filled-new-array {v6}, [I

    move-result-object v6

    const/16 v9, 0x19c3

    invoke-direct {v2, v6, v9}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v69, v2

    const/16 v6, 0x30

    filled-new-array {v6}, [I

    move-result-object v6

    const/16 v9, 0x19c7

    invoke-direct {v2, v6, v9}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v70, v2

    const/16 v6, 0x14

    new-array v6, v6, [I

    fill-array-data v6, :array_11

    const/16 v9, 0x19c9

    invoke-direct {v2, v6, v9}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v71, v2

    const/16 v6, 0x62

    const/16 v9, 0x25

    const/16 v10, 0x4b

    const/16 v11, 0x62

    const/16 v12, 0xc2

    filled-new-array {v10, v6, v9, v11, v12}, [I

    move-result-object v6

    const/16 v9, 0x19de

    invoke-direct {v2, v6, v9}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v72, v2

    const/16 v6, 0x77

    filled-new-array {v6}, [I

    move-result-object v6

    const/16 v9, 0x19e4

    invoke-direct {v2, v6, v9}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v73, v2

    new-array v5, v5, [I

    fill-array-data v5, :array_12

    const/16 v6, 0x19e6

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v74, v2

    new-array v5, v14, [I

    fill-array-data v5, :array_13

    const/16 v6, 0x1a07

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v75, v2

    const/16 v5, 0x85

    const/16 v15, 0x37

    const/16 v6, 0x38

    const/16 v9, 0x91

    filled-new-array {v15, v5, v7, v6, v9}, [I

    move-result-object v5

    const/16 v6, 0x1a10

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v76, v2

    const/16 v5, 0x39

    const/16 v6, 0x9e

    filled-new-array {v5, v6}, [I

    move-result-object v5

    const/16 v6, 0x1a16

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v77, v2

    const/16 v5, 0x3a

    const/16 v6, 0xaa

    filled-new-array {v5, v6}, [I

    move-result-object v5

    const/16 v6, 0x1a19

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v78, v2

    const/16 v5, 0x11

    new-array v5, v5, [I

    fill-array-data v5, :array_14

    const/16 v6, 0x1a1c

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v79, v2

    const/16 v5, 0x1a

    new-array v5, v5, [I

    fill-array-data v5, :array_15

    const/16 v6, 0x1a2e

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v80, v2

    const/16 v5, 0x3e

    new-array v5, v5, [I

    fill-array-data v5, :array_16

    const/16 v6, 0x1a49

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v81, v2

    const/16 v5, 0xc0

    new-array v5, v5, [I

    fill-array-data v5, :array_17

    const/16 v6, 0x1a88

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v82, v2

    const/16 v5, 0x25de

    filled-new-array {v15}, [I

    move-result-object v6

    invoke-direct {v2, v6, v5}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    move-object/from16 v83, v2

    const/16 v5, 0xa9

    const/16 v12, 0xd0

    filled-new-array {v5, v12}, [I

    move-result-object v5

    const/16 v6, 0x3ffe

    invoke-direct {v2, v5, v6}, Le/i;-><init>([II)V

    filled-new-array/range {v16 .. v83}, [Le/i;

    move-result-object v2

    const-string v5, "EXACT 24C128 WDX DCBDC-1260E 06 P2 EK76603Q load repair"

    const/16 v6, 0x4000

    invoke-direct {v1, v5, v6, v8, v2}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v1, Lg1/w;

    move-object v5, v1

    new-instance v2, Le/i;

    const/16 v57, 0x58

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v6

    const v13, 0xe27b

    invoke-direct {v2, v6, v13}, Le/i;-><init>([II)V

    filled-new-array {v2}, [Le/i;

    move-result-object v2

    const-string v6, "dc30e504dbc91d70080f6bb9100ca43a28c10865da1796d8c1dafc7755bb9075"

    const-string v7, "EXACT 1MB 1S 4K division repair"

    const/high16 v11, 0x100000

    invoke-direct {v1, v7, v11, v6, v2}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v16, Lg1/w;

    move-object/from16 v6, v16

    const-string v17, "EXACT TD-0006 4K division repair"

    const/high16 v18, 0x100000

    const/16 v1, 0x41

    new-array v2, v1, [I

    fill-array-data v2, :array_18

    const/16 v20, 0x20

    const/16 v21, 0x0

    const v22, 0x271ce

    move-object/from16 v19, v2

    invoke-direct/range {v16 .. v22}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v23, Lg1/w;

    move-object/from16 v7, v23

    const-string v24, "EXACT 25Q40 4MB 4K division repair"

    const/high16 v25, 0x400000

    const/16 v1, 0x41

    new-array v2, v1, [I

    fill-array-data v2, :array_19

    const/16 v27, 0x20

    const/16 v28, 0x54

    const v29, 0x13c4b

    move-object/from16 v26, v2

    invoke-direct/range {v23 .. v29}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v16, Lg1/w;

    move-object/from16 v8, v16

    const-string v17, "EXACT ACE25Q800G 4K division repair"

    const/16 v1, 0x41

    new-array v2, v1, [I

    fill-array-data v2, :array_1a

    const/16 v21, 0x49

    const v22, 0x1174b

    move-object/from16 v19, v2

    invoke-direct/range {v16 .. v22}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v23, Lg1/w;

    const/4 v2, 0x3

    move-object/from16 v9, v23

    const-string v24, "EXACT N4TB430UHDF7D K1.0D DD 2S / 1S 4K division repair"

    const/high16 v25, 0x80000

    const-string v26, "e06cc0db617372a37ee824da67e427c7d6ae101d4db465f19ac3542421dbfc30"

    const-string v27, "7d78440b96871341f3d4068f9271a5a046fdfe27f53dd7e9c2f803ee51b6cf17"

    new-instance v10, Le/i;

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v1

    invoke-direct {v10, v1, v13}, Le/i;-><init>([II)V

    filled-new-array {v10}, [Le/i;

    move-result-object v28

    new-instance v1, Le/i;

    const/16 v69, 0x59

    filled-new-array/range {v69 .. v69}, [I

    move-result-object v10

    invoke-direct {v1, v10, v13}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v29

    const/16 v30, 0x0

    invoke-direct/range {v23 .. v30}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;Z)V

    new-instance v16, Lg1/w;

    move-object/from16 v10, v16

    const-string v17, "EXACT 43F7D 1S / 2S 4K division repair"

    const/high16 v18, 0x80000

    const-string v19, "b57726865d68e8b192d563fc8baef309a876f32d76cf677d8066076904972170"

    const-string v20, "95266779da3709288120e55ff7f14c0e276d86420694553201b1436788d1e089"

    new-instance v1, Le/i;

    const v11, 0x1317b

    filled-new-array/range {v69 .. v69}, [I

    move-result-object v12

    invoke-direct {v1, v12, v11}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v21

    new-instance v1, Le/i;

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v12

    invoke-direct {v1, v12, v11}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v22

    invoke-direct/range {v16 .. v22}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;)V

    new-instance v24, Lg1/w;

    const/16 v1, 0x15

    const/high16 v12, 0x100000

    const/16 v53, 0x4c

    move-object/from16 v11, v24

    const-string v25, "EXACT 1S FILE 5 1S / 2S 4K division repair"

    const/high16 v26, 0x80000

    const-string v27, "01e4921510f536711ad60b0cbbbd650dbffacefdc319eb85ff585d3c8833414e"

    const-string v28, "744a9180b93abbdfbbffb33e373073e44c667330b1a82058da15ebb7bbe1045a"

    new-instance v12, Le/i;

    filled-new-array/range {v69 .. v69}, [I

    move-result-object v13

    const v2, 0xf77b

    invoke-direct {v12, v13, v2}, Le/i;-><init>([II)V

    filled-new-array {v12}, [Le/i;

    move-result-object v29

    new-instance v12, Le/i;

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v13

    invoke-direct {v12, v13, v2}, Le/i;-><init>([II)V

    filled-new-array {v12}, [Le/i;

    move-result-object v30

    invoke-direct/range {v24 .. v30}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;)V

    new-instance v31, Lg1/w;

    const/high16 v1, 0x100000

    const/16 v13, 0x41

    move-object/from16 v12, v31

    const-string v32, "EXACT BOE 43 WDX F7D 4K division repair"

    const/high16 v33, 0x80000

    new-array v15, v13, [I

    fill-array-data v15, :array_1b

    const/16 v35, 0x20

    const/16 v36, 0x58

    const v37, 0x1075b

    move-object/from16 v34, v15

    invoke-direct/range {v31 .. v37}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v15, Lg1/w;

    move v2, v13

    const v1, 0xe27b

    const/16 v55, 0x60

    move-object v13, v15

    new-instance v2, Le/i;

    filled-new-array {v14}, [I

    move-result-object v0

    invoke-direct {v2, v0, v1}, Le/i;-><init>([II)V

    filled-new-array {v2}, [Le/i;

    move-result-object v0

    const-string v2, "74562a7c3dd32130218ebe0cd9aaf32e65dfa8fd0db099d7bb102e1d247a3c3e"

    const-string v14, "EXACT BOE HV430QUB F7A 4K division repair"

    const/high16 v1, 0x80000

    invoke-direct {v15, v14, v1, v2, v0}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    const/16 v2, 0x8

    move-object v14, v0

    new-instance v15, Le/i;

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v2

    const v1, 0xe27b

    invoke-direct {v15, v2, v1}, Le/i;-><init>([II)V

    filled-new-array {v15}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT TU682KCG4F1-A V1.0 4K division repair"

    const-string v15, "90214734922181f5b55faa7cd46b004cf8437f9fe502da3581635d4f41c9409c"

    move-object/from16 v125, v3

    const/high16 v3, 0x80000

    invoke-direct {v0, v2, v3, v15, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v18, Lg1/w;

    const/4 v0, 0x0

    const/16 v1, 0x37

    move-object/from16 v15, v18

    const-string v19, "EXACT FM25Q08 4K division repair"

    const/high16 v20, 0x100000

    const/16 v2, 0x41

    new-array v3, v2, [I

    fill-array-data v3, :array_1c

    const/16 v22, 0x20

    const/16 v23, 0x0

    const v24, 0x2724e

    move-object/from16 v21, v3

    invoke-direct/range {v18 .. v24}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v30, Lg1/w;

    move-object/from16 v16, v30

    const-string v31, "EXACT HV550QUB E1E WDX 4K division repair"

    const/high16 v32, 0x80000

    const/16 v2, 0x41

    new-array v3, v2, [I

    fill-array-data v3, :array_1d

    const/16 v34, 0x20

    const/16 v35, 0x0

    const/16 v36, 0x645d

    move-object/from16 v33, v3

    invoke-direct/range {v30 .. v36}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v18, Lg1/w;

    move-object/from16 v17, v18

    const-string v19, "EXACT HV550QUB FID 4K division repair"

    const/16 v2, 0x41

    new-array v3, v2, [I

    fill-array-data v3, :array_1e

    const/16 v23, 0x58

    const v24, 0xe25b

    move-object/from16 v21, v3

    invoke-direct/range {v18 .. v24}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v2, Lg1/w;

    move-object/from16 v18, v2

    new-instance v3, Le/i;

    const v1, 0x10c7b

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v0

    invoke-direct {v3, v0, v1}, Le/i;-><init>([II)V

    filled-new-array {v3}, [Le/i;

    move-result-object v0

    const-string v1, "EXACT HF500QUB-F20 4K division repair"

    const-string v3, "d78d599cca8d84caefb4216b0e83c96c9c57aa2afc35258a415baeba6f288f92"

    move-object/from16 v126, v4

    const/high16 v4, 0x80000

    invoke-direct {v2, v1, v4, v3, v0}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v20, Lg1/w;

    move-object/from16 v19, v20

    const-string v21, "EXACT HV55QUB F72 4K division repair"

    const/high16 v22, 0x80000

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_1f

    const/16 v24, 0x20

    const/16 v25, 0x0

    const/16 v26, 0x645e

    move-object/from16 v23, v1

    invoke-direct/range {v20 .. v26}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v30, Lg1/w;

    move-object/from16 v20, v30

    const-string v31, "EXACT IS25LQ020B PT430 4K division repair"

    const/high16 v32, 0x40000

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_20

    const/16 v35, 0x54

    const v36, 0x12a4b

    move-object/from16 v33, v1

    invoke-direct/range {v30 .. v36}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v22, Lg1/w;

    move-object/from16 v21, v22

    const-string v23, "EXACT LC550 EQC KIWMAGIC 4K division repair"

    const/high16 v24, 0x80000

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_21

    const/16 v26, 0x20

    const/16 v27, 0x48

    const v28, 0xdb5b

    move-object/from16 v25, v1

    invoke-direct/range {v22 .. v28}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v0, Lg1/w;

    move-object/from16 v22, v0

    new-instance v1, Le/i;

    filled-new-array/range {v84 .. v84}, [I

    move-result-object v2

    const v3, 0xe27b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT DCBDU-C196A-17 Kiwiimage KV7636 51pin to96pin 4K division repair"

    const-string v3, "4ba69a8b6a32edb69d241bad1e3d8fc7dcef33928025e2565abeab2d31105e7e"

    const/high16 v4, 0x80000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v23, v0

    new-instance v1, Le/i;

    const v2, 0x11b6b

    filled-new-array/range {v53 .. v53}, [I

    move-result-object v3

    invoke-direct {v1, v3, v2}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const/high16 v2, 0x200000

    const-string v3, "e34295a3275a0ce80fa41373154b06ca3375c5b52cfd549d76976d5d22aaeee2"

    const-string v4, "EXACT PT550GT03-1C KV7636VPP 4K division repair"

    invoke-direct {v0, v4, v2, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v30, Lg1/w;

    move-object/from16 v24, v30

    const-string v31, "EXACT P25Q80H 170338 4K division repair"

    const/high16 v32, 0x100000

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_22

    const/16 v35, 0x47

    const v36, 0xe25b

    move-object/from16 v33, v1

    invoke-direct/range {v30 .. v36}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v41, Lg1/w;

    move-object/from16 v25, v41

    const-string v42, "EXACT P25Q80H 20543 4K division repair"

    const/high16 v43, 0x100000

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_23

    const/16 v45, 0x20

    const/16 v46, 0x6

    const/16 v47, 0x207c

    move-object/from16 v44, v1

    invoke-direct/range {v41 .. v47}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v0, Lg1/w;

    move-object/from16 v26, v0

    new-instance v1, Le/i;

    const v2, 0xf57b

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v3

    invoke-direct {v1, v3, v2}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT P25Q80H LQ-K12-B13-11 HV750QUB-E97 4K division repair"

    const-string v3, "e07a8e5fb96efa005e4a885939378949d0e87f63065f430f9448166c66faf6fb"

    const/high16 v4, 0x100000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v27, v0

    new-instance v1, Le/i;

    const/16 v2, 0x57

    filled-new-array {v2}, [I

    move-result-object v2

    const v3, 0xe07b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT P25Q80H 20251110 171519 4K division repair"

    const-string v3, "d34f02ac11387f50595825cb8850fd63befca39e9092ac5ce7cdb9f8706c6fd6"

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v28, v0

    new-instance v1, Le/i;

    const/16 v2, 0x49

    filled-new-array {v2}, [I

    move-result-object v2

    const v3, 0xf77b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT T500QVN04.1 4K division repair"

    const-string v3, "5b69c27522d29c82f99802ccc4c1eb8ac70f824a50543279f417d27185b3d6be"

    const/high16 v4, 0x80000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v30, Lg1/w;

    move-object/from16 v29, v30

    const-string v31, "EXACT ST425D02 4K division repair"

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_24

    const/16 v35, 0x4c

    const v36, 0xf75b

    move-object/from16 v33, v1

    invoke-direct/range {v30 .. v36}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v41, Lg1/w;

    move-object/from16 v30, v41

    const-string v42, "EXACT ST5461D13 4K division repair"

    const/high16 v43, 0x80000

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_25

    const/16 v46, 0x4c

    const v47, 0xe25b

    move-object/from16 v44, v1

    invoke-direct/range {v41 .. v47}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v32, Lg1/w;

    move-object/from16 v31, v32

    const-string v33, "EXACT STOG 4K division repair"

    const/high16 v34, 0x80000

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_26

    const/16 v36, 0x20

    const/16 v37, 0x0

    const/16 v38, 0x645d

    move-object/from16 v35, v1

    invoke-direct/range {v32 .. v38}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v41, Lg1/w;

    move-object/from16 v32, v41

    const-string v42, "EXACT V500DJ7 QE1 4K division repair"

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_27

    const/16 v46, 0x0

    const/16 v47, 0x645d

    move-object/from16 v44, v1

    invoke-direct/range {v41 .. v47}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v70, Lg1/w;

    move-object/from16 v33, v70

    const-string v71, "EXACT ZB25VQ40 184339 4K division repair"

    const/high16 v72, 0x80000

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_28

    const/16 v74, 0x20

    const/16 v75, 0x4c

    const v76, 0xf75b

    move-object/from16 v73, v1

    invoke-direct/range {v70 .. v76}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v41, Lg1/w;

    move-object/from16 v34, v41

    const-string v42, "EXACT ZB25VQ40 202835 4K division repair"

    const/16 v0, 0x41

    new-array v1, v0, [I

    fill-array-data v1, :array_29

    const/16 v46, 0x48

    const v47, 0xe25b

    move-object/from16 v44, v1

    invoke-direct/range {v41 .. v47}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v70, Lg1/w;

    move-object/from16 v35, v70

    const-string v71, "EXACT ZB25VQ40 ORG 4K division repair"

    const/16 v0, 0x41

    new-array v0, v0, [I

    fill-array-data v0, :array_2a

    const/16 v75, 0x14

    const v76, 0xf85b

    move-object/from16 v73, v0

    invoke-direct/range {v70 .. v76}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v0, Lg1/w;

    move-object/from16 v36, v0

    new-instance v1, Le/i;

    const/16 v2, 0x51

    filled-new-array {v2}, [I

    move-result-object v2

    const v3, 0x11a7b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT ZB25VQ40 ORG 11A7B 4K division repair"

    const-string v4, "c83d09d36d3f727319950fce1c797fb9273c4ddd0a57e225b4db26b05c05b4ad"

    const/high16 v3, 0x80000

    invoke-direct {v0, v2, v3, v4, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v37, v0

    new-instance v1, Le/i;

    const v2, 0xcc74

    const/4 v4, 0x0

    filled-new-array {v4}, [I

    move-result-object v3

    invoke-direct {v1, v3, v2}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT ZB25VQ40 20251018 194514 4K division repair"

    const-string v3, "2455bdb7fca51e9308cdd833719f724950438140cc268f13d4bbb9d19950c3f0"

    const/high16 v4, 0x80000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v38, v0

    new-instance v1, Le/i;

    filled-new-array/range {v84 .. v84}, [I

    move-result-object v2

    const v3, 0xe27b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT ZB25VQ40 20260703 144805 4K division repair"

    const-string v3, "0dc4d002b461c8a9a683bbd3ddeccd8f132812c7fb81aedbfc1efa51eb199f20"

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v39, v0

    new-instance v1, Le/i;

    const/16 v2, 0x34

    const/16 v3, 0x31

    const/16 v4, 0x38

    filled-new-array {v2, v3, v4}, [I

    move-result-object v2

    const v4, 0x17fe7

    invoke-direct {v1, v2, v4}, Le/i;-><init>([II)V

    new-instance v2, Le/i;

    const/16 v4, 0x35

    const/16 v3, 0x40

    move-object/from16 v127, v5

    const/16 v5, 0x37

    filled-new-array {v5, v4, v3}, [I

    move-result-object v3

    const v4, 0x17feb

    invoke-direct {v2, v3, v4}, Le/i;-><init>([II)V

    new-instance v3, Le/i;

    const/16 v4, 0x36

    filled-new-array {v4}, [I

    move-result-object v4

    const v5, 0x17fef

    invoke-direct {v3, v4, v5}, Le/i;-><init>([II)V

    new-instance v4, Le/i;

    move-object/from16 v128, v6

    const/4 v5, 0x0

    filled-new-array {v5}, [I

    move-result-object v6

    const v5, 0x18d82

    invoke-direct {v4, v6, v5}, Le/i;-><init>([II)V

    filled-new-array {v1, v2, v3, v4}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT ZB25VQ40 20260203 194126 4K division repair"

    const-string v3, "5eaa16fded7b4e4f3422fbb4b4843c41db86e5a04760dd0ea4ec8fb06c4f6790"

    const/high16 v4, 0x80000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v40, v0

    new-instance v1, Le/i;

    const/4 v2, 0x0

    filled-new-array {v2}, [I

    move-result-object v3

    const/16 v6, 0x647e

    invoke-direct {v1, v3, v6}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT ZB25VQ40 DCBDS-B268G 09 4K division repair"

    const-string v6, "9afe52d8e2c24409857ced189e132cfc2c90b6fbadeaa10edfff09662e936c08"

    invoke-direct {v0, v3, v4, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v41, v0

    new-instance v1, Le/i;

    filled-new-array {v2}, [I

    move-result-object v3

    invoke-direct {v1, v3, v5}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT ZB25VQ40 20260926 133153 1S 4K division repair"

    const-string v3, "0ef6359d5cf7f87d06d54c07fd62b9ee4347155005a8c46fd2782cf407b5ddb9"

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v42, v0

    new-instance v1, Le/i;

    const/16 v2, 0x10

    filled-new-array {v2}, [I

    move-result-object v3

    const/16 v6, 0x647e

    invoke-direct {v1, v3, v6}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT ZB25VQ40 DCBDS-B268G 09 HV650QUB-F74 1S 4K division repair"

    const-string v6, "7a18cf2a5604042dd610f241f64bb5a0ece1a9d18f6852ccb67f774df9c873ba"

    invoke-direct {v0, v3, v4, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v43, v0

    new-instance v1, Le/i;

    const v3, 0x127bb

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v6

    invoke-direct {v1, v6, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT ZB25VQ40 HV550QU1-BF2 2S DCBDS-B268N-03 4K division repair"

    const-string v6, "408a48b647d0b89c7657a8e47781cba873902b6705f25723d61997b28cbe9764"

    invoke-direct {v0, v3, v4, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v44, v0

    new-instance v1, Le/i;

    const/16 v3, 0x45

    filled-new-array {v3}, [I

    move-result-object v3

    const v6, 0x11a7b

    invoke-direct {v1, v3, v6}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT ZB25VQ40 2S 20260903 4K division repair"

    const-string v6, "cc22d4234a87fefb679295aeac2bf72b941bb92e39cc6de235d3585b09d28613"

    invoke-direct {v0, v3, v4, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v45, v0

    new-instance v1, Le/i;

    filled-new-array/range {v69 .. v69}, [I

    move-result-object v3

    const v6, 0xe27b

    invoke-direct {v1, v3, v6}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT HV650QUB-F70 2S 4K division repair"

    const-string v6, "aa6b584f8facb04d665e262bf316995aca49ebf101010c779b261d4598a61cf5"

    invoke-direct {v0, v3, v4, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v70, Lg1/w;

    move-object/from16 v46, v70

    const-string v71, "EXACT BOE HV430QUB-F70 DCBDS-B260B-16 1S / 2S 4K division repair"

    const v72, 0x1425c

    const-string v73, "462e806097585b5050523e1e164fa5b384aece7788afb9cc89f532e6594fd068"

    const-string v74, "9e519352bf814417a680d3188b159e91daba8c5cd42d4ab2ee7f2457acb59f9f"

    new-instance v0, Le/i;

    filled-new-array/range {v69 .. v69}, [I

    move-result-object v1

    const v3, 0xe07b

    invoke-direct {v0, v1, v3}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v75

    new-instance v0, Le/i;

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v1

    invoke-direct {v0, v1, v3}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v76

    invoke-direct/range {v70 .. v76}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;)V

    new-instance v77, Lg1/w;

    move-object/from16 v47, v77

    const-string v78, "EXACT HV430QUB-F70 B260B-08 HX5602L07 1S / 2S 4K division repair"

    const v79, 0x7aa5d

    const-string v80, "54109920647cc12286148918ec85281b85a9597c468872a82a09d370ac6237ea"

    const-string v81, "df6bc802f7561ef2db2ff3d450385a13932fc1d705cffe960cd7a03b6767e6ae"

    new-instance v0, Le/i;

    filled-new-array {v2}, [I

    move-result-object v1

    invoke-direct {v0, v1, v5}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v82

    new-instance v0, Le/i;

    const/4 v1, 0x0

    filled-new-array {v1}, [I

    move-result-object v3

    invoke-direct {v0, v3, v5}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v83

    invoke-direct/range {v77 .. v83}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;)V

    new-instance v91, Lg1/w;

    move-object/from16 v48, v91

    const-string v92, "EXACT ZB25VQ40 F70 1S / 2S 4K division repair"

    const/high16 v93, 0x80000

    const-string v94, "1897fde6a97692f58851491dd6d9f4113e566da52bb09ac6633e42e498c87f25"

    const-string v95, "66427131b54f339c4e6dd074e3d3278e8b358d622cf0dd391346a75a5d30ac1f"

    new-instance v0, Le/i;

    filled-new-array/range {v69 .. v69}, [I

    move-result-object v1

    const v3, 0xe07b

    invoke-direct {v0, v1, v3}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v96

    new-instance v0, Le/i;

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v1

    invoke-direct {v0, v1, v3}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v97

    const/16 v98, 0x0

    invoke-direct/range {v91 .. v98}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;Z)V

    new-instance v70, Lg1/w;

    move-object/from16 v49, v70

    const-string v71, "EXACT ZB25VQ40 20261022 181407 1S / 2S 4K division repair"

    const/high16 v72, 0x80000

    const-string v73, "fb5396536cc64c01c9cfd44e52161395cdd441b618118431dc2fb798fc84cf6b"

    const-string v74, "5fd2b14c7c6e17de9b58267504a462518c2000c0174b9135266bbd0d42cedece"

    new-instance v0, Le/i;

    filled-new-array/range {v69 .. v69}, [I

    move-result-object v1

    const v3, 0xe07b

    invoke-direct {v0, v1, v3}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v75

    new-instance v0, Le/i;

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v1

    invoke-direct {v0, v1, v3}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v76

    const/16 v77, 0x0

    invoke-direct/range {v70 .. v77}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;Z)V

    new-instance v91, Lg1/w;

    move-object/from16 v50, v91

    const-string v92, "EXACT ZB25VQ40 AUO43 96PIN 1S / 2S 4K division repair"

    const-string v94, "ec2a26c8edd87e252b40f2c7c094153f241d07aaeae92a2bdb614a966933e16a"

    const-string v95, "b9ebc8f023db3239a7e671bf401381bdfdd9cb7f604f185fb96ff816fa4b7d02"

    new-instance v0, Le/i;

    filled-new-array/range {v84 .. v84}, [I

    move-result-object v1

    const v3, 0x1077b

    invoke-direct {v0, v1, v3}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v96

    new-instance v0, Le/i;

    const/16 v1, 0x49

    filled-new-array {v1}, [I

    move-result-object v1

    invoke-direct {v0, v1, v3}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v97

    invoke-direct/range {v91 .. v98}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;Z)V

    new-instance v70, Lg1/w;

    move-object/from16 v51, v70

    const-string v71, "EXACT ZB25VQ40 6260477298542124958 1S / 2S 4K division repair"

    const-string v73, "0acd1f66bf3a21d58ac14a65ecc3558f0f032bda640ccc874ff675a2235e4d82"

    const-string v74, "249090cd5e34ced7fc89bb52fb4926f988c06d9f54a76c70902e113c85bfe0ea"

    new-instance v0, Le/i;

    const/16 v1, 0x15

    filled-new-array {v1}, [I

    move-result-object v1

    const v4, 0x1277b

    invoke-direct {v0, v1, v4}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v75

    new-instance v0, Le/i;

    const/16 v1, 0x14

    filled-new-array {v1}, [I

    move-result-object v1

    invoke-direct {v0, v1, v4}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v76

    invoke-direct/range {v70 .. v76}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;)V

    new-instance v77, Lg1/w;

    move-object/from16 v52, v77

    const-string v78, "EXACT ST442 1S / 2S 4K division repair"

    const/high16 v79, 0x100000

    const-string v80, "fdd6880e095e9750fb019fc7d87ca922c90ac970b920bd5021f1a695c6b1ac46"

    const-string v81, "4214843332a8a7600eb47c00dadd7b49ec65ed785838dbc0562a5167820c4388"

    new-instance v0, Le/i;

    const/16 v1, 0x4d

    filled-new-array {v1}, [I

    move-result-object v1

    const v4, 0x1322b

    invoke-direct {v0, v1, v4}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v82

    new-instance v0, Le/i;

    const v1, 0x1322b

    filled-new-array/range {v53 .. v53}, [I

    move-result-object v4

    invoke-direct {v0, v4, v1}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v83

    invoke-direct/range {v77 .. v83}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;)V

    new-instance v85, Lg1/w;

    move-object/from16 v53, v85

    const-string v86, "EXACT HV550QUB-F70 1S / 2S 4K division repair"

    const/high16 v87, 0x80000

    const-string v88, "7f07ad4ebc1ce882664619b5e86fe6ae7085b5872d93d93e0952e1b3c190d80f"

    const-string v89, "622aad08d947462ecf20009660ebe138217297cd742f27a8fd1893f755f95d53"

    new-instance v0, Le/i;

    const/4 v1, 0x0

    filled-new-array {v1}, [I

    move-result-object v4

    const/16 v1, 0x647d

    invoke-direct {v0, v4, v1}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v90

    new-instance v0, Le/i;

    filled-new-array {v2}, [I

    move-result-object v4

    invoke-direct {v0, v4, v1}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v91

    const/16 v92, 0x0

    invoke-direct/range {v85 .. v92}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;Z)V

    new-instance v70, Lg1/w;

    move-object/from16 v54, v70

    const-string v71, "EXACT ZB25VQ40 20261027 194517 1S / 2S 4K division repair"

    const-string v73, "93c9230423ec7cb0f51bc7dd3c8940cd5ebf8646067899c6aa5bc371ce7ac39e"

    const-string v74, "bb9af845f69982c674445c5396bdec24e3bb2f85241adae0bff73d945eb4a6c8"

    new-instance v0, Le/i;

    filled-new-array/range {v55 .. v55}, [I

    move-result-object v4

    const v6, 0x1bddb

    invoke-direct {v0, v4, v6}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v75

    new-instance v0, Le/i;

    const/16 v4, 0x61

    filled-new-array {v4}, [I

    move-result-object v4

    invoke-direct {v0, v4, v6}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v76

    const/16 v77, 0x0

    invoke-direct/range {v70 .. v77}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;Z)V

    new-instance v85, Lg1/w;

    move-object/from16 v55, v85

    const-string v86, "EXACT 430QUB-F7F 1S / 2S 4K division repair"

    const-string v88, "e9b8cdaaa78e6ab0e1e2c13fe1d19e6a74c7d0d010f9316505115cf2ebf926b2f"

    const-string v89, "2f4cfbb1a762c3cb49c03918315ef661b85d7f7b93c8df1056dcc6fdaf1d7cbc"

    new-instance v0, Le/i;

    const/4 v4, 0x0

    filled-new-array {v4}, [I

    move-result-object v6

    const/16 v4, 0x647e

    invoke-direct {v0, v6, v4}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v90

    new-instance v0, Le/i;

    filled-new-array {v2}, [I

    move-result-object v6

    invoke-direct {v0, v6, v4}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v91

    invoke-direct/range {v85 .. v92}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;Z)V

    new-instance v0, Lg1/w;

    move-object/from16 v56, v0

    new-instance v4, Le/i;

    const v6, 0xe47b

    filled-new-array/range {v57 .. v57}, [I

    move-result-object v1

    invoke-direct {v4, v1, v6}, Le/i;-><init>([II)V

    filled-new-array {v4}, [Le/i;

    move-result-object v1

    const-string v4, "EXACT ZB25VQ40 HV650QUB-E9D 1S 4K division repair"

    const-string v6, "d598f6f16a9672d451d11344a6a82e44542a14546c4b3650106b2ffdf8f6a841"

    const/high16 v2, 0x80000

    invoke-direct {v0, v4, v2, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v57, v0

    new-instance v1, Le/i;

    filled-new-array/range {v84 .. v84}, [I

    move-result-object v4

    invoke-direct {v1, v4, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT ZB25VQ40 1S TCON 4K division repair"

    const-string v4, "d7d9be4b7257d17ef1fbe9bb747b3839112fd2f4e28bc2c08e3a906884383287"

    invoke-direct {v0, v3, v2, v4, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v58, v0

    new-instance v1, Le/i;

    const/4 v3, 0x0

    filled-new-array {v3}, [I

    move-result-object v4

    const/16 v6, 0x647e

    invoke-direct {v1, v4, v6}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v4, "EXACT ZB25VQ40 SAMSUNG 43 1S 4K division repair"

    const-string v6, "661d157091f7688b349bd73ddd8abbad4bdb3b0460d71cf755df0910d6865ff6"

    invoke-direct {v0, v4, v2, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v59, v0

    new-instance v1, Le/i;

    const/16 v4, 0x1e0

    filled-new-array {v3}, [I

    move-result-object v6

    invoke-direct {v1, v6, v4}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v4, "EXACT ZB25VQ40 20111114 1S 4K division repair"

    const-string v6, "a5fd9d7ce7089467342b906e0c4464fbe77a0c97b0ce3b9b5252702713cd9fbe"

    invoke-direct {v0, v4, v2, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v60, v0

    new-instance v1, Le/i;

    filled-new-array {v3}, [I

    move-result-object v4

    const/16 v6, 0x647e

    invoke-direct {v1, v4, v6}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v4, "EXACT 25X40 512KB 1S 4K division repair"

    const-string v6, "e7d52c44f65bfbb30d2c54f12ff64320d4ca943324ddc35b61497eaa051181ce"

    invoke-direct {v0, v4, v2, v6, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v61, v0

    new-instance v1, Le/i;

    filled-new-array {v3}, [I

    move-result-object v4

    invoke-direct {v1, v4, v5}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT 25X40 512KB 20261003 4K division repair"

    const-string v4, "b216f1e3068b8a0100994a5830a0f4539275380682c0435e6c724ec913a3ca09"

    invoke-direct {v0, v3, v2, v4, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v62, v0

    new-instance v1, Le/i;

    const/16 v3, 0x44

    filled-new-array {v3}, [I

    move-result-object v3

    const v4, 0x11a7b

    invoke-direct {v1, v3, v4}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT LC550EQC-SMA4 1S 4K division repair"

    const-string v4, "81c610e17d9089b8c28c007d63cb8398d954dfab52debd086c2401795910ca54"

    invoke-direct {v0, v3, v2, v4, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v63, v0

    new-instance v1, Le/i;

    filled-new-array/range {v84 .. v84}, [I

    move-result-object v2

    const v3, 0xe27b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT P25Q80H SOP8-200 1S 4K division repair"

    const-string v3, "2aeae874d1057083faf34dc8b74789f9dbd24ed3525a416316f312434327e888"

    const/high16 v4, 0x100000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v64, v0

    new-instance v1, Le/i;

    const/16 v2, 0xd

    filled-new-array {v2}, [I

    move-result-object v2

    const v3, 0xee7b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT P25Q80 ST5461D11D 2S 4K division repair"

    const-string v3, "9aa516428d69a647de66d222f091547390c928c765b1db137548f5576d563628"

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v65, v0

    new-instance v1, Le/i;

    const/16 v2, 0x54

    filled-new-array {v2}, [I

    move-result-object v2

    const v3, 0x13c6b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT PT430GT01 1S 4K division repair"

    const-string v3, "69780b4d6d8bf1f3eaedeebe20e990243beb30e72980c4dea7f6f9dd3cf6e0d0"

    const/high16 v4, 0x80000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v70, Lg1/w;

    move-object/from16 v66, v70

    const-string v71, "EXACT HV430QUB-F70 N4TB550UHDF70 V3.0 K2.7 P25Q40H 1S / 2S 4K division repair"

    const-string v73, "1ec47ac3bbd297d2c4646992e8aafe54f1c96ad2792f2a88ce4d0ae89afbf21c"

    const-string v74, "d095d1eb13109f468b258e807a2d37458e5fb624036f929ed48a6c0b25d00b01"

    new-instance v0, Le/i;

    const/16 v1, 0x10

    filled-new-array {v1}, [I

    move-result-object v1

    const/16 v2, 0x647e

    invoke-direct {v0, v1, v2}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v75

    new-instance v0, Le/i;

    const/4 v1, 0x0

    filled-new-array {v1}, [I

    move-result-object v3

    invoke-direct {v0, v3, v2}, Le/i;-><init>([II)V

    filled-new-array {v0}, [Le/i;

    move-result-object v76

    invoke-direct/range {v70 .. v76}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;[Le/i;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v67, v0

    new-instance v1, Le/i;

    const/16 v2, 0x51

    filled-new-array {v2}, [I

    move-result-object v2

    const v3, 0x10b6b

    invoke-direct {v1, v2, v3}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT P25Q40H SOP8-200 2S 4K division repair"

    const-string v3, "2430558cb3782bc21c6b9821fc9f5c3c3de90dd5a25324872c75c7922c0f922b"

    const/high16 v4, 0x80000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v68, v0

    new-instance v1, Le/i;

    const v2, 0x1147b

    filled-new-array/range {v69 .. v69}, [I

    move-result-object v3

    invoke-direct {v1, v3, v2}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT P25Q40H SOP8-200 2S 20260928 4K division repair"

    const-string v3, "ffacef4ddabd36e4bc188d3abb5285197286a532550c82ebf2d9aebe48ae2f0c"

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v70, Lg1/w;

    move-object/from16 v69, v70

    const-string v71, "AUTO TD-0006 25-series 4K division repair"

    const/high16 v72, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_2b

    const/16 v74, 0x18

    const/16 v75, 0x0

    move-object/from16 v73, v1

    invoke-direct/range {v70 .. v75}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v76, Lg1/w;

    move-object/from16 v70, v76

    const-string v77, "AUTO 25Q40 4MB 4K division repair"

    const/high16 v78, 0x400000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_2c

    const/16 v80, 0x18

    const/16 v81, 0x54

    const v82, 0x13c53

    move-object/from16 v79, v1

    invoke-direct/range {v76 .. v82}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v83, Lg1/w;

    move-object/from16 v71, v83

    const-string v84, "AUTO ACE25Q800G 4K division repair"

    const/high16 v85, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_2d

    const/16 v87, 0x18

    const/16 v88, 0x49

    move-object/from16 v86, v1

    invoke-direct/range {v83 .. v88}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v73, Lg1/w;

    move-object/from16 v72, v73

    const-string v74, "AUTO BOE 43 WDX F7D 4K division repair"

    const/high16 v75, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_2e

    const/16 v77, 0x18

    const/16 v78, 0x58

    move-object/from16 v76, v1

    invoke-direct/range {v73 .. v78}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v79, Lg1/w;

    move-object/from16 v73, v79

    const-string v80, "AUTO DCBDC 260C 05P1 4K division repair"

    const/high16 v81, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_2f

    const/16 v83, 0x18

    const/16 v84, 0x58

    move-object/from16 v82, v1

    invoke-direct/range {v79 .. v84}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v85, Lg1/w;

    move-object/from16 v74, v85

    const-string v86, "AUTO DOC WA0433 4K division repair"

    const/high16 v87, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_30

    const/16 v89, 0x18

    const/16 v90, 0x10

    move-object/from16 v88, v1

    invoke-direct/range {v85 .. v90}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v76, Lg1/w;

    move-object/from16 v75, v76

    const-string v77, "AUTO FM25Q08 4K division repair"

    const/high16 v78, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_31

    const/16 v80, 0x18

    const/16 v81, 0x0

    move-object/from16 v79, v1

    invoke-direct/range {v76 .. v81}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v82, Lg1/w;

    move-object/from16 v76, v82

    const-string v83, "AUTO HV550QUB E1E WDX 4K division repair"

    const/high16 v84, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_32

    const/16 v86, 0x18

    const/16 v87, 0x0

    move-object/from16 v85, v1

    invoke-direct/range {v82 .. v87}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v88, Lg1/w;

    move-object/from16 v77, v88

    const-string v89, "AUTO HV550QUB FID 4K division repair"

    const/high16 v90, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_33

    const/16 v92, 0x18

    const/16 v93, 0x58

    move-object/from16 v91, v1

    invoke-direct/range {v88 .. v93}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v79, Lg1/w;

    move-object/from16 v78, v79

    const-string v80, "AUTO HV55QUB F72 4K division repair"

    const/high16 v81, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_34

    const/16 v83, 0x18

    const/16 v84, 0x0

    move-object/from16 v82, v1

    invoke-direct/range {v79 .. v84}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v85, Lg1/w;

    move-object/from16 v79, v85

    const-string v86, "AUTO IS25LQ020B PT430 4K division repair"

    const/high16 v87, 0x40000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_35

    const/16 v89, 0x18

    const/16 v90, 0x54

    move-object/from16 v88, v1

    invoke-direct/range {v85 .. v90}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v91, Lg1/w;

    move-object/from16 v80, v91

    const-string v92, "AUTO LC550 EQC KIWMAGIC 4K division repair"

    const/high16 v93, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_36

    const/16 v95, 0x18

    const/16 v96, 0x48

    move-object/from16 v94, v1

    invoke-direct/range {v91 .. v96}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v82, Lg1/w;

    move-object/from16 v81, v82

    const-string v83, "AUTO P25Q80H 173458 4K division repair"

    const/high16 v84, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_37

    const/16 v86, 0x18

    const/16 v87, 0x0

    move-object/from16 v85, v1

    invoke-direct/range {v82 .. v87}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v88, Lg1/w;

    move-object/from16 v82, v88

    const-string v89, "AUTO P25Q80H 125213 4K division repair"

    const/high16 v90, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_38

    const/16 v92, 0x18

    const/16 v93, 0x6

    move-object/from16 v91, v1

    invoke-direct/range {v88 .. v93}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v94, Lg1/w;

    move-object/from16 v83, v94

    const-string v95, "AUTO P25Q80H 170338 4K division repair"

    const/high16 v96, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_39

    const/16 v98, 0x18

    const/16 v99, 0x47

    move-object/from16 v97, v1

    invoke-direct/range {v94 .. v99}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v85, Lg1/w;

    move-object/from16 v84, v85

    const-string v86, "AUTO P25Q80H 20543 4K division repair"

    const/high16 v87, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_3a

    const/16 v89, 0x18

    const/16 v90, 0x6

    move-object/from16 v88, v1

    invoke-direct/range {v85 .. v90}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v91, Lg1/w;

    move-object/from16 v85, v91

    const-string v92, "AUTO ST425D02 4K division repair"

    const/high16 v93, 0x100000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_3b

    const/16 v95, 0x18

    const/16 v96, 0x4c

    move-object/from16 v94, v1

    invoke-direct/range {v91 .. v96}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v97, Lg1/w;

    move-object/from16 v86, v97

    const-string v98, "AUTO ST5461D13 4K division repair"

    const/high16 v99, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_3c

    const/16 v101, 0x18

    const/16 v102, 0x4c

    move-object/from16 v100, v1

    invoke-direct/range {v97 .. v102}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v88, Lg1/w;

    move-object/from16 v87, v88

    const-string v89, "AUTO STOG 4K division repair"

    const/high16 v90, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_3d

    const/16 v92, 0x18

    const/16 v93, 0x0

    move-object/from16 v91, v1

    invoke-direct/range {v88 .. v93}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v94, Lg1/w;

    move-object/from16 v88, v94

    const-string v95, "AUTO V500DJ7 QE1 4K division repair"

    const/high16 v96, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_3e

    const/16 v98, 0x18

    const/16 v99, 0x0

    move-object/from16 v97, v1

    invoke-direct/range {v94 .. v99}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v105, Lg1/w;

    move-object/from16 v89, v105

    const-string v106, "AUTO ZB25VQ40 184339 4K division repair"

    const/high16 v107, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_3f

    const/16 v109, 0x18

    const/16 v110, 0x4c

    move-object/from16 v108, v1

    invoke-direct/range {v105 .. v110}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v91, Lg1/w;

    move-object/from16 v90, v91

    const-string v92, "AUTO ZB25VQ40 202835 4K division repair"

    const/high16 v93, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_40

    const/16 v95, 0x18

    const/16 v96, 0x48

    move-object/from16 v94, v1

    invoke-direct/range {v91 .. v96}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v97, Lg1/w;

    move-object/from16 v91, v97

    const-string v98, "AUTO ZB25VQ40 ORG 4K division repair"

    const/high16 v99, 0x80000

    const/16 v0, 0x31

    new-array v1, v0, [I

    fill-array-data v1, :array_41

    const/16 v102, 0x14

    move-object/from16 v100, v1

    invoke-direct/range {v97 .. v102}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v105, Lg1/w;

    move-object/from16 v92, v105

    const-string v106, "3 BOE-TY5 HV55QUB F72 4K division repair"

    const/16 v0, 0x21

    new-array v1, v0, [I

    fill-array-data v1, :array_42

    const/16 v109, 0x10

    const/16 v110, 0x0

    move-object/from16 v108, v1

    invoke-direct/range {v105 .. v110}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v94, Lg1/w;

    move-object/from16 v93, v94

    const-string v95, "4 BOE-KIWI dcbds 260c 05p1 4K division repair"

    const/high16 v96, 0x80000

    new-array v1, v0, [I

    fill-array-data v1, :array_43

    const/16 v98, 0x10

    const/16 v99, 0x58

    move-object/from16 v97, v1

    invoke-direct/range {v94 .. v99}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v105, Lg1/w;

    move-object/from16 v94, v105

    const-string v106, "5 CHOT-KIWI ZB25VQ40 ORG 4K division repair"

    new-array v1, v0, [I

    fill-array-data v1, :array_44

    const/16 v110, 0x14

    move-object/from16 v108, v1

    invoke-direct/range {v105 .. v110}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v96, Lg1/w;

    move-object/from16 v95, v96

    const-string v97, "6 BOE P25Q80H SOP8 200 20260702 20543 4K division repair"

    const/high16 v98, 0x100000

    new-array v1, v0, [I

    fill-array-data v1, :array_45

    const/16 v100, 0x10

    const/16 v101, 0x6

    move-object/from16 v99, v1

    invoke-direct/range {v96 .. v101}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v105, Lg1/w;

    move-object/from16 v96, v105

    const-string v106, "7 LG-KIWI lc 550 eqc star tcon kiwmagic 4K division repair"

    new-array v1, v0, [I

    fill-array-data v1, :array_46

    const/16 v110, 0x48

    move-object/from16 v108, v1

    invoke-direct/range {v105 .. v110}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v98, Lg1/w;

    move-object/from16 v97, v98

    const-string v99, "8 INNOLUX-TY5 V500DJ7 QE1 C9 DCBDS H268C 03 P1 Origel 4K division repair"

    const/high16 v100, 0x80000

    new-array v1, v0, [I

    fill-array-data v1, :array_47

    const/16 v102, 0x10

    const/16 v103, 0x0

    move-object/from16 v101, v1

    invoke-direct/range {v98 .. v103}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v105, Lg1/w;

    move-object/from16 v98, v105

    const-string v106, "9 CSOT-TY5 stog 4K division repair"

    new-array v1, v0, [I

    fill-array-data v1, :array_48

    const/16 v110, 0x0

    move-object/from16 v108, v1

    invoke-direct/range {v105 .. v110}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v111, Lg1/w;

    move-object/from16 v99, v111

    const-string v112, "10 BOE-KIWI boe 43 wdx f7d 4K division repair"

    const/high16 v113, 0x80000

    new-array v1, v0, [I

    fill-array-data v1, :array_49

    const/16 v115, 0x10

    const/16 v116, 0x58

    move-object/from16 v114, v1

    invoke-direct/range {v111 .. v116}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v105, Lg1/w;

    move-object/from16 v100, v105

    const-string v106, "11 PT-KIWI IS25LQ020B PT430 1 4K division repair"

    const/high16 v107, 0x40000

    new-array v1, v0, [I

    fill-array-data v1, :array_4a

    const/16 v110, 0x54

    move-object/from16 v108, v1

    invoke-direct/range {v105 .. v110}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v111, Lg1/w;

    move-object/from16 v101, v111

    const-string v112, "12 PT-KIWI 25X40 4K division repair"

    const/16 v1, 0x31

    new-array v2, v1, [I

    fill-array-data v2, :array_4b

    const/16 v115, 0x18

    const/16 v116, 0x8

    move-object/from16 v114, v2

    invoke-direct/range {v111 .. v116}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v105, Lg1/w;

    move-object/from16 v102, v105

    const-string v106, "12 CS0T-KIWI ZB25VQ40 20260516 202835 st5461d16 1 1 4K division repair"

    const/high16 v107, 0x80000

    new-array v1, v0, [I

    fill-array-data v1, :array_4c

    const/16 v110, 0x8

    move-object/from16 v108, v1

    invoke-direct/range {v105 .. v110}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v111, Lg1/w;

    move-object/from16 v103, v111

    const-string v112, "12B ZB25VQ40 25X40 4K division repair"

    const/16 v1, 0x31

    new-array v1, v1, [I

    fill-array-data v1, :array_4d

    const/16 v116, 0x14

    move-object/from16 v114, v1

    invoke-direct/range {v111 .. v116}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v105, Lg1/w;

    move-object/from16 v104, v105

    const-string v106, "13 LG-TY5 P25Q80H SOP8 200 20260510 170338 4K division repair"

    const/high16 v107, 0x100000

    new-array v1, v0, [I

    fill-array-data v1, :array_4e

    const/16 v110, 0x47

    move-object/from16 v108, v1

    invoke-direct/range {v105 .. v110}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v111, Lg1/w;

    move-object/from16 v105, v111

    const-string v112, "14 BOE-KIWI HV550QUB FID 2 DIV 4K division repair"

    const/high16 v113, 0x100000

    new-array v1, v0, [I

    fill-array-data v1, :array_4f

    const/16 v115, 0x10

    const/16 v116, 0x58

    move-object/from16 v114, v1

    invoke-direct/range {v111 .. v116}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v129, Lg1/w;

    move-object/from16 v106, v129

    const-string v130, "16 BOE-TY5 DOC 20260501 WA0433 4K division repair"

    const/high16 v131, 0x80000

    new-array v1, v0, [I

    fill-array-data v1, :array_50

    const/16 v133, 0x10

    const/16 v134, 0x10

    move-object/from16 v132, v1

    invoke-direct/range {v129 .. v134}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v108, Lg1/w;

    move-object/from16 v107, v108

    const-string v109, "18 CSOT-TD-0006 TD 0006 du 4K division repair"

    const/high16 v110, 0x100000

    new-array v1, v0, [I

    fill-array-data v1, :array_51

    const/16 v112, 0x10

    const/16 v113, 0x0

    move-object/from16 v111, v1

    invoke-direct/range {v108 .. v113}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v114, Lg1/w;

    move-object/from16 v108, v114

    const-string v115, "19 BOE-TY5 hv550 qub e1e wdx 4K division repair"

    const/high16 v116, 0x80000

    new-array v1, v0, [I

    fill-array-data v1, :array_52

    const/16 v118, 0x10

    const/16 v119, 0x0

    move-object/from16 v117, v1

    invoke-direct/range {v114 .. v119}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v129, Lg1/w;

    move-object/from16 v109, v129

    const-string v130, "20 PT P25Q80H SOP8 200 20260419 125213 4K division repair"

    const/high16 v131, 0x100000

    new-array v1, v0, [I

    fill-array-data v1, :array_53

    const/16 v134, 0x6

    move-object/from16 v132, v1

    invoke-direct/range {v129 .. v134}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v111, Lg1/w;

    move-object/from16 v110, v111

    const-string v112, "21 CSOT-TD-000P FM25Q08 20260411 111053 4K division repair"

    const/high16 v113, 0x100000

    new-array v1, v0, [I

    fill-array-data v1, :array_54

    const/16 v115, 0x10

    const/16 v116, 0x0

    move-object/from16 v114, v1

    invoke-direct/range {v111 .. v116}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v129, Lg1/w;

    move-object/from16 v111, v129

    const-string v130, "22 ST-KIWI ST425D02 LQ K12 K03 01 2 DIVISION P25Q80H SOP8 200 20260406 184721 4K division repair"

    new-array v1, v0, [I

    fill-array-data v1, :array_55

    const/16 v134, 0x4c

    move-object/from16 v132, v1

    invoke-direct/range {v129 .. v134}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v113, Lg1/w;

    move-object/from16 v112, v113

    const-string v114, "23 AUO-KIWI ZB25VQ40 20260330 184339 4K division repair"

    const/high16 v115, 0x80000

    new-array v1, v0, [I

    fill-array-data v1, :array_56

    const/16 v117, 0x10

    const/16 v118, 0x4c

    move-object/from16 v116, v1

    invoke-direct/range {v113 .. v118}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v129, Lg1/w;

    move-object/from16 v113, v129

    const-string v130, "24 CSOT-TD-000L P25Q80H SOP8 200 20260327 173458 4K division repair"

    new-array v1, v0, [I

    fill-array-data v1, :array_57

    const/16 v134, 0x0

    move-object/from16 v132, v1

    invoke-direct/range {v129 .. v134}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v135, Lg1/w;

    move-object/from16 v114, v135

    const-string v136, "26 INNOLUX-KWI ACE25Q800G ISP 20260320 111816 4K division repair"

    const/high16 v137, 0x100000

    new-array v1, v0, [I

    fill-array-data v1, :array_58

    const/16 v139, 0x10

    const/16 v140, 0x49

    move-object/from16 v138, v1

    invoke-direct/range {v135 .. v140}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v129, Lg1/w;

    move-object/from16 v115, v129

    const-string v130, "27 CSOT-KIWI ST5461D13 2 DIVISION2S OK 4K division repair"

    const/high16 v131, 0x80000

    new-array v0, v0, [I

    fill-array-data v0, :array_59

    const/16 v134, 0x4c

    move-object/from16 v132, v0

    invoke-direct/range {v129 .. v134}, Lg1/w;-><init>(Ljava/lang/String;I[III)V

    new-instance v135, Lg1/w;

    move-object/from16 v116, v135

    const-string v136, "28 DOC KV7636-VPP 49-2 to 48-1 4K division repair"

    const/high16 v137, 0x80000

    const/16 v0, 0xc

    new-array v0, v0, [I

    fill-array-data v0, :array_5a

    const/16 v139, 0xb

    const/16 v140, 0x48

    const v141, 0xe270

    move-object/from16 v138, v0

    invoke-direct/range {v135 .. v141}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v142, Lg1/w;

    move-object/from16 v117, v142

    const-string v143, "29 DOC HV7636-VPN 59-2 to 58-1 4K division repair"

    const/high16 v144, 0x80000

    const/16 v0, 0xc

    new-array v0, v0, [I

    fill-array-data v0, :array_5b

    const/16 v146, 0xb

    const/16 v147, 0x58

    const v148, 0x10770

    move-object/from16 v145, v0

    invoke-direct/range {v142 .. v148}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v129, Lg1/w;

    move-object/from16 v118, v129

    const-string v130, "30 DOC SW08503 0A-2 to 06-1 4K division repair"

    const/16 v0, 0xa4

    const/16 v1, 0xa

    const/4 v2, 0x1

    const/16 v3, 0x8

    const/16 v4, 0xd0

    filled-new-array {v4, v3, v0, v2, v1}, [I

    move-result-object v132

    const/16 v133, 0x4

    const/16 v134, 0x6

    const/16 v135, 0x2088

    invoke-direct/range {v129 .. v135}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v136, Lg1/w;

    move-object/from16 v119, v136

    const-string v137, "31 DOC TY50606A 0A-2 to 06-1 4K division repair"

    const/high16 v138, 0x80000

    const/4 v2, 0x1

    const/16 v3, 0x8

    filled-new-array {v4, v3, v0, v2, v1}, [I

    move-result-object v139

    const/16 v140, 0x4

    const/16 v141, 0x6

    const/16 v142, 0x2088

    invoke-direct/range {v136 .. v142}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v0, Lg1/w;

    move-object/from16 v120, v0

    new-instance v1, Le/i;

    const/4 v2, 0x0

    filled-new-array {v2}, [I

    move-result-object v3

    const/16 v4, 0x647d

    invoke-direct {v1, v3, v4}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v3, "EXACT HV430QUB-F1Z single 4K division repair"

    const-string v5, "4c482da6f5020b5f4c5ebf4c97d2138d35e112962380beff7896e93642371629"

    const/high16 v6, 0x80000

    invoke-direct {v0, v3, v6, v5, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v121, v0

    new-instance v1, Le/i;

    filled-new-array {v2}, [I

    move-result-object v3

    invoke-direct {v1, v3, v4}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const/high16 v3, 0x200000

    const-string v5, "b195e4796f55883ef3ee94ff777a0aeafd7f46e5f3f4576c86495a50fd2f7eb1"

    const-string v6, "EXACT GD25VQ16C 50 INCH MI 4K division repair"

    invoke-direct {v0, v6, v3, v5, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v0, Lg1/w;

    move-object/from16 v122, v0

    new-instance v1, Le/i;

    filled-new-array {v2}, [I

    move-result-object v3

    invoke-direct {v1, v3, v4}, Le/i;-><init>([II)V

    filled-new-array {v1}, [Le/i;

    move-result-object v1

    const-string v2, "EXACT GD25VQ41B LG 55 INCH 4K division repair"

    const-string v3, "1403afb3da54f0d60ed824c95ea5fdd039da69e9f907726b8bfbe56f3a18eede"

    const/high16 v4, 0x80000

    invoke-direct {v0, v2, v4, v3, v1}, Lg1/w;-><init>(Ljava/lang/String;ILjava/lang/String;[Le/i;)V

    new-instance v129, Lg1/w;

    move-object/from16 v123, v129

    const-string v130, "32 DOC HIMAX HX5206 10-2 to 00-1 4K division repair"

    const/16 v0, 0xe

    new-array v0, v0, [I

    fill-array-data v0, :array_5c

    const/16 v133, 0xd

    const/16 v134, 0x0

    const/16 v135, 0x6470

    move-object/from16 v132, v0

    invoke-direct/range {v129 .. v135}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    new-instance v136, Lg1/w;

    move-object/from16 v124, v136

    const-string v137, "33 DOC EK76603L 01-2 to 00-1 4K division repair"

    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_5d

    const/16 v140, 0x2

    const/16 v141, 0x0

    const/16 v142, 0x18b0

    move-object/from16 v139, v0

    invoke-direct/range {v136 .. v142}, Lg1/w;-><init>(Ljava/lang/String;I[IIII)V

    move-object/from16 v3, v125

    move-object/from16 v4, v126

    move-object/from16 v5, v127

    move-object/from16 v6, v128

    filled-new-array/range {v3 .. v124}, [Lg1/w;

    move-result-object v0

    move-object/from16 v1, p0

    iput-object v0, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->O:[Lg1/w;

    new-instance v0, Lc/c;

    const/4 v2, 0x0

    invoke-direct {v0, v2}, Lc/c;-><init>(I)V

    new-instance v3, Lg1/s;

    invoke-direct {v3, v1, v2}, Lg1/s;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    invoke-virtual {v1, v3, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->P:Lb/h;

    new-instance v0, Le/d0;

    const/4 v2, 0x3

    invoke-direct {v0, v2, v1}, Le/d0;-><init>(ILjava/lang/Object;)V

    iput-object v0, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->Q:Le/d0;

    return-void

    :array_0
    .array-data 4
        0xff
        0xff
        0xff
        0xff
        0xff
        0xff
        0xff
    .end array-data

    :array_1
    .array-data 4
        0x10
        0xc
        0xf5
        0xc0
        0x13
        0x78
        0x41
    .end array-data

    :array_2
    .array-data 4
        0x9b
        0x62
        0x2a
        0xb2
        0xf2
        0x2b
        0xcb
        0x82
        0x2d
        0xe4
        0x2
        0x2f
        0xfa
        0x42
        0x30
        0xf
        0x93
        0x31
        0x22
        0xc3
        0x32
        0x36
    .end array-data

    :array_3
    .array-data 4
        0x33
        0x48
        0x13
        0x35
        0x5a
        0x33
        0x36
        0x6c
        0x43
        0x37
        0x7c
        0x43
        0x38
        0x8b
        0x33
        0x39
        0x9a
        0x23
        0x3a
        0xa9
        0x13
        0x3b
        0xb9
        0x13
        0x3c
        0xc8
        0x3
        0x3d
        0xd8
        0x3
        0x3e
        0xe7
        0xf3
    .end array-data

    :array_4
    .array-data 4
        0xfd
        0xc3
        0x40
        0x1a
        0x84
        0x42
        0x38
        0x84
        0x44
        0x57
        0x74
        0x46
        0x76
        0x64
        0x48
        0x95
        0x44
        0x4a
        0xb4
        0x34
        0x4c
        0xd3
        0x34
        0x4e
        0xf2
        0x24
        0x50
        0x11
        0x5
        0x52
        0x2f
        0xf5
        0x53
        0x4d
        0xc5
        0x55
        0x6b
        0xa5
        0x57
        0x89
        0x85
        0x59
        0xa7
        0x75
        0x5b
        0xc6
        0x55
        0x5d
        0xe4
        0x35
        0x5f
        0x3
        0x26
        0x61
        0x23
        0x26
        0x63
        0x42
        0x26
        0x65
        0x62
        0x36
        0x67
        0x82
        0x36
        0x69
        0xa2
        0x26
        0x6b
        0xc3
        0x36
        0x6d
        0xe3
        0x36
        0x6f
        0x5
        0x67
        0x71
        0x28
        0xa7
        0x73
        0x4b
        0xc7
        0x75
        0x6e
    .end array-data

    :array_5
    .array-data 4
        0x80
        0x1f
        0x28
        0x83
        0x45
        0x78
        0x85
        0x69
        0xb8
        0x87
        0x8d
        0xf8
        0x89
        0xb2
        0x58
        0x8c
        0xd7
        0x98
        0x8e
        0xfb
        0xe8
        0x90
        0x21
        0x69
        0x93
        0x48
        0xa9
        0x95
        0x6c
        0xe9
        0x97
        0x90
        0x39
        0x9a
        0xb6
        0x89
        0x9c
        0xdb
        0xe9
        0x9e
        0x1
        0x4a
        0xa1
        0x26
        0x9a
        0xa3
        0x4c
    .end array-data

    :array_6
    .array-data 4
        0xa5
        0x71
        0x6a
        0xa8
        0x99
        0xca
        0xaa
        0xbf
        0x1a
        0xad
        0xe2
        0x3a
        0xaf
        0x6
        0x9b
        0xb1
        0x2b
        0xfb
        0xb3
        0x51
        0x4b
        0xb6
        0x76
        0x9b
        0xb8
        0x9b
        0xeb
        0xba
        0xc0
        0xb
        0xbd
        0xe0
        0xb
        0xbf
        0x1
        0xec
        0xc0
        0x1b
        0xac
        0xc2
        0x38
        0x5c
        0xc4
        0x53
        0x1c
        0xc6
        0x6e
        0xdc
        0xc7
        0x8a
        0x7c
        0xc9
        0xa5
        0x2c
        0xcb
        0xc0
        0xdc
        0xcc
        0xdb
        0x8c
        0xce
        0xf5
        0x3c
        0xd0
        0x10
        0xed
        0xd1
        0x2b
        0xad
        0xd3
        0x47
        0x4d
        0xd5
        0x61
        0xed
        0xd6
        0x7b
        0x8d
        0xd8
        0x95
        0x3d
        0xda
        0xb1
        0xed
        0xdb
        0xcc
        0x9d
        0xdd
        0xe6
        0x3d
        0xdf
        0x0
        0xde
        0xe0
        0x1a
        0x7e
        0xe2
        0x34
        0x2e
        0xe4
        0x4e
        0xce
        0xe5
        0x69
        0x6e
        0xe7
        0x83
        0xe
        0xe9
        0x9c
        0xae
        0xea
        0xb8
        0x4e
        0xec
        0xd0
    .end array-data

    :array_7
    .array-data 4
        0xed
        0xea
        0x8e
        0xef
        0x5
        0x2f
        0xf1
        0x1e
        0xbf
        0xf2
        0x38
        0x5f
        0xf4
        0x52
        0xef
        0xf5
        0x6a
        0x6f
        0xf7
        0x83
        0xff
        0xf8
        0x9c
        0x8f
        0xfa
        0xb4
        0xf
        0xfc
        0xcc
        0x8f
        0xfd
        0xe4
    .end array-data

    :array_8
    .array-data 4
        0x80
        0x7
        0xe4
        0x30
        0x12
        0x5a
        0x61
        0x18
        0xa8
        0x61
        0x1c
        0xde
        0x21
        0x1f
        0x5
        0x42
        0x21
        0x22
        0xe2
        0x22
        0x3b
    .end array-data

    :array_9
    .array-data 4
        0x24
        0x53
        0xd2
        0x25
        0x67
        0x12
    .end array-data

    :array_a
    .array-data 4
        0x7d
        0x82
        0x28
        0x93
        0xd2
        0x29
        0xa7
        0x22
    .end array-data

    :array_b
    .array-data 4
        0xbd
        0x82
        0x2c
        0xd3
        0xe2
        0x2d
        0xe8
        0x22
    .end array-data

    :array_c
    .array-data 4
        0xfc
        0x52
        0x30
        0xe
        0x73
        0x31
        0x1f
        0x83
        0x32
        0x31
        0x93
        0x33
        0x41
        0x93
        0x34
        0x52
        0x93
        0x35
        0x61
        0x93
        0x36
        0x71
        0x83
        0x37
        0x7e
        0x53
        0x38
        0x8c
        0x33
        0x39
        0x9a
        0x3
    .end array-data

    :array_d
    .array-data 4
        0x3a
        0xb5
        0xc3
        0x3b
        0xc3
        0x93
        0x3c
        0xd0
        0x73
        0x3d
        0xde
        0x53
        0x3e
        0xeb
        0x33
        0x3f
        0x0
        0xe4
        0x40
        0x1a
        0x74
        0x42
        0x34
        0x34
        0x44
        0x51
        0xf4
        0x45
        0x6d
        0xc4
        0x47
        0x89
        0x74
        0x49
        0xa5
        0x24
        0x4b
        0xc0
        0xe4
        0x4c
        0xdc
        0xa4
        0x4e
        0xf8
        0x64
        0x50
        0x14
        0x25
        0x52
        0x30
        0xd5
        0x53
        0x4b
        0x85
        0x55
        0x66
        0x35
        0x57
        0x81
        0xf5
        0x58
        0x9c
        0xa5
        0x5a
        0xb8
    .end array-data

    :array_e
    .array-data 4
        0x5c
        0xd3
        0x15
        0x5e
        0xee
        0xe5
        0x5f
        0xc
        0xa6
        0x61
        0x28
        0x76
        0x63
        0x45
        0x46
        0x65
        0x63
        0x26
        0x67
        0x80
        0xf6
        0x68
        0x9d
        0xc6
        0x6a
        0xbb
        0xa6
        0x6c
        0xd9
        0x86
        0x6e
        0xf8
        0x86
        0x70
        0x18
        0x87
        0x72
        0x38
        0x87
        0x74
        0x59
        0xa7
        0x76
        0x7b
        0xb7
        0x78
        0x9c
        0xd7
        0x7a
        0xbd
        0xd7
        0x7c
        0xdd
        0xd7
        0x7e
        0xfe
        0xf7
        0x80
        0x21
        0x38
        0x83
        0x44
        0x68
        0x85
        0x67
        0x88
        0x87
        0x89
        0xa8
        0x89
        0xac
        0xe8
        0x8b
        0xcf
        0x8
        0x8e
        0xf2
        0x38
        0x90
        0x16
        0x89
        0x92
        0x3c
        0xd9
        0x94
        0x5e
        0x9
        0x97
        0x82
        0x39
        0x99
        0xa5
        0x79
        0x9b
        0xca
        0xc9
        0x9d
        0xee
        0x19
        0xa0
        0x13
        0x5a
        0xa2
        0x37
        0xaa
        0xa4
        0x5c
        0xea
        0xa6
        0x7b
        0xba
        0xa8
        0x9d
        0xa
        0xab
        0xc3
        0x5a
        0xad
        0xe8
        0xba
        0xaf
        0xd
        0xb
        0xb2
        0x33
        0x5b
        0xb4
        0x58
        0xbb
        0xb6
        0x7e
        0x1b
        0xb9
        0xa3
        0x6b
        0xbb
        0xc8
        0x8b
        0xbd
        0xe9
        0x9b
        0xbf
        0x8
        0x6c
        0xc1
        0x24
        0x2c
        0xc3
        0x40
        0xec
        0xc4
        0x5c
        0xbc
        0xc6
        0x79
        0x7c
    .end array-data

    :array_f
    .array-data 4
        0xcf
        0xa
        0x9d
        0xd1
        0x29
        0x9d
        0xd3
        0x48
        0x6d
        0xd5
        0x65
    .end array-data

    :array_10
    .array-data 4
        0xd7
        0x83
        0x2d
        0xd9
        0xa1
        0x1d
        0xdb
        0xc1
        0xd
        0xdd
        0xe0
        0xfd
        0xde
        0xff
        0xed
        0xe0
        0x1e
        0xee
        0xe2
        0x3e
        0xde
        0xe4
        0x5e
        0xee
        0xe6
        0x7e
        0xee
        0xe8
        0x9f
        0x1e
        0xeb
        0xc2
        0x2e
        0xed
        0xe5
        0x7e
        0xef
        0xa
        0xdf
        0xf1
        0x31
        0x3f
        0xf4
        0x56
    .end array-data

    :array_11
    .array-data 4
        0xd9
        0x90
        0x11
        0x4d
        0x51
        0x17
        0x96
        0x31
        0x1b
        0xcd
        0x11
        0x1e
        0xf0
        0x41
        0x20
        0x15
        0x32
        0x22
        0x30
        0xe2
    .end array-data

    :array_12
    .array-data 4
        0x28
        0x8f
        0x92
        0x29
        0xa4
        0xf2
        0x2a
        0xba
        0x52
        0x2c
        0xd0
        0xb2
        0x2d
        0xe6
        0x2
        0x2f
        0xf9
        0x22
        0x30
        0xb
        0x43
        0x31
        0x1c
        0x43
        0x32
        0x2d
        0x53
        0x33
        0x3d
        0x43
        0x34
        0x4c
    .end array-data

    :array_13
    .array-data 4
        0x35
        0x5b
        0x33
        0x36
        0x6a
        0x13
        0x37
        0x78
    .end array-data

    :array_14
    .array-data 4
        0x3b
        0xb7
        0xd3
        0x3b
        0xc4
        0xa3
        0x3c
        0xd0
        0x73
        0x3d
        0xdd
        0x43
        0x3e
        0xea
        0x3
        0x3f
        0xfc
    .end array-data

    :array_15
    .array-data 4
        0x40
        0x14
        0x4
        0x42
        0x2c
        0x94
        0x43
        0x46
        0x34
        0x45
        0x60
        0xc4
        0x46
        0x79
        0x64
        0x48
        0x92
        0xf4
        0x49
        0xab
        0x84
        0x4b
        0xc4
        0x14
        0x4d
        0xde
    .end array-data

    :array_16
    .array-data 4
        0x4e
        0xf7
        0x44
        0x50
        0x10
        0xd5
        0x51
        0x2a
        0x65
        0x53
        0x42
        0xe5
        0x54
        0x5a
        0x75
        0x56
        0x73
        0xf5
        0x57
        0x8c
        0x85
        0x59
        0xa4
        0x15
        0x5b
        0xbe
        0xa5
        0x5c
        0xd6
        0x35
        0x5e
        0xef
        0xd5
        0x5f
        0x9
        0x66
        0x61
        0x23
        0x6
        0x63
        0x3d
        0xa6
        0x64
        0x58
        0x56
        0x66
        0x73
        0x6
        0x68
        0x8d
        0xa6
        0x69
        0xa7
        0x56
        0x6b
        0xc3
        0xf6
        0x6c
        0xdd
        0xb6
        0x6e
        0xf9
    .end array-data

    :array_17
    .array-data 4
        0x70
        0x16
        0x57
        0x72
        0x34
        0x27
        0x74
        0x51
        0x7
        0x76
        0x6f
        0xe7
        0x77
        0x8d
        0xc7
        0x79
        0xac
        0xa7
        0x7b
        0xc9
        0x87
        0x7d
        0xe6
        0x57
        0x7f
        0x4
        0x48
        0x81
        0x24
        0x48
        0x83
        0x44
        0x48
        0x85
        0x64
        0x38
        0x87
        0x83
        0x28
        0x89
        0xa2
        0x38
        0x8b
        0xc3
        0x28
        0x8d
        0xe2
        0x28
        0x8f
        0x2
        0x39
        0x91
        0x24
        0x69
        0x93
        0x46
        0x69
        0x95
        0x66
        0x69
        0x97
        0x86
        0x79
        0x99
        0xa7
        0x89
        0x9b
        0xc9
        0x99
        0x9d
        0xea
        0xc9
        0x9f
        0xd
        0xda
        0xa1
        0x2e
        0xa
        0xa4
        0x50
        0x1a
        0xa6
        0x72
        0x6a
        0xa8
        0x97
        0x9a
        0xaa
        0xba
        0xba
        0xac
        0xdc
        0xda
        0xae
        0xff
        0xa
        0xb1
        0x22
        0x4b
        0xb3
        0x46
        0x7b
        0xb5
        0x69
        0xbb
        0xb7
        0x8e
        0xfb
        0xb9
        0xb1
        0x3b
        0xbc
        0xd3
        0x3b
        0xbe
        0xf3
        0x3b
        0xc0
        0x11
        0xec
        0xc1
        0x2c
        0xac
        0xc3
        0x47
        0x5c
        0xc5
        0x64
        0x2c
        0xc7
        0x81
        0xfc
        0xc8
        0x9d
        0xcc
        0xca
        0xbb
        0xac
        0xcc
        0xd8
        0x7c
        0xce
        0xf6
        0x5c
        0xd0
        0x14
        0x4d
        0xd2
        0x35
        0x5d
        0xd4
        0x54
        0x4d
        0xd6
        0x74
        0x4d
        0xd8
        0x94
        0x5d
        0xda
        0xb7
        0x9d
        0xdc
        0xda
        0xcd
        0xde
        0xfe
        0xd
        0xe1
        0x23
        0x6e
        0xe3
        0x4a
        0xee
        0xe5
        0x73
        0x8e
        0xe8
        0x9f
        0x8e
        0xeb
        0xd0
        0xce
        0xee
        0xb
        0xdf
        0xf2
        0x50
        0x3f
        0xf7
        0xff
        0xf
    .end array-data

    :array_18
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x1
        0x0
        0x1
        0xe
        0x0
        0x0
        0x1
        0x0
        0x1
        0x0
        0x2
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x7
        0x0
        0x0
    .end array-data

    :array_19
    .array-data 4
        0x20
        0x0
        0x0
        0x6
        0xa0
        0xac
        0x33
        0x8d
        0x83
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x6
        0xa0
        0xff
        0xff
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x55
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x14
        0x0
        0x0
        0x0
        0x5
        0xc8
        0xa1
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_1a
    .array-data 4
        0x20
        0x0
        0x0
        0x6
        0xa0
        0xac
        0x33
        0x8d
        0x83
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x6
        0xa0
        0xff
        0xff
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x50
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xca
        0x59
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_1b
    .array-data 4
        0x0
        0x0
        0x1
        0x3
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x59
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x6
        0xa8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_1c
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x1
        0x0
        0x1
        0xe
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x7
        0x0
        0x0
        0x0
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xf
        0x70
        0x8
        0x2c
        0x0
        0x8
        0x0
        0xa
        0x0
        0x0
    .end array-data

    :array_1d
    .array-data 4
        0x48
        0x5a
        0x62
        0xe
        0xf0
        0xf0
        0x3f
        0xa
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
        0x28
        0x0
        0x5
        0x45
        0x21
        0xe2
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc0
        0x3
        0xe
        0x5
        0x10
        0x0
        0x0
        0x0
        0x0
        0x80
        0x47
        0x0
    .end array-data

    :array_1e
    .array-data 4
        0x0
        0x0
        0x0
        0xde
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x59
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x7
        0x7
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x6
        0xa8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_1f
    .array-data 4
        0x48
        0x5a
        0x62
        0xe
        0xf0
        0xf0
        0x3f
        0xa
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0x12
        0x4a
        0x74
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
        0x28
        0x0
        0x5
        0x44
        0x21
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc3
        0x3
        0xe
        0x5
        0x10
        0x0
        0x0
        0x0
        0x0
        0x80
        0x47
        0x0
    .end array-data

    :array_20
    .array-data 4
        0x20
        0x0
        0x0
        0x6
        0xa0
        0xac
        0x33
        0x8d
        0x83
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x6
        0xa0
        0xff
        0xff
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x55
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xc8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_21
    .array-data 4
        0x0
        0x0
        0x0
        0xd7
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x49
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x14
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_22
    .array-data 4
        0x0
        0x0
        0x0
        0xde
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x48
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_23
    .array-data 4
        0x56
        0x78
        0x9a
        0xb1
        0x44
        0x44
        0x44
        0x44
        0x44
        0x44
        0x2
        0x1
        0x11
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1
        0xff
        0x1
        0x23
        0x45
        0x67
        0xa
        0xf
        0x0
        0x8
        0x70
        0x11
        0x30
        0x8
        0xca
        0x10
        0x90
        0x11
        0xd0
        0x8
        0x84
        0xd
        0x34
        0x10
        0x80
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_24
    .array-data 4
        0x0
        0x0
        0x0
        0xf3
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x4d
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x6
        0xa8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_25
    .array-data 4
        0x0
        0x0
        0x0
        0xde
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x4d
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_26
    .array-data 4
        0x48
        0x5a
        0x62
        0xe
        0xf0
        0xf0
        0x3f
        0xa
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x84
        0x1
        0xc
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
        0x28
        0x0
        0x5
        0x44
        0x21
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc1
        0x3
        0xe
        0x5
        0x10
        0x0
        0x0
        0x0
        0x0
        0x80
        0x47
        0x0
    .end array-data

    :array_27
    .array-data 4
        0x48
        0x5a
        0x62
        0xe
        0xf0
        0xf0
        0x3f
        0xa
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x84
        0x9
        0xc
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
        0x28
        0x0
        0x5
        0x45
        0x1
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc0
        0x3
        0xe
        0x5
        0x10
        0x0
        0x0
        0x0
        0x0
        0x80
        0x47
        0x0
    .end array-data

    :array_28
    .array-data 4
        0x0
        0x0
        0x0
        0xf3
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x4d
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_29
    .array-data 4
        0x0
        0x0
        0x0
        0xde
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x49
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_2a
    .array-data 4
        0x0
        0x0
        0x0
        0xf4
        0x80
        0x0
        0x0
        0x3
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x15
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0x8a
        0x51
        0xc0
        0x0
        0x9c
        0x10
        0x0
        0x11
        0x0
        0x0
    .end array-data

    :array_2b
    .array-data 4
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x1
        0x0
        0x1
        0xe
        0x0
        0x0
        0x1
        0x0
        0x1
        0x0
        0x2
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2c
    .array-data 4
        0x83
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x6
        0xa0
        0xff
        0xff
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x55
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x14
        0x0
        0x0
        0x0
        0x5
        0xc8
        0xa1
    .end array-data

    :array_2d
    .array-data 4
        0x83
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x6
        0xa0
        0xff
        0xff
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x50
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xca
        0x59
    .end array-data

    :array_2e
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x59
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x6
        0xa8
        0x61
    .end array-data

    :array_2f
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x59
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x6
        0xa8
        0x61
    .end array-data

    :array_30
    .array-data 4
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x0
        0x28
        0x0
        0x5
        0x45
        0x21
        0x42
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc0
        0x3
        0xe
        0x5
    .end array-data

    :array_31
    .array-data 4
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x1
        0x0
        0x1
        0xe
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x7
        0x0
        0x0
        0x0
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xf
        0x70
    .end array-data

    :array_32
    .array-data 4
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
        0x28
        0x0
        0x5
        0x45
        0x21
        0xe2
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc0
        0x3
        0xe
        0x5
    .end array-data

    :array_33
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x59
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x7
        0x7
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x6
        0xa8
        0x61
    .end array-data

    :array_34
    .array-data 4
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0x12
        0x4a
        0x74
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
        0x28
        0x0
        0x5
        0x44
        0x21
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc3
        0x3
        0xe
        0x5
    .end array-data

    :array_35
    .array-data 4
        0x83
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x6
        0xa0
        0xff
        0xff
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x55
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xc8
        0x61
    .end array-data

    :array_36
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x49
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x14
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
    .end array-data

    :array_37
    .array-data 4
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x1
        0x0
        0x1
        0xe
        0x0
        0x0
        0x1
        0x0
        0x1
        0x0
        0x2
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_38
    .array-data 4
        0x44
        0x44
        0x2
        0x1
        0x11
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1
        0xff
        0x1
        0x23
        0x45
        0x67
        0xa
        0xf
        0x0
        0x8
        0x70
        0x11
        0x30
        0x8
        0xca
        0x10
        0x90
        0x11
        0xd0
        0x8
        0x84
        0xd
        0x34
        0x10
        0x80
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_39
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x48
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
    .end array-data

    :array_3a
    .array-data 4
        0x44
        0x44
        0x2
        0x1
        0x11
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1
        0xff
        0x1
        0x23
        0x45
        0x67
        0xa
        0xf
        0x0
        0x8
        0x70
        0x11
        0x30
        0x8
        0xca
        0x10
        0x90
        0x11
        0xd0
        0x8
        0x84
        0xd
        0x34
        0x10
        0x80
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3b
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x4d
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x6
        0xa8
        0x61
    .end array-data

    :array_3c
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x4d
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
    .end array-data

    :array_3d
    .array-data 4
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x84
        0x1
        0xc
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
        0x28
        0x0
        0x5
        0x44
        0x21
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc1
        0x3
        0xe
        0x5
    .end array-data

    :array_3e
    .array-data 4
        0xa
        0xa
        0x80
        0x7
        0x87
        0x98
        0x88
        0x8e
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x84
        0x9
        0xc
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
        0x28
        0x0
        0x5
        0x45
        0x1
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
        0x0
        0x0
        0x0
        0x0
        0xc0
        0x3
        0xe
        0x5
    .end array-data

    :array_3f
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x4d
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
    .end array-data

    :array_40
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x49
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0x61
    .end array-data

    :array_41
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x15
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0x8a
        0x51
    .end array-data

    :array_42
    .array-data 4
        0xd0
        0x11
        0x3a
        0x12
        0x4a
        0x74
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        -0x1
        0x28
        0x0
        0x5
        0x44
        0x21
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
    .end array-data

    :array_43
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_44
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_45
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1
        0xff
        0x1
        0x23
        0x45
        0x67
        -0x1
        0xf
        0x0
        0x8
        0x70
        0x11
        0x30
        0x8
        0xca
        0x10
        0x90
        0x11
        0xd0
        0x8
        0x84
        0xd
        0x34
    .end array-data

    :array_46
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_47
    .array-data 4
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x84
        0x9
        0xc
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        -0x1
        0x28
        0x0
        0x5
        0x45
        0x1
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
    .end array-data

    :array_48
    .array-data 4
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x84
        0x1
        0xc
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        -0x1
        0x28
        0x0
        0x5
        0x44
        0x21
        0x82
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
    .end array-data

    :array_49
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_4a
    .array-data 4
        0xa0
        0xff
        0xff
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_4b
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x9
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0xa8
        0xa1
    .end array-data

    :array_4c
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x9
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_4d
    .array-data 4
        0x78
        0x76
        0xd4
        0xa2
        0xcc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x15
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x3f
        0xff
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
        0x0
        0x13
        0x0
        0x0
        0x0
        0x5
        0x8a
        0x51
    .end array-data

    :array_4e
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x7f
        0x7f
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_4f
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x7
        0x7
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_50
    .array-data 4
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        -0x1
        0x28
        0x0
        0x5
        0x45
        0x21
        0x42
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
    .end array-data

    :array_51
    .array-data 4
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        -0x1
        0x0
        0x1
        0xe
        0x0
        0x0
        0x1
        0x0
        0x1
        0x0
        0x2
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_52
    .array-data 4
        0xd0
        0x11
        0x3a
        0xc2
        0x44
        0x74
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        -0x1
        0x28
        0x0
        0x5
        0x45
        0x21
        0xe2
        0xe0
        0x2e
        0x30
        0x0
        0x0
        0x0
        0x0
        0x14
        0x4
        0x25
    .end array-data

    :array_53
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1
        0xff
        0x1
        0x23
        0x45
        0x67
        -0x1
        0xf
        0x0
        0x8
        0x70
        0x11
        0x30
        0x8
        0xca
        0x10
        0x90
        0x11
        0xd0
        0x8
        0x84
        0xd
        0x34
    .end array-data

    :array_54
    .array-data 4
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        -0x1
        0x0
        0x1
        0xe
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x7
        0x0
        0x0
        0x0
        0x1
        0x0
        0x0
    .end array-data

    :array_55
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_56
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_57
    .array-data 4
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0xe8
        0x3
        0x0
        0x0
        -0x1
        0x0
        0x1
        0xe
        0x0
        0x0
        0x1
        0x0
        0x1
        0x0
        0x2
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_58
    .array-data 4
        0xa0
        0xff
        0xff
        0xff
        0xff
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_59
    .array-data 4
        0x0
        0x0
        0x0
        0x3
        0x78
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        -0x1
        0xc0
        0x0
        0x9c
        0x14
        0x0
        0x1d
        0x0
        0x0
        0x0
        0x0
        0x3f
        0x3f
        0xc0
        0x0
        0x9c
        0xc
    .end array-data

    :array_5a
    .array-data 4
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0x8
        0x0
        0x0
        0x0
        0x0
        0x0
        0x49
    .end array-data

    :array_5b
    .array-data 4
        0xc0
        0x0
        0x9c
        0x8
        0x0
        0xc
        0x0
        0x0
        0x0
        0x0
        0x0
        0x59
    .end array-data

    :array_5c
    .array-data 4
        0xc2
        0x47
        0x14
        0x44
        0x9
        0x8
        0xf0
        0x0
        0x0
        0x0
        0x74
        0x97
        0x53
        0x10
    .end array-data

    :array_5d
    .array-data 4
        0x6f
        0x4e
        0x1
        0x54
        0x4f
        0x6f
        0xc3
        0xaf
    .end array-data
.end method

.method public static B([B)Ljava/lang/String;
    .locals 8

    .line 1
    :try_start_0
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    array-length v1, p0

    mul-int/lit8 v1, v1, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    array-length v1, p0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_0

    aget-byte v4, p0, v3

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v6, "%02x"

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    and-int/lit16 v4, v4, 0xff

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v7, v2

    invoke-static {v5, v6, v7}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    const-string p0, ""

    return-object p0
.end method

.method public static C(I)Ljava/lang/String;
    .locals 1

    .line 1
    const/high16 v0, 0x40000

    if-eq p0, v0, :cond_4

    const/high16 v0, 0x80000

    if-eq p0, v0, :cond_3

    const/high16 v0, 0x100000

    if-eq p0, v0, :cond_2

    const/high16 v0, 0x200000

    if-eq p0, v0, :cond_1

    const/high16 v0, 0x400000

    if-eq p0, v0, :cond_0

    const-string p0, "25-series SPI"

    return-object p0

    :cond_0
    const-string p0, "25X32 SPI (4 MB)"

    return-object p0

    :cond_1
    const-string p0, "25X16 SPI (2 MB)"

    return-object p0

    :cond_2
    const-string p0, "25X80 SPI (1 MB)"

    return-object p0

    :cond_3
    const-string p0, "25X40 SPI (512 KB)"

    return-object p0

    :cond_4
    const-string p0, "25X20 SPI (256 KB)"

    return-object p0
.end method

.method public static D(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    const-string v0, ""

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    return-object v0

    :cond_1
    const-string v1, "Known database file:"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_10

    const-string v1, "Best profile:"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_10

    const-string v1, "Equivalent profile"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    goto/16 :goto_3

    :cond_2
    const-string v1, "Candidate:"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    return-object v0

    :cond_3
    const-string v1, "Detected 25"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_f

    const-string v1, "25-series SPI chip detected."

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f

    const-string v1, "Reading 25"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_f

    const-string v1, "Preparing safe fast write"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_f

    const-string v1, "Writing repaired data to chip"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    goto :goto_2

    :cond_4
    const-string v1, "No automatic match found"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_5

    const-string p0, "Profile not found. Send original and edited BIN to add this model."

    return-object p0

    :cond_5
    const-string v1, "Multiple profile matches found"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_e

    const-string v1, "Known file fingerprint collision"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6

    goto :goto_1

    :cond_6
    const-string v1, "SPI chip size not recognized"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_d

    const-string v1, "Unsupported SPI chip size"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_7

    goto :goto_0

    :cond_7
    const-string v1, "25-series SPI auto read failed"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_8

    const-string p0, "Read failed. Check chip contact."

    return-object p0

    :cond_8
    const-string v1, "No valid 25-series SPI chip detected"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_9

    const-string p0, "No SPI chip detected. Check wiring."

    return-object p0

    :cond_9
    const-string v1, "Backup saved automatically"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_a

    const-string p0, "Backup saved."

    return-object p0

    :cond_a
    const-string v1, "Saved:"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_b

    return-object p0

    :cond_b
    const-string v1, "0x"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_c

    return-object v0

    :cond_c
    return-object p0

    :cond_d
    :goto_0
    const-string p0, "Chip not supported. Repair blocked for safety."

    return-object p0

    :cond_e
    :goto_1
    const-string p0, "Profile not unique. Repair blocked for safety."

    return-object p0

    :cond_f
    :goto_2
    return-object v0

    :cond_10
    :goto_3
    const-string p0, "Panel profile detected."

    return-object p0
.end method

.method public static v(I[B[I)I
    .locals 5

    .line 1
    const/4 v0, -0x1

    if-eqz p1, :cond_3

    if-eqz p2, :cond_3

    array-length v1, p2

    if-nez v1, :cond_0

    goto :goto_2

    :cond_0
    const/4 v1, 0x0

    invoke-static {v1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    :goto_0
    array-length v2, p1

    array-length v3, p2

    sub-int/2addr v2, v3

    if-gt p0, v2, :cond_3

    move v2, v1

    :goto_1
    array-length v3, p2

    if-ge v2, v3, :cond_2

    aget v3, p2, v2

    if-ltz v3, :cond_1

    add-int v4, p0, v2

    aget-byte v4, p1, v4

    and-int/lit16 v4, v4, 0xff

    if-eq v4, v3, :cond_1

    add-int/lit8 p0, p0, 0x1

    goto :goto_0

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    return p0

    :cond_3
    :goto_2
    return v0
.end method

.method public static z(Ljava/util/ArrayList;)Z
    .locals 6

    .line 1
    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lg1/v;

    iget v2, v0, Lg1/v;->b:I

    iget-object v0, v0, Lg1/v;->a:Lg1/w;

    iget v3, v0, Lg1/w;->d:I

    add-int/2addr v2, v3

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lg1/v;

    iget v4, v3, Lg1/v;->b:I

    iget-object v3, v3, Lg1/v;->a:Lg1/w;

    iget v5, v3, Lg1/w;->d:I

    add-int/2addr v4, v5

    if-ne v4, v2, :cond_2

    iget v3, v3, Lg1/w;->e:I

    iget v4, v0, Lg1/w;->e:I

    if-eq v3, v4, :cond_1

    :cond_2
    return v1

    :cond_3
    const/4 p0, 0x1

    return p0
.end method


# virtual methods
.method public final A(Ljava/lang/String;[B)V
    .locals 4

    .line 1
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyyMMdd_HHmmss"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "_"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ".bin"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/16 v1, 0x1d

    const-string v2, "Saved: "

    if-ge v0, v1, :cond_1

    :try_start_1
    new-instance v0, Ljava/io/File;

    sget-object v1, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-static {v1}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const-string v3, "GKC_Terminal_Pro"

    invoke-direct {v0, v1, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v1

    if-nez v1, :cond_0

    const-string p1, "Save failed: cannot create folder."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    return-void

    :catch_0
    move-exception p1

    goto :goto_0

    :cond_0
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance p1, Ljava/io/FileOutputStream;

    invoke-direct {p1, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    invoke-virtual {p1, p2}, Ljava/io/FileOutputStream;->write([B)V

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    return-void

    :cond_1
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const-string v1, "_display_name"

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "mime_type"

    const-string v3, "application/octet-stream"

    invoke-virtual {v0, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "relative_path"

    const-string v3, "Download/GKC_Terminal_Pro"

    invoke-virtual {v0, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-static {}, La0/b;->f()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v1, v3, v0}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v0

    if-nez v0, :cond_2

    const-string p1, "Save failed: no output URI."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    return-void

    :cond_2
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v0

    if-nez v0, :cond_3

    const-string p1, "Save failed: no output stream."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    return-void

    :cond_3
    invoke-virtual {v0, p2}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :goto_0
    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Save failed: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    :goto_1
    return-void
.end method

.method public final E(Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-static {p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->D(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_0
    return-void
.end method

.method public final F()Le/i;
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-object v0, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->I:Lg1/n;

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x0

    .line 7
    :try_start_0
    invoke-virtual {v0}, Lg1/n;->j()Z

    .line 8
    .line 9
    .line 10
    move-result v4

    .line 11
    if-nez v4, :cond_0

    .line 12
    .line 13
    iget-object v4, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 14
    .line 15
    iget-object v5, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->K:Landroid/hardware/usb/UsbDevice;

    .line 16
    .line 17
    invoke-virtual {v0, v4, v5}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    .line 18
    .line 19
    .line 20
    goto :goto_0

    .line 21
    :catch_0
    move-exception v0

    .line 22
    goto/16 :goto_b

    .line 23
    .line 24
    :cond_0
    :goto_0
    invoke-virtual {v0}, Lg1/n;->t()[B

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    new-instance v5, Lg1/q;

    .line 29
    .line 30
    const/4 v6, 0x6

    .line 31
    invoke-direct {v5, v1, v6}, Lg1/q;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1, v5}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 35
    .line 36
    .line 37
    array-length v5, v4

    .line 38
    const/4 v6, 0x3

    .line 39
    if-ge v5, v6, :cond_1

    .line 40
    .line 41
    goto/16 :goto_a

    .line 42
    .line 43
    :cond_1
    array-length v5, v4

    .line 44
    const/4 v8, 0x1

    .line 45
    move v10, v8

    .line 46
    move v11, v10

    .line 47
    const/4 v9, 0x0

    .line 48
    :goto_1
    const/16 v12, 0xff

    .line 49
    .line 50
    if-ge v9, v5, :cond_4

    .line 51
    .line 52
    aget-byte v13, v4, v9

    .line 53
    .line 54
    and-int/2addr v13, v12

    .line 55
    if-ne v13, v12, :cond_2

    .line 56
    .line 57
    move v12, v8

    .line 58
    goto :goto_2

    .line 59
    :cond_2
    const/4 v12, 0x0

    .line 60
    :goto_2
    and-int/2addr v10, v12

    .line 61
    if-nez v13, :cond_3

    .line 62
    .line 63
    move v12, v8

    .line 64
    goto :goto_3

    .line 65
    :cond_3
    const/4 v12, 0x0

    .line 66
    :goto_3
    and-int/2addr v11, v12

    .line 67
    add-int/lit8 v9, v9, 0x1

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_4
    if-nez v10, :cond_c

    .line 71
    .line 72
    if-nez v11, :cond_c

    .line 73
    .line 74
    array-length v5, v4

    .line 75
    if-ge v5, v6, :cond_5

    .line 76
    .line 77
    :goto_4
    const/4 v4, 0x0

    .line 78
    goto :goto_5

    .line 79
    :cond_5
    aget-byte v4, v4, v2

    .line 80
    .line 81
    and-int/2addr v4, v12

    .line 82
    packed-switch v4, :pswitch_data_0

    .line 83
    .line 84
    .line 85
    goto :goto_4

    .line 86
    :pswitch_0
    const/high16 v4, 0x1000000

    .line 87
    .line 88
    goto :goto_5

    .line 89
    :pswitch_1
    const/high16 v4, 0x800000

    .line 90
    .line 91
    goto :goto_5

    .line 92
    :pswitch_2
    const/high16 v4, 0x400000

    .line 93
    .line 94
    goto :goto_5

    .line 95
    :pswitch_3
    const/high16 v4, 0x200000

    .line 96
    .line 97
    goto :goto_5

    .line 98
    :pswitch_4
    const/high16 v4, 0x100000

    .line 99
    .line 100
    goto :goto_5

    .line 101
    :pswitch_5
    const/high16 v4, 0x80000

    .line 102
    .line 103
    goto :goto_5

    .line 104
    :pswitch_6
    const/high16 v4, 0x40000

    .line 105
    .line 106
    :goto_5
    invoke-virtual {v1, v4}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->y(I)[I

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    array-length v5, v4

    .line 111
    if-nez v5, :cond_6

    .line 112
    .line 113
    return-object v3

    .line 114
    :cond_6
    array-length v5, v4

    .line 115
    const/4 v9, 0x0

    .line 116
    :goto_6
    if-ge v9, v5, :cond_d

    .line 117
    .line 118
    aget v10, v4, v9

    .line 119
    .line 120
    iget-object v11, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->O:[Lg1/w;

    .line 121
    .line 122
    array-length v13, v11

    .line 123
    const/4 v14, 0x0

    .line 124
    :goto_7
    if-ge v14, v13, :cond_b

    .line 125
    .line 126
    aget-object v15, v11, v14

    .line 127
    .line 128
    iget-object v7, v15, Lg1/w;->c:[I

    .line 129
    .line 130
    if-eqz v7, :cond_a

    .line 131
    .line 132
    iget v7, v15, Lg1/w;->b:I

    .line 133
    .line 134
    if-ne v7, v10, :cond_a

    .line 135
    .line 136
    new-instance v7, Lg1/t;

    .line 137
    .line 138
    invoke-direct {v7, v1, v10, v6}, Lg1/t;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;II)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v1, v7}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 142
    .line 143
    .line 144
    new-instance v7, Lg1/s;

    .line 145
    .line 146
    invoke-direct {v7, v1, v8}, Lg1/s;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v0, v10, v7}, Lg1/n;->s(ILg1/p;)[B

    .line 150
    .line 151
    .line 152
    move-result-object v7

    .line 153
    array-length v11, v7

    .line 154
    if-nez v11, :cond_7

    .line 155
    .line 156
    goto :goto_9

    .line 157
    :cond_7
    array-length v11, v7

    .line 158
    const/16 v13, 0x1000

    .line 159
    .line 160
    invoke-static {v11, v13}, Ljava/lang/Math;->min(II)I

    .line 161
    .line 162
    .line 163
    move-result v11

    .line 164
    const/4 v13, 0x0

    .line 165
    :goto_8
    if-ge v13, v11, :cond_9

    .line 166
    .line 167
    aget-byte v14, v7, v13

    .line 168
    .line 169
    and-int/2addr v14, v12

    .line 170
    if-eq v14, v12, :cond_8

    .line 171
    .line 172
    goto :goto_9

    .line 173
    :cond_8
    add-int/lit8 v13, v13, 0x1

    .line 174
    .line 175
    goto :goto_8

    .line 176
    :cond_9
    new-instance v11, Lg1/q;

    .line 177
    .line 178
    const/16 v13, 0x8

    .line 179
    .line 180
    invoke-direct {v11, v1, v13}, Lg1/q;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {v1, v11}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 184
    .line 185
    .line 186
    :goto_9
    invoke-static {v7}, Lg1/n;->d([B)[B

    .line 187
    .line 188
    .line 189
    move-result-object v11

    .line 190
    iput-object v11, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->L:[B

    .line 191
    .line 192
    invoke-static {v7}, Lg1/n;->d([B)[B

    .line 193
    .line 194
    .line 195
    move-result-object v7

    .line 196
    iput-object v7, v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 197
    .line 198
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->t()Lg1/v;

    .line 199
    .line 200
    .line 201
    move-result-object v7

    .line 202
    if-eqz v7, :cond_b

    .line 203
    .line 204
    new-instance v0, Le/i;

    .line 205
    .line 206
    invoke-direct {v0, v10, v7}, Le/i;-><init>(ILjava/lang/Object;)V

    .line 207
    .line 208
    .line 209
    return-object v0

    .line 210
    :cond_a
    add-int/lit8 v14, v14, 0x1

    .line 211
    .line 212
    goto :goto_7

    .line 213
    :cond_b
    add-int/lit8 v9, v9, 0x1

    .line 214
    .line 215
    goto :goto_6

    .line 216
    :cond_c
    :goto_a
    new-instance v0, Lg1/q;

    .line 217
    .line 218
    const/4 v4, 0x7

    .line 219
    invoke-direct {v0, v1, v4}, Lg1/q;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 223
    .line 224
    .line 225
    return-object v3

    .line 226
    :goto_b
    new-instance v4, Lg1/u;

    .line 227
    .line 228
    invoke-direct {v4, v1, v0, v2}, Lg1/u;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;Ljava/lang/Exception;I)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {v1, v4}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 232
    .line 233
    .line 234
    :cond_d
    return-object v3

    .line 235
    :pswitch_data_0
    .packed-switch 0x12
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
.end method

.method public final G([B)I
    .locals 3

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->I:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->j()Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->H:Landroid/hardware/usb/UsbManager;

    iget-object v2, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->K:Landroid/hardware/usb/UsbDevice;

    invoke-virtual {v0, v1, v2}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    :cond_0
    new-instance v1, Lg1/s;

    const/4 v2, 0x3

    invoke-direct {v1, p0, v2}, Lg1/s;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    invoke-virtual {v0, p1, v1}, Lg1/n;->I([BLg1/p;)I

    move-result p1

    return p1
.end method

.method public final H([B[B)V
    .locals 3

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->I:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->j()Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->H:Landroid/hardware/usb/UsbManager;

    iget-object v2, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->K:Landroid/hardware/usb/UsbDevice;

    invoke-virtual {v0, v1, v2}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    :cond_0
    const-string v1, "Preparing safe fast write..."

    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    const-string v1, "Writing repaired data to chip..."

    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    new-instance v1, Lg1/s;

    const/4 v2, 0x2

    invoke-direct {v1, p0, v2}, Lg1/s;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    invoke-virtual {v0, p2, p1, v1}, Lg1/n;->N([B[BLg1/p;)V

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 7

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const v0, 0x7f09018a

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-ne p1, v0, :cond_4

    .line 10
    .line 11
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->J:Z

    .line 12
    .line 13
    if-eqz p1, :cond_0

    .line 14
    .line 15
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->s()V

    .line 16
    .line 17
    .line 18
    goto/16 :goto_10

    .line 19
    .line 20
    :cond_0
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 21
    .line 22
    invoke-virtual {p1}, Landroid/hardware/usb/UsbManager;->getDeviceList()Ljava/util/HashMap;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    :cond_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_3

    .line 39
    .line 40
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    check-cast v0, Landroid/hardware/usb/UsbDevice;

    .line 45
    .line 46
    invoke-virtual {v0}, Landroid/hardware/usb/UsbDevice;->getVendorId()I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    const/16 v3, 0x1a86

    .line 51
    .line 52
    if-ne v2, v3, :cond_1

    .line 53
    .line 54
    invoke-virtual {v0}, Landroid/hardware/usb/UsbDevice;->getProductId()I

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    const/16 v3, 0x5512

    .line 59
    .line 60
    if-ne v2, v3, :cond_1

    .line 61
    .line 62
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 63
    .line 64
    invoke-virtual {p1, v0}, Landroid/hardware/usb/UsbManager;->hasPermission(Landroid/hardware/usb/UsbDevice;)Z

    .line 65
    .line 66
    .line 67
    move-result p1

    .line 68
    if-eqz p1, :cond_2

    .line 69
    .line 70
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->x(Landroid/hardware/usb/UsbDevice;)V

    .line 71
    .line 72
    .line 73
    goto/16 :goto_10

    .line 74
    .line 75
    :cond_2
    new-instance p1, Landroid/content/Intent;

    .line 76
    .line 77
    const-string v2, "app.gkc.terminal.pro.DIVISION_REPAIR_USB_PERMISSION"

    .line 78
    .line 79
    invoke-direct {p1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    invoke-virtual {p1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 87
    .line 88
    .line 89
    const/high16 v2, 0x2000000

    .line 90
    .line 91
    invoke-static {p0, v1, p1, v2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    iget-object v1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->H:Landroid/hardware/usb/UsbManager;

    .line 96
    .line 97
    invoke-virtual {v1, v0, p1}, Landroid/hardware/usb/UsbManager;->requestPermission(Landroid/hardware/usb/UsbDevice;Landroid/app/PendingIntent;)V

    .line 98
    .line 99
    .line 100
    const-string p1, "Requesting USB permission..."

    .line 101
    .line 102
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    goto/16 :goto_10

    .line 106
    .line 107
    :cond_3
    const-string p1, "CH341A not found."

    .line 108
    .line 109
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    const-string p1, "CH341A not found"

    .line 113
    .line 114
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 119
    .line 120
    .line 121
    goto/16 :goto_10

    .line 122
    .line 123
    :cond_4
    const v0, 0x7f090188

    .line 124
    .line 125
    .line 126
    if-ne p1, v0, :cond_5

    .line 127
    .line 128
    const-string p1, "25-series SPI auto detect is enabled."

    .line 129
    .line 130
    :goto_0
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    goto/16 :goto_10

    .line 134
    .line 135
    :cond_5
    const v0, 0x7f09018f

    .line 136
    .line 137
    .line 138
    if-ne p1, v0, :cond_6

    .line 139
    .line 140
    const-string p1, "Panel data is checked automatically."

    .line 141
    .line 142
    goto :goto_0

    .line 143
    :cond_6
    const v0, 0x7f090195

    .line 144
    .line 145
    .line 146
    const/4 v2, 0x0

    .line 147
    if-ne p1, v0, :cond_7

    .line 148
    .line 149
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 150
    .line 151
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 152
    .line 153
    .line 154
    const-string v0, "4K Division SOP"

    .line 155
    .line 156
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    const-string v0, "1. Connect CH341A and the 25-series flash.\n\n2. Tap ONE CLICK REPAIR for chip read, match, backup, write and verify.\n\n3. The app writes only when a compatible profile is found.\n\n4. For customer BIN files, use LOAD BIN and CONVERT BIN only.\n\n5. Export the edited BIN for RT809 or other programmers.\n\n6. If no compatible profile is found, do not write."

    .line 161
    .line 162
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 163
    .line 164
    .line 165
    move-result-object p1

    .line 166
    const-string v0, "OK"

    .line 167
    .line 168
    invoke-virtual {p1, v0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 173
    .line 174
    .line 175
    goto/16 :goto_10

    .line 176
    .line 177
    :cond_7
    const v0, 0x7f09018d

    .line 178
    .line 179
    .line 180
    if-ne p1, v0, :cond_8

    .line 181
    .line 182
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->P:Lb/h;

    .line 183
    .line 184
    const-string v0, "*/*"

    .line 185
    .line 186
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    goto/16 :goto_10

    .line 190
    .line 191
    :cond_8
    const/4 v0, 0x1

    .line 192
    const v3, 0x7f090192

    .line 193
    .line 194
    .line 195
    const-string v4, "0%"

    .line 196
    .line 197
    const-string v5, "Connect CH341A first."

    .line 198
    .line 199
    if-ne p1, v3, :cond_b

    .line 200
    .line 201
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->J:Z

    .line 202
    .line 203
    if-eqz p1, :cond_a

    .line 204
    .line 205
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->I:Lg1/n;

    .line 206
    .line 207
    invoke-virtual {p1}, Lg1/n;->j()Z

    .line 208
    .line 209
    .line 210
    move-result p1

    .line 211
    if-nez p1, :cond_9

    .line 212
    .line 213
    goto :goto_1

    .line 214
    :cond_9
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->D:Landroid/widget/TextView;

    .line 215
    .line 216
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 217
    .line 218
    .line 219
    const-string p1, "Starting one click 4K / double division repair..."

    .line 220
    .line 221
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    new-instance p1, Ljava/lang/Thread;

    .line 225
    .line 226
    new-instance v1, Lg1/q;

    .line 227
    .line 228
    invoke-direct {v1, p0, v0}, Lg1/q;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 229
    .line 230
    .line 231
    invoke-direct {p1, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 235
    .line 236
    .line 237
    goto/16 :goto_10

    .line 238
    .line 239
    :cond_a
    :goto_1
    invoke-virtual {p0, v5}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    goto/16 :goto_10

    .line 243
    .line 244
    :cond_b
    const v3, 0x7f090187

    .line 245
    .line 246
    .line 247
    const-string v6, "Cancel"

    .line 248
    .line 249
    if-ne p1, v3, :cond_10

    .line 250
    .line 251
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->J:Z

    .line 252
    .line 253
    if-eqz p1, :cond_f

    .line 254
    .line 255
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->K:Landroid/hardware/usb/UsbDevice;

    .line 256
    .line 257
    if-nez p1, :cond_c

    .line 258
    .line 259
    goto :goto_3

    .line 260
    :cond_c
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->L:[B

    .line 261
    .line 262
    if-eqz p1, :cond_e

    .line 263
    .line 264
    array-length p1, p1

    .line 265
    if-nez p1, :cond_d

    .line 266
    .line 267
    goto :goto_2

    .line 268
    :cond_d
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 269
    .line 270
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 271
    .line 272
    .line 273
    const-string v1, "Restore original?"

    .line 274
    .line 275
    invoke-virtual {p1, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 276
    .line 277
    .line 278
    move-result-object p1

    .line 279
    const-string v1, "This writes the saved original data back to EEPROM."

    .line 280
    .line 281
    invoke-virtual {p1, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 282
    .line 283
    .line 284
    move-result-object p1

    .line 285
    invoke-virtual {p1, v6, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 286
    .line 287
    .line 288
    move-result-object p1

    .line 289
    new-instance v1, Lg1/r;

    .line 290
    .line 291
    invoke-direct {v1, p0, v0}, Lg1/r;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 292
    .line 293
    .line 294
    const-string v0, "Restore"

    .line 295
    .line 296
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 297
    .line 298
    .line 299
    move-result-object p1

    .line 300
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 301
    .line 302
    .line 303
    goto/16 :goto_10

    .line 304
    .line 305
    :cond_e
    :goto_2
    const-string p1, "No original backup in memory. Load original BIN first."

    .line 306
    .line 307
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 308
    .line 309
    .line 310
    goto/16 :goto_10

    .line 311
    .line 312
    :cond_f
    :goto_3
    invoke-virtual {p0, v5}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 313
    .line 314
    .line 315
    goto/16 :goto_10

    .line 316
    .line 317
    :cond_10
    const v3, 0x7f090186

    .line 318
    .line 319
    .line 320
    if-ne p1, v3, :cond_1b

    .line 321
    .line 322
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 323
    .line 324
    if-eqz p1, :cond_1a

    .line 325
    .line 326
    array-length p1, p1

    .line 327
    if-nez p1, :cond_11

    .line 328
    .line 329
    goto :goto_9

    .line 330
    :cond_11
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->t()Lg1/v;

    .line 331
    .line 332
    .line 333
    move-result-object p1

    .line 334
    if-nez p1, :cond_12

    .line 335
    .line 336
    const-string p1, "No automatic match found. Send original and edited BIN to add this model."

    .line 337
    .line 338
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    const-string p1, "No auto repair match"

    .line 342
    .line 343
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 344
    .line 345
    .line 346
    move-result-object p1

    .line 347
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 348
    .line 349
    .line 350
    goto/16 :goto_10

    .line 351
    .line 352
    :cond_12
    iget-object v2, p1, Lg1/v;->a:Lg1/w;

    .line 353
    .line 354
    invoke-virtual {v2}, Lg1/w;->a()Z

    .line 355
    .line 356
    .line 357
    move-result v3

    .line 358
    if-eqz v3, :cond_19

    .line 359
    .line 360
    iget p1, p1, Lg1/v;->d:I

    .line 361
    .line 362
    if-ne p1, v0, :cond_13

    .line 363
    .line 364
    move v1, v0

    .line 365
    :cond_13
    if-eqz v1, :cond_14

    .line 366
    .line 367
    const-string p1, "1S detected. Converting to 2S."

    .line 368
    .line 369
    goto :goto_4

    .line 370
    :cond_14
    const-string p1, "2S detected. Converting to 1S."

    .line 371
    .line 372
    :goto_4
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    if-eqz v1, :cond_15

    .line 376
    .line 377
    iget-object p1, v2, Lg1/w;->g:[Le/i;

    .line 378
    .line 379
    goto :goto_5

    .line 380
    :cond_15
    iget-object p1, v2, Lg1/w;->h:[Le/i;

    .line 381
    .line 382
    :goto_5
    if-eqz v1, :cond_16

    .line 383
    .line 384
    const-string v0, "1S to 2S conversion"

    .line 385
    .line 386
    goto :goto_6

    .line 387
    :cond_16
    const-string v0, "2S to 1S conversion"

    .line 388
    .line 389
    :goto_6
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->q([Le/i;Ljava/lang/String;)Z

    .line 390
    .line 391
    .line 392
    move-result p1

    .line 393
    if-eqz p1, :cond_2a

    .line 394
    .line 395
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->C:Landroid/widget/TextView;

    .line 396
    .line 397
    if-eqz v1, :cond_17

    .line 398
    .line 399
    const-string v0, "2S converted BIN ready to export"

    .line 400
    .line 401
    goto :goto_7

    .line 402
    :cond_17
    const-string v0, "1S converted BIN ready to export"

    .line 403
    .line 404
    :goto_7
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 405
    .line 406
    .line 407
    if-eqz v1, :cond_18

    .line 408
    .line 409
    const-string p1, "2S conversion complete."

    .line 410
    .line 411
    goto :goto_8

    .line 412
    :cond_18
    const-string p1, "1S conversion complete."

    .line 413
    .line 414
    :goto_8
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 415
    .line 416
    .line 417
    goto/16 :goto_10

    .line 418
    .line 419
    :cond_19
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->r(Lg1/v;)Z

    .line 420
    .line 421
    .line 422
    goto/16 :goto_10

    .line 423
    .line 424
    :cond_1a
    :goto_9
    const-string p1, "Read EEPROM or load BIN first."

    .line 425
    .line 426
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 427
    .line 428
    .line 429
    goto/16 :goto_10

    .line 430
    .line 431
    :cond_1b
    const v0, 0x7f09018b

    .line 432
    .line 433
    .line 434
    if-ne p1, v0, :cond_1f

    .line 435
    .line 436
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 437
    .line 438
    if-eqz p1, :cond_1e

    .line 439
    .line 440
    array-length v0, p1

    .line 441
    if-nez v0, :cond_1c

    .line 442
    .line 443
    goto :goto_b

    .line 444
    :cond_1c
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->L:[B

    .line 445
    .line 446
    if-eqz v0, :cond_1d

    .line 447
    .line 448
    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([B[B)Z

    .line 449
    .line 450
    .line 451
    move-result p1

    .line 452
    if-eqz p1, :cond_1d

    .line 453
    .line 454
    const-string p1, "No converted change found. Tap CONVERT BIN first."

    .line 455
    .line 456
    :goto_a
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 457
    .line 458
    .line 459
    goto/16 :goto_10

    .line 460
    .line 461
    :cond_1d
    const-string p1, "gkc_4k_division_repaired"

    .line 462
    .line 463
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 464
    .line 465
    invoke-virtual {p0, p1, v0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->A(Ljava/lang/String;[B)V

    .line 466
    .line 467
    .line 468
    const-string p1, "Edited BIN exported. Use this file with RT809H/RT809F or any programmer."

    .line 469
    .line 470
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 471
    .line 472
    .line 473
    goto/16 :goto_10

    .line 474
    .line 475
    :cond_1e
    :goto_b
    const-string p1, "Load or read BIN first."

    .line 476
    .line 477
    goto :goto_a

    .line 478
    :cond_1f
    const v0, 0x7f090198

    .line 479
    .line 480
    .line 481
    if-ne p1, v0, :cond_24

    .line 482
    .line 483
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->J:Z

    .line 484
    .line 485
    if-eqz p1, :cond_23

    .line 486
    .line 487
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->K:Landroid/hardware/usb/UsbDevice;

    .line 488
    .line 489
    if-nez p1, :cond_20

    .line 490
    .line 491
    goto :goto_d

    .line 492
    :cond_20
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 493
    .line 494
    if-eqz p1, :cond_22

    .line 495
    .line 496
    array-length p1, p1

    .line 497
    if-nez p1, :cond_21

    .line 498
    .line 499
    goto :goto_c

    .line 500
    :cond_21
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 501
    .line 502
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 503
    .line 504
    .line 505
    const-string v0, "Write EEPROM?"

    .line 506
    .line 507
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 508
    .line 509
    .line 510
    move-result-object p1

    .line 511
    const-string v0, "Backup original data before writing. Continue?"

    .line 512
    .line 513
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 514
    .line 515
    .line 516
    move-result-object p1

    .line 517
    invoke-virtual {p1, v6, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 518
    .line 519
    .line 520
    move-result-object p1

    .line 521
    new-instance v0, Lg1/r;

    .line 522
    .line 523
    invoke-direct {v0, p0, v1}, Lg1/r;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 524
    .line 525
    .line 526
    const-string v1, "Write"

    .line 527
    .line 528
    invoke-virtual {p1, v1, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 529
    .line 530
    .line 531
    move-result-object p1

    .line 532
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 533
    .line 534
    .line 535
    goto :goto_10

    .line 536
    :cond_22
    :goto_c
    const-string p1, "No repaired BIN loaded."

    .line 537
    .line 538
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 539
    .line 540
    .line 541
    goto :goto_10

    .line 542
    :cond_23
    :goto_d
    invoke-virtual {p0, v5}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 543
    .line 544
    .line 545
    goto :goto_10

    .line 546
    :cond_24
    const v0, 0x7f090197

    .line 547
    .line 548
    .line 549
    if-ne p1, v0, :cond_29

    .line 550
    .line 551
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->J:Z

    .line 552
    .line 553
    if-eqz p1, :cond_28

    .line 554
    .line 555
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->K:Landroid/hardware/usb/UsbDevice;

    .line 556
    .line 557
    if-nez p1, :cond_25

    .line 558
    .line 559
    goto :goto_f

    .line 560
    :cond_25
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 561
    .line 562
    if-eqz p1, :cond_27

    .line 563
    .line 564
    array-length p1, p1

    .line 565
    if-nez p1, :cond_26

    .line 566
    .line 567
    goto :goto_e

    .line 568
    :cond_26
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->D:Landroid/widget/TextView;

    .line 569
    .line 570
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 571
    .line 572
    .line 573
    const-string p1, "Verifying chip data..."

    .line 574
    .line 575
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 576
    .line 577
    .line 578
    new-instance p1, Ljava/lang/Thread;

    .line 579
    .line 580
    new-instance v0, Lg1/q;

    .line 581
    .line 582
    invoke-direct {v0, p0, v1}, Lg1/q;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 583
    .line 584
    .line 585
    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 586
    .line 587
    .line 588
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 589
    .line 590
    .line 591
    goto :goto_10

    .line 592
    :cond_27
    :goto_e
    const-string p1, "No BIN loaded."

    .line 593
    .line 594
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 595
    .line 596
    .line 597
    goto :goto_10

    .line 598
    :cond_28
    :goto_f
    invoke-virtual {p0, v5}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E(Ljava/lang/String;)V

    .line 599
    .line 600
    .line 601
    goto :goto_10

    .line 602
    :cond_29
    const v0, 0x7f090189

    .line 603
    .line 604
    .line 605
    if-ne p1, v0, :cond_2a

    .line 606
    .line 607
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E:Landroid/widget/TextView;

    .line 608
    .line 609
    const-string v0, ""

    .line 610
    .line 611
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 612
    .line 613
    .line 614
    const-string p1, "Log cleared."

    .line 615
    .line 616
    goto/16 :goto_0

    .line 617
    .line 618
    :cond_2a
    :goto_10
    return-void
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0020

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const-string p1, "usb"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/usb/UsbManager;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->H:Landroid/hardware/usb/UsbManager;

    const p1, 0x7f090196

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->B:Landroid/widget/TextView;

    const p1, 0x7f090190

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const p1, 0x7f09018c

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->C:Landroid/widget/TextView;

    const p1, 0x7f090191

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->D:Landroid/widget/TextView;

    const p1, 0x7f09018e

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E:Landroid/widget/TextView;

    const p1, 0x7f090194

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ScrollView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->F:Landroid/widget/ScrollView;

    const p1, 0x7f09018a

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->G:Landroid/widget/Button;

    const/16 p1, 0xc

    new-array v0, p1, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p1, :cond_0

    aget v2, v0, v1

    invoke-virtual {p0, v2}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance p1, Landroid/content/IntentFilter;

    const-string v0, "app.gkc.terminal.pro.DIVISION_REPAIR_USB_PERMISSION"

    invoke-direct {p1, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->Q:Le/d0;

    invoke-static {p0, v0, p1}, Le2/m;->e1(Landroid/content/Context;Le/d0;Landroid/content/IntentFilter;)V

    const-string p1, "System ready. Connect CH341A, then tap ONE CLICK REPAIR."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    return-void

    :array_0
    .array-data 4
        0x7f09018a
        0x7f090188
        0x7f09018f
        0x7f090195
        0x7f09018d
        0x7f090192
        0x7f090187
        0x7f090186
        0x7f09018b
        0x7f090198
        0x7f090197
        0x7f090189
    .end array-data
.end method

.method public final onDestroy()V
    .locals 1

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->s()V

    :try_start_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->Q:Le/d0;

    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-super {p0}, Le/m;->onDestroy()V

    return-void
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final p(Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-static {p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->D(Ljava/lang/String;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-ne v0, v1, :cond_1

    .line 21
    .line 22
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E:Landroid/widget/TextView;

    .line 23
    .line 24
    const-string v1, "\n"

    .line 25
    .line 26
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    .line 31
    .line 32
    .line 33
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->E:Landroid/widget/TextView;

    .line 34
    .line 35
    new-instance v0, Lg1/q;

    .line 36
    .line 37
    const/4 v1, 0x2

    .line 38
    invoke-direct {v0, p0, v1}, Lg1/q;-><init>(Lapp/gkc/terminal/Activity/DivisionRepairActivity;I)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    new-instance v0, Landroidx/activity/p;

    .line 46
    .line 47
    const/16 v1, 0x8

    .line 48
    .line 49
    invoke-direct {v0, v1, p0, p1}, Landroidx/activity/p;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 53
    .line 54
    .line 55
    :goto_0
    return-void
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final q([Le/i;Ljava/lang/String;)Z
    .locals 8

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    array-length v0, v0

    if-nez v0, :cond_0

    goto :goto_5

    :cond_0
    array-length v0, p1

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_3

    aget-object v3, p1, v2

    iget v4, v3, Le/i;->b:I

    if-ltz v4, :cond_2

    iget-object v3, v3, Le/i;->c:Ljava/lang/Object;

    check-cast v3, [I

    array-length v3, v3

    add-int/2addr v4, v3

    iget-object v3, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    array-length v3, v3

    if-le v4, v3, :cond_1

    goto :goto_1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    const-string p1, "Profile data outside file. Repair blocked."

    :goto_2
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    return v1

    :cond_3
    array-length v0, p1

    move v2, v1

    :goto_3
    if-ge v2, v0, :cond_5

    aget-object v3, p1, v2

    move v4, v1

    :goto_4
    iget-object v5, v3, Le/i;->c:Ljava/lang/Object;

    check-cast v5, [I

    array-length v6, v5

    if-ge v4, v6, :cond_4

    iget-object v6, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    iget v7, v3, Le/i;->b:I

    add-int/2addr v7, v4

    aget v5, v5, v4

    and-int/lit16 v5, v5, 0xff

    int-to-byte v5, v5

    aput-byte v5, v6, v7

    add-int/lit8 v4, v4, 0x1

    goto :goto_4

    :cond_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_5
    const-string p1, "Compatible panel data found."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    const-string p1, " prepared."

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->C:Landroid/widget/TextView;

    const-string p2, "Edited BIN ready to export"

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string p1, "Backup saved."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    const/4 p1, 0x1

    return p1

    :cond_6
    :goto_5
    const-string p1, "No BIN loaded."

    goto :goto_2
.end method

.method public final r(Lg1/v;)Z
    .locals 7

    .line 1
    iget-object v0, p1, Lg1/v;->a:Lg1/w;

    .line 2
    .line 3
    iget-object v1, v0, Lg1/w;->g:[Le/i;

    .line 4
    .line 5
    array-length v1, v1

    .line 6
    const/4 v2, 0x0

    .line 7
    if-lez v1, :cond_2

    .line 8
    .line 9
    invoke-virtual {v0}, Lg1/w;->a()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    iget-object v0, v0, Lg1/w;->g:[Le/i;

    .line 14
    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    const/4 v1, 0x2

    .line 18
    iget p1, p1, Lg1/v;->d:I

    .line 19
    .line 20
    if-ne p1, v1, :cond_0

    .line 21
    .line 22
    const-string p1, "2S BIN detected. Reverse is available only from CONVERT BIN selection."

    .line 23
    .line 24
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return v2

    .line 28
    :cond_0
    const-string p1, "1S to 2S conversion"

    .line 29
    .line 30
    invoke-virtual {p0, v0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->q([Le/i;Ljava/lang/String;)Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    return p1

    .line 35
    :cond_1
    const-string p1, "Repair"

    .line 36
    .line 37
    invoke-virtual {p0, v0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->q([Le/i;Ljava/lang/String;)Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    return p1

    .line 42
    :cond_2
    iget v1, p1, Lg1/v;->b:I

    .line 43
    .line 44
    iget v3, v0, Lg1/w;->d:I

    .line 45
    .line 46
    add-int/2addr v1, v3

    .line 47
    const-string v4, "No automatic match found. Send original and edited BIN to add this model."

    .line 48
    .line 49
    if-ltz v1, :cond_8

    .line 50
    .line 51
    iget-object v5, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 52
    .line 53
    array-length v6, v5

    .line 54
    if-lt v1, v6, :cond_3

    .line 55
    .line 56
    goto :goto_2

    .line 57
    :cond_3
    aget-byte v6, v5, v1

    .line 58
    .line 59
    and-int/lit16 v6, v6, 0xff

    .line 60
    .line 61
    iget-boolean p1, p1, Lg1/v;->c:Z

    .line 62
    .line 63
    if-nez p1, :cond_7

    .line 64
    .line 65
    iget p1, v0, Lg1/w;->e:I

    .line 66
    .line 67
    if-ne v6, p1, :cond_4

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_4
    iget-object v0, v0, Lg1/w;->c:[I

    .line 71
    .line 72
    aget v0, v0, v3

    .line 73
    .line 74
    if-ltz v0, :cond_6

    .line 75
    .line 76
    if-eq v6, v0, :cond_5

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_5
    int-to-byte p1, p1

    .line 80
    aput-byte p1, v5, v1

    .line 81
    .line 82
    const-string p1, "Compatible panel data found."

    .line 83
    .line 84
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    const-string p1, "Repair data prepared."

    .line 88
    .line 89
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->C:Landroid/widget/TextView;

    .line 93
    .line 94
    const-string v0, "Edited BIN ready to export"

    .line 95
    .line 96
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 97
    .line 98
    .line 99
    const-string p1, "Backup saved automatically before write."

    .line 100
    .line 101
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    const/4 p1, 0x1

    .line 105
    return p1

    .line 106
    :cond_6
    :goto_0
    invoke-virtual {p0, v4}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    return v2

    .line 110
    :cond_7
    :goto_1
    const-string p1, "Division repair already applied. No change needed."

    .line 111
    .line 112
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    return v2

    .line 116
    :cond_8
    :goto_2
    invoke-virtual {p0, v4}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    return v2
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final s()V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->I:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->c()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->J:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->K:Landroid/hardware/usb/UsbDevice;

    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->B:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    const-string v1, "4K DIVISION: Disconnected"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->G:Landroid/widget/Button;

    if-eqz v0, :cond_1

    const-string v1, "CONNECT"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    return-void
.end method

.method public final t()Lg1/v;
    .locals 14

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->O:[Lg1/w;

    .line 7
    .line 8
    array-length v2, v1

    .line 9
    const/4 v3, 0x0

    .line 10
    move v4, v3

    .line 11
    :goto_0
    const/4 v5, 0x2

    .line 12
    const/4 v6, 0x1

    .line 13
    if-ge v4, v2, :cond_a

    .line 14
    .line 15
    aget-object v7, v1, v4

    .line 16
    .line 17
    iget-object v8, v7, Lg1/w;->g:[Le/i;

    .line 18
    .line 19
    array-length v8, v8

    .line 20
    iget v9, v7, Lg1/w;->b:I

    .line 21
    .line 22
    if-lez v8, :cond_4

    .line 23
    .line 24
    if-lez v9, :cond_0

    .line 25
    .line 26
    iget-object v8, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 27
    .line 28
    array-length v8, v8

    .line 29
    if-eq v8, v9, :cond_0

    .line 30
    .line 31
    goto/16 :goto_3

    .line 32
    .line 33
    :cond_0
    iget-object v8, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 34
    .line 35
    invoke-static {v8}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->B([B)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v8

    .line 39
    iget-object v9, v7, Lg1/w;->i:Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {v9, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v9

    .line 45
    iget-boolean v10, v7, Lg1/w;->k:Z

    .line 46
    .line 47
    if-eqz v9, :cond_2

    .line 48
    .line 49
    new-instance v8, Lg1/v;

    .line 50
    .line 51
    if-eqz v10, :cond_1

    .line 52
    .line 53
    move v5, v6

    .line 54
    :cond_1
    invoke-direct {v8, v7, v3, v3, v5}, Lg1/v;-><init>(Lg1/w;IZI)V

    .line 55
    .line 56
    .line 57
    :goto_1
    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    goto :goto_3

    .line 61
    :cond_2
    iget-object v9, v7, Lg1/w;->j:Ljava/lang/String;

    .line 62
    .line 63
    invoke-virtual {v9, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v8

    .line 67
    if-eqz v8, :cond_9

    .line 68
    .line 69
    new-instance v8, Lg1/v;

    .line 70
    .line 71
    if-eqz v10, :cond_3

    .line 72
    .line 73
    goto :goto_2

    .line 74
    :cond_3
    move v5, v6

    .line 75
    :goto_2
    invoke-direct {v8, v7, v3, v3, v5}, Lg1/v;-><init>(Lg1/w;IZI)V

    .line 76
    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_4
    iget-object v5, v7, Lg1/w;->c:[I

    .line 80
    .line 81
    if-nez v5, :cond_5

    .line 82
    .line 83
    goto :goto_3

    .line 84
    :cond_5
    if-lez v9, :cond_6

    .line 85
    .line 86
    iget-object v8, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 87
    .line 88
    array-length v8, v8

    .line 89
    if-eq v8, v9, :cond_6

    .line 90
    .line 91
    goto :goto_3

    .line 92
    :cond_6
    iget v8, v7, Lg1/w;->d:I

    .line 93
    .line 94
    if-ltz v8, :cond_9

    .line 95
    .line 96
    array-length v9, v5

    .line 97
    if-ge v8, v9, :cond_9

    .line 98
    .line 99
    aget v9, v5, v8

    .line 100
    .line 101
    if-gez v9, :cond_7

    .line 102
    .line 103
    goto :goto_3

    .line 104
    :cond_7
    invoke-virtual {p0, v7, v5, v3}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->w(Lg1/w;[IZ)Lg1/v;

    .line 105
    .line 106
    .line 107
    move-result-object v9

    .line 108
    if-eqz v9, :cond_8

    .line 109
    .line 110
    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    :cond_8
    aget v9, v5, v8

    .line 114
    .line 115
    iget v10, v7, Lg1/w;->e:I

    .line 116
    .line 117
    if-eq v9, v10, :cond_9

    .line 118
    .line 119
    invoke-virtual {v5}, [I->clone()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v5

    .line 123
    check-cast v5, [I

    .line 124
    .line 125
    aput v10, v5, v8

    .line 126
    .line 127
    invoke-virtual {p0, v7, v5, v6}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->w(Lg1/w;[IZ)Lg1/v;

    .line 128
    .line 129
    .line 130
    move-result-object v5

    .line 131
    if-eqz v5, :cond_9

    .line 132
    .line 133
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 134
    .line 135
    .line 136
    :cond_9
    :goto_3
    add-int/lit8 v4, v4, 0x1

    .line 137
    .line 138
    goto :goto_0

    .line 139
    :cond_a
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    const/4 v2, 0x0

    .line 144
    if-eqz v1, :cond_b

    .line 145
    .line 146
    return-object v2

    .line 147
    :cond_b
    iget-object v1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 148
    .line 149
    invoke-static {v1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->B([B)Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 154
    .line 155
    .line 156
    move-result v4

    .line 157
    const/4 v7, -0x1

    .line 158
    const/4 v8, 0x3

    .line 159
    if-nez v4, :cond_41

    .line 160
    .line 161
    new-instance v4, Ljava/util/ArrayList;

    .line 162
    .line 163
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 167
    .line 168
    .line 169
    move-result-object v9

    .line 170
    :cond_c
    :goto_4
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 171
    .line 172
    .line 173
    move-result v10

    .line 174
    if-eqz v10, :cond_3e

    .line 175
    .line 176
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v10

    .line 180
    check-cast v10, Lg1/v;

    .line 181
    .line 182
    iget-object v11, v10, Lg1/v;->a:Lg1/w;

    .line 183
    .line 184
    iget-object v12, v11, Lg1/w;->i:Ljava/lang/String;

    .line 185
    .line 186
    invoke-virtual {v12, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 187
    .line 188
    .line 189
    move-result v12

    .line 190
    if-nez v12, :cond_3d

    .line 191
    .line 192
    iget-object v12, v11, Lg1/w;->j:Ljava/lang/String;

    .line 193
    .line 194
    invoke-virtual {v12, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    move-result v12

    .line 198
    if-eqz v12, :cond_d

    .line 199
    .line 200
    goto/16 :goto_9

    .line 201
    .line 202
    :cond_d
    iget-object v11, v11, Lg1/w;->a:Ljava/lang/String;

    .line 203
    .line 204
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 205
    .line 206
    .line 207
    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    .line 208
    .line 209
    .line 210
    move-result v12

    .line 211
    sparse-switch v12, :sswitch_data_0

    .line 212
    .line 213
    .line 214
    :goto_5
    move v11, v7

    .line 215
    goto/16 :goto_6

    .line 216
    .line 217
    :sswitch_0
    const-string v12, "EXACT HV650QUB-F70 2S 4K division repair"

    .line 218
    .line 219
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v11

    .line 223
    if-nez v11, :cond_e

    .line 224
    .line 225
    goto :goto_5

    .line 226
    :cond_e
    const/16 v11, 0x2e

    .line 227
    .line 228
    goto/16 :goto_6

    .line 229
    .line 230
    :sswitch_1
    const-string v12, "EXACT GD25VQ16C 50 INCH MI 4K division repair"

    .line 231
    .line 232
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 233
    .line 234
    .line 235
    move-result v11

    .line 236
    if-nez v11, :cond_f

    .line 237
    .line 238
    goto :goto_5

    .line 239
    :cond_f
    const/16 v11, 0x2d

    .line 240
    .line 241
    goto/16 :goto_6

    .line 242
    .line 243
    :sswitch_2
    const-string v12, "EXACT P25Q80H 170338 4K division repair"

    .line 244
    .line 245
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 246
    .line 247
    .line 248
    move-result v11

    .line 249
    if-nez v11, :cond_10

    .line 250
    .line 251
    goto :goto_5

    .line 252
    :cond_10
    const/16 v11, 0x2c

    .line 253
    .line 254
    goto/16 :goto_6

    .line 255
    .line 256
    :sswitch_3
    const-string v12, "EXACT ACE25Q800G 4K division repair"

    .line 257
    .line 258
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v11

    .line 262
    if-nez v11, :cond_11

    .line 263
    .line 264
    goto :goto_5

    .line 265
    :cond_11
    const/16 v11, 0x2b

    .line 266
    .line 267
    goto/16 :goto_6

    .line 268
    .line 269
    :sswitch_4
    const-string v12, "EXACT ZB25VQ40 HV550QU1-BF2 2S DCBDS-B268N-03 4K division repair"

    .line 270
    .line 271
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v11

    .line 275
    if-nez v11, :cond_12

    .line 276
    .line 277
    goto :goto_5

    .line 278
    :cond_12
    const/16 v11, 0x2a

    .line 279
    .line 280
    goto/16 :goto_6

    .line 281
    .line 282
    :sswitch_5
    const-string v12, "EXACT T500QVN04.1 4K division repair"

    .line 283
    .line 284
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 285
    .line 286
    .line 287
    move-result v11

    .line 288
    if-nez v11, :cond_13

    .line 289
    .line 290
    goto :goto_5

    .line 291
    :cond_13
    const/16 v11, 0x29

    .line 292
    .line 293
    goto/16 :goto_6

    .line 294
    .line 295
    :sswitch_6
    const-string v12, "EXACT ZB25VQ40 1S TCON 4K division repair"

    .line 296
    .line 297
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 298
    .line 299
    .line 300
    move-result v11

    .line 301
    if-nez v11, :cond_14

    .line 302
    .line 303
    goto :goto_5

    .line 304
    :cond_14
    const/16 v11, 0x28

    .line 305
    .line 306
    goto/16 :goto_6

    .line 307
    .line 308
    :sswitch_7
    const-string v12, "EXACT HV55QUB F72 4K division repair"

    .line 309
    .line 310
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 311
    .line 312
    .line 313
    move-result v11

    .line 314
    if-nez v11, :cond_15

    .line 315
    .line 316
    goto :goto_5

    .line 317
    :cond_15
    const/16 v11, 0x27

    .line 318
    .line 319
    goto/16 :goto_6

    .line 320
    .line 321
    :sswitch_8
    const-string v12, "EXACT P25Q80 ST5461D11D 2S 4K division repair"

    .line 322
    .line 323
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 324
    .line 325
    .line 326
    move-result v11

    .line 327
    if-nez v11, :cond_16

    .line 328
    .line 329
    goto :goto_5

    .line 330
    :cond_16
    const/16 v11, 0x26

    .line 331
    .line 332
    goto/16 :goto_6

    .line 333
    .line 334
    :sswitch_9
    const-string v12, "EXACT ZB25VQ40 2S 20260903 4K division repair"

    .line 335
    .line 336
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 337
    .line 338
    .line 339
    move-result v11

    .line 340
    if-nez v11, :cond_17

    .line 341
    .line 342
    goto/16 :goto_5

    .line 343
    .line 344
    :cond_17
    const/16 v11, 0x25

    .line 345
    .line 346
    goto/16 :goto_6

    .line 347
    .line 348
    :sswitch_a
    const-string v12, "EXACT HV550QUB FID 4K division repair"

    .line 349
    .line 350
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 351
    .line 352
    .line 353
    move-result v11

    .line 354
    if-nez v11, :cond_18

    .line 355
    .line 356
    goto/16 :goto_5

    .line 357
    .line 358
    :cond_18
    const/16 v11, 0x24

    .line 359
    .line 360
    goto/16 :goto_6

    .line 361
    .line 362
    :sswitch_b
    const-string v12, "EXACT IS25LQ020B PT430 4K division repair"

    .line 363
    .line 364
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 365
    .line 366
    .line 367
    move-result v11

    .line 368
    if-nez v11, :cond_19

    .line 369
    .line 370
    goto/16 :goto_5

    .line 371
    .line 372
    :cond_19
    const/16 v11, 0x23

    .line 373
    .line 374
    goto/16 :goto_6

    .line 375
    .line 376
    :sswitch_c
    const-string v12, "EXACT V500DJ7 QE1 4K division repair"

    .line 377
    .line 378
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 379
    .line 380
    .line 381
    move-result v11

    .line 382
    if-nez v11, :cond_1a

    .line 383
    .line 384
    goto/16 :goto_5

    .line 385
    .line 386
    :cond_1a
    const/16 v11, 0x22

    .line 387
    .line 388
    goto/16 :goto_6

    .line 389
    .line 390
    :sswitch_d
    const-string v12, "EXACT FM25Q08 4K division repair"

    .line 391
    .line 392
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 393
    .line 394
    .line 395
    move-result v11

    .line 396
    if-nez v11, :cond_1b

    .line 397
    .line 398
    goto/16 :goto_5

    .line 399
    .line 400
    :cond_1b
    const/16 v11, 0x21

    .line 401
    .line 402
    goto/16 :goto_6

    .line 403
    .line 404
    :sswitch_e
    const-string v12, "EXACT TD-0006 4K division repair"

    .line 405
    .line 406
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 407
    .line 408
    .line 409
    move-result v11

    .line 410
    if-nez v11, :cond_1c

    .line 411
    .line 412
    goto/16 :goto_5

    .line 413
    .line 414
    :cond_1c
    const/16 v11, 0x20

    .line 415
    .line 416
    goto/16 :goto_6

    .line 417
    .line 418
    :sswitch_f
    const-string v12, "EXACT ZB25VQ40 SAMSUNG 43 1S 4K division repair"

    .line 419
    .line 420
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 421
    .line 422
    .line 423
    move-result v11

    .line 424
    if-nez v11, :cond_1d

    .line 425
    .line 426
    goto/16 :goto_5

    .line 427
    .line 428
    :cond_1d
    const/16 v11, 0x1f

    .line 429
    .line 430
    goto/16 :goto_6

    .line 431
    .line 432
    :sswitch_10
    const-string v12, "EXACT GD25VQ41B LG 55 INCH 4K division repair"

    .line 433
    .line 434
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 435
    .line 436
    .line 437
    move-result v11

    .line 438
    if-nez v11, :cond_1e

    .line 439
    .line 440
    goto/16 :goto_5

    .line 441
    .line 442
    :cond_1e
    const/16 v11, 0x1e

    .line 443
    .line 444
    goto/16 :goto_6

    .line 445
    .line 446
    :sswitch_11
    const-string v12, "EXACT HF500QUB-F20 4K division repair"

    .line 447
    .line 448
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 449
    .line 450
    .line 451
    move-result v11

    .line 452
    if-nez v11, :cond_1f

    .line 453
    .line 454
    goto/16 :goto_5

    .line 455
    .line 456
    :cond_1f
    const/16 v11, 0x1d

    .line 457
    .line 458
    goto/16 :goto_6

    .line 459
    .line 460
    :sswitch_12
    const-string v12, "EXACT ZB25VQ40 20260203 194126 4K division repair"

    .line 461
    .line 462
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 463
    .line 464
    .line 465
    move-result v11

    .line 466
    if-nez v11, :cond_20

    .line 467
    .line 468
    goto/16 :goto_5

    .line 469
    .line 470
    :cond_20
    const/16 v11, 0x1c

    .line 471
    .line 472
    goto/16 :goto_6

    .line 473
    .line 474
    :sswitch_13
    const-string v12, "EXACT P25Q80H LQ-K12-B13-11 HV750QUB-E97 4K division repair"

    .line 475
    .line 476
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 477
    .line 478
    .line 479
    move-result v11

    .line 480
    if-nez v11, :cond_21

    .line 481
    .line 482
    goto/16 :goto_5

    .line 483
    .line 484
    :cond_21
    const/16 v11, 0x1b

    .line 485
    .line 486
    goto/16 :goto_6

    .line 487
    .line 488
    :sswitch_14
    const-string v12, "EXACT PT430GT01 1S 4K division repair"

    .line 489
    .line 490
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 491
    .line 492
    .line 493
    move-result v11

    .line 494
    if-nez v11, :cond_22

    .line 495
    .line 496
    goto/16 :goto_5

    .line 497
    .line 498
    :cond_22
    const/16 v11, 0x1a

    .line 499
    .line 500
    goto/16 :goto_6

    .line 501
    .line 502
    :sswitch_15
    const-string v12, "EXACT P25Q80H 20543 4K division repair"

    .line 503
    .line 504
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 505
    .line 506
    .line 507
    move-result v11

    .line 508
    if-nez v11, :cond_23

    .line 509
    .line 510
    goto/16 :goto_5

    .line 511
    .line 512
    :cond_23
    const/16 v11, 0x19

    .line 513
    .line 514
    goto/16 :goto_6

    .line 515
    .line 516
    :sswitch_16
    const-string v12, "EXACT ZB25VQ40 20251018 194514 4K division repair"

    .line 517
    .line 518
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 519
    .line 520
    .line 521
    move-result v11

    .line 522
    if-nez v11, :cond_24

    .line 523
    .line 524
    goto/16 :goto_5

    .line 525
    .line 526
    :cond_24
    const/16 v11, 0x18

    .line 527
    .line 528
    goto/16 :goto_6

    .line 529
    .line 530
    :sswitch_17
    const-string v12, "EXACT TU682KCG4F1-A V1.0 4K division repair"

    .line 531
    .line 532
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 533
    .line 534
    .line 535
    move-result v11

    .line 536
    if-nez v11, :cond_25

    .line 537
    .line 538
    goto/16 :goto_5

    .line 539
    .line 540
    :cond_25
    const/16 v11, 0x17

    .line 541
    .line 542
    goto/16 :goto_6

    .line 543
    .line 544
    :sswitch_18
    const-string v12, "EXACT STOG 4K division repair"

    .line 545
    .line 546
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 547
    .line 548
    .line 549
    move-result v11

    .line 550
    if-nez v11, :cond_26

    .line 551
    .line 552
    goto/16 :goto_5

    .line 553
    .line 554
    :cond_26
    const/16 v11, 0x16

    .line 555
    .line 556
    goto/16 :goto_6

    .line 557
    .line 558
    :sswitch_19
    const-string v12, "EXACT ZB25VQ40 ORG 4K division repair"

    .line 559
    .line 560
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 561
    .line 562
    .line 563
    move-result v11

    .line 564
    if-nez v11, :cond_27

    .line 565
    .line 566
    goto/16 :goto_5

    .line 567
    .line 568
    :cond_27
    const/16 v11, 0x15

    .line 569
    .line 570
    goto/16 :goto_6

    .line 571
    .line 572
    :sswitch_1a
    const-string v12, "EXACT LC550EQC-SMA4 1S 4K division repair"

    .line 573
    .line 574
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 575
    .line 576
    .line 577
    move-result v11

    .line 578
    if-nez v11, :cond_28

    .line 579
    .line 580
    goto/16 :goto_5

    .line 581
    .line 582
    :cond_28
    const/16 v11, 0x14

    .line 583
    .line 584
    goto/16 :goto_6

    .line 585
    .line 586
    :sswitch_1b
    const-string v12, "EXACT P25Q80H 20251110 171519 4K division repair"

    .line 587
    .line 588
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 589
    .line 590
    .line 591
    move-result v11

    .line 592
    if-nez v11, :cond_29

    .line 593
    .line 594
    goto/16 :goto_5

    .line 595
    .line 596
    :cond_29
    const/16 v11, 0x13

    .line 597
    .line 598
    goto/16 :goto_6

    .line 599
    .line 600
    :sswitch_1c
    const-string v12, "EXACT HV430QUB-F1Z single 4K division repair"

    .line 601
    .line 602
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 603
    .line 604
    .line 605
    move-result v11

    .line 606
    if-nez v11, :cond_2a

    .line 607
    .line 608
    goto/16 :goto_5

    .line 609
    .line 610
    :cond_2a
    const/16 v11, 0x12

    .line 611
    .line 612
    goto/16 :goto_6

    .line 613
    .line 614
    :sswitch_1d
    const-string v12, "EXACT P25Q40H SOP8-200 2S 20260928 4K division repair"

    .line 615
    .line 616
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 617
    .line 618
    .line 619
    move-result v11

    .line 620
    if-nez v11, :cond_2b

    .line 621
    .line 622
    goto/16 :goto_5

    .line 623
    .line 624
    :cond_2b
    const/16 v11, 0x11

    .line 625
    .line 626
    goto/16 :goto_6

    .line 627
    .line 628
    :sswitch_1e
    const-string v12, "EXACT ZB25VQ40 DCBDS-B268G 09 HV650QUB-F74 1S 4K division repair"

    .line 629
    .line 630
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 631
    .line 632
    .line 633
    move-result v11

    .line 634
    if-nez v11, :cond_2c

    .line 635
    .line 636
    goto/16 :goto_5

    .line 637
    .line 638
    :cond_2c
    const/16 v11, 0x10

    .line 639
    .line 640
    goto/16 :goto_6

    .line 641
    .line 642
    :sswitch_1f
    const-string v12, "EXACT 1MB 1S 4K division repair"

    .line 643
    .line 644
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 645
    .line 646
    .line 647
    move-result v11

    .line 648
    if-nez v11, :cond_2d

    .line 649
    .line 650
    goto/16 :goto_5

    .line 651
    .line 652
    :cond_2d
    const/16 v11, 0xf

    .line 653
    .line 654
    goto/16 :goto_6

    .line 655
    .line 656
    :sswitch_20
    const-string v12, "EXACT P25Q40H SOP8-200 2S 4K division repair"

    .line 657
    .line 658
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 659
    .line 660
    .line 661
    move-result v11

    .line 662
    if-nez v11, :cond_2e

    .line 663
    .line 664
    goto/16 :goto_5

    .line 665
    .line 666
    :cond_2e
    const/16 v11, 0xe

    .line 667
    .line 668
    goto/16 :goto_6

    .line 669
    .line 670
    :sswitch_21
    const-string v12, "EXACT LC550 EQC KIWMAGIC 4K division repair"

    .line 671
    .line 672
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 673
    .line 674
    .line 675
    move-result v11

    .line 676
    if-nez v11, :cond_2f

    .line 677
    .line 678
    goto/16 :goto_5

    .line 679
    .line 680
    :cond_2f
    const/16 v11, 0xd

    .line 681
    .line 682
    goto/16 :goto_6

    .line 683
    .line 684
    :sswitch_22
    const-string v12, "EXACT DCBDU-C196A-17 Kiwiimage KV7636 51pin to96pin 4K division repair"

    .line 685
    .line 686
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 687
    .line 688
    .line 689
    move-result v11

    .line 690
    if-nez v11, :cond_30

    .line 691
    .line 692
    goto/16 :goto_5

    .line 693
    .line 694
    :cond_30
    const/16 v11, 0xc

    .line 695
    .line 696
    goto/16 :goto_6

    .line 697
    .line 698
    :sswitch_23
    const-string v12, "EXACT ST5461D13 4K division repair"

    .line 699
    .line 700
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 701
    .line 702
    .line 703
    move-result v11

    .line 704
    if-nez v11, :cond_31

    .line 705
    .line 706
    goto/16 :goto_5

    .line 707
    .line 708
    :cond_31
    const/16 v11, 0xb

    .line 709
    .line 710
    goto/16 :goto_6

    .line 711
    .line 712
    :sswitch_24
    const-string v12, "EXACT ZB25VQ40 202835 4K division repair"

    .line 713
    .line 714
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 715
    .line 716
    .line 717
    move-result v11

    .line 718
    if-nez v11, :cond_32

    .line 719
    .line 720
    goto/16 :goto_5

    .line 721
    .line 722
    :cond_32
    const/16 v11, 0xa

    .line 723
    .line 724
    goto/16 :goto_6

    .line 725
    .line 726
    :sswitch_25
    const-string v12, "EXACT ZB25VQ40 DCBDS-B268G 09 4K division repair"

    .line 727
    .line 728
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 729
    .line 730
    .line 731
    move-result v11

    .line 732
    if-nez v11, :cond_33

    .line 733
    .line 734
    goto/16 :goto_5

    .line 735
    .line 736
    :cond_33
    const/16 v11, 0x9

    .line 737
    .line 738
    goto/16 :goto_6

    .line 739
    .line 740
    :sswitch_26
    const-string v12, "EXACT 24C128 WDX DCBDC-1260E 06 P2 EK76603Q 1S division repair"

    .line 741
    .line 742
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 743
    .line 744
    .line 745
    move-result v11

    .line 746
    if-nez v11, :cond_34

    .line 747
    .line 748
    goto/16 :goto_5

    .line 749
    .line 750
    :cond_34
    const/16 v11, 0x8

    .line 751
    .line 752
    goto/16 :goto_6

    .line 753
    .line 754
    :sswitch_27
    const-string v12, "EXACT BOE HV430QUB F7A 4K division repair"

    .line 755
    .line 756
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 757
    .line 758
    .line 759
    move-result v11

    .line 760
    if-nez v11, :cond_35

    .line 761
    .line 762
    goto/16 :goto_5

    .line 763
    .line 764
    :cond_35
    const/4 v11, 0x7

    .line 765
    goto :goto_6

    .line 766
    :sswitch_28
    const-string v12, "EXACT P25Q80H SOP8-200 1S 4K division repair"

    .line 767
    .line 768
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 769
    .line 770
    .line 771
    move-result v11

    .line 772
    if-nez v11, :cond_36

    .line 773
    .line 774
    goto/16 :goto_5

    .line 775
    .line 776
    :cond_36
    const/4 v11, 0x6

    .line 777
    goto :goto_6

    .line 778
    :sswitch_29
    const-string v12, "EXACT ZB25VQ40 184339 4K division repair"

    .line 779
    .line 780
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 781
    .line 782
    .line 783
    move-result v11

    .line 784
    if-nez v11, :cond_37

    .line 785
    .line 786
    goto/16 :goto_5

    .line 787
    .line 788
    :cond_37
    const/4 v11, 0x5

    .line 789
    goto :goto_6

    .line 790
    :sswitch_2a
    const-string v12, "EXACT 25Q40 4MB 4K division repair"

    .line 791
    .line 792
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 793
    .line 794
    .line 795
    move-result v11

    .line 796
    if-nez v11, :cond_38

    .line 797
    .line 798
    goto/16 :goto_5

    .line 799
    .line 800
    :cond_38
    const/4 v11, 0x4

    .line 801
    goto :goto_6

    .line 802
    :sswitch_2b
    const-string v12, "EXACT ZB25VQ40 20260703 144805 4K division repair"

    .line 803
    .line 804
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 805
    .line 806
    .line 807
    move-result v11

    .line 808
    if-nez v11, :cond_39

    .line 809
    .line 810
    goto/16 :goto_5

    .line 811
    .line 812
    :cond_39
    move v11, v8

    .line 813
    goto :goto_6

    .line 814
    :sswitch_2c
    const-string v12, "EXACT ST425D02 4K division repair"

    .line 815
    .line 816
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 817
    .line 818
    .line 819
    move-result v11

    .line 820
    if-nez v11, :cond_3a

    .line 821
    .line 822
    goto/16 :goto_5

    .line 823
    .line 824
    :cond_3a
    move v11, v5

    .line 825
    goto :goto_6

    .line 826
    :sswitch_2d
    const-string v12, "EXACT HV550QUB E1E WDX 4K division repair"

    .line 827
    .line 828
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 829
    .line 830
    .line 831
    move-result v11

    .line 832
    if-nez v11, :cond_3b

    .line 833
    .line 834
    goto/16 :goto_5

    .line 835
    .line 836
    :cond_3b
    move v11, v6

    .line 837
    goto :goto_6

    .line 838
    :sswitch_2e
    const-string v12, "EXACT BOE 43 WDX F7D 4K division repair"

    .line 839
    .line 840
    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 841
    .line 842
    .line 843
    move-result v11

    .line 844
    if-nez v11, :cond_3c

    .line 845
    .line 846
    goto/16 :goto_5

    .line 847
    .line 848
    :cond_3c
    move v11, v3

    .line 849
    :goto_6
    packed-switch v11, :pswitch_data_0

    .line 850
    .line 851
    .line 852
    goto/16 :goto_4

    .line 853
    .line 854
    :pswitch_0
    const-string v11, "aa6b584f8facb04d665e262bf316995aca49ebf101010c779b261d4598a61cf5"

    .line 855
    .line 856
    :goto_7
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 857
    .line 858
    .line 859
    move-result v11

    .line 860
    goto/16 :goto_8

    .line 861
    .line 862
    :pswitch_1
    const-string v11, "b195e4796f55883ef3ee94ff777a0aeafd7f46e5f3f4576c86495a50fd2f7eb1"

    .line 863
    .line 864
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 865
    .line 866
    .line 867
    move-result v11

    .line 868
    if-nez v11, :cond_3d

    .line 869
    .line 870
    const-string v11, "799e0ca1ad760208c627ca3bea62b87c2c9e12c50ef1cd4a0ca9232d39257e25"

    .line 871
    .line 872
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 873
    .line 874
    .line 875
    move-result v11

    .line 876
    if-eqz v11, :cond_c

    .line 877
    .line 878
    goto/16 :goto_9

    .line 879
    .line 880
    :pswitch_2
    const-string v11, "f880c0c3989dd4b01b37662c9619b050a82b2d16d7038ecd8dcb346c7c8ba92b"

    .line 881
    .line 882
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 883
    .line 884
    .line 885
    move-result v11

    .line 886
    if-nez v11, :cond_3d

    .line 887
    .line 888
    const-string v11, "b93436ff25dd4f6ebcbc561c9fafdf8b0b87b9ced6748b904e15de7c214898f8"

    .line 889
    .line 890
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 891
    .line 892
    .line 893
    move-result v11

    .line 894
    if-eqz v11, :cond_c

    .line 895
    .line 896
    goto/16 :goto_9

    .line 897
    .line 898
    :pswitch_3
    const-string v11, "b6a610430d26e479f46b2f02c2973077363ecb819176e70cd31c468db38b6e11"

    .line 899
    .line 900
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 901
    .line 902
    .line 903
    move-result v11

    .line 904
    if-nez v11, :cond_3d

    .line 905
    .line 906
    const-string v11, "fd0324beb078193ccc5723b89e261cea4b6e1534d3455cc03b468579db43a15d"

    .line 907
    .line 908
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 909
    .line 910
    .line 911
    move-result v11

    .line 912
    if-eqz v11, :cond_c

    .line 913
    .line 914
    goto/16 :goto_9

    .line 915
    .line 916
    :pswitch_4
    const-string v11, "408a48b647d0b89c7657a8e47781cba873902b6705f25723d61997b28cbe9764"

    .line 917
    .line 918
    goto :goto_7

    .line 919
    :pswitch_5
    const-string v11, "5b69c27522d29c82f99802ccc4c1eb8ac70f824a50543279f417d27185b3d6be"

    .line 920
    .line 921
    goto :goto_7

    .line 922
    :pswitch_6
    const-string v11, "d7d9be4b7257d17ef1fbe9bb747b3839112fd2f4e28bc2c08e3a906884383287"

    .line 923
    .line 924
    goto :goto_7

    .line 925
    :pswitch_7
    const-string v11, "eaef7923e1d976636f90b027dc33791fd9d22d84b1f45241cc18feacc8904f7f"

    .line 926
    .line 927
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 928
    .line 929
    .line 930
    move-result v11

    .line 931
    if-nez v11, :cond_3d

    .line 932
    .line 933
    const-string v11, "c10570df60515249aaf263634c6fddbb997be32144f062956cedbe9577c1b93d"

    .line 934
    .line 935
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 936
    .line 937
    .line 938
    move-result v11

    .line 939
    if-eqz v11, :cond_c

    .line 940
    .line 941
    goto/16 :goto_9

    .line 942
    .line 943
    :pswitch_8
    const-string v11, "9aa516428d69a647de66d222f091547390c928c765b1db137548f5576d563628"

    .line 944
    .line 945
    goto :goto_7

    .line 946
    :pswitch_9
    const-string v11, "cc22d4234a87fefb679295aeac2bf72b941bb92e39cc6de235d3585b09d28613"

    .line 947
    .line 948
    goto :goto_7

    .line 949
    :pswitch_a
    const-string v11, "8624e668aa5d65fa579e14c4077bffaf38ef5772181a52f55cf03cc1ef0f15ac"

    .line 950
    .line 951
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 952
    .line 953
    .line 954
    move-result v11

    .line 955
    if-nez v11, :cond_3d

    .line 956
    .line 957
    const-string v11, "06c3bd1fa8647520d68c80094cd54e5641ddd47bb2840c2cced7d1a21e87de40"

    .line 958
    .line 959
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 960
    .line 961
    .line 962
    move-result v11

    .line 963
    if-eqz v11, :cond_c

    .line 964
    .line 965
    goto/16 :goto_9

    .line 966
    .line 967
    :pswitch_b
    const-string v11, "cd4a5753f8ababec90b0692899be3ebb0de5c0462ce0bd70f5f4644a3574d446"

    .line 968
    .line 969
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 970
    .line 971
    .line 972
    move-result v11

    .line 973
    if-nez v11, :cond_3d

    .line 974
    .line 975
    const-string v11, "a333ddbe7e7c603c23df63efd998416c33b25eb89828d70d135c7794c433ff72"

    .line 976
    .line 977
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 978
    .line 979
    .line 980
    move-result v11

    .line 981
    if-eqz v11, :cond_c

    .line 982
    .line 983
    goto/16 :goto_9

    .line 984
    .line 985
    :pswitch_c
    const-string v11, "eeff9ba1e4e12df5e2985de81dd35638e17f6c598727ada3027ffd9050668bdf"

    .line 986
    .line 987
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 988
    .line 989
    .line 990
    move-result v11

    .line 991
    if-nez v11, :cond_3d

    .line 992
    .line 993
    const-string v11, "e4b50a460c210cf80f4f1e12e1b3e2faf6f56d5e256d662d4a734e1d848533fc"

    .line 994
    .line 995
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 996
    .line 997
    .line 998
    move-result v11

    .line 999
    if-eqz v11, :cond_c

    .line 1000
    .line 1001
    goto/16 :goto_9

    .line 1002
    .line 1003
    :pswitch_d
    const-string v11, "8a4944766299cbd3f99568423c8b9686efae2554412d143dc720bed0520bf8d7"

    .line 1004
    .line 1005
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1006
    .line 1007
    .line 1008
    move-result v11

    .line 1009
    if-nez v11, :cond_3d

    .line 1010
    .line 1011
    const-string v11, "ed49742d025b3825f95cd46ff81dc38c044a3187cc8f60dd6a40dcf8af4b97b1"

    .line 1012
    .line 1013
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1014
    .line 1015
    .line 1016
    move-result v11

    .line 1017
    if-eqz v11, :cond_c

    .line 1018
    .line 1019
    goto/16 :goto_9

    .line 1020
    .line 1021
    :pswitch_e
    const-string v11, "e8fa90a0b305b0126594a7fedf8ab624894960d24caa0842800757fda42765db"

    .line 1022
    .line 1023
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1024
    .line 1025
    .line 1026
    move-result v11

    .line 1027
    if-nez v11, :cond_3d

    .line 1028
    .line 1029
    const-string v11, "1b6751db3228783eb4ee2e5bc948a2e4689930b3553bf6b288eb656c53af9696"

    .line 1030
    .line 1031
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1032
    .line 1033
    .line 1034
    move-result v11

    .line 1035
    if-eqz v11, :cond_c

    .line 1036
    .line 1037
    goto/16 :goto_9

    .line 1038
    .line 1039
    :pswitch_f
    const-string v11, "661d157091f7688b349bd73ddd8abbad4bdb3b0460d71cf755df0910d6865ff6"

    .line 1040
    .line 1041
    goto/16 :goto_7

    .line 1042
    .line 1043
    :pswitch_10
    const-string v11, "1403afb3da54f0d60ed824c95ea5fdd039da69e9f907726b8bfbe56f3a18eede"

    .line 1044
    .line 1045
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1046
    .line 1047
    .line 1048
    move-result v11

    .line 1049
    if-nez v11, :cond_3d

    .line 1050
    .line 1051
    const-string v11, "fd21afec3b330e6d521de9ad829ab6b616f55be331b6f56e299892480e3d5206"

    .line 1052
    .line 1053
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1054
    .line 1055
    .line 1056
    move-result v11

    .line 1057
    if-eqz v11, :cond_c

    .line 1058
    .line 1059
    goto/16 :goto_9

    .line 1060
    .line 1061
    :pswitch_11
    const-string v11, "d78d599cca8d84caefb4216b0e83c96c9c57aa2afc35258a415baeba6f288f92"

    .line 1062
    .line 1063
    goto/16 :goto_7

    .line 1064
    .line 1065
    :pswitch_12
    const-string v11, "5eaa16fded7b4e4f3422fbb4b4843c41db86e5a04760dd0ea4ec8fb06c4f6790"

    .line 1066
    .line 1067
    goto/16 :goto_7

    .line 1068
    .line 1069
    :pswitch_13
    const-string v11, "e07a8e5fb96efa005e4a885939378949d0e87f63065f430f9448166c66faf6fb"

    .line 1070
    .line 1071
    goto/16 :goto_7

    .line 1072
    .line 1073
    :pswitch_14
    const-string v11, "69780b4d6d8bf1f3eaedeebe20e990243beb30e72980c4dea7f6f9dd3cf6e0d0"

    .line 1074
    .line 1075
    goto/16 :goto_7

    .line 1076
    .line 1077
    :pswitch_15
    const-string v11, "4a05b81da72e0d38d6ad85542eef9f57d8117dbdd4405900fa828322822e6e93"

    .line 1078
    .line 1079
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1080
    .line 1081
    .line 1082
    move-result v11

    .line 1083
    if-nez v11, :cond_3d

    .line 1084
    .line 1085
    const-string v11, "4c61bf2f4c58292657b138a7a02e62ef96bc007f4859ea226aaed8b2785e0a83"

    .line 1086
    .line 1087
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1088
    .line 1089
    .line 1090
    move-result v11

    .line 1091
    if-eqz v11, :cond_c

    .line 1092
    .line 1093
    goto/16 :goto_9

    .line 1094
    .line 1095
    :pswitch_16
    const-string v11, "2455bdb7fca51e9308cdd833719f724950438140cc268f13d4bbb9d19950c3f0"

    .line 1096
    .line 1097
    goto/16 :goto_7

    .line 1098
    .line 1099
    :pswitch_17
    const-string v11, "90214734922181f5b55faa7cd46b004cf8437f9fe502da3581635d4f41c9409c"

    .line 1100
    .line 1101
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1102
    .line 1103
    .line 1104
    move-result v11

    .line 1105
    if-nez v11, :cond_3d

    .line 1106
    .line 1107
    const-string v11, "834b45f53daddb9300b5612ce312f420fb7e76ce1d47b484d620e56615c4f851"

    .line 1108
    .line 1109
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1110
    .line 1111
    .line 1112
    move-result v11

    .line 1113
    if-eqz v11, :cond_c

    .line 1114
    .line 1115
    goto/16 :goto_9

    .line 1116
    .line 1117
    :pswitch_18
    const-string v11, "c7456892532dd0f8b0f2117a33980cde29730814826a2ed1809d7483fcea2b8b"

    .line 1118
    .line 1119
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1120
    .line 1121
    .line 1122
    move-result v11

    .line 1123
    if-nez v11, :cond_3d

    .line 1124
    .line 1125
    const-string v11, "c6d064a20412c84c2ccfee194a7f30dfba12890434396bb3803b1ebf73456120"

    .line 1126
    .line 1127
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1128
    .line 1129
    .line 1130
    move-result v11

    .line 1131
    if-eqz v11, :cond_c

    .line 1132
    .line 1133
    goto/16 :goto_9

    .line 1134
    .line 1135
    :pswitch_19
    const-string v11, "96d323cb6cb4dad888d0ef26ecb924f5f6483a10dd32aea2b3807e1c36848892"

    .line 1136
    .line 1137
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1138
    .line 1139
    .line 1140
    move-result v11

    .line 1141
    if-nez v11, :cond_3d

    .line 1142
    .line 1143
    const-string v11, "8f57078f0b9c9e5c022e0e5da93e92dd23e9f9ca000bcfa9744ac61db46607e8"

    .line 1144
    .line 1145
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1146
    .line 1147
    .line 1148
    move-result v11

    .line 1149
    if-eqz v11, :cond_c

    .line 1150
    .line 1151
    goto/16 :goto_9

    .line 1152
    .line 1153
    :pswitch_1a
    const-string v11, "81c610e17d9089b8c28c007d63cb8398d954dfab52debd086c2401795910ca54"

    .line 1154
    .line 1155
    goto/16 :goto_7

    .line 1156
    .line 1157
    :pswitch_1b
    const-string v11, "d34f02ac11387f50595825cb8850fd63befca39e9092ac5ce7cdb9f8706c6fd6"

    .line 1158
    .line 1159
    goto/16 :goto_7

    .line 1160
    .line 1161
    :pswitch_1c
    const-string v11, "4c482da6f5020b5f4c5ebf4c97d2138d35e112962380beff7896e93642371629"

    .line 1162
    .line 1163
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1164
    .line 1165
    .line 1166
    move-result v11

    .line 1167
    if-nez v11, :cond_3d

    .line 1168
    .line 1169
    const-string v11, "4a05d2dcc5f254ebbd557beba94d45d4c9c41184b0d01b6b7fa1185cbde82954"

    .line 1170
    .line 1171
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1172
    .line 1173
    .line 1174
    move-result v11

    .line 1175
    if-eqz v11, :cond_c

    .line 1176
    .line 1177
    goto/16 :goto_9

    .line 1178
    .line 1179
    :pswitch_1d
    const-string v11, "ffacef4ddabd36e4bc188d3abb5285197286a532550c82ebf2d9aebe48ae2f0c"

    .line 1180
    .line 1181
    goto/16 :goto_7

    .line 1182
    .line 1183
    :pswitch_1e
    const-string v11, "7a18cf2a5604042dd610f241f64bb5a0ece1a9d18f6852ccb67f774df9c873ba"

    .line 1184
    .line 1185
    goto/16 :goto_7

    .line 1186
    .line 1187
    :pswitch_1f
    const-string v11, "dc30e504dbc91d70080f6bb9100ca43a28c10865da1796d8c1dafc7755bb9075"

    .line 1188
    .line 1189
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1190
    .line 1191
    .line 1192
    move-result v11

    .line 1193
    if-nez v11, :cond_3d

    .line 1194
    .line 1195
    const-string v11, "813de90fd6e6bc3af31081c0e49921e7dcedda092dae6d558ad522b487d16ed8"

    .line 1196
    .line 1197
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1198
    .line 1199
    .line 1200
    move-result v11

    .line 1201
    if-eqz v11, :cond_c

    .line 1202
    .line 1203
    goto/16 :goto_9

    .line 1204
    .line 1205
    :pswitch_20
    const-string v11, "2430558cb3782bc21c6b9821fc9f5c3c3de90dd5a25324872c75c7922c0f922b"

    .line 1206
    .line 1207
    goto/16 :goto_7

    .line 1208
    .line 1209
    :pswitch_21
    const-string v11, "d9a8a142f942ffa7840d95b23973ad1c9a36162cfd845f31b2f5544bff9c4d9a"

    .line 1210
    .line 1211
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1212
    .line 1213
    .line 1214
    move-result v11

    .line 1215
    if-nez v11, :cond_3d

    .line 1216
    .line 1217
    const-string v11, "aecd0fd9a9fec37850193b518dc973bd28739272af9c1e959fbf07cde51999cc"

    .line 1218
    .line 1219
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1220
    .line 1221
    .line 1222
    move-result v11

    .line 1223
    if-eqz v11, :cond_c

    .line 1224
    .line 1225
    goto/16 :goto_9

    .line 1226
    .line 1227
    :pswitch_22
    const-string v11, "4ba69a8b6a32edb69d241bad1e3d8fc7dcef33928025e2565abeab2d31105e7e"

    .line 1228
    .line 1229
    goto/16 :goto_7

    .line 1230
    .line 1231
    :pswitch_23
    const-string v11, "c603ef27c0774ff74c1d82c1dfba8dd878b4f91268d4bd74f3e0565b1c13388d"

    .line 1232
    .line 1233
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1234
    .line 1235
    .line 1236
    move-result v11

    .line 1237
    if-nez v11, :cond_3d

    .line 1238
    .line 1239
    const-string v11, "a77122fbd40d4a5e6639bf205f730e1401fbe9aa8b7ac4f3e8a5d3cf0cb25f0e"

    .line 1240
    .line 1241
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1242
    .line 1243
    .line 1244
    move-result v11

    .line 1245
    if-eqz v11, :cond_c

    .line 1246
    .line 1247
    goto/16 :goto_9

    .line 1248
    .line 1249
    :pswitch_24
    const-string v11, "6c796affcf6db6de4be87b371a8014fbc8f40b8f436ef444cf3e1edefe4dd114"

    .line 1250
    .line 1251
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1252
    .line 1253
    .line 1254
    move-result v11

    .line 1255
    if-nez v11, :cond_3d

    .line 1256
    .line 1257
    const-string v11, "e49bcc69f8b57921ceca5a20c4e8191ba4d170e6dd504af7cd9f786a6f2f9fbf"

    .line 1258
    .line 1259
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1260
    .line 1261
    .line 1262
    move-result v11

    .line 1263
    if-eqz v11, :cond_c

    .line 1264
    .line 1265
    goto/16 :goto_9

    .line 1266
    .line 1267
    :pswitch_25
    const-string v11, "9afe52d8e2c24409857ced189e132cfc2c90b6fbadeaa10edfff09662e936c08"

    .line 1268
    .line 1269
    goto/16 :goto_7

    .line 1270
    .line 1271
    :pswitch_26
    const-string v11, "11b7ec4beed7596d3410f7f21c8b78126dc31a4e11e3c7539127a5c632ba66e5"

    .line 1272
    .line 1273
    goto/16 :goto_7

    .line 1274
    .line 1275
    :pswitch_27
    const-string v11, "74562a7c3dd32130218ebe0cd9aaf32e65dfa8fd0db099d7bb102e1d247a3c3e"

    .line 1276
    .line 1277
    goto/16 :goto_7

    .line 1278
    .line 1279
    :pswitch_28
    const-string v11, "2aeae874d1057083faf34dc8b74789f9dbd24ed3525a416316f312434327e888"

    .line 1280
    .line 1281
    goto/16 :goto_7

    .line 1282
    .line 1283
    :pswitch_29
    const-string v11, "82ae41db7794fe1acc778432d0cf003d8fbea0423c425b2195dbcc60215dd654"

    .line 1284
    .line 1285
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1286
    .line 1287
    .line 1288
    move-result v11

    .line 1289
    if-nez v11, :cond_3d

    .line 1290
    .line 1291
    const-string v11, "6bbbcabe1371e8aec6fdde8a7d1e6f2ec5ac0228de3b3cb9672ba97d95e7adaa"

    .line 1292
    .line 1293
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1294
    .line 1295
    .line 1296
    move-result v11

    .line 1297
    if-eqz v11, :cond_c

    .line 1298
    .line 1299
    goto :goto_9

    .line 1300
    :pswitch_2a
    const-string v11, "c78a71d90cc5569e710ecf78acef8c87e7049e92f864712bede099b9cdfafdc9"

    .line 1301
    .line 1302
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1303
    .line 1304
    .line 1305
    move-result v11

    .line 1306
    if-nez v11, :cond_3d

    .line 1307
    .line 1308
    const-string v11, "a95f9b2a73432b1dde7a5561c5c9b11f1ac39182e83a88b153d09e9246ff2fe5"

    .line 1309
    .line 1310
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1311
    .line 1312
    .line 1313
    move-result v11

    .line 1314
    if-eqz v11, :cond_c

    .line 1315
    .line 1316
    goto :goto_9

    .line 1317
    :pswitch_2b
    const-string v11, "0dc4d002b461c8a9a683bbd3ddeccd8f132812c7fb81aedbfc1efa51eb199f20"

    .line 1318
    .line 1319
    goto/16 :goto_7

    .line 1320
    .line 1321
    :goto_8
    if-eqz v11, :cond_c

    .line 1322
    .line 1323
    goto :goto_9

    .line 1324
    :pswitch_2c
    const-string v11, "ae1bf2f2ec9ff0e1306f93abfeb6e34e9053a501652ce69a974881931cfeed70"

    .line 1325
    .line 1326
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1327
    .line 1328
    .line 1329
    move-result v11

    .line 1330
    if-nez v11, :cond_3d

    .line 1331
    .line 1332
    const-string v11, "704616c52acada42114f4737837706f298a1c3c7ce1361a1901b5ba2b49d3ce9"

    .line 1333
    .line 1334
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1335
    .line 1336
    .line 1337
    move-result v11

    .line 1338
    if-eqz v11, :cond_c

    .line 1339
    .line 1340
    goto :goto_9

    .line 1341
    :pswitch_2d
    const-string v11, "c921e3dba1938ff419a96058717c4d72193a0d7c313e868cd9750e34512cde54"

    .line 1342
    .line 1343
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1344
    .line 1345
    .line 1346
    move-result v11

    .line 1347
    if-nez v11, :cond_3d

    .line 1348
    .line 1349
    const-string v11, "4128fec4564e2e96f0b93d1070d21d217ca29cb48cc6a18e9eecc4708247bdd2"

    .line 1350
    .line 1351
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1352
    .line 1353
    .line 1354
    move-result v11

    .line 1355
    if-eqz v11, :cond_c

    .line 1356
    .line 1357
    goto :goto_9

    .line 1358
    :pswitch_2e
    const-string v11, "def7c00130297569987d9907388e3c67ed262f7257ee328ab93b52de3dfdd5d5"

    .line 1359
    .line 1360
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1361
    .line 1362
    .line 1363
    move-result v11

    .line 1364
    if-nez v11, :cond_3d

    .line 1365
    .line 1366
    const-string v11, "2e8d1a49d38929ddccbdafd82cefe6172f3424ada5d11bced996c38015d25a43"

    .line 1367
    .line 1368
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1369
    .line 1370
    .line 1371
    move-result v11

    .line 1372
    if-eqz v11, :cond_c

    .line 1373
    .line 1374
    :cond_3d
    :goto_9
    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1375
    .line 1376
    .line 1377
    goto/16 :goto_4

    .line 1378
    .line 1379
    :cond_3e
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1380
    .line 1381
    .line 1382
    move-result v1

    .line 1383
    if-nez v1, :cond_41

    .line 1384
    .line 1385
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 1386
    .line 1387
    .line 1388
    move-result v0

    .line 1389
    if-eq v0, v6, :cond_40

    .line 1390
    .line 1391
    invoke-static {v4}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->z(Ljava/util/ArrayList;)Z

    .line 1392
    .line 1393
    .line 1394
    move-result v0

    .line 1395
    if-eqz v0, :cond_3f

    .line 1396
    .line 1397
    goto :goto_a

    .line 1398
    :cond_3f
    const-string v0, "Known file fingerprint collision. Repair blocked for safety."

    .line 1399
    .line 1400
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 1401
    .line 1402
    .line 1403
    return-object v2

    .line 1404
    :cond_40
    :goto_a
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1405
    .line 1406
    .line 1407
    move-result-object v0

    .line 1408
    check-cast v0, Lg1/v;

    .line 1409
    .line 1410
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1411
    .line 1412
    const-string v2, "Known database file: "

    .line 1413
    .line 1414
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1415
    .line 1416
    .line 1417
    iget-object v2, v0, Lg1/v;->a:Lg1/w;

    .line 1418
    .line 1419
    iget-object v2, v2, Lg1/w;->a:Ljava/lang/String;

    .line 1420
    .line 1421
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1422
    .line 1423
    .line 1424
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1425
    .line 1426
    .line 1427
    move-result-object v1

    .line 1428
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 1429
    .line 1430
    .line 1431
    return-object v0

    .line 1432
    :cond_41
    new-instance v1, Ljava/util/ArrayList;

    .line 1433
    .line 1434
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 1435
    .line 1436
    .line 1437
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1438
    .line 1439
    .line 1440
    move-result-object v0

    .line 1441
    :cond_42
    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1442
    .line 1443
    .line 1444
    move-result v4

    .line 1445
    if-eqz v4, :cond_49

    .line 1446
    .line 1447
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1448
    .line 1449
    .line 1450
    move-result-object v4

    .line 1451
    check-cast v4, Lg1/v;

    .line 1452
    .line 1453
    iget-object v5, v4, Lg1/v;->a:Lg1/w;

    .line 1454
    .line 1455
    iget-object v9, v5, Lg1/w;->c:[I

    .line 1456
    .line 1457
    if-eqz v9, :cond_44

    .line 1458
    .line 1459
    array-length v10, v9

    .line 1460
    move v11, v3

    .line 1461
    move v12, v11

    .line 1462
    :goto_c
    if-ge v11, v10, :cond_45

    .line 1463
    .line 1464
    aget v13, v9, v11

    .line 1465
    .line 1466
    if-ltz v13, :cond_43

    .line 1467
    .line 1468
    add-int/lit8 v12, v12, 0x1

    .line 1469
    .line 1470
    :cond_43
    add-int/lit8 v11, v11, 0x1

    .line 1471
    .line 1472
    goto :goto_c

    .line 1473
    :cond_44
    move v12, v3

    .line 1474
    :cond_45
    iget v9, v5, Lg1/w;->f:I

    .line 1475
    .line 1476
    if-ltz v9, :cond_46

    .line 1477
    .line 1478
    add-int/lit16 v12, v12, 0x3e8

    .line 1479
    .line 1480
    :cond_46
    iget-object v5, v5, Lg1/w;->a:Ljava/lang/String;

    .line 1481
    .line 1482
    const-string v9, "EXACT "

    .line 1483
    .line 1484
    invoke-virtual {v5, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1485
    .line 1486
    .line 1487
    move-result v5

    .line 1488
    if-eqz v5, :cond_47

    .line 1489
    .line 1490
    add-int/lit16 v12, v12, 0x3e8

    .line 1491
    .line 1492
    :cond_47
    if-le v12, v7, :cond_48

    .line 1493
    .line 1494
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 1495
    .line 1496
    .line 1497
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1498
    .line 1499
    .line 1500
    move v7, v12

    .line 1501
    goto :goto_b

    .line 1502
    :cond_48
    if-ne v12, v7, :cond_42

    .line 1503
    .line 1504
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1505
    .line 1506
    .line 1507
    goto :goto_b

    .line 1508
    :cond_49
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 1509
    .line 1510
    .line 1511
    move-result v0

    .line 1512
    if-eq v0, v6, :cond_4c

    .line 1513
    .line 1514
    invoke-static {v1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->z(Ljava/util/ArrayList;)Z

    .line 1515
    .line 1516
    .line 1517
    move-result v0

    .line 1518
    if-eqz v0, :cond_4a

    .line 1519
    .line 1520
    goto :goto_e

    .line 1521
    :cond_4a
    const-string v0, "Multiple profile matches found. Repair blocked for safety."

    .line 1522
    .line 1523
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 1524
    .line 1525
    .line 1526
    :goto_d
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 1527
    .line 1528
    .line 1529
    move-result v0

    .line 1530
    if-ge v3, v0, :cond_4b

    .line 1531
    .line 1532
    if-ge v3, v8, :cond_4b

    .line 1533
    .line 1534
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1535
    .line 1536
    const-string v4, "Candidate: "

    .line 1537
    .line 1538
    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1539
    .line 1540
    .line 1541
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1542
    .line 1543
    .line 1544
    move-result-object v4

    .line 1545
    check-cast v4, Lg1/v;

    .line 1546
    .line 1547
    iget-object v4, v4, Lg1/v;->a:Lg1/w;

    .line 1548
    .line 1549
    iget-object v4, v4, Lg1/w;->a:Ljava/lang/String;

    .line 1550
    .line 1551
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1552
    .line 1553
    .line 1554
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1555
    .line 1556
    .line 1557
    move-result-object v0

    .line 1558
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 1559
    .line 1560
    .line 1561
    add-int/lit8 v3, v3, 0x1

    .line 1562
    .line 1563
    goto :goto_d

    .line 1564
    :cond_4b
    return-object v2

    .line 1565
    :cond_4c
    :goto_e
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1566
    .line 1567
    .line 1568
    move-result-object v0

    .line 1569
    check-cast v0, Lg1/v;

    .line 1570
    .line 1571
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1572
    .line 1573
    const-string v3, "Best profile: "

    .line 1574
    .line 1575
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1576
    .line 1577
    .line 1578
    iget-object v3, v0, Lg1/v;->a:Lg1/w;

    .line 1579
    .line 1580
    iget-object v3, v3, Lg1/w;->a:Ljava/lang/String;

    .line 1581
    .line 1582
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1583
    .line 1584
    .line 1585
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1586
    .line 1587
    .line 1588
    move-result-object v2

    .line 1589
    invoke-virtual {p0, v2}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 1590
    .line 1591
    .line 1592
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 1593
    .line 1594
    .line 1595
    move-result v1

    .line 1596
    if-le v1, v6, :cond_4d

    .line 1597
    .line 1598
    const-string v1, "Equivalent profile matches share the same repair data."

    .line 1599
    .line 1600
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 1601
    .line 1602
    .line 1603
    :cond_4d
    return-object v0

    .line 1604
    nop

    :sswitch_data_0
    .sparse-switch
        -0x7c30c44f -> :sswitch_2e
        -0x7835ff0a -> :sswitch_2d
        -0x779daada -> :sswitch_2c
        -0x770bb0cc -> :sswitch_2b
        -0x6faa9b5b -> :sswitch_2a
        -0x6f50a1b2 -> :sswitch_29
        -0x6d4962f3 -> :sswitch_28
        -0x6625203d -> :sswitch_27
        -0x661a5afe -> :sswitch_26
        -0x633e0035 -> :sswitch_25
        -0x5d7ab28c -> :sswitch_24
        -0x5d32f153 -> :sswitch_23
        -0x5bc7e9ca -> :sswitch_22
        -0x593a036e -> :sswitch_21
        -0x552f7dee -> :sswitch_20
        -0x52f48fa6 -> :sswitch_1f
        -0x52456166 -> :sswitch_1e
        -0x5032ef95 -> :sswitch_1d
        -0x4268ca13 -> :sswitch_1c
        -0x2d1a5ccc -> :sswitch_1b
        -0x2ad115d0 -> :sswitch_1a
        -0x28f65610 -> :sswitch_19
        -0x25d603e3 -> :sswitch_18
        -0x1fbd8d94 -> :sswitch_17
        -0x1fa2f831 -> :sswitch_16
        -0x1564a130 -> :sswitch_15
        -0x14cc27f1 -> :sswitch_14
        -0x100f1956 -> :sswitch_13
        -0x667b5ee -> :sswitch_12
        0x10ae8eb8 -> :sswitch_11
        0x1d44b1bb -> :sswitch_10
        0x215f7017 -> :sswitch_f
        0x22535ab5 -> :sswitch_e
        0x33a407e9 -> :sswitch_d
        0x3be89d49 -> :sswitch_c
        0x444f9523 -> :sswitch_b
        0x456c7339 -> :sswitch_a
        0x56a70467 -> :sswitch_9
        0x58dbf4fa -> :sswitch_8
        0x62213787 -> :sswitch_7
        0x66aa8588 -> :sswitch_6
        0x6d355229 -> :sswitch_5
        0x6e91aae0 -> :sswitch_4
        0x7534267c -> :sswitch_3
        0x79d4913a -> :sswitch_2
        0x79ed2bcc -> :sswitch_1
        0x7c347704 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2e
        :pswitch_2d
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final u()Lg1/v;
    .locals 11

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    array-length v2, v0

    if-nez v2, :cond_0

    goto :goto_3

    :cond_0
    invoke-static {v0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->B([B)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->O:[Lg1/w;

    array-length v3, v2

    const/4 v4, 0x0

    move v5, v4

    :goto_0
    if-ge v5, v3, :cond_6

    aget-object v6, v2, v5

    invoke-virtual {v6}, Lg1/w;->a()Z

    move-result v7

    if-eqz v7, :cond_5

    iget-object v7, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    array-length v7, v7

    iget v8, v6, Lg1/w;->b:I

    if-eq v8, v7, :cond_1

    goto :goto_2

    :cond_1
    iget-object v7, v6, Lg1/w;->i:Ljava/lang/String;

    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-boolean v10, v6, Lg1/w;->k:Z

    if-eqz v7, :cond_3

    new-instance v0, Lg1/v;

    if-eqz v10, :cond_2

    goto :goto_1

    :cond_2
    move v8, v9

    :goto_1
    invoke-direct {v0, v6, v4, v4, v8}, Lg1/v;-><init>(Lg1/w;IZI)V

    return-object v0

    :cond_3
    iget-object v7, v6, Lg1/w;->j:Ljava/lang/String;

    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_5

    new-instance v0, Lg1/v;

    if-eqz v10, :cond_4

    move v8, v9

    :cond_4
    invoke-direct {v0, v6, v4, v4, v8}, Lg1/v;-><init>(Lg1/w;IZI)V

    return-object v0

    :cond_5
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_6
    :goto_3
    return-object v1
.end method

.method public final w(Lg1/w;[IZ)Lg1/v;
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    iget v1, p1, Lg1/w;->f:I

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x0

    .line 6
    if-ltz v1, :cond_3

    .line 7
    .line 8
    iget-object v4, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 9
    .line 10
    array-length v4, v4

    .line 11
    array-length v5, p2

    .line 12
    sub-int/2addr v4, v5

    .line 13
    if-le v1, v4, :cond_0

    .line 14
    .line 15
    return-object v3

    .line 16
    :cond_0
    :goto_0
    array-length v4, p2

    .line 17
    if-ge v2, v4, :cond_2

    .line 18
    .line 19
    aget v4, p2, v2

    .line 20
    .line 21
    if-ltz v4, :cond_1

    .line 22
    .line 23
    iget-object v5, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 24
    .line 25
    add-int v6, v1, v2

    .line 26
    .line 27
    aget-byte v5, v5, v6

    .line 28
    .line 29
    and-int/lit16 v5, v5, 0xff

    .line 30
    .line 31
    if-eq v5, v4, :cond_1

    .line 32
    .line 33
    return-object v3

    .line 34
    :cond_1
    add-int/lit8 v2, v2, 0x1

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_2
    new-instance p2, Lg1/v;

    .line 38
    .line 39
    invoke-direct {p2, p1, v1, p3, v0}, Lg1/v;-><init>(Lg1/w;IZI)V

    .line 40
    .line 41
    .line 42
    return-object p2

    .line 43
    :cond_3
    iget-object v1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 44
    .line 45
    invoke-static {v2, v1, p2}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->v(I[B[I)I

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-gez v1, :cond_4

    .line 50
    .line 51
    return-object v3

    .line 52
    :cond_4
    iget-object v2, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->M:[B

    .line 53
    .line 54
    add-int/lit8 v4, v1, 0x1

    .line 55
    .line 56
    invoke-static {v4, v2, p2}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->v(I[B[I)I

    .line 57
    .line 58
    .line 59
    move-result p2

    .line 60
    if-ltz p2, :cond_5

    .line 61
    .line 62
    const-string p1, "Panel data check stopped for safety."

    .line 63
    .line 64
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    return-object v3

    .line 68
    :cond_5
    new-instance p2, Lg1/v;

    .line 69
    .line 70
    invoke-direct {p2, p1, v1, p3, v0}, Lg1/v;-><init>(Lg1/w;IZI)V

    .line 71
    .line 72
    .line 73
    return-object p2
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public final x(Landroid/hardware/usb/UsbDevice;)V
    .locals 2

    .line 1
    :try_start_0
    iput-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->K:Landroid/hardware/usb/UsbDevice;

    iget-object v0, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->I:Lg1/n;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->H:Landroid/hardware/usb/UsbManager;

    invoke-virtual {v0, v1, p1}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->J:Z

    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->B:Landroid/widget/TextView;

    const-string v0, "4K DIVISION: Connected"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->G:Landroid/widget/Button;

    const-string v0, "DISCONNECT"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string p1, "CH341A connected for 25-series SPI."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Connect failed: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->s()V

    :goto_0
    return-void
.end method

.method public final y(I)[I
    .locals 4

    .line 1
    const/4 v0, 0x0

    if-gtz p1, :cond_0

    const-string p1, "SPI chip size not recognized. Repair blocked for safety."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    new-array p1, v0, [I

    return-object p1

    :cond_0
    sget-object v1, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->R:[I

    move v2, v0

    :goto_0
    const/4 v3, 0x5

    if-ge v2, v3, :cond_2

    aget v3, v1, v2

    if-ne v3, p1, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Detected "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->C(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    filled-new-array {p1}, [I

    move-result-object p1

    return-object p1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    const-string p1, "Unsupported SPI chip size. Repair blocked for safety."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/DivisionRepairActivity;->p(Ljava/lang/String;)V

    new-array p1, v0, [I

    return-object p1
.end method
