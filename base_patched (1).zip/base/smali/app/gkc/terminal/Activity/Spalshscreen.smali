.class public Lapp/gkc/terminal/Activity/Spalshscreen;
.super Le/m;
.source "SourceFile"


# static fields
.field public static final synthetic E:I


# instance fields
.field public final B:Landroid/os/Handler;

.field public C:Z

.field public final D:Le/o0;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Le/m;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->B:Landroid/os/Handler;

    new-instance v0, Le/o0;

    const/16 v1, 0xc

    invoke-direct {v0, v1, p0}, Le/o0;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->D:Le/o0;

    return-void
.end method


# virtual methods
.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0036

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const p1, 0x7f090303

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    const v0, 0x7f090304

    invoke-virtual {p0, v0}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/VideoView;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "android.resource://"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "/2131820544"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setVideoURI(Landroid/net/Uri;)V

    new-instance v1, Lg1/p3;

    invoke-direct {v1, v0}, Lg1/p3;-><init>(Landroid/widget/VideoView;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    new-instance v1, Lg1/q3;

    invoke-direct {v1, p0}, Lg1/q3;-><init>(Lapp/gkc/terminal/Activity/Spalshscreen;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    new-instance v1, Lg1/r3;

    invoke-direct {v1, p0, p1}, Lg1/r3;-><init>(Lapp/gkc/terminal/Activity/Spalshscreen;Landroid/widget/ImageView;)V

    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->B:Landroid/os/Handler;

    iget-object v0, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->D:Le/o0;

    const-wide/16 v1, 0x1068

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final onDestroy()V
    .locals 2

    iget-object v0, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->B:Landroid/os/Handler;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->D:Le/o0;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-super {p0}, Le/m;->onDestroy()V

    return-void
.end method

.method public final p()V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->C:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->C:Z

    iget-object v0, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->B:Landroid/os/Handler;

    iget-object v1, p0, Lapp/gkc/terminal/Activity/Spalshscreen;->D:Le/o0;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lapp/gkc/terminal/Activity/ProToolsActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method
