.class public Lapp/gkc/terminal/Activity/MiNetflixFixActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final M:[Ljava/lang/String;


# instance fields
.field public B:Landroid/net/Uri;

.field public C:Landroid/net/Uri;

.field public D:Landroid/net/Uri;

.field public E:Landroid/widget/TextView;

.field public F:Landroid/widget/TextView;

.field public G:Landroid/widget/TextView;

.field public H:Landroid/widget/TextView;

.field public I:Ljava/util/List;

.field public final J:Lb/h;

.field public final K:Lb/h;

.field public final L:Lb/h;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const-string v0, "misc"

    const-string v1, "param"

    const-string v2, "factory"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->M:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    invoke-direct {p0}, Le/m;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->I:Ljava/util/List;

    new-instance v0, Lc/c;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lc/c;-><init>(I)V

    new-instance v2, Lg1/f2;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v3}, Lg1/f2;-><init>(Lapp/gkc/terminal/Activity/MiNetflixFixActivity;I)V

    invoke-virtual {p0, v2, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->J:Lb/h;

    new-instance v0, Lc/c;

    invoke-direct {v0, v1}, Lc/c;-><init>(I)V

    new-instance v2, Lg1/f2;

    invoke-direct {v2, p0, v1}, Lg1/f2;-><init>(Lapp/gkc/terminal/Activity/MiNetflixFixActivity;I)V

    invoke-virtual {p0, v2, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->K:Lb/h;

    new-instance v0, Lc/b;

    invoke-direct {v0}, Lc/b;-><init>()V

    new-instance v1, Lg1/f2;

    const/4 v2, 0x2

    invoke-direct {v1, p0, v2}, Lg1/f2;-><init>(Lapp/gkc/terminal/Activity/MiNetflixFixActivity;I)V

    invoke-virtual {p0, v1, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    move-result-object v0

    iput-object v0, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->L:Lb/h;

    return-void
.end method

.method public static A(Ljava/nio/channels/FileChannel;J)Ljava/util/ArrayList;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-wide/16 v1, 0x400

    .line 4
    .line 5
    cmp-long v1, p1, v1

    .line 6
    .line 7
    if-gez v1, :cond_0

    .line 8
    .line 9
    new-instance v0, Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 12
    .line 13
    .line 14
    return-object v0

    .line 15
    :cond_0
    const-wide/16 v1, 0x200

    .line 16
    .line 17
    const/16 v3, 0x200

    .line 18
    .line 19
    invoke-static {v0, v1, v2, v3}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->B(Ljava/nio/channels/FileChannel;JI)[B

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    const/16 v4, 0x8

    .line 24
    .line 25
    new-array v4, v4, [I

    .line 26
    .line 27
    fill-array-data v4, :array_0

    .line 28
    .line 29
    .line 30
    const/4 v5, 0x0

    .line 31
    invoke-static {v5, v3, v4}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->w(I[B[I)Z

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    if-nez v4, :cond_1

    .line 36
    .line 37
    new-instance v0, Ljava/util/ArrayList;

    .line 38
    .line 39
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 40
    .line 41
    .line 42
    return-object v0

    .line 43
    :cond_1
    const/16 v4, 0x48

    .line 44
    .line 45
    invoke-static {v3, v4}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->u([BI)J

    .line 46
    .line 47
    .line 48
    move-result-wide v6

    .line 49
    const/16 v8, 0x50

    .line 50
    .line 51
    invoke-static {v3, v8}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->C([BI)J

    .line 52
    .line 53
    .line 54
    move-result-wide v8

    .line 55
    const/16 v10, 0x54

    .line 56
    .line 57
    invoke-static {v3, v10}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->C([BI)J

    .line 58
    .line 59
    .line 60
    move-result-wide v10

    .line 61
    mul-long v12, v8, v10

    .line 62
    .line 63
    const-wide/16 v14, 0x0

    .line 64
    .line 65
    cmp-long v3, v8, v14

    .line 66
    .line 67
    if-lez v3, :cond_a

    .line 68
    .line 69
    const-wide/16 v16, 0x1000

    .line 70
    .line 71
    cmp-long v3, v8, v16

    .line 72
    .line 73
    if-gtz v3, :cond_a

    .line 74
    .line 75
    const-wide/16 v16, 0x80

    .line 76
    .line 77
    cmp-long v3, v10, v16

    .line 78
    .line 79
    if-ltz v3, :cond_a

    .line 80
    .line 81
    const-wide/32 v16, 0x400000

    .line 82
    .line 83
    .line 84
    cmp-long v3, v12, v16

    .line 85
    .line 86
    if-gtz v3, :cond_a

    .line 87
    .line 88
    mul-long/2addr v6, v1

    .line 89
    add-long v16, v6, v12

    .line 90
    .line 91
    cmp-long v3, v16, p1

    .line 92
    .line 93
    if-lez v3, :cond_2

    .line 94
    .line 95
    goto/16 :goto_4

    .line 96
    .line 97
    :cond_2
    long-to-int v3, v12

    .line 98
    invoke-static {v0, v6, v7, v3}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->B(Ljava/nio/channels/FileChannel;JI)[B

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    new-instance v3, Ljava/util/ArrayList;

    .line 103
    .line 104
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 105
    .line 106
    .line 107
    move v6, v5

    .line 108
    :goto_0
    int-to-long v12, v6

    .line 109
    cmp-long v7, v12, v8

    .line 110
    .line 111
    if-gez v7, :cond_9

    .line 112
    .line 113
    mul-long/2addr v12, v10

    .line 114
    long-to-int v7, v12

    .line 115
    move v12, v5

    .line 116
    :goto_1
    const/16 v13, 0x10

    .line 117
    .line 118
    if-ge v12, v13, :cond_8

    .line 119
    .line 120
    add-int v13, v7, v12

    .line 121
    .line 122
    aget-byte v13, v0, v13

    .line 123
    .line 124
    if-eqz v13, :cond_7

    .line 125
    .line 126
    add-int/lit8 v12, v7, 0x38

    .line 127
    .line 128
    long-to-int v13, v10

    .line 129
    add-int/lit8 v13, v13, -0x38

    .line 130
    .line 131
    invoke-static {v4, v13}, Ljava/lang/Math;->min(II)I

    .line 132
    .line 133
    .line 134
    move-result v13

    .line 135
    add-int/2addr v13, v12

    .line 136
    move/from16 v16, v12

    .line 137
    .line 138
    :goto_2
    add-int/lit8 v4, v16, 0x1

    .line 139
    .line 140
    if-ge v4, v13, :cond_4

    .line 141
    .line 142
    aget-byte v18, v0, v16

    .line 143
    .line 144
    if-nez v18, :cond_3

    .line 145
    .line 146
    aget-byte v4, v0, v4

    .line 147
    .line 148
    if-eqz v4, :cond_4

    .line 149
    .line 150
    :cond_3
    add-int/lit8 v16, v16, 0x2

    .line 151
    .line 152
    const/16 v4, 0x48

    .line 153
    .line 154
    goto :goto_2

    .line 155
    :cond_4
    new-instance v4, Ljava/lang/String;

    .line 156
    .line 157
    sub-int v13, v16, v12

    .line 158
    .line 159
    const-string v5, "UTF-16LE"

    .line 160
    .line 161
    invoke-direct {v4, v0, v12, v13, v5}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v19

    .line 168
    invoke-virtual/range {v19 .. v19}, Ljava/lang/String;->isEmpty()Z

    .line 169
    .line 170
    .line 171
    move-result v4

    .line 172
    if-eqz v4, :cond_5

    .line 173
    .line 174
    goto :goto_3

    .line 175
    :cond_5
    add-int/lit8 v4, v7, 0x20

    .line 176
    .line 177
    invoke-static {v0, v4}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->u([BI)J

    .line 178
    .line 179
    .line 180
    move-result-wide v4

    .line 181
    add-int/lit8 v7, v7, 0x28

    .line 182
    .line 183
    invoke-static {v0, v7}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->u([BI)J

    .line 184
    .line 185
    .line 186
    move-result-wide v12

    .line 187
    cmp-long v7, v4, v14

    .line 188
    .line 189
    if-lez v7, :cond_8

    .line 190
    .line 191
    cmp-long v7, v12, v4

    .line 192
    .line 193
    if-gez v7, :cond_6

    .line 194
    .line 195
    goto :goto_3

    .line 196
    :cond_6
    new-instance v7, Lg1/h2;

    .line 197
    .line 198
    mul-long v24, v4, v1

    .line 199
    .line 200
    sub-long/2addr v12, v4

    .line 201
    const-wide/16 v4, 0x1

    .line 202
    .line 203
    add-long/2addr v12, v4

    .line 204
    mul-long/2addr v12, v1

    .line 205
    move-object/from16 v18, v7

    .line 206
    .line 207
    move-wide/from16 v20, v24

    .line 208
    .line 209
    move-wide/from16 v22, v12

    .line 210
    .line 211
    invoke-direct/range {v18 .. v23}, Lg1/h2;-><init>(Ljava/lang/String;JJ)V

    .line 212
    .line 213
    .line 214
    add-long v24, v24, v12

    .line 215
    .line 216
    cmp-long v4, v24, p1

    .line 217
    .line 218
    if-gtz v4, :cond_8

    .line 219
    .line 220
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 221
    .line 222
    .line 223
    goto :goto_3

    .line 224
    :cond_7
    add-int/lit8 v12, v12, 0x1

    .line 225
    .line 226
    const/16 v4, 0x48

    .line 227
    .line 228
    const/4 v5, 0x0

    .line 229
    goto :goto_1

    .line 230
    :cond_8
    :goto_3
    add-int/lit8 v6, v6, 0x1

    .line 231
    .line 232
    const/16 v4, 0x48

    .line 233
    .line 234
    const/4 v5, 0x0

    .line 235
    goto :goto_0

    .line 236
    :cond_9
    return-object v3

    .line 237
    :cond_a
    :goto_4
    new-instance v0, Ljava/util/ArrayList;

    .line 238
    .line 239
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 240
    .line 241
    .line 242
    return-object v0

    .line 243
    :array_0
    .array-data 4
        0x45
        0x46
        0x49
        0x20
        0x50
        0x41
        0x52
        0x54
    .end array-data
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public static B(Ljava/nio/channels/FileChannel;JI)[B
    .locals 0

    .line 1
    invoke-static {p3}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object p3

    invoke-virtual {p0, p1, p2}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    :goto_0
    invoke-virtual {p3}, Ljava/nio/Buffer;->hasRemaining()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p0, p3}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result p1

    if-ltz p1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p3}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object p0

    return-object p0
.end method

.method public static C([BI)J
    .locals 2

    .line 1
    const/4 v0, 0x4

    invoke-static {p0, p1, v0}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object p0

    sget-object p1, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->getInt()I

    move-result p0

    int-to-long p0, p0

    const-wide v0, 0xffffffffL

    and-long/2addr p0, v0

    return-wide p0
.end method

.method public static D(Ljava/nio/channels/FileChannel;Ljava/nio/channels/FileChannel;JJ)V
    .locals 9

    .line 1
    const/high16 v0, 0x100000

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v1

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    const-wide/16 v2, 0x0

    :goto_0
    cmp-long v4, v2, p4

    if-gez v4, :cond_1

    invoke-virtual {v1}, Ljava/nio/Buffer;->capacity()I

    move-result v4

    int-to-long v4, v4

    sub-long v6, p4, v2

    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v4

    long-to-int v4, v4

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    invoke-virtual {v1, v4}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    invoke-virtual {v0, v4}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    add-long v5, p2, v2

    invoke-virtual {p0, v5, v6}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    invoke-virtual {p1, v5, v6}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    invoke-virtual {p0, v1}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v7

    if-ne v7, v4, :cond_0

    invoke-virtual {p1, v0}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v7

    if-ne v7, v4, :cond_0

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v7

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v8

    invoke-static {v7, v8}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v7

    if-eqz v7, :cond_0

    int-to-long v4, v4

    add-long/2addr v2, v4

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/Exception;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Verification failed at 0x"

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v5, v6}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    return-void
.end method

.method public static q(Ljava/nio/channels/FileChannel;Ljava/nio/channels/FileChannel;JJ)V
    .locals 7

    .line 1
    const/high16 v0, 0x100000

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    const-wide/16 v1, 0x0

    :goto_0
    cmp-long v3, v1, p4

    if-gez v3, :cond_2

    invoke-virtual {v0}, Ljava/nio/Buffer;->capacity()I

    move-result v3

    int-to-long v3, v3

    sub-long v5, p4, v1

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    long-to-int v3, v3

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    invoke-virtual {v0, v3}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    add-long v4, p2, v1

    invoke-virtual {p0, v4, v5}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    invoke-virtual {p0, v0}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v6

    if-ne v6, v3, :cond_1

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    invoke-virtual {p1, v4, v5}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    :goto_1
    invoke-virtual {v0}, Ljava/nio/Buffer;->hasRemaining()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {p1, v0}, Ljava/nio/channels/FileChannel;->write(Ljava/nio/ByteBuffer;)I

    goto :goto_1

    :cond_0
    int-to-long v3, v3

    add-long/2addr v1, v3

    goto :goto_0

    :cond_1
    new-instance p0, Ljava/lang/Exception;

    const-string p1, "Original file ended early"

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    return-void
.end method

.method public static r(Ljava/util/List;)Ljava/lang/String;
    .locals 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_2

    .line 15
    .line 16
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Lg1/h2;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-lez v2, :cond_0

    .line 27
    .line 28
    const-string v2, ", "

    .line 29
    .line 30
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    :cond_0
    iget-object v2, v1, Lg1/h2;->a:Ljava/lang/String;

    .line 34
    .line 35
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    const-string v2, " ("

    .line 39
    .line 40
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    iget-wide v1, v1, Lg1/h2;->c:J

    .line 44
    .line 45
    const-wide/32 v3, 0x40000000

    .line 46
    .line 47
    .line 48
    cmp-long v3, v1, v3

    .line 49
    .line 50
    if-ltz v3, :cond_1

    .line 51
    .line 52
    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 53
    .line 54
    long-to-double v1, v1

    .line 55
    const-wide/high16 v4, 0x41d0000000000000L    # 1.073741824E9

    .line 56
    .line 57
    div-double/2addr v1, v4

    .line 58
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    const-string v2, "%.2f GB"

    .line 67
    .line 68
    invoke-static {v3, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    goto :goto_1

    .line 73
    :cond_1
    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 74
    .line 75
    long-to-double v1, v1

    .line 76
    const-wide/high16 v4, 0x4130000000000000L    # 1048576.0

    .line 77
    .line 78
    div-double/2addr v1, v4

    .line 79
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    const-string v2, "%.2f MB"

    .line 88
    .line 89
    invoke-static {v3, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    :goto_1
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    const-string v1, ")"

    .line 97
    .line 98
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    goto :goto_0

    .line 102
    :cond_2
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    return-object p0
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public static u([BI)J
    .locals 1

    .line 1
    const/16 v0, 0x8

    invoke-static {p0, p1, v0}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object p0

    sget-object p1, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->getLong()J

    move-result-wide p0

    return-wide p0
.end method

.method public static varargs w(I[B[I)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    if-ltz p0, :cond_3

    array-length v1, p2

    add-int/2addr v1, p0

    array-length v2, p1

    if-le v1, v2, :cond_0

    goto :goto_1

    :cond_0
    move v1, v0

    :goto_0
    array-length v2, p2

    if-ge v1, v2, :cond_2

    add-int v2, p0, v1

    aget-byte v2, p1, v2

    and-int/lit16 v2, v2, 0xff

    aget v3, p2, v1

    and-int/lit16 v3, v3, 0xff

    if-eq v2, v3, :cond_1

    return v0

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x1

    return p0

    :cond_3
    :goto_1
    return v0
.end method

.method public static x(Ljava/util/ArrayList;Ljava/util/ArrayList;)Ljava/util/ArrayList;
    .locals 8

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lg1/h2;

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lg1/h2;

    iget-object v4, v1, Lg1/h2;->a:Ljava/lang/String;

    iget-object v5, v3, Lg1/h2;->a:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    iget-wide v4, v1, Lg1/h2;->b:J

    iget-wide v6, v3, Lg1/h2;->b:J

    cmp-long v4, v4, v6

    if-nez v4, :cond_1

    iget-wide v4, v1, Lg1/h2;->c:J

    iget-wide v6, v3, Lg1/h2;->c:J

    cmp-long v3, v4, v6

    if-nez v3, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public static y(Ljava/util/List;)Ljava/lang/String;
    .locals 8

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sget-object v1, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->M:[Ljava/lang/String;

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/4 v4, 0x3

    if-ge v3, v4, :cond_3

    aget-object v4, v1, v3

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    move v6, v2

    :cond_0
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lg1/h2;

    iget-object v7, v7, Lg1/h2;->a:Ljava/lang/String;

    invoke-virtual {v4, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_0

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    if-nez v6, :cond_2

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_4

    const-string p0, ""

    goto :goto_3

    :cond_4
    new-instance p0, Ljava/lang/StringBuilder;

    const-string v1, "missing or incompatible: "

    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    goto :goto_2

    :cond_5
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_3
    return-object p0
.end method

.method public static z(Ljava/nio/channels/FileChannel;J)Ljava/util/ArrayList;
    .locals 28

    .line 1
    move-wide/from16 v0, p1

    const-wide/32 v2, 0xa000000

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    const-wide/16 v6, 0x0

    :goto_0
    cmp-long v8, v6, v2

    if-gez v8, :cond_c

    const-wide/32 v8, 0x101000

    sub-long v10, v0, v6

    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v8

    long-to-int v8, v8

    move-object/from16 v9, p0

    invoke-static {v9, v6, v7, v8}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->B(Ljava/nio/channels/FileChannel;JI)[B

    move-result-object v8

    const/4 v10, 0x0

    move v11, v10

    :goto_1
    add-int/lit16 v12, v11, 0x200

    array-length v13, v8

    if-gt v12, v13, :cond_b

    const/16 v13, 0x54

    const/16 v14, 0x4d

    const/16 v15, 0x50

    filled-new-array {v14, v15, v13, v10}, [I

    move-result-object v13

    invoke-static {v11, v8, v13}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->w(I[B[I)Z

    move-result v13

    if-nez v13, :cond_1

    :cond_0
    :goto_2
    move-wide/from16 v19, v2

    const-wide/16 v16, 0x0

    goto/16 :goto_9

    :cond_1
    add-int/lit8 v13, v11, 0x10

    invoke-static {v8, v13}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->C([BI)J

    move-result-wide v13

    long-to-int v13, v13

    const/4 v14, 0x3

    if-lt v13, v14, :cond_0

    const/16 v15, 0x40

    if-le v13, v15, :cond_2

    goto :goto_2

    :cond_2
    const/16 v15, 0x30

    const/16 v10, 0x28

    const/16 v4, 0x24

    filled-new-array {v10, v4, v15}, [I

    move-result-object v4

    const/4 v5, 0x0

    :goto_3
    if-ge v5, v14, :cond_0

    aget v10, v4, v5

    add-int/lit8 v15, v11, 0x18

    mul-int v18, v13, v10

    add-int v14, v18, v15

    move-wide/from16 v19, v2

    array-length v2, v8

    if-le v14, v2, :cond_3

    move-object/from16 v18, v4

    const/4 v4, 0x3

    const-wide/16 v16, 0x0

    goto/16 :goto_8

    :cond_3
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    :goto_4
    if-ge v3, v13, :cond_9

    mul-int v14, v3, v10

    add-int/2addr v14, v15

    move-object/from16 v18, v4

    const/4 v4, 0x0

    :goto_5
    const/16 v9, 0x10

    if-ge v4, v9, :cond_4

    add-int v21, v14, v4

    aget-byte v21, v8, v21

    if-eqz v21, :cond_4

    add-int/lit8 v4, v4, 0x1

    goto :goto_5

    :cond_4
    if-eqz v4, :cond_7

    if-ne v4, v9, :cond_5

    goto :goto_6

    :cond_5
    new-instance v9, Ljava/lang/String;

    move/from16 v27, v10

    const-string v10, "US-ASCII"

    invoke-direct {v9, v8, v14, v4, v10}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    add-int/lit8 v4, v14, 0x10

    invoke-static {v8, v4}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->u([BI)J

    move-result-wide v25

    add-int/lit8 v14, v14, 0x18

    invoke-static {v8, v14}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->u([BI)J

    move-result-wide v23

    const-string v4, "[A-Za-z][A-Za-z0-9_-]*"

    invoke-virtual {v9, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_7

    const-wide/16 v16, 0x0

    cmp-long v4, v25, v16

    if-lez v4, :cond_8

    cmp-long v4, v23, v16

    if-ltz v4, :cond_8

    add-long v21, v23, v25

    cmp-long v4, v21, v0

    if-lez v4, :cond_6

    goto :goto_7

    :cond_6
    new-instance v4, Lg1/h2;

    move-object/from16 v21, v4

    move-object/from16 v22, v9

    invoke-direct/range {v21 .. v26}, Lg1/h2;-><init>(Ljava/lang/String;JJ)V

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    move-object/from16 v9, p0

    move-object/from16 v4, v18

    move/from16 v10, v27

    goto :goto_4

    :cond_7
    :goto_6
    const-wide/16 v16, 0x0

    :cond_8
    :goto_7
    const/4 v4, 0x3

    goto :goto_8

    :cond_9
    move-object/from16 v18, v4

    const-wide/16 v16, 0x0

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x3

    if-lt v3, v4, :cond_a

    return-object v2

    :cond_a
    :goto_8
    add-int/lit8 v5, v5, 0x1

    move-object/from16 v9, p0

    move v14, v4

    move-object/from16 v4, v18

    move-wide/from16 v2, v19

    goto/16 :goto_3

    :goto_9
    const/4 v10, 0x0

    move-object/from16 v9, p0

    move v11, v12

    move-wide/from16 v2, v19

    goto/16 :goto_1

    :cond_b
    move-wide/from16 v19, v2

    const-wide/16 v16, 0x0

    const-wide/32 v2, 0x100000

    add-long/2addr v6, v2

    move-wide/from16 v2, v19

    goto/16 :goto_0

    :cond_c
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const v0, 0x7f0902ab

    .line 6
    .line 7
    .line 8
    const-string v1, "application/*"

    .line 9
    .line 10
    const-string v2, "application/octet-stream"

    .line 11
    .line 12
    if-ne p1, v0, :cond_0

    .line 13
    .line 14
    iget-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->J:Lb/h;

    .line 15
    .line 16
    filled-new-array {v2, v1}, [Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const v0, 0x7f0902ae

    .line 25
    .line 26
    .line 27
    if-ne p1, v0, :cond_1

    .line 28
    .line 29
    iget-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->K:Lb/h;

    .line 30
    .line 31
    filled-new-array {v2, v1}, [Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    const v0, 0x7f0902a7

    .line 40
    .line 41
    .line 42
    if-ne p1, v0, :cond_2

    .line 43
    .line 44
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->p()V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_2
    const v0, 0x7f0902a8

    .line 49
    .line 50
    .line 51
    if-ne p1, v0, :cond_6

    .line 52
    .line 53
    iget-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->D:Landroid/net/Uri;

    .line 54
    .line 55
    if-nez p1, :cond_3

    .line 56
    .line 57
    iget-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->L:Lb/h;

    .line 58
    .line 59
    const-string v0, "Mi_Netflix_Fixed.bin"

    .line 60
    .line 61
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_3
    const/4 p1, 0x1

    .line 66
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->t(Z)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_4

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_4
    iget-object v0, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->I:Ljava/util/List;

    .line 74
    .line 75
    invoke-static {v0}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->y(Ljava/util/List;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-nez v0, :cond_5

    .line 84
    .line 85
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->p()V

    .line 86
    .line 87
    .line 88
    const-string v0, "Check compatible files first"

    .line 89
    .line 90
    invoke-static {p0, v0, p1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 95
    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_5
    iget-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->G:Landroid/widget/TextView;

    .line 99
    .line 100
    const-string v0, "Creating new Mi Netflix fixed BIN. Please wait..."

    .line 101
    .line 102
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 103
    .line 104
    .line 105
    new-instance p1, Ljava/lang/Thread;

    .line 106
    .line 107
    new-instance v0, Lg1/e2;

    .line 108
    .line 109
    const/4 v1, 0x0

    .line 110
    invoke-direct {v0, p0, v1}, Lg1/e2;-><init>(Lapp/gkc/terminal/Activity/MiNetflixFixActivity;I)V

    .line 111
    .line 112
    .line 113
    invoke-direct {p1, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 117
    .line 118
    .line 119
    :cond_6
    :goto_0
    return-void
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c002d

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const p1, 0x7f0902ac

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->E:Landroid/widget/TextView;

    const p1, 0x7f0902af

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->F:Landroid/widget/TextView;

    const p1, 0x7f0902ad

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->G:Landroid/widget/TextView;

    const p1, 0x7f0902a9

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->H:Landroid/widget/TextView;

    const p1, 0x7f0902a7

    const v0, 0x7f0902a8

    const v1, 0x7f0902ab

    const v2, 0x7f0902ae

    filled-new-array {v1, v2, p1, v0}, [I

    move-result-object p1

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x4

    if-ge v0, v1, :cond_0

    aget v1, p1, v0

    invoke-virtual {p0, v1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    const-string p1, "Mi Netflix Fix ready. Source dumps are never edited."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->v(Ljava/lang/String;)V

    return-void
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final p()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->t(Z)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->G:Landroid/widget/TextView;

    const-string v1, "Checking Amlogic/GPT partition tables..."

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lg1/e2;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lg1/e2;-><init>(Lapp/gkc/terminal/Activity/MiNetflixFixActivity;I)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public final s(Landroid/net/Uri;)Ljava/util/ArrayList;
    .locals 6

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "r"

    .line 6
    .line 7
    invoke-virtual {v0, p1, v1}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    :try_start_0
    new-instance v0, Ljava/io/FileInputStream;

    .line 12
    .line 13
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-direct {v0, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 21
    .line 22
    .line 23
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 24
    :try_start_1
    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->size()J

    .line 25
    .line 26
    .line 27
    move-result-wide v1

    .line 28
    invoke-static {v0, v1, v2}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->A(Ljava/nio/channels/FileChannel;J)Ljava/util/ArrayList;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 33
    .line 34
    .line 35
    move-result v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 36
    if-nez v4, :cond_0

    .line 37
    .line 38
    :goto_0
    :try_start_2
    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 39
    .line 40
    .line 41
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V

    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :catchall_0
    move-exception v0

    .line 46
    goto :goto_4

    .line 47
    :cond_0
    :try_start_3
    invoke-static {v0, v1, v2}, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->z(Ljava/nio/channels/FileChannel;J)Ljava/util/ArrayList;

    .line 48
    .line 49
    .line 50
    move-result-object v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 51
    goto :goto_0

    .line 52
    :goto_1
    new-instance p1, Ljava/util/ArrayList;

    .line 53
    .line 54
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 55
    .line 56
    .line 57
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    if-eqz v1, :cond_3

    .line 66
    .line 67
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    check-cast v1, Lg1/h2;

    .line 72
    .line 73
    sget-object v2, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->M:[Ljava/lang/String;

    .line 74
    .line 75
    const/4 v3, 0x0

    .line 76
    :goto_2
    const/4 v4, 0x3

    .line 77
    if-ge v3, v4, :cond_1

    .line 78
    .line 79
    aget-object v4, v2, v3

    .line 80
    .line 81
    iget-object v5, v1, Lg1/h2;->a:Ljava/lang/String;

    .line 82
    .line 83
    invoke-virtual {v4, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 84
    .line 85
    .line 86
    move-result v4

    .line 87
    if-eqz v4, :cond_2

    .line 88
    .line 89
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    :cond_2
    add-int/lit8 v3, v3, 0x1

    .line 93
    .line 94
    goto :goto_2

    .line 95
    :cond_3
    return-object p1

    .line 96
    :catchall_1
    move-exception v1

    .line 97
    if-eqz v0, :cond_4

    .line 98
    .line 99
    :try_start_4
    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 100
    .line 101
    .line 102
    goto :goto_3

    .line 103
    :catchall_2
    move-exception v0

    .line 104
    :try_start_5
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 105
    .line 106
    .line 107
    :cond_4
    :goto_3
    throw v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 108
    :goto_4
    if-eqz p1, :cond_5

    .line 109
    .line 110
    :try_start_6
    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 111
    .line 112
    .line 113
    goto :goto_5

    .line 114
    :catchall_3
    move-exception p1

    .line 115
    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 116
    .line 117
    .line 118
    :cond_5
    :goto_5
    throw v0
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final t(Z)Z
    .locals 4

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->B:Landroid/net/Uri;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_3

    iget-object v3, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->C:Landroid/net/Uri;

    if-nez v3, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v0, v3}, Landroid/net/Uri;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p1, "Select two different dump files"

    :goto_0
    invoke-static {p0, p1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return v1

    :cond_1
    if-eqz p1, :cond_2

    iget-object p1, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->D:Landroid/net/Uri;

    if-nez p1, :cond_2

    const-string p1, "Select new output BIN"

    goto :goto_0

    :cond_2
    return v2

    :cond_3
    :goto_1
    const-string p1, "Select original and working dumps"

    goto :goto_0
.end method

.method public final v(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/MiNetflixFixActivity;->H:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\n"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    return-void
.end method
