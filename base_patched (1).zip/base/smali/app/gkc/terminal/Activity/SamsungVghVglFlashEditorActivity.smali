.class public Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;
.super Le/m;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field public static final synthetic Y:I


# instance fields
.field public B:Landroid/widget/TextView;

.field public C:Landroid/widget/TextView;

.field public D:Landroid/widget/TextView;

.field public E:Landroid/widget/TextView;

.field public F:Landroid/widget/TextView;

.field public G:Landroid/widget/TextView;

.field public H:Landroid/widget/ScrollView;

.field public I:Landroid/widget/Button;

.field public J:Landroid/hardware/usb/UsbManager;

.field public final K:Lg1/n;

.field public L:Z

.field public M:I

.field public N:[B

.field public O:[B

.field public P:Lg1/j3;

.field public final Q:Ljava/util/ArrayList;

.field public R:I

.field public S:I

.field public T:I

.field public U:I

.field public final V:Lb/h;

.field public final W:Le/d0;

.field public final X:[Lg1/j3;


# direct methods
.method public constructor <init>()V
    .locals 14

    .line 1
    invoke-direct {p0}, Le/m;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lg1/n;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-direct {v0, v1}, Lg1/n;-><init>(I)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->K:Lg1/n;

    .line 11
    .line 12
    new-instance v0, Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->Q:Ljava/util/ArrayList;

    .line 18
    .line 19
    const/4 v0, -0x1

    .line 20
    iput v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->R:I

    .line 21
    .line 22
    iput v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->S:I

    .line 23
    .line 24
    iput v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->T:I

    .line 25
    .line 26
    iput v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->U:I

    .line 27
    .line 28
    new-instance v0, Lc/c;

    .line 29
    .line 30
    const/4 v1, 0x0

    .line 31
    invoke-direct {v0, v1}, Lc/c;-><init>(I)V

    .line 32
    .line 33
    .line 34
    new-instance v2, Lg1/d3;

    .line 35
    .line 36
    invoke-direct {v2, p0, v1}, Lg1/d3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p0, v2, v0}, Landroidx/activity/q;->l(Lb/c;Le2/m;)Lb/h;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    iput-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->V:Lb/h;

    .line 44
    .line 45
    new-instance v0, Le/d0;

    .line 46
    .line 47
    const/16 v2, 0x8

    .line 48
    .line 49
    invoke-direct {v0, v2, p0}, Le/d0;-><init>(ILjava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iput-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->W:Le/d0;

    .line 53
    .line 54
    const/16 v0, 0x9b

    .line 55
    .line 56
    new-array v2, v0, [Lg1/j3;

    .line 57
    .line 58
    :goto_0
    if-ge v1, v0, :cond_0

    .line 59
    .line 60
    sget-object v3, Lg1/b3;->a:[Lg1/a3;

    .line 61
    .line 62
    aget-object v3, v3, v1

    .line 63
    .line 64
    new-instance v13, Lg1/j3;

    .line 65
    .line 66
    iget-object v5, v3, Lg1/a3;->a:Ljava/lang/String;

    .line 67
    .line 68
    iget v6, v3, Lg1/a3;->b:I

    .line 69
    .line 70
    iget v7, v3, Lg1/a3;->c:I

    .line 71
    .line 72
    iget v8, v3, Lg1/a3;->d:I

    .line 73
    .line 74
    iget-boolean v9, v3, Lg1/a3;->e:Z

    .line 75
    .line 76
    iget v10, v3, Lg1/a3;->f:I

    .line 77
    .line 78
    iget v11, v3, Lg1/a3;->g:I

    .line 79
    .line 80
    iget v12, v3, Lg1/a3;->h:I

    .line 81
    .line 82
    move-object v4, v13

    .line 83
    invoke-direct/range {v4 .. v12}, Lg1/j3;-><init>(Ljava/lang/String;IIIZIII)V

    .line 84
    .line 85
    .line 86
    aput-object v13, v2, v1

    .line 87
    .line 88
    add-int/lit8 v1, v1, 0x1

    .line 89
    .line 90
    goto :goto_0

    .line 91
    :cond_0
    iput-object v2, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->X:[Lg1/j3;

    .line 92
    .line 93
    return-void
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public static E([B)I
    .locals 3

    .line 1
    array-length v0, p0

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-lt v0, v1, :cond_1

    invoke-static {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->w([B)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    aget-byte p0, p0, v0

    and-int/lit16 p0, p0, 0xff

    packed-switch p0, :pswitch_data_0

    return v2

    :pswitch_0
    const/high16 p0, 0x1000000

    return p0

    :pswitch_1
    const/high16 p0, 0x800000

    return p0

    :pswitch_2
    const/high16 p0, 0x400000

    return p0

    :pswitch_3
    const/high16 p0, 0x200000

    return p0

    :pswitch_4
    const/high16 p0, 0x100000

    return p0

    :pswitch_5
    const/high16 p0, 0x80000

    return p0

    :pswitch_6
    const/high16 p0, 0x40000

    return p0

    :cond_1
    :goto_0
    return v2

    nop

    :pswitch_data_0
    .packed-switch 0x12
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static p(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;ILjava/lang/String;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v0, Lg1/g3;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-direct {v0, p0, p1, p2, v1}, Lg1/g3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;ILjava/lang/String;I)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 11
    .line 12
    .line 13
    return-void
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public static w([B)Z
    .locals 6

    .line 1
    array-length v0, p0

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-ge v0, v1, :cond_0

    return v2

    :cond_0
    aget-byte v0, p0, v2

    const/16 v1, 0xff

    and-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_1

    aget-byte v5, p0, v4

    and-int/2addr v5, v1

    if-nez v5, :cond_1

    aget-byte v5, p0, v3

    and-int/2addr v5, v1

    if-eqz v5, :cond_3

    :cond_1
    if-ne v0, v1, :cond_2

    aget-byte v0, p0, v4

    and-int/2addr v0, v1

    if-ne v0, v1, :cond_2

    aget-byte p0, p0, v3

    and-int/2addr p0, v1

    if-eq p0, v1, :cond_3

    :cond_2
    move v2, v4

    :cond_3
    return v2
.end method


# virtual methods
.method public final A()V
    .locals 5

    .line 1
    const-string v0, "gkc_samsung_vgh_vgl_edited_"

    iget-object v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    const/4 v2, 0x0

    if-nez v1, :cond_0

    const-string v0, "No edited buffer to save."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    const-string v0, "Load BIN first"

    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    :try_start_0
    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v3, "yyyyMMdd_HHmmss"

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v1, v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v3, Ljava/util/Date;

    invoke-direct {v3}, Ljava/util/Date;-><init>()V

    invoke-virtual {v1, v3}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ".bin"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Landroid/content/ContentValues;

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    const-string v3, "_display_name"

    invoke-virtual {v1, v3, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "mime_type"

    const-string v3, "application/octet-stream"

    invoke-virtual {v1, v0, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1d

    if-lt v0, v3, :cond_1

    const-string v0, "relative_path"

    const-string v3, "Download/GKC_CH341A"

    invoke-virtual {v1, v0, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    :catch_0
    move-exception v0

    goto :goto_2

    :cond_1
    :goto_0
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-static {}, La0/b;->f()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v0, v3, v1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v0

    if-nez v0, :cond_2

    const-string v0, "Save failed: MediaStore returned null."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    return-void

    :cond_2
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v0

    if-nez v0, :cond_3

    const-string v0, "Save failed: output stream null."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    return-void

    :cond_3
    iget-object v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    invoke-virtual {v0, v1}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    const-string v0, "Edited BIN saved in Download/GKC_CH341A."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->L:Z

    if-eqz v0, :cond_4

    const-string v0, "Edited file saved before write."

    goto :goto_1

    :cond_4
    const-string v0, "File saved only. CH341A not connected."

    :goto_1
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    const-string v0, "Edited BIN saved"

    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :goto_2
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Save failed: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    :goto_3
    return-void
.end method

.method public final B(I)V
    .locals 4

    .line 1
    const-string v0, "Backup save failed."

    const-string v1, "gkc_samsung_original_backup_"

    iget-object v2, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->N:[B

    if-eqz v2, :cond_6

    array-length v3, v2

    if-nez v3, :cond_0

    goto/16 :goto_3

    :cond_0
    if-lez p1, :cond_2

    array-length v2, v2

    if-ne v2, p1, :cond_1

    goto :goto_0

    :cond_1
    const-string p1, "Original backup size mismatch. Write blocked."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "Backup size mismatch."

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    :goto_0
    :try_start_0
    new-instance p1, Ljava/text/SimpleDateFormat;

    const-string v2, "yyyyMMdd_HHmmss"

    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {p1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v2, Ljava/util/Date;

    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    invoke-virtual {p1, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ".bin"

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Landroid/content/ContentValues;

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    const-string v2, "_display_name"

    invoke-virtual {v1, v2, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "mime_type"

    const-string v2, "application/octet-stream"

    invoke-virtual {v1, p1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1d

    if-lt p1, v2, :cond_3

    const-string p1, "relative_path"

    const-string v2, "Download/GKC_CH341A"

    invoke-virtual {v1, p1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_2

    :cond_3
    :goto_1
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    invoke-static {}, La0/b;->f()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {p1, v2, v1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object p1

    if-eqz p1, :cond_5

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object p1

    if-eqz p1, :cond_4

    iget-object v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->N:[B

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {p1}, Ljava/io/OutputStream;->close()V

    const-string p1, "Original backup saved."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    return-void

    :cond_4
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_2
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_6
    :goto_3
    const-string p1, "Original backup not available."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    return-void
.end method

.method public final C()V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->Q:Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 6
    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    iput-object v2, v0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 10
    .line 11
    iget-object v3, v0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 12
    .line 13
    const/4 v4, 0x0

    .line 14
    if-nez v3, :cond_1

    .line 15
    .line 16
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->v()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    const-string v1, "Searching Samsung profile..."

    .line 23
    .line 24
    invoke-virtual {v0, v1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const/4 v1, 0x1

    .line 28
    invoke-virtual {v0, v1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->D(Z)V

    .line 29
    .line 30
    .line 31
    new-instance v1, Ljava/lang/Thread;

    .line 32
    .line 33
    new-instance v2, Lg1/e3;

    .line 34
    .line 35
    invoke-direct {v2, v0, v4}, Lg1/e3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    .line 36
    .line 37
    .line 38
    invoke-direct {v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    const-string v1, "Connect CH341A first."

    .line 46
    .line 47
    invoke-virtual {v0, v1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    :goto_0
    return-void

    .line 51
    :cond_1
    iget-object v3, v0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->X:[Lg1/j3;

    .line 52
    .line 53
    array-length v5, v3

    .line 54
    move v6, v4

    .line 55
    move v7, v6

    .line 56
    :goto_1
    if-ge v6, v5, :cond_a

    .line 57
    .line 58
    aget-object v8, v3, v6

    .line 59
    .line 60
    iget-object v9, v0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 61
    .line 62
    if-eqz v9, :cond_7

    .line 63
    .line 64
    invoke-virtual {v8}, Lg1/j3;->h()I

    .line 65
    .line 66
    .line 67
    move-result v10

    .line 68
    if-ltz v10, :cond_6

    .line 69
    .line 70
    invoke-virtual {v8}, Lg1/j3;->i()I

    .line 71
    .line 72
    .line 73
    move-result v10

    .line 74
    if-ltz v10, :cond_6

    .line 75
    .line 76
    invoke-virtual {v8}, Lg1/j3;->h()I

    .line 77
    .line 78
    .line 79
    move-result v10

    .line 80
    array-length v11, v9

    .line 81
    if-ge v10, v11, :cond_6

    .line 82
    .line 83
    invoke-virtual {v8}, Lg1/j3;->i()I

    .line 84
    .line 85
    .line 86
    move-result v10

    .line 87
    array-length v11, v9

    .line 88
    if-ge v10, v11, :cond_6

    .line 89
    .line 90
    const-string v10, "25X40"

    .line 91
    .line 92
    iget-object v11, v8, Lg1/j3;->a:Ljava/lang/String;

    .line 93
    .line 94
    invoke-virtual {v11, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 95
    .line 96
    .line 97
    move-result v10

    .line 98
    if-eqz v10, :cond_2

    .line 99
    .line 100
    array-length v10, v9

    .line 101
    const/high16 v12, 0x80000

    .line 102
    .line 103
    if-eq v10, v12, :cond_2

    .line 104
    .line 105
    :goto_2
    move v14, v4

    .line 106
    goto :goto_4

    .line 107
    :cond_2
    invoke-virtual {v8}, Lg1/j3;->h()I

    .line 108
    .line 109
    .line 110
    move-result v10

    .line 111
    aget-byte v10, v9, v10

    .line 112
    .line 113
    and-int/lit16 v10, v10, 0xff

    .line 114
    .line 115
    invoke-virtual {v8}, Lg1/j3;->i()I

    .line 116
    .line 117
    .line 118
    move-result v12

    .line 119
    aget-byte v12, v9, v12

    .line 120
    .line 121
    and-int/lit16 v12, v12, 0xff

    .line 122
    .line 123
    invoke-static {v10}, Lg1/j3;->f(I)Z

    .line 124
    .line 125
    .line 126
    move-result v13

    .line 127
    if-eqz v13, :cond_6

    .line 128
    .line 129
    invoke-static {v12}, Lg1/j3;->f(I)Z

    .line 130
    .line 131
    .line 132
    move-result v13

    .line 133
    if-nez v13, :cond_3

    .line 134
    .line 135
    goto :goto_3

    .line 136
    :cond_3
    invoke-static {v10, v12}, Lg1/j3;->e(II)Z

    .line 137
    .line 138
    .line 139
    move-result v13

    .line 140
    if-nez v13, :cond_4

    .line 141
    .line 142
    goto :goto_2

    .line 143
    :cond_4
    iget-boolean v13, v8, Lg1/j3;->e:Z

    .line 144
    .line 145
    const/16 v14, 0xa

    .line 146
    .line 147
    if-eqz v13, :cond_8

    .line 148
    .line 149
    invoke-virtual {v8}, Lg1/j3;->b()I

    .line 150
    .line 151
    .line 152
    move-result v13

    .line 153
    invoke-virtual {v8}, Lg1/j3;->c()I

    .line 154
    .line 155
    .line 156
    move-result v15

    .line 157
    if-ltz v13, :cond_8

    .line 158
    .line 159
    if-ltz v15, :cond_8

    .line 160
    .line 161
    array-length v4, v9

    .line 162
    if-ge v13, v4, :cond_8

    .line 163
    .line 164
    array-length v4, v9

    .line 165
    if-ge v15, v4, :cond_8

    .line 166
    .line 167
    const-string v4, "double table"

    .line 168
    .line 169
    invoke-virtual {v11, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 170
    .line 171
    .line 172
    move-result v4

    .line 173
    if-eqz v4, :cond_5

    .line 174
    .line 175
    const/16 v14, 0xf

    .line 176
    .line 177
    :cond_5
    aget-byte v4, v9, v13

    .line 178
    .line 179
    and-int/lit16 v4, v4, 0xff

    .line 180
    .line 181
    if-ne v4, v10, :cond_8

    .line 182
    .line 183
    aget-byte v4, v9, v15

    .line 184
    .line 185
    and-int/lit16 v4, v4, 0xff

    .line 186
    .line 187
    if-ne v4, v12, :cond_8

    .line 188
    .line 189
    add-int/lit8 v14, v14, 0xa

    .line 190
    .line 191
    goto :goto_4

    .line 192
    :cond_6
    :goto_3
    const/4 v14, 0x0

    .line 193
    goto :goto_4

    .line 194
    :cond_7
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 195
    .line 196
    .line 197
    goto :goto_3

    .line 198
    :cond_8
    :goto_4
    if-lez v14, :cond_9

    .line 199
    .line 200
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 201
    .line 202
    .line 203
    if-le v14, v7, :cond_9

    .line 204
    .line 205
    move-object v2, v8

    .line 206
    move v7, v14

    .line 207
    :cond_9
    add-int/lit8 v6, v6, 0x1

    .line 208
    .line 209
    const/4 v4, 0x0

    .line 210
    goto/16 :goto_1

    .line 211
    .line 212
    :cond_a
    const-string v1, "Search complete."

    .line 213
    .line 214
    invoke-virtual {v0, v1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    if-nez v2, :cond_b

    .line 218
    .line 219
    iget-object v1, v0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->D:Landroid/widget/TextView;

    .line 220
    .line 221
    const-string v2, "No safe Samsung profile found"

    .line 222
    .line 223
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 224
    .line 225
    .line 226
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->F()V

    .line 227
    .line 228
    .line 229
    const-string v1, "No safe Samsung profile found. Use MANUAL only if you know this panel."

    .line 230
    .line 231
    invoke-virtual {v0, v1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    goto :goto_5

    .line 235
    :cond_b
    iput-object v2, v0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 236
    .line 237
    const-string v1, "Safe Samsung profile selected."

    .line 238
    .line 239
    invoke-virtual {v0, v1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    invoke-virtual/range {p0 .. p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->z()V

    .line 243
    .line 244
    .line 245
    :goto_5
    return-void
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
.end method

.method public final D(Z)V
    .locals 2

    .line 1
    new-instance v0, Lg1/p1;

    const/4 v1, 0x2

    invoke-direct {v0, p0, p1, v1}, Lg1/p1;-><init>(Landroid/view/KeyEvent$Callback;ZI)V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final F()V
    .locals 10

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->E:Landroid/widget/TextView;

    .line 2
    .line 3
    if-eqz v0, :cond_b

    .line 4
    .line 5
    iget-object v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->F:Landroid/widget/TextView;

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    goto/16 :goto_7

    .line 10
    .line 11
    :cond_0
    iget-object v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 12
    .line 13
    const-string v2, "--.- V"

    .line 14
    .line 15
    if-nez v1, :cond_2

    .line 16
    .line 17
    :cond_1
    :goto_0
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->F:Landroid/widget/TextView;

    .line 21
    .line 22
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_2
    iget-object v3, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 27
    .line 28
    if-nez v3, :cond_5

    .line 29
    .line 30
    iget v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->T:I

    .line 31
    .line 32
    if-ltz v1, :cond_3

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_3
    iget v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->R:I

    .line 36
    .line 37
    :goto_1
    iget v3, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->U:I

    .line 38
    .line 39
    if-ltz v3, :cond_4

    .line 40
    .line 41
    goto :goto_2

    .line 42
    :cond_4
    iget v3, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->S:I

    .line 43
    .line 44
    :goto_2
    if-ltz v1, :cond_1

    .line 45
    .line 46
    if-gez v3, :cond_6

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_5
    invoke-virtual {v1}, Lg1/j3;->h()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    aget-byte v0, v3, v0

    .line 54
    .line 55
    and-int/lit16 v1, v0, 0xff

    .line 56
    .line 57
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 58
    .line 59
    iget-object v2, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 60
    .line 61
    invoke-virtual {v2}, Lg1/j3;->i()I

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    aget-byte v0, v0, v2

    .line 66
    .line 67
    and-int/lit16 v3, v0, 0xff

    .line 68
    .line 69
    :cond_6
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->E:Landroid/widget/TextView;

    .line 70
    .line 71
    sget-object v2, Lg1/b3;->b:[I

    .line 72
    .line 73
    sget-object v4, Lg1/b3;->c:[D

    .line 74
    .line 75
    const/4 v5, 0x0

    .line 76
    move v6, v5

    .line 77
    :goto_3
    const/16 v7, 0x72

    .line 78
    .line 79
    const-wide/high16 v8, 0x7ff8000000000000L    # Double.NaN

    .line 80
    .line 81
    if-ge v6, v7, :cond_8

    .line 82
    .line 83
    aget v7, v2, v6

    .line 84
    .line 85
    if-ne v7, v1, :cond_7

    .line 86
    .line 87
    aget-wide v1, v4, v6

    .line 88
    .line 89
    goto :goto_4

    .line 90
    :cond_7
    add-int/lit8 v6, v6, 0x1

    .line 91
    .line 92
    goto :goto_3

    .line 93
    :cond_8
    move-wide v1, v8

    .line 94
    :goto_4
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 95
    .line 96
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    const-string v2, "%.1f V"

    .line 105
    .line 106
    invoke-static {v4, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 111
    .line 112
    .line 113
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->F:Landroid/widget/TextView;

    .line 114
    .line 115
    sget-object v1, Lg1/b3;->d:[I

    .line 116
    .line 117
    sget-object v4, Lg1/b3;->e:[D

    .line 118
    .line 119
    :goto_5
    const/16 v6, 0x4f

    .line 120
    .line 121
    if-ge v5, v6, :cond_a

    .line 122
    .line 123
    aget v6, v1, v5

    .line 124
    .line 125
    if-ne v6, v3, :cond_9

    .line 126
    .line 127
    aget-wide v8, v4, v5

    .line 128
    .line 129
    goto :goto_6

    .line 130
    :cond_9
    add-int/lit8 v5, v5, 0x1

    .line 131
    .line 132
    goto :goto_5

    .line 133
    :cond_a
    :goto_6
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 134
    .line 135
    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 136
    .line 137
    .line 138
    move-result-object v3

    .line 139
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    invoke-static {v1, v2, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 148
    .line 149
    .line 150
    :cond_b
    :goto_7
    return-void
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final G([B)I
    .locals 5

    .line 1
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->u()V

    new-instance v0, Lg1/d3;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lg1/d3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    iget-object v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->K:Lg1/n;

    invoke-virtual {v1, p1, v0}, Lg1/n;->I([BLg1/p;)I

    move-result v0

    const/4 v2, -0x1

    if-gez v0, :cond_0

    return v2

    :cond_0
    const-wide/16 v3, 0xfa

    :try_start_0
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->u()V

    new-instance v0, Lg1/d3;

    const/4 v3, 0x4

    invoke-direct {v0, p0, v3}, Lg1/d3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    invoke-virtual {v1, p1, v0}, Lg1/n;->I([BLg1/p;)I

    move-result p1

    if-gez p1, :cond_1

    goto :goto_0

    :cond_1
    move v2, p1

    :goto_0
    return v2

    :catch_0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    return v0
.end method

.method public onClick(Landroid/view/View;)V
    .locals 11

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const v0, 0x7f0901e4

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x0

    .line 10
    if-ne p1, v0, :cond_5

    .line 11
    .line 12
    iget-boolean p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->L:Z

    .line 13
    .line 14
    if-eqz p1, :cond_0

    .line 15
    .line 16
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->t()V

    .line 17
    .line 18
    .line 19
    goto/16 :goto_4

    .line 20
    .line 21
    :cond_0
    :try_start_0
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->J:Landroid/hardware/usb/UsbManager;

    .line 22
    .line 23
    invoke-virtual {p1}, Landroid/hardware/usb/UsbManager;->getDeviceList()Ljava/util/HashMap;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-virtual {p1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    :cond_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_2

    .line 40
    .line 41
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    check-cast v0, Landroid/hardware/usb/UsbDevice;

    .line 46
    .line 47
    invoke-virtual {v0}, Landroid/hardware/usb/UsbDevice;->getVendorId()I

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    const/16 v4, 0x1a86

    .line 52
    .line 53
    if-ne v3, v4, :cond_1

    .line 54
    .line 55
    const-string p1, "CH341A adapter detected."

    .line 56
    .line 57
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    move-object v1, v0

    .line 61
    :cond_2
    if-nez v1, :cond_3

    .line 62
    .line 63
    const-string p1, "CH341A not found. Connect OTG + CH341A."

    .line 64
    .line 65
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    const-string p1, "CH341A not found"

    .line 69
    .line 70
    invoke-static {p0, p1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 75
    .line 76
    .line 77
    goto/16 :goto_4

    .line 78
    .line 79
    :catch_0
    move-exception p1

    .line 80
    goto :goto_0

    .line 81
    :cond_3
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->J:Landroid/hardware/usb/UsbManager;

    .line 82
    .line 83
    invoke-virtual {p1, v1}, Landroid/hardware/usb/UsbManager;->hasPermission(Landroid/hardware/usb/UsbDevice;)Z

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    if-nez p1, :cond_4

    .line 88
    .line 89
    const-string p1, "Requesting USB permission..."

    .line 90
    .line 91
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    new-instance p1, Landroid/content/Intent;

    .line 95
    .line 96
    const-string v0, "app.gkc.terminal.pro.SAMSUNG_FLASH_USB_PERMISSION"

    .line 97
    .line 98
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    invoke-virtual {p1, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 106
    .line 107
    .line 108
    const/high16 v0, 0xa000000

    .line 109
    .line 110
    invoke-static {p0, v2, p1, v0}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->J:Landroid/hardware/usb/UsbManager;

    .line 115
    .line 116
    invoke-virtual {v0, v1, p1}, Landroid/hardware/usb/UsbManager;->requestPermission(Landroid/hardware/usb/UsbDevice;Landroid/app/PendingIntent;)V

    .line 117
    .line 118
    .line 119
    goto/16 :goto_4

    .line 120
    .line 121
    :cond_4
    invoke-virtual {p0, v1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->x(Landroid/hardware/usb/UsbDevice;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 122
    .line 123
    .line 124
    goto/16 :goto_4

    .line 125
    .line 126
    :goto_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 127
    .line 128
    const-string v1, "Connect failed: "

    .line 129
    .line 130
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    const-string v1, " "

    .line 145
    .line 146
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 147
    .line 148
    .line 149
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object p1

    .line 153
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 154
    .line 155
    .line 156
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    goto/16 :goto_4

    .line 164
    .line 165
    :cond_5
    const v0, 0x7f0901e8

    .line 166
    .line 167
    .line 168
    if-ne p1, v0, :cond_6

    .line 169
    .line 170
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->V:Lb/h;

    .line 171
    .line 172
    const-string v0, "*/*"

    .line 173
    .line 174
    invoke-virtual {p1, v0}, Le2/m;->y0(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    goto/16 :goto_4

    .line 178
    .line 179
    :cond_6
    const/4 v0, 0x1

    .line 180
    const v3, 0x7f0901ea

    .line 181
    .line 182
    .line 183
    const/4 v4, 0x3

    .line 184
    if-ne p1, v3, :cond_b

    .line 185
    .line 186
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->v()Z

    .line 187
    .line 188
    .line 189
    move-result p1

    .line 190
    if-nez p1, :cond_7

    .line 191
    .line 192
    goto/16 :goto_4

    .line 193
    .line 194
    :cond_7
    iget p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->M:I

    .line 195
    .line 196
    if-lez p1, :cond_a

    .line 197
    .line 198
    const/high16 v1, 0x100000

    .line 199
    .line 200
    if-lt p1, v1, :cond_8

    .line 201
    .line 202
    rem-int v3, p1, v1

    .line 203
    .line 204
    if-nez v3, :cond_8

    .line 205
    .line 206
    new-instance v3, Ljava/lang/StringBuilder;

    .line 207
    .line 208
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 209
    .line 210
    .line 211
    div-int v1, p1, v1

    .line 212
    .line 213
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 214
    .line 215
    .line 216
    const-string v1, " MB"

    .line 217
    .line 218
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 219
    .line 220
    .line 221
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object v1

    .line 225
    goto :goto_2

    .line 226
    :cond_8
    const/16 v1, 0x400

    .line 227
    .line 228
    if-lt p1, v1, :cond_9

    .line 229
    .line 230
    rem-int/lit16 v1, p1, 0x400

    .line 231
    .line 232
    if-nez v1, :cond_9

    .line 233
    .line 234
    new-instance v1, Ljava/lang/StringBuilder;

    .line 235
    .line 236
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 237
    .line 238
    .line 239
    div-int/lit16 v3, p1, 0x400

    .line 240
    .line 241
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 242
    .line 243
    .line 244
    const-string v3, " KB"

    .line 245
    .line 246
    :goto_1
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 247
    .line 248
    .line 249
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 250
    .line 251
    .line 252
    move-result-object v1

    .line 253
    goto :goto_2

    .line 254
    :cond_9
    new-instance v1, Ljava/lang/StringBuilder;

    .line 255
    .line 256
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 257
    .line 258
    .line 259
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 260
    .line 261
    .line 262
    const-string v3, " bytes"

    .line 263
    .line 264
    goto :goto_1

    .line 265
    :goto_2
    const-string v3, "Reading panel flash."

    .line 266
    .line 267
    invoke-virtual {p0, v3}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->D(Z)V

    .line 271
    .line 272
    .line 273
    new-instance v0, Ljava/lang/Thread;

    .line 274
    .line 275
    new-instance v3, Lg1/g3;

    .line 276
    .line 277
    invoke-direct {v3, p0, p1, v1, v2}, Lg1/g3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;ILjava/lang/String;I)V

    .line 278
    .line 279
    .line 280
    invoke-direct {v0, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 281
    .line 282
    .line 283
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 284
    .line 285
    .line 286
    goto/16 :goto_4

    .line 287
    .line 288
    :cond_a
    const-string v5, "512 KB"

    .line 289
    .line 290
    const-string v6, "1 MB"

    .line 291
    .line 292
    const-string v7, "2 MB"

    .line 293
    .line 294
    const-string v8, "4 MB"

    .line 295
    .line 296
    const-string v9, "8 MB"

    .line 297
    .line 298
    const-string v10, "16 MB"

    .line 299
    .line 300
    filled-new-array/range {v5 .. v10}, [Ljava/lang/String;

    .line 301
    .line 302
    .line 303
    move-result-object p1

    .line 304
    const/4 v0, 0x6

    .line 305
    new-array v0, v0, [I

    .line 306
    .line 307
    fill-array-data v0, :array_0

    .line 308
    .line 309
    .line 310
    new-instance v1, Landroid/app/AlertDialog$Builder;

    .line 311
    .line 312
    invoke-direct {v1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 313
    .line 314
    .line 315
    const-string v2, "Select Panel Flash Size"

    .line 316
    .line 317
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 318
    .line 319
    .line 320
    move-result-object v1

    .line 321
    new-instance v2, Lg1/l1;

    .line 322
    .line 323
    invoke-direct {v2, p0, v0, p1, v4}, Lg1/l1;-><init>(Le/m;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 324
    .line 325
    .line 326
    invoke-virtual {v1, p1, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 327
    .line 328
    .line 329
    move-result-object p1

    .line 330
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 331
    .line 332
    .line 333
    goto/16 :goto_4

    .line 334
    .line 335
    :cond_b
    const v3, 0x7f0901ed

    .line 336
    .line 337
    .line 338
    if-ne p1, v3, :cond_c

    .line 339
    .line 340
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->C()V

    .line 341
    .line 342
    .line 343
    goto/16 :goto_4

    .line 344
    .line 345
    :cond_c
    const v3, 0x7f0901ee

    .line 346
    .line 347
    .line 348
    const-string v5, "Run SEARCH first"

    .line 349
    .line 350
    const-string v6, "Run SEARCH first."

    .line 351
    .line 352
    if-ne p1, v3, :cond_f

    .line 353
    .line 354
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->Q:Ljava/util/ArrayList;

    .line 355
    .line 356
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 357
    .line 358
    .line 359
    move-result v1

    .line 360
    if-eqz v1, :cond_d

    .line 361
    .line 362
    invoke-virtual {p0, v6}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 363
    .line 364
    .line 365
    invoke-static {p0, v5, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 366
    .line 367
    .line 368
    move-result-object p1

    .line 369
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 370
    .line 371
    .line 372
    goto/16 :goto_4

    .line 373
    .line 374
    :cond_d
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 375
    .line 376
    .line 377
    move-result v1

    .line 378
    new-array v1, v1, [Ljava/lang/String;

    .line 379
    .line 380
    :goto_3
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 381
    .line 382
    .line 383
    move-result v3

    .line 384
    if-ge v2, v3, :cond_e

    .line 385
    .line 386
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 387
    .line 388
    .line 389
    move-result-object v3

    .line 390
    check-cast v3, Lg1/j3;

    .line 391
    .line 392
    iget-object v3, v3, Lg1/j3;->a:Ljava/lang/String;

    .line 393
    .line 394
    aput-object v3, v1, v2

    .line 395
    .line 396
    add-int/lit8 v2, v2, 0x1

    .line 397
    .line 398
    goto :goto_3

    .line 399
    :cond_e
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 400
    .line 401
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 402
    .line 403
    .line 404
    const-string v2, "Select Samsung Profile"

    .line 405
    .line 406
    invoke-virtual {p1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 407
    .line 408
    .line 409
    move-result-object p1

    .line 410
    new-instance v2, Lg1/f3;

    .line 411
    .line 412
    invoke-direct {v2, p0, v0}, Lg1/f3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    .line 413
    .line 414
    .line 415
    invoke-virtual {p1, v1, v2}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 416
    .line 417
    .line 418
    move-result-object p1

    .line 419
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 420
    .line 421
    .line 422
    goto/16 :goto_4

    .line 423
    .line 424
    :cond_f
    const v3, 0x7f0901ef

    .line 425
    .line 426
    .line 427
    if-ne p1, v3, :cond_10

    .line 428
    .line 429
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 430
    .line 431
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 432
    .line 433
    .line 434
    const-string v0, "Samsung Offline SOP"

    .line 435
    .line 436
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 437
    .line 438
    .line 439
    move-result-object p1

    .line 440
    const-string v0, "1. Connect CH341A and the panel flash safely.\n\n2. Tap AUTO SEARCH to detect the Samsung profile.\n\n3. If no unique profile is found, do not write.\n\n4. Adjust VGH/VGL in small steps only.\n\n5. Confirm target value with meter or service data.\n\n6. Tap WRITE CHIP, then power cycle and check the panel."

    .line 441
    .line 442
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 443
    .line 444
    .line 445
    move-result-object p1

    .line 446
    const-string v0, "OK"

    .line 447
    .line 448
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 449
    .line 450
    .line 451
    move-result-object p1

    .line 452
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 453
    .line 454
    .line 455
    goto/16 :goto_4

    .line 456
    .line 457
    :cond_10
    const v3, 0x7f0901eb

    .line 458
    .line 459
    .line 460
    if-ne p1, v3, :cond_12

    .line 461
    .line 462
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->N:[B

    .line 463
    .line 464
    if-nez p1, :cond_11

    .line 465
    .line 466
    const-string p1, "No original buffer loaded."

    .line 467
    .line 468
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 469
    .line 470
    .line 471
    goto/16 :goto_4

    .line 472
    .line 473
    :cond_11
    array-length v0, p1

    .line 474
    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    .line 475
    .line 476
    .line 477
    move-result-object p1

    .line 478
    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 479
    .line 480
    const-string p1, "Working buffer restored from loaded BIN."

    .line 481
    .line 482
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 483
    .line 484
    .line 485
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->z()V

    .line 486
    .line 487
    .line 488
    goto/16 :goto_4

    .line 489
    .line 490
    :cond_12
    const v3, 0x7f0901f8

    .line 491
    .line 492
    .line 493
    const-string v7, "CANCEL"

    .line 494
    .line 495
    if-ne p1, v3, :cond_18

    .line 496
    .line 497
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 498
    .line 499
    const-string v0, "WRITE"

    .line 500
    .line 501
    const-string v3, "Write Panel Fix?"

    .line 502
    .line 503
    if-nez p1, :cond_15

    .line 504
    .line 505
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 506
    .line 507
    if-eqz p1, :cond_14

    .line 508
    .line 509
    iget p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->T:I

    .line 510
    .line 511
    if-ltz p1, :cond_14

    .line 512
    .line 513
    iget p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->U:I

    .line 514
    .line 515
    if-ltz p1, :cond_14

    .line 516
    .line 517
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->v()Z

    .line 518
    .line 519
    .line 520
    move-result p1

    .line 521
    if-eqz p1, :cond_14

    .line 522
    .line 523
    iget p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->M:I

    .line 524
    .line 525
    if-gtz p1, :cond_13

    .line 526
    .line 527
    const-string p1, "Flash size not detected. Reconnect CH341A."

    .line 528
    .line 529
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 530
    .line 531
    .line 532
    goto/16 :goto_4

    .line 533
    .line 534
    :cond_13
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 535
    .line 536
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 537
    .line 538
    .line 539
    invoke-virtual {p1, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 540
    .line 541
    .line 542
    move-result-object p1

    .line 543
    const-string v2, "The app writes only the confirmed Samsung voltage data and checks it."

    .line 544
    .line 545
    invoke-virtual {p1, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 546
    .line 547
    .line 548
    move-result-object p1

    .line 549
    new-instance v2, Lg1/f3;

    .line 550
    .line 551
    invoke-direct {v2, p0, v4}, Lg1/f3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    .line 552
    .line 553
    .line 554
    invoke-virtual {p1, v0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 555
    .line 556
    .line 557
    move-result-object p1

    .line 558
    invoke-virtual {p1, v7, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 559
    .line 560
    .line 561
    move-result-object p1

    .line 562
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 563
    .line 564
    .line 565
    goto/16 :goto_4

    .line 566
    .line 567
    :cond_14
    invoke-virtual {p0, v6}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 568
    .line 569
    .line 570
    invoke-static {p0, v5, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 571
    .line 572
    .line 573
    move-result-object p1

    .line 574
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 575
    .line 576
    .line 577
    goto/16 :goto_4

    .line 578
    .line 579
    :cond_15
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->v()Z

    .line 580
    .line 581
    .line 582
    move-result p1

    .line 583
    if-nez p1, :cond_16

    .line 584
    .line 585
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->A()V

    .line 586
    .line 587
    .line 588
    goto/16 :goto_4

    .line 589
    .line 590
    :cond_16
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->s()Z

    .line 591
    .line 592
    .line 593
    move-result p1

    .line 594
    if-nez p1, :cond_17

    .line 595
    .line 596
    goto/16 :goto_4

    .line 597
    .line 598
    :cond_17
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 599
    .line 600
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 601
    .line 602
    .line 603
    invoke-virtual {p1, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 604
    .line 605
    .line 606
    move-result-object p1

    .line 607
    const-string v2, "The app saves a backup, writes the edited panel data, and verifies the result."

    .line 608
    .line 609
    invoke-virtual {p1, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 610
    .line 611
    .line 612
    move-result-object p1

    .line 613
    new-instance v2, Lg1/f3;

    .line 614
    .line 615
    const/4 v3, 0x2

    .line 616
    invoke-direct {v2, p0, v3}, Lg1/f3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    .line 617
    .line 618
    .line 619
    invoke-virtual {p1, v0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 620
    .line 621
    .line 622
    move-result-object p1

    .line 623
    invoke-virtual {p1, v7, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 624
    .line 625
    .line 626
    move-result-object p1

    .line 627
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 628
    .line 629
    .line 630
    goto/16 :goto_4

    .line 631
    .line 632
    :cond_18
    const v3, 0x7f0901e6

    .line 633
    .line 634
    .line 635
    if-ne p1, v3, :cond_1a

    .line 636
    .line 637
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->v()Z

    .line 638
    .line 639
    .line 640
    move-result p1

    .line 641
    if-nez p1, :cond_19

    .line 642
    .line 643
    goto/16 :goto_4

    .line 644
    .line 645
    :cond_19
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 646
    .line 647
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 648
    .line 649
    .line 650
    const-string v0, "Erase SPI Flash?"

    .line 651
    .line 652
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 653
    .line 654
    .line 655
    move-result-object p1

    .line 656
    const-string v0, "This clears the connected chip. Keep original backup before erase."

    .line 657
    .line 658
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 659
    .line 660
    .line 661
    move-result-object p1

    .line 662
    new-instance v0, Lg1/f3;

    .line 663
    .line 664
    invoke-direct {v0, p0, v2}, Lg1/f3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    .line 665
    .line 666
    .line 667
    const-string v2, "ERASE"

    .line 668
    .line 669
    invoke-virtual {p1, v2, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 670
    .line 671
    .line 672
    move-result-object p1

    .line 673
    invoke-virtual {p1, v7, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 674
    .line 675
    .line 676
    move-result-object p1

    .line 677
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 678
    .line 679
    .line 680
    goto/16 :goto_4

    .line 681
    .line 682
    :cond_1a
    const v1, 0x7f0901f1

    .line 683
    .line 684
    .line 685
    if-ne p1, v1, :cond_1e

    .line 686
    .line 687
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 688
    .line 689
    if-nez p1, :cond_1b

    .line 690
    .line 691
    const-string p1, "No buffer to verify."

    .line 692
    .line 693
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 694
    .line 695
    .line 696
    const-string p1, "No data to verify"

    .line 697
    .line 698
    invoke-static {p0, p1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 699
    .line 700
    .line 701
    move-result-object p1

    .line 702
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 703
    .line 704
    .line 705
    goto :goto_4

    .line 706
    :cond_1b
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->v()Z

    .line 707
    .line 708
    .line 709
    move-result p1

    .line 710
    if-nez p1, :cond_1c

    .line 711
    .line 712
    goto :goto_4

    .line 713
    :cond_1c
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->s()Z

    .line 714
    .line 715
    .line 716
    move-result p1

    .line 717
    if-nez p1, :cond_1d

    .line 718
    .line 719
    goto :goto_4

    .line 720
    :cond_1d
    const-string p1, "Verify started."

    .line 721
    .line 722
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 723
    .line 724
    .line 725
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->D(Z)V

    .line 726
    .line 727
    .line 728
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 729
    .line 730
    invoke-static {p1}, Lg1/n;->d([B)[B

    .line 731
    .line 732
    .line 733
    move-result-object p1

    .line 734
    new-instance v0, Ljava/lang/Thread;

    .line 735
    .line 736
    new-instance v1, Lg1/c3;

    .line 737
    .line 738
    invoke-direct {v1, v2, p0, p1}, Lg1/c3;-><init>(ILapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;[B)V

    .line 739
    .line 740
    .line 741
    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 742
    .line 743
    .line 744
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 745
    .line 746
    .line 747
    goto :goto_4

    .line 748
    :cond_1e
    const v1, 0x7f0901e3

    .line 749
    .line 750
    .line 751
    if-ne p1, v1, :cond_1f

    .line 752
    .line 753
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->G:Landroid/widget/TextView;

    .line 754
    .line 755
    const-string v0, ""

    .line 756
    .line 757
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 758
    .line 759
    .line 760
    const-string p1, "Log cleared."

    .line 761
    .line 762
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 763
    .line 764
    .line 765
    goto :goto_4

    .line 766
    :cond_1f
    const v1, 0x7f0901f2

    .line 767
    .line 768
    .line 769
    const/4 v3, -0x1

    .line 770
    if-ne p1, v1, :cond_20

    .line 771
    .line 772
    invoke-virtual {p0, v3, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->q(IZ)V

    .line 773
    .line 774
    .line 775
    goto :goto_4

    .line 776
    :cond_20
    const v1, 0x7f0901f3

    .line 777
    .line 778
    .line 779
    if-ne p1, v1, :cond_21

    .line 780
    .line 781
    invoke-virtual {p0, v0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->q(IZ)V

    .line 782
    .line 783
    .line 784
    goto :goto_4

    .line 785
    :cond_21
    const v1, 0x7f0901f5

    .line 786
    .line 787
    .line 788
    if-ne p1, v1, :cond_22

    .line 789
    .line 790
    invoke-virtual {p0, v3, v2}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->q(IZ)V

    .line 791
    .line 792
    .line 793
    goto :goto_4

    .line 794
    :cond_22
    const v1, 0x7f0901f6

    .line 795
    .line 796
    .line 797
    if-ne p1, v1, :cond_23

    .line 798
    .line 799
    invoke-virtual {p0, v0, v2}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->q(IZ)V

    .line 800
    .line 801
    .line 802
    :cond_23
    :goto_4
    return-void

    .line 803
    :array_0
    .array-data 4
        0x80000
        0x100000
        0x200000
        0x400000
        0x800000
        0x1000000
    .end array-data
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    invoke-super {p0, p1}, Landroidx/fragment/app/y;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c0033

    invoke-virtual {p0, p1}, Le/m;->setContentView(I)V

    const-string p1, "usb"

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/usb/UsbManager;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->J:Landroid/hardware/usb/UsbManager;

    const p1, 0x7f0901f0

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->B:Landroid/widget/TextView;

    const p1, 0x7f0901e7

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->C:Landroid/widget/TextView;

    const p1, 0x7f0901ec

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->D:Landroid/widget/TextView;

    const p1, 0x7f0901f4

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->E:Landroid/widget/TextView;

    const p1, 0x7f0901f7

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->F:Landroid/widget/TextView;

    const p1, 0x7f0901e9

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->G:Landroid/widget/TextView;

    invoke-static {}, Landroid/text/method/ScrollingMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->G:Landroid/widget/TextView;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setVerticalScrollBarEnabled(Z)V

    const p1, 0x7f0901e5

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ScrollView;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->H:Landroid/widget/ScrollView;

    const p1, 0x7f0901e4

    invoke-virtual {p0, p1}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->I:Landroid/widget/Button;

    const/16 p1, 0xf

    new-array v0, p1, [I

    fill-array-data v0, :array_0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p1, :cond_0

    aget v2, v0, v1

    invoke-virtual {p0, v2}, Le/m;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    new-instance p1, Landroid/content/IntentFilter;

    const-string v0, "app.gkc.terminal.pro.SAMSUNG_FLASH_USB_PERMISSION"

    invoke-direct {p1, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->W:Le/d0;

    invoke-static {p0, v0, p1}, Le2/m;->e1(Landroid/content/Context;Le/d0;Landroid/content/IntentFilter;)V

    const-string p1, "System ready. Connect CH341A, then tap AUTO SEARCH."

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    return-void

    :array_0
    .array-data 4
        0x7f0901e4
        0x7f0901e8
        0x7f0901ed
        0x7f0901ee
        0x7f0901ef
        0x7f0901eb
        0x7f0901f8
        0x7f0901e3
        0x7f0901f2
        0x7f0901f3
        0x7f0901f5
        0x7f0901f6
        0x7f0901ea
        0x7f0901e6
        0x7f0901f1
    .end array-data
.end method

.method public final onDestroy()V
    .locals 1

    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->t()V

    :try_start_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->W:Le/d0;

    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-super {p0}, Le/m;->onDestroy()V

    return-void
.end method

.method public final onResume()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/y;->onResume()V

    invoke-static {p0}, Lg1/b3;->z(Landroid/app/Activity;)V

    return-void
.end method

.method public final q(IZ)V
    .locals 7

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 2
    .line 3
    const-string v1, " adjusted."

    .line 4
    .line 5
    const-string v2, "VGL"

    .line 6
    .line 7
    const-string v3, "VGH"

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    const/16 v5, 0xff

    .line 11
    .line 12
    if-eqz v0, :cond_5

    .line 13
    .line 14
    iget-object v6, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 15
    .line 16
    if-nez v6, :cond_0

    .line 17
    .line 18
    goto :goto_2

    .line 19
    :cond_0
    if-eqz p2, :cond_1

    .line 20
    .line 21
    invoke-virtual {v0}, Lg1/j3;->h()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    goto :goto_0

    .line 26
    :cond_1
    invoke-virtual {v0}, Lg1/j3;->i()I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    :goto_0
    iget-object v6, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 31
    .line 32
    aget-byte v6, v6, v0

    .line 33
    .line 34
    and-int/2addr v6, v5

    .line 35
    add-int/2addr v6, p1

    .line 36
    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    invoke-static {v4, p1}, Ljava/lang/Math;->max(II)I

    .line 41
    .line 42
    .line 43
    move-result p1

    .line 44
    iget-object v4, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 45
    .line 46
    int-to-byte p1, p1

    .line 47
    aput-byte p1, v4, v0

    .line 48
    .line 49
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 50
    .line 51
    iget-boolean v4, v0, Lg1/j3;->e:Z

    .line 52
    .line 53
    if-eqz v4, :cond_3

    .line 54
    .line 55
    if-eqz p2, :cond_2

    .line 56
    .line 57
    invoke-virtual {v0}, Lg1/j3;->b()I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    goto :goto_1

    .line 62
    :cond_2
    invoke-virtual {v0}, Lg1/j3;->c()I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    :goto_1
    if-ltz v0, :cond_3

    .line 67
    .line 68
    iget-object v4, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 69
    .line 70
    array-length v5, v4

    .line 71
    if-ge v0, v5, :cond_3

    .line 72
    .line 73
    aput-byte p1, v4, v0

    .line 74
    .line 75
    :cond_3
    if-eqz p2, :cond_4

    .line 76
    .line 77
    move-object v2, v3

    .line 78
    :cond_4
    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->z()V

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :cond_5
    :goto_2
    if-eqz v0, :cond_8

    .line 90
    .line 91
    iget v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->R:I

    .line 92
    .line 93
    if-ltz v0, :cond_8

    .line 94
    .line 95
    iget v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->S:I

    .line 96
    .line 97
    if-ltz v0, :cond_8

    .line 98
    .line 99
    if-eqz p2, :cond_6

    .line 100
    .line 101
    iget v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->T:I

    .line 102
    .line 103
    add-int/2addr v0, p1

    .line 104
    invoke-static {v5, v0}, Ljava/lang/Math;->min(II)I

    .line 105
    .line 106
    .line 107
    move-result p1

    .line 108
    invoke-static {v4, p1}, Ljava/lang/Math;->max(II)I

    .line 109
    .line 110
    .line 111
    move-result p1

    .line 112
    iput p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->T:I

    .line 113
    .line 114
    goto :goto_3

    .line 115
    :cond_6
    iget v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->U:I

    .line 116
    .line 117
    add-int/2addr v0, p1

    .line 118
    invoke-static {v5, v0}, Ljava/lang/Math;->min(II)I

    .line 119
    .line 120
    .line 121
    move-result p1

    .line 122
    invoke-static {v4, p1}, Ljava/lang/Math;->max(II)I

    .line 123
    .line 124
    .line 125
    move-result p1

    .line 126
    iput p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->U:I

    .line 127
    .line 128
    :goto_3
    if-eqz p2, :cond_7

    .line 129
    .line 130
    move-object v2, v3

    .line 131
    :cond_7
    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->F()V

    .line 139
    .line 140
    .line 141
    return-void

    .line 142
    :cond_8
    const-string p1, "Run SEARCH first."

    .line 143
    .line 144
    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    const-string p1, "Run SEARCH first"

    .line 148
    .line 149
    invoke-static {p0, p1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 150
    .line 151
    .line 152
    move-result-object p1

    .line 153
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 154
    .line 155
    .line 156
    return-void
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public final r(Ljava/lang/String;)V
    .locals 2

    .line 1
    if-eqz p1, :cond_2

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    if-ne v0, v1, :cond_1

    .line 23
    .line 24
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->G:Landroid/widget/TextView;

    .line 25
    .line 26
    const-string v1, "\n"

    .line 27
    .line 28
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    .line 33
    .line 34
    .line 35
    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->G:Landroid/widget/TextView;

    .line 36
    .line 37
    new-instance v0, Lg1/e3;

    .line 38
    .line 39
    const/4 v1, 0x1

    .line 40
    invoke-direct {v0, p0, v1}, Lg1/e3;-><init>(Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;I)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 44
    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_1
    new-instance v0, Landroidx/activity/p;

    .line 48
    .line 49
    const/16 v1, 0x17

    .line 50
    .line 51
    invoke-direct {v0, v1, p0, p1}, Landroidx/activity/p;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 55
    .line 56
    .line 57
    :cond_2
    :goto_0
    return-void
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final s()Z
    .locals 3

    .line 1
    iget v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->M:I

    const/4 v1, 0x1

    if-lez v0, :cond_2

    iget-object v2, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    array-length v2, v2

    if-ne v2, v0, :cond_1

    return v1

    :cond_1
    const-string v0, "Write blocked: loaded file size does not match the connected chip."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    const-string v0, "Read the full chip again before writing."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    const-string v0, "BIN size does not match chip"

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const/4 v0, 0x0

    return v0

    :cond_2
    :goto_0
    return v1
.end method

.method public final t()V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->K:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->c()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->L:Z

    iput v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->M:I

    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->B:Landroid/widget/TextView;

    if-eqz v0, :cond_0

    const-string v1, "PANEL FLASH: Disconnected"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->I:Landroid/widget/Button;

    if-eqz v0, :cond_1

    const-string v1, "CONNECT"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    const-string v0, "Panel flash link disconnected."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    return-void
.end method

.method public final u()V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->K:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->t()[B

    move-result-object v0

    invoke-static {v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->w([B)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Chip contact lost."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final v()Z
    .locals 2

    .line 1
    iget-boolean v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->L:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->K:Lg1/n;

    invoke-virtual {v0}, Lg1/n;->j()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const-string v0, "Connect CH341A first."

    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    const-string v0, "Connect CH341A first"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return v1
.end method

.method public final x(Landroid/hardware/usb/UsbDevice;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->K:Lg1/n;

    const/4 v1, 0x1

    :try_start_0
    iget-object v2, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->J:Landroid/hardware/usb/UsbManager;

    invoke-virtual {v0, v2, p1}, Lg1/n;->m(Landroid/hardware/usb/UsbManager;Landroid/hardware/usb/UsbDevice;)V

    iput-boolean v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->L:Z

    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->B:Landroid/widget/TextView;

    const-string v2, "FLASH EDITOR: Connected"

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->I:Landroid/widget/Button;

    const-string v2, "DISCONNECT"

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Lg1/n;->t()[B

    move-result-object p1

    invoke-static {p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->E([B)I

    move-result p1

    iput p1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->M:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v0, "SPI connected. Tap AUTO SEARCH."

    :try_start_1
    invoke-virtual {p0, v0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    goto :goto_0

    :catch_0
    move-exception p1

    goto :goto_1

    :goto_0
    const-string p1, "CH341A connected"

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_2

    :goto_1
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->t()V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Open failed: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->r(Ljava/lang/String;)V

    const-string p1, "Open failed. See log."

    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_2
    return-void
.end method

.method public final y(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 2

    .line 1
    new-instance v0, Landroidx/emoji2/text/n;

    const/16 v1, 0x11

    invoke-direct {v0, p0, p1, p2, v1}, Landroidx/emoji2/text/n;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final z()V
    .locals 2

    .line 1
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->O:[B

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->R:I

    .line 10
    .line 11
    if-gez v0, :cond_0

    .line 12
    .line 13
    goto :goto_3

    .line 14
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 15
    .line 16
    const-string v1, "Samsung profile ready\nVGH adjustment ready\nVGL adjustment ready"

    .line 17
    .line 18
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->P:Lg1/j3;

    .line 22
    .line 23
    iget-boolean v1, v1, Lg1/j3;->e:Z

    .line 24
    .line 25
    if-eqz v1, :cond_1

    .line 26
    .line 27
    const-string v1, "\nBackup voltage data will be updated"

    .line 28
    .line 29
    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_1
    const-string v1, "\nMain panel voltage data ready"

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :goto_1
    iget-object v1, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->D:Landroid/widget/TextView;

    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 43
    .line 44
    .line 45
    :goto_2
    invoke-virtual {p0}, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->F()V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :cond_2
    :goto_3
    iget-object v0, p0, Lapp/gkc/terminal/Activity/SamsungVghVglFlashEditorActivity;->D:Landroid/widget/TextView;

    .line 50
    .line 51
    const-string v1, "No profile selected"

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 54
    .line 55
    .line 56
    goto :goto_2
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method
