.class public abstract Ld3/g;
.super Le2/m;
.source "SourceFile"
