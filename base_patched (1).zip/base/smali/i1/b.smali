.class public final synthetic Li1/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic g:Lapp/gkc/terminal/USB/Esp32FlashActivity;

.field public final synthetic h:Li1/d;

.field public final synthetic i:[B

.field public final synthetic j:I

.field public final synthetic k:Z


# direct methods
.method public synthetic constructor <init>(Lapp/gkc/terminal/USB/Esp32FlashActivity;Li1/d;[BIZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li1/b;->g:Lapp/gkc/terminal/USB/Esp32FlashActivity;

    iput-object p2, p0, Li1/b;->h:Li1/d;

    iput-object p3, p0, Li1/b;->i:[B

    iput p4, p0, Li1/b;->j:I

    iput-boolean p5, p0, Li1/b;->k:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 11

    .line 1
    iget-object v0, p0, Li1/b;->h:Li1/d;

    .line 2
    .line 3
    iget-object v1, p0, Li1/b;->i:[B

    .line 4
    .line 5
    iget v2, p0, Li1/b;->j:I

    .line 6
    .line 7
    iget-boolean v3, p0, Li1/b;->k:Z

    .line 8
    .line 9
    sget v4, Lapp/gkc/terminal/USB/Esp32FlashActivity;->R:I

    .line 10
    .line 11
    iget-object v4, p0, Li1/b;->g:Lapp/gkc/terminal/USB/Esp32FlashActivity;

    .line 12
    .line 13
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const/4 v5, 0x1

    .line 17
    const/4 v6, 0x0

    .line 18
    :try_start_0
    const-string v7, "usb"

    .line 19
    .line 20
    invoke-virtual {v4, v7}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v7

    .line 24
    check-cast v7, Landroid/hardware/usb/UsbManager;

    .line 25
    .line 26
    iget-object v8, v0, Li1/d;->c:Lcom/hoho/android/usbserial/driver/UsbSerialDriver;

    .line 27
    .line 28
    invoke-interface {v8}, Lcom/hoho/android/usbserial/driver/UsbSerialDriver;->getDevice()Landroid/hardware/usb/UsbDevice;

    .line 29
    .line 30
    .line 31
    move-result-object v8

    .line 32
    invoke-virtual {v7, v8}, Landroid/hardware/usb/UsbManager;->openDevice(Landroid/hardware/usb/UsbDevice;)Landroid/hardware/usb/UsbDeviceConnection;

    .line 33
    .line 34
    .line 35
    move-result-object v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 36
    if-eqz v7, :cond_0

    .line 37
    .line 38
    :try_start_1
    iget-object v8, v0, Li1/d;->c:Lcom/hoho/android/usbserial/driver/UsbSerialDriver;

    .line 39
    .line 40
    invoke-interface {v8}, Lcom/hoho/android/usbserial/driver/UsbSerialDriver;->getPorts()Ljava/util/List;

    .line 41
    .line 42
    .line 43
    move-result-object v8

    .line 44
    iget v0, v0, Li1/d;->b:I

    .line 45
    .line 46
    invoke-interface {v8, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    check-cast v0, Lcom/hoho/android/usbserial/driver/UsbSerialPort;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 51
    .line 52
    :try_start_2
    invoke-interface {v0, v7}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->open(Landroid/hardware/usb/UsbDeviceConnection;)V

    .line 53
    .line 54
    .line 55
    const v6, 0x1c200

    .line 56
    .line 57
    .line 58
    const/16 v8, 0x8

    .line 59
    .line 60
    const/4 v9, 0x0

    .line 61
    invoke-interface {v0, v6, v8, v5, v9}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->setParameters(IIII)V

    .line 62
    .line 63
    .line 64
    new-instance v6, Li1/e;

    .line 65
    .line 66
    new-instance v8, Le/n0;

    .line 67
    .line 68
    const/16 v10, 0x19

    .line 69
    .line 70
    invoke-direct {v8, v10, v4}, Le/n0;-><init>(ILjava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 74
    .line 75
    .line 76
    iput-object v0, v6, Li1/e;->a:Ljava/lang/Object;

    .line 77
    .line 78
    iput-object v8, v6, Li1/e;->b:Ljava/lang/Object;

    .line 79
    .line 80
    invoke-virtual {v6, v1, v2, v3}, Li1/e;->c([BIZ)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 81
    .line 82
    .line 83
    :try_start_3
    invoke-interface {v0}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->close()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 84
    .line 85
    .line 86
    :catch_0
    :try_start_4
    invoke-virtual {v7}, Landroid/hardware/usb/UsbDeviceConnection;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    .line 87
    .line 88
    .line 89
    :catch_1
    new-instance v0, Li1/c;

    .line 90
    .line 91
    invoke-direct {v0, v4, v9}, Li1/c;-><init>(Lapp/gkc/terminal/USB/Esp32FlashActivity;I)V

    .line 92
    .line 93
    .line 94
    :goto_0
    invoke-virtual {v4, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 95
    .line 96
    .line 97
    goto :goto_3

    .line 98
    :catchall_0
    move-exception v1

    .line 99
    move-object v6, v0

    .line 100
    goto :goto_1

    .line 101
    :catchall_1
    move-exception v1

    .line 102
    goto :goto_1

    .line 103
    :cond_0
    :try_start_5
    new-instance v0, Ljava/lang/Exception;

    .line 104
    .line 105
    const-string v1, "USB open failed"

    .line 106
    .line 107
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 111
    :catchall_2
    move-exception v1

    .line 112
    move-object v7, v6

    .line 113
    :goto_1
    :try_start_6
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    if-nez v0, :cond_1

    .line 118
    .line 119
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    goto :goto_2

    .line 128
    :cond_1
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    :goto_2
    new-instance v1, Landroidx/activity/p;

    .line 133
    .line 134
    const/16 v2, 0x18

    .line 135
    .line 136
    invoke-direct {v1, v2, v4, v0}, Landroidx/activity/p;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v4, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 140
    .line 141
    .line 142
    if-eqz v6, :cond_2

    .line 143
    .line 144
    :try_start_7
    invoke-interface {v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->close()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_2

    .line 145
    .line 146
    .line 147
    :catch_2
    :cond_2
    if-eqz v7, :cond_3

    .line 148
    .line 149
    :try_start_8
    invoke-virtual {v7}, Landroid/hardware/usb/UsbDeviceConnection;->close()V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3

    .line 150
    .line 151
    .line 152
    :catch_3
    :cond_3
    new-instance v0, Li1/c;

    .line 153
    .line 154
    invoke-direct {v0, v4, v5}, Li1/c;-><init>(Lapp/gkc/terminal/USB/Esp32FlashActivity;I)V

    .line 155
    .line 156
    .line 157
    goto :goto_0

    .line 158
    :goto_3
    return-void

    .line 159
    :catchall_3
    move-exception v0

    .line 160
    if-eqz v6, :cond_4

    .line 161
    .line 162
    :try_start_9
    invoke-interface {v6}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->close()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4

    .line 163
    .line 164
    .line 165
    :catch_4
    :cond_4
    if-eqz v7, :cond_5

    .line 166
    .line 167
    :try_start_a
    invoke-virtual {v7}, Landroid/hardware/usb/UsbDeviceConnection;->close()V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_5

    .line 168
    .line 169
    .line 170
    :catch_5
    :cond_5
    new-instance v1, Li1/c;

    .line 171
    .line 172
    const/4 v2, 0x2

    .line 173
    invoke-direct {v1, v4, v2}, Li1/c;-><init>(Lapp/gkc/terminal/USB/Esp32FlashActivity;I)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v4, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 177
    .line 178
    .line 179
    throw v0
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method
