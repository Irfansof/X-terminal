.class public Lq/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public A:I

.field public B:F

.field public final C:[I

.field public D:F

.field public E:Z

.field public F:Z

.field public G:I

.field public H:I

.field public final I:Lq/c;

.field public final J:Lq/c;

.field public final K:Lq/c;

.field public final L:Lq/c;

.field public final M:Lq/c;

.field public final N:Lq/c;

.field public final O:Lq/c;

.field public final P:Lq/c;

.field public final Q:[Lq/c;

.field public final R:Ljava/util/ArrayList;

.field public final S:[Z

.field public T:Lq/d;

.field public U:I

.field public V:I

.field public W:F

.field public X:I

.field public Y:I

.field public Z:I

.field public a:Z

.field public a0:I

.field public b:Lr/c;

.field public b0:I

.field public c:Lr/c;

.field public c0:I

.field public d:Lr/k;

.field public d0:F

.field public e:Lr/m;

.field public e0:F

.field public final f:[Z

.field public f0:Ljava/lang/Object;

.field public g:Z

.field public g0:I

.field public h:I

.field public h0:Ljava/lang/String;

.field public i:I

.field public i0:I

.field public j:Ljava/lang/String;

.field public j0:I

.field public k:Z

.field public final k0:[F

.field public l:Z

.field public final l0:[Lq/d;

.field public m:Z

.field public final m0:[Lq/d;

.field public n:Z

.field public n0:I

.field public o:I

.field public o0:I

.field public p:I

.field public final p0:[I

.field public q:I

.field public r:I

.field public s:I

.field public final t:[I

.field public u:I

.field public v:I

.field public w:F

.field public x:I

.field public y:I

.field public z:F


# direct methods
.method public constructor <init>()V
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    iput-boolean v1, v0, Lq/d;->a:Z

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    iput-object v2, v0, Lq/d;->d:Lr/k;

    .line 11
    .line 12
    iput-object v2, v0, Lq/d;->e:Lr/m;

    .line 13
    .line 14
    const/4 v3, 0x2

    .line 15
    new-array v4, v3, [Z

    .line 16
    .line 17
    fill-array-data v4, :array_0

    .line 18
    .line 19
    .line 20
    iput-object v4, v0, Lq/d;->f:[Z

    .line 21
    .line 22
    const/4 v4, 0x1

    .line 23
    iput-boolean v4, v0, Lq/d;->g:Z

    .line 24
    .line 25
    const/4 v5, -0x1

    .line 26
    iput v5, v0, Lq/d;->h:I

    .line 27
    .line 28
    iput v5, v0, Lq/d;->i:I

    .line 29
    .line 30
    new-instance v6, Ljava/util/HashMap;

    .line 31
    .line 32
    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    .line 33
    .line 34
    .line 35
    iput-boolean v1, v0, Lq/d;->k:Z

    .line 36
    .line 37
    iput-boolean v1, v0, Lq/d;->l:Z

    .line 38
    .line 39
    iput-boolean v1, v0, Lq/d;->m:Z

    .line 40
    .line 41
    iput-boolean v1, v0, Lq/d;->n:Z

    .line 42
    .line 43
    iput v5, v0, Lq/d;->o:I

    .line 44
    .line 45
    iput v5, v0, Lq/d;->p:I

    .line 46
    .line 47
    iput v1, v0, Lq/d;->q:I

    .line 48
    .line 49
    iput v1, v0, Lq/d;->r:I

    .line 50
    .line 51
    iput v1, v0, Lq/d;->s:I

    .line 52
    .line 53
    new-array v6, v3, [I

    .line 54
    .line 55
    iput-object v6, v0, Lq/d;->t:[I

    .line 56
    .line 57
    iput v1, v0, Lq/d;->u:I

    .line 58
    .line 59
    iput v1, v0, Lq/d;->v:I

    .line 60
    .line 61
    const/high16 v6, 0x3f800000    # 1.0f

    .line 62
    .line 63
    iput v6, v0, Lq/d;->w:F

    .line 64
    .line 65
    iput v1, v0, Lq/d;->x:I

    .line 66
    .line 67
    iput v1, v0, Lq/d;->y:I

    .line 68
    .line 69
    iput v6, v0, Lq/d;->z:F

    .line 70
    .line 71
    iput v5, v0, Lq/d;->A:I

    .line 72
    .line 73
    iput v6, v0, Lq/d;->B:F

    .line 74
    .line 75
    const v6, 0x7fffffff

    .line 76
    .line 77
    .line 78
    filled-new-array {v6, v6}, [I

    .line 79
    .line 80
    .line 81
    move-result-object v6

    .line 82
    iput-object v6, v0, Lq/d;->C:[I

    .line 83
    .line 84
    const/4 v6, 0x0

    .line 85
    iput v6, v0, Lq/d;->D:F

    .line 86
    .line 87
    iput-boolean v1, v0, Lq/d;->E:Z

    .line 88
    .line 89
    iput-boolean v1, v0, Lq/d;->F:Z

    .line 90
    .line 91
    iput v1, v0, Lq/d;->G:I

    .line 92
    .line 93
    iput v1, v0, Lq/d;->H:I

    .line 94
    .line 95
    new-instance v13, Lq/c;

    .line 96
    .line 97
    invoke-direct {v13, v0, v3}, Lq/c;-><init>(Lq/d;I)V

    .line 98
    .line 99
    .line 100
    iput-object v13, v0, Lq/d;->I:Lq/c;

    .line 101
    .line 102
    new-instance v14, Lq/c;

    .line 103
    .line 104
    const/4 v7, 0x3

    .line 105
    invoke-direct {v14, v0, v7}, Lq/c;-><init>(Lq/d;I)V

    .line 106
    .line 107
    .line 108
    iput-object v14, v0, Lq/d;->J:Lq/c;

    .line 109
    .line 110
    new-instance v15, Lq/c;

    .line 111
    .line 112
    const/4 v7, 0x4

    .line 113
    invoke-direct {v15, v0, v7}, Lq/c;-><init>(Lq/d;I)V

    .line 114
    .line 115
    .line 116
    iput-object v15, v0, Lq/d;->K:Lq/c;

    .line 117
    .line 118
    new-instance v12, Lq/c;

    .line 119
    .line 120
    const/4 v7, 0x5

    .line 121
    invoke-direct {v12, v0, v7}, Lq/c;-><init>(Lq/d;I)V

    .line 122
    .line 123
    .line 124
    iput-object v12, v0, Lq/d;->L:Lq/c;

    .line 125
    .line 126
    new-instance v11, Lq/c;

    .line 127
    .line 128
    const/4 v7, 0x6

    .line 129
    invoke-direct {v11, v0, v7}, Lq/c;-><init>(Lq/d;I)V

    .line 130
    .line 131
    .line 132
    iput-object v11, v0, Lq/d;->M:Lq/c;

    .line 133
    .line 134
    new-instance v10, Lq/c;

    .line 135
    .line 136
    const/16 v7, 0x8

    .line 137
    .line 138
    invoke-direct {v10, v0, v7}, Lq/c;-><init>(Lq/d;I)V

    .line 139
    .line 140
    .line 141
    iput-object v10, v0, Lq/d;->N:Lq/c;

    .line 142
    .line 143
    new-instance v9, Lq/c;

    .line 144
    .line 145
    const/16 v7, 0x9

    .line 146
    .line 147
    invoke-direct {v9, v0, v7}, Lq/c;-><init>(Lq/d;I)V

    .line 148
    .line 149
    .line 150
    iput-object v9, v0, Lq/d;->O:Lq/c;

    .line 151
    .line 152
    new-instance v8, Lq/c;

    .line 153
    .line 154
    const/4 v7, 0x7

    .line 155
    invoke-direct {v8, v0, v7}, Lq/c;-><init>(Lq/d;I)V

    .line 156
    .line 157
    .line 158
    iput-object v8, v0, Lq/d;->P:Lq/c;

    .line 159
    .line 160
    move-object v7, v13

    .line 161
    move-object/from16 v16, v8

    .line 162
    .line 163
    move-object v8, v15

    .line 164
    move-object/from16 v17, v9

    .line 165
    .line 166
    move-object v9, v14

    .line 167
    move-object/from16 v18, v10

    .line 168
    .line 169
    move-object v10, v12

    .line 170
    move-object/from16 v19, v11

    .line 171
    .line 172
    move-object/from16 v20, v12

    .line 173
    .line 174
    move-object/from16 v12, v16

    .line 175
    .line 176
    filled-new-array/range {v7 .. v12}, [Lq/c;

    .line 177
    .line 178
    .line 179
    move-result-object v7

    .line 180
    iput-object v7, v0, Lq/d;->Q:[Lq/c;

    .line 181
    .line 182
    new-instance v7, Ljava/util/ArrayList;

    .line 183
    .line 184
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 185
    .line 186
    .line 187
    iput-object v7, v0, Lq/d;->R:Ljava/util/ArrayList;

    .line 188
    .line 189
    new-array v8, v3, [Z

    .line 190
    .line 191
    iput-object v8, v0, Lq/d;->S:[Z

    .line 192
    .line 193
    filled-new-array {v4, v4}, [I

    .line 194
    .line 195
    .line 196
    move-result-object v8

    .line 197
    iput-object v8, v0, Lq/d;->p0:[I

    .line 198
    .line 199
    iput-object v2, v0, Lq/d;->T:Lq/d;

    .line 200
    .line 201
    iput v1, v0, Lq/d;->U:I

    .line 202
    .line 203
    iput v1, v0, Lq/d;->V:I

    .line 204
    .line 205
    iput v6, v0, Lq/d;->W:F

    .line 206
    .line 207
    iput v5, v0, Lq/d;->X:I

    .line 208
    .line 209
    iput v1, v0, Lq/d;->Y:I

    .line 210
    .line 211
    iput v1, v0, Lq/d;->Z:I

    .line 212
    .line 213
    iput v1, v0, Lq/d;->a0:I

    .line 214
    .line 215
    const/high16 v6, 0x3f000000    # 0.5f

    .line 216
    .line 217
    iput v6, v0, Lq/d;->d0:F

    .line 218
    .line 219
    iput v6, v0, Lq/d;->e0:F

    .line 220
    .line 221
    iput v1, v0, Lq/d;->g0:I

    .line 222
    .line 223
    iput-object v2, v0, Lq/d;->h0:Ljava/lang/String;

    .line 224
    .line 225
    iput v1, v0, Lq/d;->i0:I

    .line 226
    .line 227
    iput v1, v0, Lq/d;->j0:I

    .line 228
    .line 229
    new-array v6, v3, [F

    .line 230
    .line 231
    fill-array-data v6, :array_1

    .line 232
    .line 233
    .line 234
    iput-object v6, v0, Lq/d;->k0:[F

    .line 235
    .line 236
    new-array v6, v3, [Lq/d;

    .line 237
    .line 238
    aput-object v2, v6, v1

    .line 239
    .line 240
    aput-object v2, v6, v4

    .line 241
    .line 242
    iput-object v6, v0, Lq/d;->l0:[Lq/d;

    .line 243
    .line 244
    new-array v3, v3, [Lq/d;

    .line 245
    .line 246
    aput-object v2, v3, v1

    .line 247
    .line 248
    aput-object v2, v3, v4

    .line 249
    .line 250
    iput-object v3, v0, Lq/d;->m0:[Lq/d;

    .line 251
    .line 252
    iput v5, v0, Lq/d;->n0:I

    .line 253
    .line 254
    iput v5, v0, Lq/d;->o0:I

    .line 255
    .line 256
    invoke-virtual {v7, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    invoke-virtual {v7, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 260
    .line 261
    .line 262
    invoke-virtual {v7, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 263
    .line 264
    .line 265
    move-object/from16 v1, v20

    .line 266
    .line 267
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 268
    .line 269
    .line 270
    move-object/from16 v1, v18

    .line 271
    .line 272
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 273
    .line 274
    .line 275
    move-object/from16 v1, v17

    .line 276
    .line 277
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    move-object/from16 v1, v16

    .line 281
    .line 282
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    move-object/from16 v1, v19

    .line 286
    .line 287
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 288
    .line 289
    .line 290
    return-void

    .line 291
    :array_0
    .array-data 1
        0x1t
        0x1t
    .end array-data

    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    nop

    .line 297
    :array_1
    .array-data 4
        -0x40800000    # -1.0f
        -0x40800000    # -1.0f
    .end array-data
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
.end method

.method public static H(IILjava/lang/String;Ljava/lang/StringBuilder;)V
    .locals 0

    .line 1
    if-ne p0, p1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " :   "

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ",\n"

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method

.method public static I(Ljava/lang/StringBuilder;Ljava/lang/String;FF)V
    .locals 0

    .line 1
    cmpl-float p3, p2, p3

    if-nez p3, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " :   "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string p1, ",\n"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method

.method public static p(Ljava/lang/StringBuilder;Ljava/lang/String;IIIIIF)V
    .locals 1

    .line 1
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " :  {\n"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "      size"

    const/4 v0, 0x0

    invoke-static {p2, v0, p1, p0}, Lq/d;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    const-string p1, "      min"

    invoke-static {p3, v0, p1, p0}, Lq/d;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    const-string p1, "      max"

    const p2, 0x7fffffff

    invoke-static {p4, p2, p1, p0}, Lq/d;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    const-string p1, "      matchMin"

    invoke-static {p5, v0, p1, p0}, Lq/d;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    const-string p1, "      matchDef"

    invoke-static {p6, v0, p1, p0}, Lq/d;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    const-string p1, "      matchPercent"

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-static {p0, p1, p7, p2}, Lq/d;->I(Ljava/lang/StringBuilder;Ljava/lang/String;FF)V

    const-string p1, "    },\n"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method

.method public static q(Ljava/lang/StringBuilder;Ljava/lang/String;Lq/c;)V
    .locals 2

    .line 1
    iget-object v0, p2, Lq/c;->f:Lq/c;

    if-nez v0, :cond_0

    return-void

    :cond_0
    const-string v0, "    "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " : [ \'"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p2, Lq/c;->f:Lq/c;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, "\'"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p1, p2, Lq/c;->h:I

    const/high16 v0, -0x80000000

    if-ne p1, v0, :cond_1

    iget p1, p2, Lq/c;->g:I

    if-eqz p1, :cond_2

    :cond_1
    const-string p1, ","

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p2, Lq/c;->g:I

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget v1, p2, Lq/c;->h:I

    if-eq v1, v0, :cond_2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p2, Lq/c;->h:I

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const-string p1, " ] ,\n"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method


# virtual methods
.method public final A()Z
    .locals 2

    .line 1
    iget-boolean v0, p0, Lq/d;->g:Z

    if-eqz v0, :cond_0

    iget v0, p0, Lq/d;->g0:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public B()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lq/d;->k:Z

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lq/d;->I:Lq/c;

    .line 6
    .line 7
    iget-boolean v0, v0, Lq/c;->c:Z

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Lq/d;->K:Lq/c;

    .line 12
    .line 13
    iget-boolean v0, v0, Lq/c;->c:Z

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v0, 0x0

    .line 19
    goto :goto_1

    .line 20
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 21
    :goto_1
    return v0
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public C()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lq/d;->l:Z

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lq/d;->J:Lq/c;

    .line 6
    .line 7
    iget-boolean v0, v0, Lq/c;->c:Z

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Lq/d;->L:Lq/c;

    .line 12
    .line 13
    iget-boolean v0, v0, Lq/c;->c:Z

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v0, 0x0

    .line 19
    goto :goto_1

    .line 20
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 21
    :goto_1
    return v0
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public D()V
    .locals 5

    .line 1
    iget-object v0, p0, Lq/d;->I:Lq/c;

    invoke-virtual {v0}, Lq/c;->j()V

    iget-object v0, p0, Lq/d;->J:Lq/c;

    invoke-virtual {v0}, Lq/c;->j()V

    iget-object v0, p0, Lq/d;->K:Lq/c;

    invoke-virtual {v0}, Lq/c;->j()V

    iget-object v0, p0, Lq/d;->L:Lq/c;

    invoke-virtual {v0}, Lq/c;->j()V

    iget-object v0, p0, Lq/d;->M:Lq/c;

    invoke-virtual {v0}, Lq/c;->j()V

    iget-object v0, p0, Lq/d;->N:Lq/c;

    invoke-virtual {v0}, Lq/c;->j()V

    iget-object v0, p0, Lq/d;->O:Lq/c;

    invoke-virtual {v0}, Lq/c;->j()V

    iget-object v0, p0, Lq/d;->P:Lq/c;

    invoke-virtual {v0}, Lq/c;->j()V

    const/4 v0, 0x0

    iput-object v0, p0, Lq/d;->T:Lq/d;

    const/4 v1, 0x0

    iput v1, p0, Lq/d;->D:F

    const/4 v2, 0x0

    iput v2, p0, Lq/d;->U:I

    iput v2, p0, Lq/d;->V:I

    iput v1, p0, Lq/d;->W:F

    const/4 v1, -0x1

    iput v1, p0, Lq/d;->X:I

    iput v2, p0, Lq/d;->Y:I

    iput v2, p0, Lq/d;->Z:I

    iput v2, p0, Lq/d;->a0:I

    iput v2, p0, Lq/d;->b0:I

    iput v2, p0, Lq/d;->c0:I

    const/high16 v3, 0x3f000000    # 0.5f

    iput v3, p0, Lq/d;->d0:F

    iput v3, p0, Lq/d;->e0:F

    iget-object v3, p0, Lq/d;->p0:[I

    const/4 v4, 0x1

    aput v4, v3, v2

    aput v4, v3, v4

    iput-object v0, p0, Lq/d;->f0:Ljava/lang/Object;

    iput v2, p0, Lq/d;->g0:I

    iput v2, p0, Lq/d;->i0:I

    iput v2, p0, Lq/d;->j0:I

    iget-object v0, p0, Lq/d;->k0:[F

    const/high16 v3, -0x40800000    # -1.0f

    aput v3, v0, v2

    aput v3, v0, v4

    iput v1, p0, Lq/d;->o:I

    iput v1, p0, Lq/d;->p:I

    iget-object v0, p0, Lq/d;->C:[I

    const v3, 0x7fffffff

    aput v3, v0, v2

    aput v3, v0, v4

    iput v2, p0, Lq/d;->r:I

    iput v2, p0, Lq/d;->s:I

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Lq/d;->w:F

    iput v0, p0, Lq/d;->z:F

    iput v3, p0, Lq/d;->v:I

    iput v3, p0, Lq/d;->y:I

    iput v2, p0, Lq/d;->u:I

    iput v2, p0, Lq/d;->x:I

    iput v1, p0, Lq/d;->A:I

    iput v0, p0, Lq/d;->B:F

    iget-object v0, p0, Lq/d;->f:[Z

    aput-boolean v4, v0, v2

    aput-boolean v4, v0, v4

    iput-boolean v2, p0, Lq/d;->F:Z

    iget-object v0, p0, Lq/d;->S:[Z

    aput-boolean v2, v0, v2

    aput-boolean v2, v0, v4

    iput-boolean v4, p0, Lq/d;->g:Z

    iget-object v0, p0, Lq/d;->t:[I

    aput v2, v0, v2

    aput v2, v0, v4

    iput v1, p0, Lq/d;->h:I

    iput v1, p0, Lq/d;->i:I

    return-void
.end method

.method public final E()V
    .locals 4

    .line 1
    iget-object v0, p0, Lq/d;->T:Lq/d;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of v1, v0, Lq/e;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    check-cast v0, Lq/e;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    :cond_0
    iget-object v0, p0, Lq/d;->R:Ljava/util/ArrayList;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/4 v2, 0x0

    .line 21
    :goto_0
    if-ge v2, v1, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    check-cast v3, Lq/c;

    .line 28
    .line 29
    invoke-virtual {v3}, Lq/c;->j()V

    .line 30
    .line 31
    .line 32
    add-int/lit8 v2, v2, 0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    return-void
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final F()V
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lq/d;->k:Z

    .line 3
    .line 4
    iput-boolean v0, p0, Lq/d;->l:Z

    .line 5
    .line 6
    iput-boolean v0, p0, Lq/d;->m:Z

    .line 7
    .line 8
    iput-boolean v0, p0, Lq/d;->n:Z

    .line 9
    .line 10
    iget-object v1, p0, Lq/d;->R:Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    move v3, v0

    .line 17
    :goto_0
    if-ge v3, v2, :cond_0

    .line 18
    .line 19
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    check-cast v4, Lq/c;

    .line 24
    .line 25
    iput-boolean v0, v4, Lq/c;->c:Z

    .line 26
    .line 27
    iput v0, v4, Lq/c;->b:I

    .line 28
    .line 29
    add-int/lit8 v3, v3, 0x1

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    return-void
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public G(Lg/g;)V
    .locals 0

    .line 1
    iget-object p1, p0, Lq/d;->I:Lq/c;

    invoke-virtual {p1}, Lq/c;->k()V

    iget-object p1, p0, Lq/d;->J:Lq/c;

    invoke-virtual {p1}, Lq/c;->k()V

    iget-object p1, p0, Lq/d;->K:Lq/c;

    invoke-virtual {p1}, Lq/c;->k()V

    iget-object p1, p0, Lq/d;->L:Lq/c;

    invoke-virtual {p1}, Lq/c;->k()V

    iget-object p1, p0, Lq/d;->M:Lq/c;

    invoke-virtual {p1}, Lq/c;->k()V

    iget-object p1, p0, Lq/d;->P:Lq/c;

    invoke-virtual {p1}, Lq/c;->k()V

    iget-object p1, p0, Lq/d;->N:Lq/c;

    invoke-virtual {p1}, Lq/c;->k()V

    iget-object p1, p0, Lq/d;->O:Lq/c;

    invoke-virtual {p1}, Lq/c;->k()V

    return-void
.end method

.method public final J(I)V
    .locals 0

    .line 1
    iput p1, p0, Lq/d;->a0:I

    if-lez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-boolean p1, p0, Lq/d;->E:Z

    return-void
.end method

.method public final K(II)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lq/d;->k:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lq/d;->I:Lq/c;

    invoke-virtual {v0, p1}, Lq/c;->l(I)V

    iget-object v0, p0, Lq/d;->K:Lq/c;

    invoke-virtual {v0, p2}, Lq/c;->l(I)V

    iput p1, p0, Lq/d;->Y:I

    sub-int/2addr p2, p1

    iput p2, p0, Lq/d;->U:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Lq/d;->k:Z

    return-void
.end method

.method public final L(II)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lq/d;->l:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lq/d;->J:Lq/c;

    invoke-virtual {v0, p1}, Lq/c;->l(I)V

    iget-object v0, p0, Lq/d;->L:Lq/c;

    invoke-virtual {v0, p2}, Lq/c;->l(I)V

    iput p1, p0, Lq/d;->Z:I

    sub-int/2addr p2, p1

    iput p2, p0, Lq/d;->V:I

    iget-boolean p2, p0, Lq/d;->E:Z

    if-eqz p2, :cond_1

    iget p2, p0, Lq/d;->a0:I

    add-int/2addr p1, p2

    iget-object p2, p0, Lq/d;->M:Lq/c;

    invoke-virtual {p2, p1}, Lq/c;->l(I)V

    :cond_1
    const/4 p1, 0x1

    iput-boolean p1, p0, Lq/d;->l:Z

    return-void
.end method

.method public final M(I)V
    .locals 1

    .line 1
    iput p1, p0, Lq/d;->V:I

    iget v0, p0, Lq/d;->c0:I

    if-ge p1, v0, :cond_0

    iput v0, p0, Lq/d;->V:I

    :cond_0
    return-void
.end method

.method public final N(I)V
    .locals 2

    .line 1
    iget-object v0, p0, Lq/d;->p0:[I

    const/4 v1, 0x0

    aput p1, v0, v1

    return-void
.end method

.method public final O(I)V
    .locals 2

    .line 1
    iget-object v0, p0, Lq/d;->p0:[I

    const/4 v1, 0x1

    aput p1, v0, v1

    return-void
.end method

.method public final P(I)V
    .locals 1

    .line 1
    iput p1, p0, Lq/d;->U:I

    iget v0, p0, Lq/d;->b0:I

    if-ge p1, v0, :cond_0

    iput v0, p0, Lq/d;->U:I

    :cond_0
    return-void
.end method

.method public Q(ZZ)V
    .locals 7

    .line 1
    iget-object v0, p0, Lq/d;->d:Lr/k;

    .line 2
    .line 3
    iget-boolean v1, v0, Lr/p;->g:Z

    .line 4
    .line 5
    and-int/2addr p1, v1

    .line 6
    iget-object v1, p0, Lq/d;->e:Lr/m;

    .line 7
    .line 8
    iget-boolean v2, v1, Lr/p;->g:Z

    .line 9
    .line 10
    and-int/2addr p2, v2

    .line 11
    iget-object v2, v0, Lr/p;->h:Lr/f;

    .line 12
    .line 13
    iget v2, v2, Lr/f;->g:I

    .line 14
    .line 15
    iget-object v3, v1, Lr/p;->h:Lr/f;

    .line 16
    .line 17
    iget v3, v3, Lr/f;->g:I

    .line 18
    .line 19
    iget-object v0, v0, Lr/p;->i:Lr/f;

    .line 20
    .line 21
    iget v0, v0, Lr/f;->g:I

    .line 22
    .line 23
    iget-object v1, v1, Lr/p;->i:Lr/f;

    .line 24
    .line 25
    iget v1, v1, Lr/f;->g:I

    .line 26
    .line 27
    sub-int v4, v0, v2

    .line 28
    .line 29
    sub-int v5, v1, v3

    .line 30
    .line 31
    const/4 v6, 0x0

    .line 32
    if-ltz v4, :cond_0

    .line 33
    .line 34
    if-ltz v5, :cond_0

    .line 35
    .line 36
    const/high16 v4, -0x80000000

    .line 37
    .line 38
    if-eq v2, v4, :cond_0

    .line 39
    .line 40
    const v5, 0x7fffffff

    .line 41
    .line 42
    .line 43
    if-eq v2, v5, :cond_0

    .line 44
    .line 45
    if-eq v3, v4, :cond_0

    .line 46
    .line 47
    if-eq v3, v5, :cond_0

    .line 48
    .line 49
    if-eq v0, v4, :cond_0

    .line 50
    .line 51
    if-eq v0, v5, :cond_0

    .line 52
    .line 53
    if-eq v1, v4, :cond_0

    .line 54
    .line 55
    if-ne v1, v5, :cond_1

    .line 56
    .line 57
    :cond_0
    move v0, v6

    .line 58
    move v1, v0

    .line 59
    move v2, v1

    .line 60
    move v3, v2

    .line 61
    :cond_1
    sub-int/2addr v0, v2

    .line 62
    sub-int/2addr v1, v3

    .line 63
    if-eqz p1, :cond_2

    .line 64
    .line 65
    iput v2, p0, Lq/d;->Y:I

    .line 66
    .line 67
    :cond_2
    if-eqz p2, :cond_3

    .line 68
    .line 69
    iput v3, p0, Lq/d;->Z:I

    .line 70
    .line 71
    :cond_3
    iget v2, p0, Lq/d;->g0:I

    .line 72
    .line 73
    const/16 v3, 0x8

    .line 74
    .line 75
    if-ne v2, v3, :cond_4

    .line 76
    .line 77
    iput v6, p0, Lq/d;->U:I

    .line 78
    .line 79
    iput v6, p0, Lq/d;->V:I

    .line 80
    .line 81
    return-void

    .line 82
    :cond_4
    iget-object v2, p0, Lq/d;->p0:[I

    .line 83
    .line 84
    const/4 v3, 0x1

    .line 85
    if-eqz p1, :cond_6

    .line 86
    .line 87
    aget p1, v2, v6

    .line 88
    .line 89
    if-ne p1, v3, :cond_5

    .line 90
    .line 91
    iget p1, p0, Lq/d;->U:I

    .line 92
    .line 93
    if-ge v0, p1, :cond_5

    .line 94
    .line 95
    move v0, p1

    .line 96
    :cond_5
    iput v0, p0, Lq/d;->U:I

    .line 97
    .line 98
    iget p1, p0, Lq/d;->b0:I

    .line 99
    .line 100
    if-ge v0, p1, :cond_6

    .line 101
    .line 102
    iput p1, p0, Lq/d;->U:I

    .line 103
    .line 104
    :cond_6
    if-eqz p2, :cond_8

    .line 105
    .line 106
    aget p1, v2, v3

    .line 107
    .line 108
    if-ne p1, v3, :cond_7

    .line 109
    .line 110
    iget p1, p0, Lq/d;->V:I

    .line 111
    .line 112
    if-ge v1, p1, :cond_7

    .line 113
    .line 114
    move v1, p1

    .line 115
    :cond_7
    iput v1, p0, Lq/d;->V:I

    .line 116
    .line 117
    iget p1, p0, Lq/d;->c0:I

    .line 118
    .line 119
    if-ge v1, p1, :cond_8

    .line 120
    .line 121
    iput p1, p0, Lq/d;->V:I

    .line 122
    .line 123
    :cond_8
    return-void
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public R(Lo/d;Z)V
    .locals 6

    .line 1
    iget-object v0, p0, Lq/d;->I:Lq/c;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {v0}, Lo/d;->n(Lq/c;)I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    iget-object v0, p0, Lq/d;->J:Lq/c;

    .line 11
    .line 12
    invoke-static {v0}, Lo/d;->n(Lq/c;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-object v1, p0, Lq/d;->K:Lq/c;

    .line 17
    .line 18
    invoke-static {v1}, Lo/d;->n(Lq/c;)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    iget-object v2, p0, Lq/d;->L:Lq/c;

    .line 23
    .line 24
    invoke-static {v2}, Lo/d;->n(Lq/c;)I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz p2, :cond_0

    .line 29
    .line 30
    iget-object v3, p0, Lq/d;->d:Lr/k;

    .line 31
    .line 32
    if-eqz v3, :cond_0

    .line 33
    .line 34
    iget-object v4, v3, Lr/p;->h:Lr/f;

    .line 35
    .line 36
    iget-boolean v5, v4, Lr/f;->j:Z

    .line 37
    .line 38
    if-eqz v5, :cond_0

    .line 39
    .line 40
    iget-object v3, v3, Lr/p;->i:Lr/f;

    .line 41
    .line 42
    iget-boolean v5, v3, Lr/f;->j:Z

    .line 43
    .line 44
    if-eqz v5, :cond_0

    .line 45
    .line 46
    iget p1, v4, Lr/f;->g:I

    .line 47
    .line 48
    iget v1, v3, Lr/f;->g:I

    .line 49
    .line 50
    :cond_0
    if-eqz p2, :cond_1

    .line 51
    .line 52
    iget-object p2, p0, Lq/d;->e:Lr/m;

    .line 53
    .line 54
    if-eqz p2, :cond_1

    .line 55
    .line 56
    iget-object v3, p2, Lr/p;->h:Lr/f;

    .line 57
    .line 58
    iget-boolean v4, v3, Lr/f;->j:Z

    .line 59
    .line 60
    if-eqz v4, :cond_1

    .line 61
    .line 62
    iget-object p2, p2, Lr/p;->i:Lr/f;

    .line 63
    .line 64
    iget-boolean v4, p2, Lr/f;->j:Z

    .line 65
    .line 66
    if-eqz v4, :cond_1

    .line 67
    .line 68
    iget v0, v3, Lr/f;->g:I

    .line 69
    .line 70
    iget v2, p2, Lr/f;->g:I

    .line 71
    .line 72
    :cond_1
    sub-int p2, v1, p1

    .line 73
    .line 74
    sub-int v3, v2, v0

    .line 75
    .line 76
    const/4 v4, 0x0

    .line 77
    if-ltz p2, :cond_2

    .line 78
    .line 79
    if-ltz v3, :cond_2

    .line 80
    .line 81
    const/high16 p2, -0x80000000

    .line 82
    .line 83
    if-eq p1, p2, :cond_2

    .line 84
    .line 85
    const v3, 0x7fffffff

    .line 86
    .line 87
    .line 88
    if-eq p1, v3, :cond_2

    .line 89
    .line 90
    if-eq v0, p2, :cond_2

    .line 91
    .line 92
    if-eq v0, v3, :cond_2

    .line 93
    .line 94
    if-eq v1, p2, :cond_2

    .line 95
    .line 96
    if-eq v1, v3, :cond_2

    .line 97
    .line 98
    if-eq v2, p2, :cond_2

    .line 99
    .line 100
    if-ne v2, v3, :cond_3

    .line 101
    .line 102
    :cond_2
    move p1, v4

    .line 103
    move v0, p1

    .line 104
    move v1, v0

    .line 105
    move v2, v1

    .line 106
    :cond_3
    sub-int/2addr v1, p1

    .line 107
    sub-int/2addr v2, v0

    .line 108
    iput p1, p0, Lq/d;->Y:I

    .line 109
    .line 110
    iput v0, p0, Lq/d;->Z:I

    .line 111
    .line 112
    iget p1, p0, Lq/d;->g0:I

    .line 113
    .line 114
    const/16 p2, 0x8

    .line 115
    .line 116
    if-ne p1, p2, :cond_4

    .line 117
    .line 118
    iput v4, p0, Lq/d;->U:I

    .line 119
    .line 120
    iput v4, p0, Lq/d;->V:I

    .line 121
    .line 122
    goto :goto_0

    .line 123
    :cond_4
    iget-object p1, p0, Lq/d;->p0:[I

    .line 124
    .line 125
    aget p2, p1, v4

    .line 126
    .line 127
    const/4 v0, 0x1

    .line 128
    if-ne p2, v0, :cond_5

    .line 129
    .line 130
    iget v3, p0, Lq/d;->U:I

    .line 131
    .line 132
    if-ge v1, v3, :cond_5

    .line 133
    .line 134
    move v1, v3

    .line 135
    :cond_5
    aget v3, p1, v0

    .line 136
    .line 137
    if-ne v3, v0, :cond_6

    .line 138
    .line 139
    iget v3, p0, Lq/d;->V:I

    .line 140
    .line 141
    if-ge v2, v3, :cond_6

    .line 142
    .line 143
    move v2, v3

    .line 144
    :cond_6
    iput v1, p0, Lq/d;->U:I

    .line 145
    .line 146
    iput v2, p0, Lq/d;->V:I

    .line 147
    .line 148
    iget v3, p0, Lq/d;->c0:I

    .line 149
    .line 150
    if-ge v2, v3, :cond_7

    .line 151
    .line 152
    iput v3, p0, Lq/d;->V:I

    .line 153
    .line 154
    :cond_7
    iget v3, p0, Lq/d;->b0:I

    .line 155
    .line 156
    if-ge v1, v3, :cond_8

    .line 157
    .line 158
    iput v3, p0, Lq/d;->U:I

    .line 159
    .line 160
    :cond_8
    iget v3, p0, Lq/d;->v:I

    .line 161
    .line 162
    const/4 v4, 0x3

    .line 163
    if-lez v3, :cond_9

    .line 164
    .line 165
    if-ne p2, v4, :cond_9

    .line 166
    .line 167
    iget p2, p0, Lq/d;->U:I

    .line 168
    .line 169
    invoke-static {p2, v3}, Ljava/lang/Math;->min(II)I

    .line 170
    .line 171
    .line 172
    move-result p2

    .line 173
    iput p2, p0, Lq/d;->U:I

    .line 174
    .line 175
    :cond_9
    iget p2, p0, Lq/d;->y:I

    .line 176
    .line 177
    if-lez p2, :cond_a

    .line 178
    .line 179
    aget p1, p1, v0

    .line 180
    .line 181
    if-ne p1, v4, :cond_a

    .line 182
    .line 183
    iget p1, p0, Lq/d;->V:I

    .line 184
    .line 185
    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    .line 186
    .line 187
    .line 188
    move-result p1

    .line 189
    iput p1, p0, Lq/d;->V:I

    .line 190
    .line 191
    :cond_a
    iget p1, p0, Lq/d;->U:I

    .line 192
    .line 193
    if-eq v1, p1, :cond_b

    .line 194
    .line 195
    iput p1, p0, Lq/d;->h:I

    .line 196
    .line 197
    :cond_b
    iget p1, p0, Lq/d;->V:I

    .line 198
    .line 199
    if-eq v2, p1, :cond_c

    .line 200
    .line 201
    iput p1, p0, Lq/d;->i:I

    .line 202
    .line 203
    :cond_c
    :goto_0
    return-void
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public final b(Lq/e;Lo/d;Ljava/util/HashSet;IZ)V
    .locals 7

    .line 1
    if-eqz p5, :cond_1

    .line 2
    .line 3
    invoke-virtual {p3, p0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p5

    .line 7
    if-nez p5, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    invoke-static {p1, p2, p0}, Lq/k;->a(Lq/e;Lo/d;Lq/d;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p3, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    const/16 p5, 0x40

    .line 17
    .line 18
    invoke-virtual {p1, p5}, Lq/e;->X(I)Z

    .line 19
    .line 20
    .line 21
    move-result p5

    .line 22
    invoke-virtual {p0, p2, p5}, Lq/d;->c(Lo/d;Z)V

    .line 23
    .line 24
    .line 25
    :cond_1
    if-nez p4, :cond_3

    .line 26
    .line 27
    iget-object p5, p0, Lq/d;->I:Lq/c;

    .line 28
    .line 29
    iget-object p5, p5, Lq/c;->a:Ljava/util/HashSet;

    .line 30
    .line 31
    if-eqz p5, :cond_2

    .line 32
    .line 33
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 34
    .line 35
    .line 36
    move-result-object p5

    .line 37
    :goto_0
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_2

    .line 42
    .line 43
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Lq/c;

    .line 48
    .line 49
    iget-object v1, v0, Lq/c;->d:Lq/d;

    .line 50
    .line 51
    const/4 v6, 0x1

    .line 52
    move-object v2, p1

    .line 53
    move-object v3, p2

    .line 54
    move-object v4, p3

    .line 55
    move v5, p4

    .line 56
    invoke-virtual/range {v1 .. v6}, Lq/d;->b(Lq/e;Lo/d;Ljava/util/HashSet;IZ)V

    .line 57
    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_2
    iget-object p5, p0, Lq/d;->K:Lq/c;

    .line 61
    .line 62
    iget-object p5, p5, Lq/c;->a:Ljava/util/HashSet;

    .line 63
    .line 64
    if-eqz p5, :cond_6

    .line 65
    .line 66
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 67
    .line 68
    .line 69
    move-result-object p5

    .line 70
    :goto_1
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-eqz v0, :cond_6

    .line 75
    .line 76
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Lq/c;

    .line 81
    .line 82
    iget-object v1, v0, Lq/c;->d:Lq/d;

    .line 83
    .line 84
    const/4 v6, 0x1

    .line 85
    move-object v2, p1

    .line 86
    move-object v3, p2

    .line 87
    move-object v4, p3

    .line 88
    move v5, p4

    .line 89
    invoke-virtual/range {v1 .. v6}, Lq/d;->b(Lq/e;Lo/d;Ljava/util/HashSet;IZ)V

    .line 90
    .line 91
    .line 92
    goto :goto_1

    .line 93
    :cond_3
    iget-object p5, p0, Lq/d;->J:Lq/c;

    .line 94
    .line 95
    iget-object p5, p5, Lq/c;->a:Ljava/util/HashSet;

    .line 96
    .line 97
    if-eqz p5, :cond_4

    .line 98
    .line 99
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 100
    .line 101
    .line 102
    move-result-object p5

    .line 103
    :goto_2
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    if-eqz v0, :cond_4

    .line 108
    .line 109
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    check-cast v0, Lq/c;

    .line 114
    .line 115
    iget-object v1, v0, Lq/c;->d:Lq/d;

    .line 116
    .line 117
    const/4 v6, 0x1

    .line 118
    move-object v2, p1

    .line 119
    move-object v3, p2

    .line 120
    move-object v4, p3

    .line 121
    move v5, p4

    .line 122
    invoke-virtual/range {v1 .. v6}, Lq/d;->b(Lq/e;Lo/d;Ljava/util/HashSet;IZ)V

    .line 123
    .line 124
    .line 125
    goto :goto_2

    .line 126
    :cond_4
    iget-object p5, p0, Lq/d;->L:Lq/c;

    .line 127
    .line 128
    iget-object p5, p5, Lq/c;->a:Ljava/util/HashSet;

    .line 129
    .line 130
    if-eqz p5, :cond_5

    .line 131
    .line 132
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 133
    .line 134
    .line 135
    move-result-object p5

    .line 136
    :goto_3
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    if-eqz v0, :cond_5

    .line 141
    .line 142
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    check-cast v0, Lq/c;

    .line 147
    .line 148
    iget-object v1, v0, Lq/c;->d:Lq/d;

    .line 149
    .line 150
    const/4 v6, 0x1

    .line 151
    move-object v2, p1

    .line 152
    move-object v3, p2

    .line 153
    move-object v4, p3

    .line 154
    move v5, p4

    .line 155
    invoke-virtual/range {v1 .. v6}, Lq/d;->b(Lq/e;Lo/d;Ljava/util/HashSet;IZ)V

    .line 156
    .line 157
    .line 158
    goto :goto_3

    .line 159
    :cond_5
    iget-object p5, p0, Lq/d;->M:Lq/c;

    .line 160
    .line 161
    iget-object p5, p5, Lq/c;->a:Ljava/util/HashSet;

    .line 162
    .line 163
    if-eqz p5, :cond_6

    .line 164
    .line 165
    invoke-virtual {p5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 166
    .line 167
    .line 168
    move-result-object p5

    .line 169
    :goto_4
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 170
    .line 171
    .line 172
    move-result v0

    .line 173
    if-eqz v0, :cond_6

    .line 174
    .line 175
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    check-cast v0, Lq/c;

    .line 180
    .line 181
    iget-object v1, v0, Lq/c;->d:Lq/d;

    .line 182
    .line 183
    const/4 v6, 0x1

    .line 184
    move-object v2, p1

    .line 185
    move-object v3, p2

    .line 186
    move-object v4, p3

    .line 187
    move v5, p4

    .line 188
    invoke-virtual/range {v1 .. v6}, Lq/d;->b(Lq/e;Lo/d;Ljava/util/HashSet;IZ)V

    .line 189
    .line 190
    .line 191
    goto :goto_4

    .line 192
    :cond_6
    return-void
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
.end method

.method public c(Lo/d;Z)V
    .locals 62

    .line 1
    move-object/from16 v15, p0

    .line 2
    .line 3
    move-object/from16 v14, p1

    .line 4
    .line 5
    iget-object v0, v15, Lq/d;->I:Lq/c;

    .line 6
    .line 7
    invoke-virtual {v14, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 8
    .line 9
    .line 10
    move-result-object v13

    .line 11
    iget-object v1, v15, Lq/d;->K:Lq/c;

    .line 12
    .line 13
    invoke-virtual {v14, v1}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 14
    .line 15
    .line 16
    move-result-object v12

    .line 17
    iget-object v2, v15, Lq/d;->J:Lq/c;

    .line 18
    .line 19
    invoke-virtual {v14, v2}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 20
    .line 21
    .line 22
    move-result-object v11

    .line 23
    iget-object v10, v15, Lq/d;->L:Lq/c;

    .line 24
    .line 25
    invoke-virtual {v14, v10}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 26
    .line 27
    .line 28
    move-result-object v9

    .line 29
    iget-object v8, v15, Lq/d;->M:Lq/c;

    .line 30
    .line 31
    invoke-virtual {v14, v8}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 32
    .line 33
    .line 34
    move-result-object v7

    .line 35
    iget-object v3, v15, Lq/d;->T:Lq/d;

    .line 36
    .line 37
    const/4 v6, 0x2

    .line 38
    const/4 v5, 0x0

    .line 39
    if-eqz v3, :cond_2

    .line 40
    .line 41
    iget-object v3, v3, Lq/d;->p0:[I

    .line 42
    .line 43
    aget v4, v3, v5

    .line 44
    .line 45
    if-ne v4, v6, :cond_0

    .line 46
    .line 47
    const/4 v4, 0x1

    .line 48
    const/16 v18, 0x1

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_0
    move/from16 v18, v5

    .line 52
    .line 53
    const/4 v4, 0x1

    .line 54
    :goto_0
    aget v3, v3, v4

    .line 55
    .line 56
    if-ne v3, v6, :cond_1

    .line 57
    .line 58
    move v3, v4

    .line 59
    goto :goto_1

    .line 60
    :cond_1
    move v3, v5

    .line 61
    :goto_1
    iget v5, v15, Lq/d;->q:I

    .line 62
    .line 63
    if-eq v5, v4, :cond_4

    .line 64
    .line 65
    if-eq v5, v6, :cond_3

    .line 66
    .line 67
    const/4 v4, 0x3

    .line 68
    if-eq v5, v4, :cond_2

    .line 69
    .line 70
    move/from16 v28, v3

    .line 71
    .line 72
    move/from16 v29, v18

    .line 73
    .line 74
    goto :goto_3

    .line 75
    :cond_2
    const/16 v28, 0x0

    .line 76
    .line 77
    :goto_2
    const/16 v29, 0x0

    .line 78
    .line 79
    goto :goto_3

    .line 80
    :cond_3
    move/from16 v28, v3

    .line 81
    .line 82
    goto :goto_2

    .line 83
    :cond_4
    move/from16 v29, v18

    .line 84
    .line 85
    const/16 v28, 0x0

    .line 86
    .line 87
    :goto_3
    iget v3, v15, Lq/d;->g0:I

    .line 88
    .line 89
    iget-object v4, v15, Lq/d;->S:[Z

    .line 90
    .line 91
    const/16 v5, 0x8

    .line 92
    .line 93
    if-ne v3, v5, :cond_8

    .line 94
    .line 95
    iget-object v3, v15, Lq/d;->R:Ljava/util/ArrayList;

    .line 96
    .line 97
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 98
    .line 99
    .line 100
    move-result v6

    .line 101
    const/4 v5, 0x0

    .line 102
    :goto_4
    if-ge v5, v6, :cond_7

    .line 103
    .line 104
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v21

    .line 108
    move-object/from16 v22, v3

    .line 109
    .line 110
    move-object/from16 v3, v21

    .line 111
    .line 112
    check-cast v3, Lq/c;

    .line 113
    .line 114
    iget-object v3, v3, Lq/c;->a:Ljava/util/HashSet;

    .line 115
    .line 116
    if-nez v3, :cond_5

    .line 117
    .line 118
    goto :goto_5

    .line 119
    :cond_5
    invoke-virtual {v3}, Ljava/util/HashSet;->size()I

    .line 120
    .line 121
    .line 122
    move-result v3

    .line 123
    if-lez v3, :cond_6

    .line 124
    .line 125
    goto :goto_6

    .line 126
    :cond_6
    :goto_5
    add-int/lit8 v5, v5, 0x1

    .line 127
    .line 128
    move-object/from16 v3, v22

    .line 129
    .line 130
    goto :goto_4

    .line 131
    :cond_7
    const/4 v3, 0x0

    .line 132
    aget-boolean v5, v4, v3

    .line 133
    .line 134
    if-nez v5, :cond_8

    .line 135
    .line 136
    const/4 v3, 0x1

    .line 137
    aget-boolean v5, v4, v3

    .line 138
    .line 139
    if-nez v5, :cond_8

    .line 140
    .line 141
    return-void

    .line 142
    :cond_8
    :goto_6
    iget-boolean v3, v15, Lq/d;->k:Z

    .line 143
    .line 144
    if-nez v3, :cond_9

    .line 145
    .line 146
    iget-boolean v5, v15, Lq/d;->l:Z

    .line 147
    .line 148
    if-eqz v5, :cond_14

    .line 149
    .line 150
    :cond_9
    if-eqz v3, :cond_d

    .line 151
    .line 152
    iget v3, v15, Lq/d;->Y:I

    .line 153
    .line 154
    invoke-virtual {v14, v13, v3}, Lo/d;->d(Lo/i;I)V

    .line 155
    .line 156
    .line 157
    iget v3, v15, Lq/d;->Y:I

    .line 158
    .line 159
    iget v5, v15, Lq/d;->U:I

    .line 160
    .line 161
    add-int/2addr v3, v5

    .line 162
    invoke-virtual {v14, v12, v3}, Lo/d;->d(Lo/i;I)V

    .line 163
    .line 164
    .line 165
    if-eqz v29, :cond_d

    .line 166
    .line 167
    iget-object v3, v15, Lq/d;->T:Lq/d;

    .line 168
    .line 169
    if-eqz v3, :cond_d

    .line 170
    .line 171
    check-cast v3, Lq/e;

    .line 172
    .line 173
    iget-object v5, v3, Lq/e;->H0:Ljava/lang/ref/WeakReference;

    .line 174
    .line 175
    if-eqz v5, :cond_a

    .line 176
    .line 177
    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v5

    .line 181
    if-eqz v5, :cond_a

    .line 182
    .line 183
    invoke-virtual {v0}, Lq/c;->d()I

    .line 184
    .line 185
    .line 186
    move-result v5

    .line 187
    iget-object v6, v3, Lq/e;->H0:Ljava/lang/ref/WeakReference;

    .line 188
    .line 189
    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v6

    .line 193
    check-cast v6, Lq/c;

    .line 194
    .line 195
    invoke-virtual {v6}, Lq/c;->d()I

    .line 196
    .line 197
    .line 198
    move-result v6

    .line 199
    if-le v5, v6, :cond_b

    .line 200
    .line 201
    :cond_a
    new-instance v5, Ljava/lang/ref/WeakReference;

    .line 202
    .line 203
    invoke-direct {v5, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    iput-object v5, v3, Lq/e;->H0:Ljava/lang/ref/WeakReference;

    .line 207
    .line 208
    :cond_b
    iget-object v5, v3, Lq/e;->J0:Ljava/lang/ref/WeakReference;

    .line 209
    .line 210
    if-eqz v5, :cond_c

    .line 211
    .line 212
    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v5

    .line 216
    if-eqz v5, :cond_c

    .line 217
    .line 218
    invoke-virtual {v1}, Lq/c;->d()I

    .line 219
    .line 220
    .line 221
    move-result v5

    .line 222
    iget-object v6, v3, Lq/e;->J0:Ljava/lang/ref/WeakReference;

    .line 223
    .line 224
    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    move-result-object v6

    .line 228
    check-cast v6, Lq/c;

    .line 229
    .line 230
    invoke-virtual {v6}, Lq/c;->d()I

    .line 231
    .line 232
    .line 233
    move-result v6

    .line 234
    if-le v5, v6, :cond_d

    .line 235
    .line 236
    :cond_c
    new-instance v5, Ljava/lang/ref/WeakReference;

    .line 237
    .line 238
    invoke-direct {v5, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 239
    .line 240
    .line 241
    iput-object v5, v3, Lq/e;->J0:Ljava/lang/ref/WeakReference;

    .line 242
    .line 243
    :cond_d
    iget-boolean v3, v15, Lq/d;->l:Z

    .line 244
    .line 245
    if-eqz v3, :cond_13

    .line 246
    .line 247
    iget v3, v15, Lq/d;->Z:I

    .line 248
    .line 249
    invoke-virtual {v14, v11, v3}, Lo/d;->d(Lo/i;I)V

    .line 250
    .line 251
    .line 252
    iget v3, v15, Lq/d;->Z:I

    .line 253
    .line 254
    iget v5, v15, Lq/d;->V:I

    .line 255
    .line 256
    add-int/2addr v3, v5

    .line 257
    invoke-virtual {v14, v9, v3}, Lo/d;->d(Lo/i;I)V

    .line 258
    .line 259
    .line 260
    iget-object v3, v8, Lq/c;->a:Ljava/util/HashSet;

    .line 261
    .line 262
    if-nez v3, :cond_e

    .line 263
    .line 264
    goto :goto_7

    .line 265
    :cond_e
    invoke-virtual {v3}, Ljava/util/HashSet;->size()I

    .line 266
    .line 267
    .line 268
    move-result v3

    .line 269
    if-lez v3, :cond_f

    .line 270
    .line 271
    iget v3, v15, Lq/d;->Z:I

    .line 272
    .line 273
    iget v5, v15, Lq/d;->a0:I

    .line 274
    .line 275
    add-int/2addr v3, v5

    .line 276
    invoke-virtual {v14, v7, v3}, Lo/d;->d(Lo/i;I)V

    .line 277
    .line 278
    .line 279
    :cond_f
    :goto_7
    if-eqz v28, :cond_13

    .line 280
    .line 281
    iget-object v3, v15, Lq/d;->T:Lq/d;

    .line 282
    .line 283
    if-eqz v3, :cond_13

    .line 284
    .line 285
    check-cast v3, Lq/e;

    .line 286
    .line 287
    iget-object v5, v3, Lq/e;->G0:Ljava/lang/ref/WeakReference;

    .line 288
    .line 289
    if-eqz v5, :cond_10

    .line 290
    .line 291
    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 292
    .line 293
    .line 294
    move-result-object v5

    .line 295
    if-eqz v5, :cond_10

    .line 296
    .line 297
    invoke-virtual {v2}, Lq/c;->d()I

    .line 298
    .line 299
    .line 300
    move-result v5

    .line 301
    iget-object v6, v3, Lq/e;->G0:Ljava/lang/ref/WeakReference;

    .line 302
    .line 303
    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v6

    .line 307
    check-cast v6, Lq/c;

    .line 308
    .line 309
    invoke-virtual {v6}, Lq/c;->d()I

    .line 310
    .line 311
    .line 312
    move-result v6

    .line 313
    if-le v5, v6, :cond_11

    .line 314
    .line 315
    :cond_10
    new-instance v5, Ljava/lang/ref/WeakReference;

    .line 316
    .line 317
    invoke-direct {v5, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    iput-object v5, v3, Lq/e;->G0:Ljava/lang/ref/WeakReference;

    .line 321
    .line 322
    :cond_11
    iget-object v5, v3, Lq/e;->I0:Ljava/lang/ref/WeakReference;

    .line 323
    .line 324
    if-eqz v5, :cond_12

    .line 325
    .line 326
    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 327
    .line 328
    .line 329
    move-result-object v5

    .line 330
    if-eqz v5, :cond_12

    .line 331
    .line 332
    invoke-virtual {v10}, Lq/c;->d()I

    .line 333
    .line 334
    .line 335
    move-result v5

    .line 336
    iget-object v6, v3, Lq/e;->I0:Ljava/lang/ref/WeakReference;

    .line 337
    .line 338
    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 339
    .line 340
    .line 341
    move-result-object v6

    .line 342
    check-cast v6, Lq/c;

    .line 343
    .line 344
    invoke-virtual {v6}, Lq/c;->d()I

    .line 345
    .line 346
    .line 347
    move-result v6

    .line 348
    if-le v5, v6, :cond_13

    .line 349
    .line 350
    :cond_12
    new-instance v5, Ljava/lang/ref/WeakReference;

    .line 351
    .line 352
    invoke-direct {v5, v10}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 353
    .line 354
    .line 355
    iput-object v5, v3, Lq/e;->I0:Ljava/lang/ref/WeakReference;

    .line 356
    .line 357
    :cond_13
    iget-boolean v3, v15, Lq/d;->k:Z

    .line 358
    .line 359
    if-eqz v3, :cond_14

    .line 360
    .line 361
    iget-boolean v3, v15, Lq/d;->l:Z

    .line 362
    .line 363
    if-eqz v3, :cond_14

    .line 364
    .line 365
    const/4 v3, 0x0

    .line 366
    iput-boolean v3, v15, Lq/d;->k:Z

    .line 367
    .line 368
    iput-boolean v3, v15, Lq/d;->l:Z

    .line 369
    .line 370
    return-void

    .line 371
    :cond_14
    iget-object v6, v15, Lq/d;->f:[Z

    .line 372
    .line 373
    if-eqz p2, :cond_18

    .line 374
    .line 375
    iget-object v3, v15, Lq/d;->d:Lr/k;

    .line 376
    .line 377
    if-eqz v3, :cond_18

    .line 378
    .line 379
    iget-object v5, v15, Lq/d;->e:Lr/m;

    .line 380
    .line 381
    if-eqz v5, :cond_18

    .line 382
    .line 383
    move-object/from16 v21, v4

    .line 384
    .line 385
    iget-object v4, v3, Lr/p;->h:Lr/f;

    .line 386
    .line 387
    move-object/from16 v22, v8

    .line 388
    .line 389
    iget-boolean v8, v4, Lr/f;->j:Z

    .line 390
    .line 391
    if-eqz v8, :cond_17

    .line 392
    .line 393
    iget-object v3, v3, Lr/p;->i:Lr/f;

    .line 394
    .line 395
    iget-boolean v3, v3, Lr/f;->j:Z

    .line 396
    .line 397
    if-eqz v3, :cond_17

    .line 398
    .line 399
    iget-object v3, v5, Lr/p;->h:Lr/f;

    .line 400
    .line 401
    iget-boolean v3, v3, Lr/f;->j:Z

    .line 402
    .line 403
    if-eqz v3, :cond_17

    .line 404
    .line 405
    iget-object v3, v5, Lr/p;->i:Lr/f;

    .line 406
    .line 407
    iget-boolean v3, v3, Lr/f;->j:Z

    .line 408
    .line 409
    if-eqz v3, :cond_17

    .line 410
    .line 411
    iget v0, v4, Lr/f;->g:I

    .line 412
    .line 413
    invoke-virtual {v14, v13, v0}, Lo/d;->d(Lo/i;I)V

    .line 414
    .line 415
    .line 416
    iget-object v0, v15, Lq/d;->d:Lr/k;

    .line 417
    .line 418
    iget-object v0, v0, Lr/p;->i:Lr/f;

    .line 419
    .line 420
    iget v0, v0, Lr/f;->g:I

    .line 421
    .line 422
    invoke-virtual {v14, v12, v0}, Lo/d;->d(Lo/i;I)V

    .line 423
    .line 424
    .line 425
    iget-object v0, v15, Lq/d;->e:Lr/m;

    .line 426
    .line 427
    iget-object v0, v0, Lr/p;->h:Lr/f;

    .line 428
    .line 429
    iget v0, v0, Lr/f;->g:I

    .line 430
    .line 431
    invoke-virtual {v14, v11, v0}, Lo/d;->d(Lo/i;I)V

    .line 432
    .line 433
    .line 434
    iget-object v0, v15, Lq/d;->e:Lr/m;

    .line 435
    .line 436
    iget-object v0, v0, Lr/p;->i:Lr/f;

    .line 437
    .line 438
    iget v0, v0, Lr/f;->g:I

    .line 439
    .line 440
    invoke-virtual {v14, v9, v0}, Lo/d;->d(Lo/i;I)V

    .line 441
    .line 442
    .line 443
    iget-object v0, v15, Lq/d;->e:Lr/m;

    .line 444
    .line 445
    iget-object v0, v0, Lr/m;->k:Lr/f;

    .line 446
    .line 447
    iget v0, v0, Lr/f;->g:I

    .line 448
    .line 449
    invoke-virtual {v14, v7, v0}, Lo/d;->d(Lo/i;I)V

    .line 450
    .line 451
    .line 452
    iget-object v0, v15, Lq/d;->T:Lq/d;

    .line 453
    .line 454
    if-eqz v0, :cond_16

    .line 455
    .line 456
    if-eqz v29, :cond_15

    .line 457
    .line 458
    const/4 v0, 0x0

    .line 459
    aget-boolean v1, v6, v0

    .line 460
    .line 461
    if-eqz v1, :cond_15

    .line 462
    .line 463
    invoke-virtual/range {p0 .. p0}, Lq/d;->y()Z

    .line 464
    .line 465
    .line 466
    move-result v1

    .line 467
    if-nez v1, :cond_15

    .line 468
    .line 469
    iget-object v1, v15, Lq/d;->T:Lq/d;

    .line 470
    .line 471
    iget-object v1, v1, Lq/d;->K:Lq/c;

    .line 472
    .line 473
    invoke-virtual {v14, v1}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 474
    .line 475
    .line 476
    move-result-object v1

    .line 477
    const/16 v2, 0x8

    .line 478
    .line 479
    invoke-virtual {v14, v1, v12, v0, v2}, Lo/d;->f(Lo/i;Lo/i;II)V

    .line 480
    .line 481
    .line 482
    :cond_15
    if-eqz v28, :cond_16

    .line 483
    .line 484
    const/4 v0, 0x1

    .line 485
    aget-boolean v0, v6, v0

    .line 486
    .line 487
    if-eqz v0, :cond_16

    .line 488
    .line 489
    invoke-virtual/range {p0 .. p0}, Lq/d;->z()Z

    .line 490
    .line 491
    .line 492
    move-result v0

    .line 493
    if-nez v0, :cond_16

    .line 494
    .line 495
    iget-object v0, v15, Lq/d;->T:Lq/d;

    .line 496
    .line 497
    iget-object v0, v0, Lq/d;->L:Lq/c;

    .line 498
    .line 499
    invoke-virtual {v14, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 500
    .line 501
    .line 502
    move-result-object v0

    .line 503
    const/16 v1, 0x8

    .line 504
    .line 505
    const/4 v3, 0x0

    .line 506
    invoke-virtual {v14, v0, v9, v3, v1}, Lo/d;->f(Lo/i;Lo/i;II)V

    .line 507
    .line 508
    .line 509
    goto :goto_8

    .line 510
    :cond_16
    const/4 v3, 0x0

    .line 511
    :goto_8
    iput-boolean v3, v15, Lq/d;->k:Z

    .line 512
    .line 513
    iput-boolean v3, v15, Lq/d;->l:Z

    .line 514
    .line 515
    return-void

    .line 516
    :cond_17
    :goto_9
    const/4 v3, 0x0

    .line 517
    goto :goto_a

    .line 518
    :cond_18
    move-object/from16 v21, v4

    .line 519
    .line 520
    move-object/from16 v22, v8

    .line 521
    .line 522
    goto :goto_9

    .line 523
    :goto_a
    iget-object v4, v15, Lq/d;->T:Lq/d;

    .line 524
    .line 525
    if-eqz v4, :cond_1d

    .line 526
    .line 527
    invoke-virtual {v15, v3}, Lq/d;->x(I)Z

    .line 528
    .line 529
    .line 530
    move-result v4

    .line 531
    if-eqz v4, :cond_19

    .line 532
    .line 533
    iget-object v4, v15, Lq/d;->T:Lq/d;

    .line 534
    .line 535
    check-cast v4, Lq/e;

    .line 536
    .line 537
    invoke-virtual {v4, v3, v15}, Lq/e;->T(ILq/d;)V

    .line 538
    .line 539
    .line 540
    const/4 v3, 0x1

    .line 541
    :goto_b
    const/4 v4, 0x1

    .line 542
    goto :goto_c

    .line 543
    :cond_19
    invoke-virtual/range {p0 .. p0}, Lq/d;->y()Z

    .line 544
    .line 545
    .line 546
    move-result v3

    .line 547
    goto :goto_b

    .line 548
    :goto_c
    invoke-virtual {v15, v4}, Lq/d;->x(I)Z

    .line 549
    .line 550
    .line 551
    move-result v5

    .line 552
    if-eqz v5, :cond_1a

    .line 553
    .line 554
    iget-object v5, v15, Lq/d;->T:Lq/d;

    .line 555
    .line 556
    check-cast v5, Lq/e;

    .line 557
    .line 558
    invoke-virtual {v5, v4, v15}, Lq/e;->T(ILq/d;)V

    .line 559
    .line 560
    .line 561
    const/4 v4, 0x1

    .line 562
    goto :goto_d

    .line 563
    :cond_1a
    invoke-virtual/range {p0 .. p0}, Lq/d;->z()Z

    .line 564
    .line 565
    .line 566
    move-result v4

    .line 567
    :goto_d
    if-nez v3, :cond_1b

    .line 568
    .line 569
    if-eqz v29, :cond_1b

    .line 570
    .line 571
    iget v5, v15, Lq/d;->g0:I

    .line 572
    .line 573
    const/16 v8, 0x8

    .line 574
    .line 575
    if-eq v5, v8, :cond_1b

    .line 576
    .line 577
    iget-object v5, v0, Lq/c;->f:Lq/c;

    .line 578
    .line 579
    if-nez v5, :cond_1b

    .line 580
    .line 581
    iget-object v5, v1, Lq/c;->f:Lq/c;

    .line 582
    .line 583
    if-nez v5, :cond_1b

    .line 584
    .line 585
    iget-object v5, v15, Lq/d;->T:Lq/d;

    .line 586
    .line 587
    iget-object v5, v5, Lq/d;->K:Lq/c;

    .line 588
    .line 589
    invoke-virtual {v14, v5}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 590
    .line 591
    .line 592
    move-result-object v5

    .line 593
    move/from16 v23, v3

    .line 594
    .line 595
    const/4 v3, 0x0

    .line 596
    const/4 v8, 0x1

    .line 597
    invoke-virtual {v14, v5, v12, v3, v8}, Lo/d;->f(Lo/i;Lo/i;II)V

    .line 598
    .line 599
    .line 600
    goto :goto_e

    .line 601
    :cond_1b
    move/from16 v23, v3

    .line 602
    .line 603
    :goto_e
    if-nez v4, :cond_1c

    .line 604
    .line 605
    if-eqz v28, :cond_1c

    .line 606
    .line 607
    iget v3, v15, Lq/d;->g0:I

    .line 608
    .line 609
    const/16 v5, 0x8

    .line 610
    .line 611
    if-eq v3, v5, :cond_1c

    .line 612
    .line 613
    iget-object v3, v2, Lq/c;->f:Lq/c;

    .line 614
    .line 615
    if-nez v3, :cond_1c

    .line 616
    .line 617
    iget-object v3, v10, Lq/c;->f:Lq/c;

    .line 618
    .line 619
    if-nez v3, :cond_1c

    .line 620
    .line 621
    if-nez v22, :cond_1c

    .line 622
    .line 623
    iget-object v3, v15, Lq/d;->T:Lq/d;

    .line 624
    .line 625
    iget-object v3, v3, Lq/d;->L:Lq/c;

    .line 626
    .line 627
    invoke-virtual {v14, v3}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 628
    .line 629
    .line 630
    move-result-object v3

    .line 631
    const/4 v5, 0x1

    .line 632
    const/4 v8, 0x0

    .line 633
    invoke-virtual {v14, v3, v9, v8, v5}, Lo/d;->f(Lo/i;Lo/i;II)V

    .line 634
    .line 635
    .line 636
    :cond_1c
    move/from16 v30, v4

    .line 637
    .line 638
    move/from16 v31, v23

    .line 639
    .line 640
    goto :goto_f

    .line 641
    :cond_1d
    const/16 v30, 0x0

    .line 642
    .line 643
    const/16 v31, 0x0

    .line 644
    .line 645
    :goto_f
    iget v3, v15, Lq/d;->U:I

    .line 646
    .line 647
    iget v4, v15, Lq/d;->b0:I

    .line 648
    .line 649
    if-ge v3, v4, :cond_1e

    .line 650
    .line 651
    goto :goto_10

    .line 652
    :cond_1e
    move v4, v3

    .line 653
    :goto_10
    iget v5, v15, Lq/d;->V:I

    .line 654
    .line 655
    iget v8, v15, Lq/d;->c0:I

    .line 656
    .line 657
    if-ge v5, v8, :cond_1f

    .line 658
    .line 659
    :goto_11
    move-object/from16 v23, v11

    .line 660
    .line 661
    goto :goto_12

    .line 662
    :cond_1f
    move v8, v5

    .line 663
    goto :goto_11

    .line 664
    :goto_12
    iget-object v11, v15, Lq/d;->p0:[I

    .line 665
    .line 666
    move/from16 v24, v4

    .line 667
    .line 668
    const/16 v19, 0x0

    .line 669
    .line 670
    aget v4, v11, v19

    .line 671
    .line 672
    move-object/from16 v27, v7

    .line 673
    .line 674
    const/4 v7, 0x3

    .line 675
    move/from16 v26, v8

    .line 676
    .line 677
    const/16 v16, 0x1

    .line 678
    .line 679
    if-eq v4, v7, :cond_20

    .line 680
    .line 681
    const/16 v25, 0x1

    .line 682
    .line 683
    goto :goto_13

    .line 684
    :cond_20
    const/16 v25, 0x0

    .line 685
    .line 686
    :goto_13
    aget v8, v11, v16

    .line 687
    .line 688
    move-object/from16 v32, v9

    .line 689
    .line 690
    if-eq v8, v7, :cond_21

    .line 691
    .line 692
    const/4 v7, 0x1

    .line 693
    goto :goto_14

    .line 694
    :cond_21
    const/4 v7, 0x0

    .line 695
    :goto_14
    iget v9, v15, Lq/d;->X:I

    .line 696
    .line 697
    iput v9, v15, Lq/d;->A:I

    .line 698
    .line 699
    move-object/from16 v33, v6

    .line 700
    .line 701
    iget v6, v15, Lq/d;->W:F

    .line 702
    .line 703
    iput v6, v15, Lq/d;->B:F

    .line 704
    .line 705
    move-object/from16 v34, v12

    .line 706
    .line 707
    iget v12, v15, Lq/d;->r:I

    .line 708
    .line 709
    move-object/from16 v35, v13

    .line 710
    .line 711
    iget v13, v15, Lq/d;->s:I

    .line 712
    .line 713
    const/16 v36, 0x0

    .line 714
    .line 715
    cmpl-float v36, v6, v36

    .line 716
    .line 717
    if-lez v36, :cond_35

    .line 718
    .line 719
    iget v14, v15, Lq/d;->g0:I

    .line 720
    .line 721
    move-object/from16 v39, v11

    .line 722
    .line 723
    const/16 v11, 0x8

    .line 724
    .line 725
    if-eq v14, v11, :cond_34

    .line 726
    .line 727
    const/4 v11, 0x3

    .line 728
    if-ne v4, v11, :cond_22

    .line 729
    .line 730
    if-nez v12, :cond_22

    .line 731
    .line 732
    move v12, v11

    .line 733
    :cond_22
    if-ne v8, v11, :cond_23

    .line 734
    .line 735
    if-nez v13, :cond_23

    .line 736
    .line 737
    move v13, v11

    .line 738
    :cond_23
    if-ne v4, v11, :cond_2f

    .line 739
    .line 740
    if-ne v8, v11, :cond_2f

    .line 741
    .line 742
    if-ne v12, v11, :cond_2f

    .line 743
    .line 744
    if-ne v13, v11, :cond_2f

    .line 745
    .line 746
    const/4 v11, -0x1

    .line 747
    if-ne v9, v11, :cond_25

    .line 748
    .line 749
    if-eqz v25, :cond_24

    .line 750
    .line 751
    if-nez v7, :cond_24

    .line 752
    .line 753
    const/4 v3, 0x0

    .line 754
    iput v3, v15, Lq/d;->A:I

    .line 755
    .line 756
    goto :goto_15

    .line 757
    :cond_24
    if-nez v25, :cond_25

    .line 758
    .line 759
    if-eqz v7, :cond_25

    .line 760
    .line 761
    const/4 v3, 0x1

    .line 762
    iput v3, v15, Lq/d;->A:I

    .line 763
    .line 764
    if-ne v9, v11, :cond_25

    .line 765
    .line 766
    const/high16 v3, 0x3f800000    # 1.0f

    .line 767
    .line 768
    div-float v14, v3, v6

    .line 769
    .line 770
    iput v14, v15, Lq/d;->B:F

    .line 771
    .line 772
    :cond_25
    :goto_15
    iget v3, v15, Lq/d;->A:I

    .line 773
    .line 774
    if-nez v3, :cond_27

    .line 775
    .line 776
    invoke-virtual {v2}, Lq/c;->h()Z

    .line 777
    .line 778
    .line 779
    move-result v3

    .line 780
    if-eqz v3, :cond_26

    .line 781
    .line 782
    invoke-virtual {v10}, Lq/c;->h()Z

    .line 783
    .line 784
    .line 785
    move-result v3

    .line 786
    if-nez v3, :cond_27

    .line 787
    .line 788
    :cond_26
    const/4 v3, 0x1

    .line 789
    goto :goto_16

    .line 790
    :cond_27
    const/4 v3, 0x1

    .line 791
    goto :goto_17

    .line 792
    :goto_16
    iput v3, v15, Lq/d;->A:I

    .line 793
    .line 794
    goto :goto_18

    .line 795
    :goto_17
    iget v4, v15, Lq/d;->A:I

    .line 796
    .line 797
    if-ne v4, v3, :cond_29

    .line 798
    .line 799
    invoke-virtual {v0}, Lq/c;->h()Z

    .line 800
    .line 801
    .line 802
    move-result v3

    .line 803
    if-eqz v3, :cond_28

    .line 804
    .line 805
    invoke-virtual {v1}, Lq/c;->h()Z

    .line 806
    .line 807
    .line 808
    move-result v3

    .line 809
    if-nez v3, :cond_29

    .line 810
    .line 811
    :cond_28
    const/4 v3, 0x0

    .line 812
    goto :goto_16

    .line 813
    :cond_29
    :goto_18
    iget v3, v15, Lq/d;->A:I

    .line 814
    .line 815
    const/4 v4, -0x1

    .line 816
    if-ne v3, v4, :cond_2c

    .line 817
    .line 818
    invoke-virtual {v2}, Lq/c;->h()Z

    .line 819
    .line 820
    .line 821
    move-result v3

    .line 822
    if-eqz v3, :cond_2a

    .line 823
    .line 824
    invoke-virtual {v10}, Lq/c;->h()Z

    .line 825
    .line 826
    .line 827
    move-result v3

    .line 828
    if-eqz v3, :cond_2a

    .line 829
    .line 830
    invoke-virtual {v0}, Lq/c;->h()Z

    .line 831
    .line 832
    .line 833
    move-result v3

    .line 834
    if-eqz v3, :cond_2a

    .line 835
    .line 836
    invoke-virtual {v1}, Lq/c;->h()Z

    .line 837
    .line 838
    .line 839
    move-result v3

    .line 840
    if-nez v3, :cond_2c

    .line 841
    .line 842
    :cond_2a
    invoke-virtual {v2}, Lq/c;->h()Z

    .line 843
    .line 844
    .line 845
    move-result v2

    .line 846
    if-eqz v2, :cond_2b

    .line 847
    .line 848
    invoke-virtual {v10}, Lq/c;->h()Z

    .line 849
    .line 850
    .line 851
    move-result v2

    .line 852
    if-eqz v2, :cond_2b

    .line 853
    .line 854
    const/4 v2, 0x0

    .line 855
    iput v2, v15, Lq/d;->A:I

    .line 856
    .line 857
    goto :goto_19

    .line 858
    :cond_2b
    invoke-virtual {v0}, Lq/c;->h()Z

    .line 859
    .line 860
    .line 861
    move-result v0

    .line 862
    if-eqz v0, :cond_2c

    .line 863
    .line 864
    invoke-virtual {v1}, Lq/c;->h()Z

    .line 865
    .line 866
    .line 867
    move-result v0

    .line 868
    if-eqz v0, :cond_2c

    .line 869
    .line 870
    iget v0, v15, Lq/d;->B:F

    .line 871
    .line 872
    const/high16 v1, 0x3f800000    # 1.0f

    .line 873
    .line 874
    div-float v14, v1, v0

    .line 875
    .line 876
    iput v14, v15, Lq/d;->B:F

    .line 877
    .line 878
    const/4 v0, 0x1

    .line 879
    iput v0, v15, Lq/d;->A:I

    .line 880
    .line 881
    :cond_2c
    :goto_19
    iget v0, v15, Lq/d;->A:I

    .line 882
    .line 883
    const/4 v1, -0x1

    .line 884
    if-ne v0, v1, :cond_2e

    .line 885
    .line 886
    iget v0, v15, Lq/d;->u:I

    .line 887
    .line 888
    if-lez v0, :cond_2d

    .line 889
    .line 890
    iget v1, v15, Lq/d;->x:I

    .line 891
    .line 892
    if-nez v1, :cond_2d

    .line 893
    .line 894
    const/4 v1, 0x0

    .line 895
    iput v1, v15, Lq/d;->A:I

    .line 896
    .line 897
    goto :goto_1a

    .line 898
    :cond_2d
    if-nez v0, :cond_2e

    .line 899
    .line 900
    iget v0, v15, Lq/d;->x:I

    .line 901
    .line 902
    if-lez v0, :cond_2e

    .line 903
    .line 904
    iget v0, v15, Lq/d;->B:F

    .line 905
    .line 906
    const/high16 v1, 0x3f800000    # 1.0f

    .line 907
    .line 908
    div-float v14, v1, v0

    .line 909
    .line 910
    iput v14, v15, Lq/d;->B:F

    .line 911
    .line 912
    const/4 v0, 0x1

    .line 913
    iput v0, v15, Lq/d;->A:I

    .line 914
    .line 915
    :cond_2e
    :goto_1a
    const/high16 v14, 0x3f800000    # 1.0f

    .line 916
    .line 917
    goto :goto_1c

    .line 918
    :cond_2f
    move v0, v11

    .line 919
    if-ne v4, v0, :cond_31

    .line 920
    .line 921
    if-ne v12, v0, :cond_31

    .line 922
    .line 923
    const/4 v1, 0x0

    .line 924
    iput v1, v15, Lq/d;->A:I

    .line 925
    .line 926
    int-to-float v1, v5

    .line 927
    mul-float/2addr v6, v1

    .line 928
    float-to-int v4, v6

    .line 929
    if-eq v8, v0, :cond_30

    .line 930
    .line 931
    move/from16 v41, v13

    .line 932
    .line 933
    move/from16 v40, v26

    .line 934
    .line 935
    const/high16 v14, 0x3f800000    # 1.0f

    .line 936
    .line 937
    const/16 v38, 0x0

    .line 938
    .line 939
    const/16 v42, 0x4

    .line 940
    .line 941
    goto :goto_1f

    .line 942
    :cond_30
    move/from16 v42, v12

    .line 943
    .line 944
    move/from16 v41, v13

    .line 945
    .line 946
    move/from16 v40, v26

    .line 947
    .line 948
    const/high16 v14, 0x3f800000    # 1.0f

    .line 949
    .line 950
    :goto_1b
    const/16 v38, 0x1

    .line 951
    .line 952
    goto :goto_1f

    .line 953
    :cond_31
    if-ne v8, v0, :cond_2e

    .line 954
    .line 955
    if-ne v13, v0, :cond_2e

    .line 956
    .line 957
    const/4 v1, 0x1

    .line 958
    iput v1, v15, Lq/d;->A:I

    .line 959
    .line 960
    const/4 v1, -0x1

    .line 961
    const/high16 v14, 0x3f800000    # 1.0f

    .line 962
    .line 963
    if-ne v9, v1, :cond_32

    .line 964
    .line 965
    div-float v1, v14, v6

    .line 966
    .line 967
    iput v1, v15, Lq/d;->B:F

    .line 968
    .line 969
    :cond_32
    iget v1, v15, Lq/d;->B:F

    .line 970
    .line 971
    int-to-float v2, v3

    .line 972
    mul-float/2addr v1, v2

    .line 973
    float-to-int v8, v1

    .line 974
    move/from16 v40, v8

    .line 975
    .line 976
    move/from16 v42, v12

    .line 977
    .line 978
    if-eq v4, v0, :cond_33

    .line 979
    .line 980
    move/from16 v4, v24

    .line 981
    .line 982
    const/16 v38, 0x0

    .line 983
    .line 984
    const/16 v41, 0x4

    .line 985
    .line 986
    goto :goto_1f

    .line 987
    :cond_33
    move/from16 v41, v13

    .line 988
    .line 989
    move/from16 v4, v24

    .line 990
    .line 991
    goto :goto_1b

    .line 992
    :goto_1c
    move/from16 v42, v12

    .line 993
    .line 994
    move/from16 v41, v13

    .line 995
    .line 996
    move/from16 v4, v24

    .line 997
    .line 998
    move/from16 v40, v26

    .line 999
    .line 1000
    goto :goto_1b

    .line 1001
    :cond_34
    :goto_1d
    const/high16 v14, 0x3f800000    # 1.0f

    .line 1002
    .line 1003
    goto :goto_1e

    .line 1004
    :cond_35
    move-object/from16 v39, v11

    .line 1005
    .line 1006
    goto :goto_1d

    .line 1007
    :goto_1e
    move/from16 v42, v12

    .line 1008
    .line 1009
    move/from16 v41, v13

    .line 1010
    .line 1011
    move/from16 v4, v24

    .line 1012
    .line 1013
    move/from16 v40, v26

    .line 1014
    .line 1015
    const/16 v38, 0x0

    .line 1016
    .line 1017
    :goto_1f
    iget-object v0, v15, Lq/d;->t:[I

    .line 1018
    .line 1019
    const/4 v1, 0x0

    .line 1020
    aput v42, v0, v1

    .line 1021
    .line 1022
    const/4 v1, 0x1

    .line 1023
    aput v41, v0, v1

    .line 1024
    .line 1025
    if-eqz v38, :cond_37

    .line 1026
    .line 1027
    iget v0, v15, Lq/d;->A:I

    .line 1028
    .line 1029
    const/4 v1, -0x1

    .line 1030
    if-eqz v0, :cond_36

    .line 1031
    .line 1032
    if-ne v0, v1, :cond_38

    .line 1033
    .line 1034
    :cond_36
    const/16 v36, 0x1

    .line 1035
    .line 1036
    goto :goto_20

    .line 1037
    :cond_37
    const/4 v1, -0x1

    .line 1038
    :cond_38
    const/16 v36, 0x0

    .line 1039
    .line 1040
    :goto_20
    if-eqz v38, :cond_3a

    .line 1041
    .line 1042
    iget v0, v15, Lq/d;->A:I

    .line 1043
    .line 1044
    const/4 v2, 0x1

    .line 1045
    if-eq v0, v2, :cond_39

    .line 1046
    .line 1047
    if-ne v0, v1, :cond_3a

    .line 1048
    .line 1049
    :cond_39
    const/4 v0, 0x0

    .line 1050
    const/16 v43, 0x1

    .line 1051
    .line 1052
    goto :goto_21

    .line 1053
    :cond_3a
    const/4 v0, 0x0

    .line 1054
    const/16 v43, 0x0

    .line 1055
    .line 1056
    :goto_21
    aget v1, v39, v0

    .line 1057
    .line 1058
    const/4 v0, 0x2

    .line 1059
    if-ne v1, v0, :cond_3b

    .line 1060
    .line 1061
    instance-of v0, v15, Lq/e;

    .line 1062
    .line 1063
    if-eqz v0, :cond_3b

    .line 1064
    .line 1065
    const/4 v9, 0x1

    .line 1066
    goto :goto_22

    .line 1067
    :cond_3b
    const/4 v9, 0x0

    .line 1068
    :goto_22
    if-eqz v9, :cond_3c

    .line 1069
    .line 1070
    const/4 v13, 0x0

    .line 1071
    goto :goto_23

    .line 1072
    :cond_3c
    move v13, v4

    .line 1073
    :goto_23
    iget-object v12, v15, Lq/d;->P:Lq/c;

    .line 1074
    .line 1075
    invoke-virtual {v12}, Lq/c;->h()Z

    .line 1076
    .line 1077
    .line 1078
    move-result v0

    .line 1079
    const/4 v1, 0x1

    .line 1080
    xor-int/lit8 v44, v0, 0x1

    .line 1081
    .line 1082
    const/4 v0, 0x0

    .line 1083
    aget-boolean v45, v21, v0

    .line 1084
    .line 1085
    aget-boolean v46, v21, v1

    .line 1086
    .line 1087
    iget v0, v15, Lq/d;->o:I

    .line 1088
    .line 1089
    iget-object v11, v15, Lq/d;->C:[I

    .line 1090
    .line 1091
    const/16 v47, 0x0

    .line 1092
    .line 1093
    const/4 v6, 0x2

    .line 1094
    if-eq v0, v6, :cond_41

    .line 1095
    .line 1096
    iget-boolean v0, v15, Lq/d;->k:Z

    .line 1097
    .line 1098
    if-nez v0, :cond_41

    .line 1099
    .line 1100
    if-eqz p2, :cond_3d

    .line 1101
    .line 1102
    iget-object v0, v15, Lq/d;->d:Lr/k;

    .line 1103
    .line 1104
    if-eqz v0, :cond_3d

    .line 1105
    .line 1106
    iget-object v1, v0, Lr/p;->h:Lr/f;

    .line 1107
    .line 1108
    iget-boolean v2, v1, Lr/f;->j:Z

    .line 1109
    .line 1110
    if-eqz v2, :cond_3d

    .line 1111
    .line 1112
    iget-object v0, v0, Lr/p;->i:Lr/f;

    .line 1113
    .line 1114
    iget-boolean v0, v0, Lr/f;->j:Z

    .line 1115
    .line 1116
    if-nez v0, :cond_3e

    .line 1117
    .line 1118
    :cond_3d
    move-object/from16 v8, p1

    .line 1119
    .line 1120
    move-object/from16 v4, v34

    .line 1121
    .line 1122
    move-object/from16 v7, v35

    .line 1123
    .line 1124
    const/16 v3, 0x8

    .line 1125
    .line 1126
    const/4 v5, 0x4

    .line 1127
    goto/16 :goto_25

    .line 1128
    .line 1129
    :cond_3e
    if-eqz p2, :cond_40

    .line 1130
    .line 1131
    iget v0, v1, Lr/f;->g:I

    .line 1132
    .line 1133
    move-object/from16 v8, p1

    .line 1134
    .line 1135
    move-object/from16 v7, v35

    .line 1136
    .line 1137
    const/4 v5, 0x4

    .line 1138
    invoke-virtual {v8, v7, v0}, Lo/d;->d(Lo/i;I)V

    .line 1139
    .line 1140
    .line 1141
    iget-object v0, v15, Lq/d;->d:Lr/k;

    .line 1142
    .line 1143
    iget-object v0, v0, Lr/p;->i:Lr/f;

    .line 1144
    .line 1145
    iget v0, v0, Lr/f;->g:I

    .line 1146
    .line 1147
    move-object/from16 v4, v34

    .line 1148
    .line 1149
    invoke-virtual {v8, v4, v0}, Lo/d;->d(Lo/i;I)V

    .line 1150
    .line 1151
    .line 1152
    iget-object v0, v15, Lq/d;->T:Lq/d;

    .line 1153
    .line 1154
    if-eqz v0, :cond_3f

    .line 1155
    .line 1156
    if-eqz v29, :cond_3f

    .line 1157
    .line 1158
    const/4 v0, 0x0

    .line 1159
    aget-boolean v1, v33, v0

    .line 1160
    .line 1161
    if-eqz v1, :cond_3f

    .line 1162
    .line 1163
    invoke-virtual/range {p0 .. p0}, Lq/d;->y()Z

    .line 1164
    .line 1165
    .line 1166
    move-result v1

    .line 1167
    if-nez v1, :cond_3f

    .line 1168
    .line 1169
    iget-object v1, v15, Lq/d;->T:Lq/d;

    .line 1170
    .line 1171
    iget-object v1, v1, Lq/d;->K:Lq/c;

    .line 1172
    .line 1173
    invoke-virtual {v8, v1}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1174
    .line 1175
    .line 1176
    move-result-object v1

    .line 1177
    const/16 v3, 0x8

    .line 1178
    .line 1179
    invoke-virtual {v8, v1, v4, v0, v3}, Lo/d;->f(Lo/i;Lo/i;II)V

    .line 1180
    .line 1181
    .line 1182
    :cond_3f
    move-object/from16 v58, v4

    .line 1183
    .line 1184
    move-object/from16 v59, v7

    .line 1185
    .line 1186
    move-object/from16 v56, v10

    .line 1187
    .line 1188
    move-object/from16 v34, v11

    .line 1189
    .line 1190
    move-object/from16 v54, v22

    .line 1191
    .line 1192
    move-object/from16 v57, v23

    .line 1193
    .line 1194
    move-object/from16 v53, v27

    .line 1195
    .line 1196
    move-object/from16 v55, v32

    .line 1197
    .line 1198
    move-object/from16 v32, v39

    .line 1199
    .line 1200
    :goto_24
    move-object/from16 v39, v12

    .line 1201
    .line 1202
    goto/16 :goto_29

    .line 1203
    .line 1204
    :cond_40
    move-object/from16 v8, p1

    .line 1205
    .line 1206
    :cond_41
    move-object/from16 v56, v10

    .line 1207
    .line 1208
    move-object/from16 v54, v22

    .line 1209
    .line 1210
    move-object/from16 v57, v23

    .line 1211
    .line 1212
    move-object/from16 v53, v27

    .line 1213
    .line 1214
    move-object/from16 v55, v32

    .line 1215
    .line 1216
    move-object/from16 v58, v34

    .line 1217
    .line 1218
    move-object/from16 v59, v35

    .line 1219
    .line 1220
    move-object/from16 v32, v39

    .line 1221
    .line 1222
    move-object/from16 v34, v11

    .line 1223
    .line 1224
    goto :goto_24

    .line 1225
    :goto_25
    iget-object v0, v15, Lq/d;->T:Lq/d;

    .line 1226
    .line 1227
    if-eqz v0, :cond_42

    .line 1228
    .line 1229
    iget-object v0, v0, Lq/d;->K:Lq/c;

    .line 1230
    .line 1231
    invoke-virtual {v8, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1232
    .line 1233
    .line 1234
    move-result-object v0

    .line 1235
    move-object/from16 v18, v0

    .line 1236
    .line 1237
    goto :goto_26

    .line 1238
    :cond_42
    move-object/from16 v18, v47

    .line 1239
    .line 1240
    :goto_26
    iget-object v0, v15, Lq/d;->T:Lq/d;

    .line 1241
    .line 1242
    if-eqz v0, :cond_43

    .line 1243
    .line 1244
    iget-object v0, v0, Lq/d;->I:Lq/c;

    .line 1245
    .line 1246
    invoke-virtual {v8, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1247
    .line 1248
    .line 1249
    move-result-object v0

    .line 1250
    move-object/from16 v20, v0

    .line 1251
    .line 1252
    goto :goto_27

    .line 1253
    :cond_43
    move-object/from16 v20, v47

    .line 1254
    .line 1255
    :goto_27
    const/16 v19, 0x0

    .line 1256
    .line 1257
    aget-boolean v21, v33, v19

    .line 1258
    .line 1259
    aget v34, v39, v19

    .line 1260
    .line 1261
    iget-object v1, v15, Lq/d;->I:Lq/c;

    .line 1262
    .line 1263
    iget-object v0, v15, Lq/d;->K:Lq/c;

    .line 1264
    .line 1265
    iget v14, v15, Lq/d;->Y:I

    .line 1266
    .line 1267
    iget v2, v15, Lq/d;->b0:I

    .line 1268
    .line 1269
    aget v48, v11, v19

    .line 1270
    .line 1271
    move/from16 v49, v2

    .line 1272
    .line 1273
    iget v2, v15, Lq/d;->d0:F

    .line 1274
    .line 1275
    const/16 v17, 0x1

    .line 1276
    .line 1277
    aget v3, v39, v17

    .line 1278
    .line 1279
    const/4 v5, 0x3

    .line 1280
    if-ne v3, v5, :cond_44

    .line 1281
    .line 1282
    move/from16 v51, v17

    .line 1283
    .line 1284
    goto :goto_28

    .line 1285
    :cond_44
    move/from16 v51, v19

    .line 1286
    .line 1287
    :goto_28
    iget v3, v15, Lq/d;->u:I

    .line 1288
    .line 1289
    move/from16 v24, v3

    .line 1290
    .line 1291
    iget v3, v15, Lq/d;->v:I

    .line 1292
    .line 1293
    move/from16 v25, v3

    .line 1294
    .line 1295
    iget v3, v15, Lq/d;->w:F

    .line 1296
    .line 1297
    move/from16 v26, v3

    .line 1298
    .line 1299
    move-object/from16 v16, v0

    .line 1300
    .line 1301
    move-object/from16 v0, p0

    .line 1302
    .line 1303
    move-object/from16 v52, v1

    .line 1304
    .line 1305
    move-object/from16 v1, p1

    .line 1306
    .line 1307
    move/from16 v37, v49

    .line 1308
    .line 1309
    move/from16 v49, v2

    .line 1310
    .line 1311
    const/4 v2, 0x1

    .line 1312
    const/16 v50, 0x8

    .line 1313
    .line 1314
    move/from16 v3, v29

    .line 1315
    .line 1316
    move-object/from16 v17, v4

    .line 1317
    .line 1318
    move/from16 v4, v28

    .line 1319
    .line 1320
    move/from16 v5, v21

    .line 1321
    .line 1322
    move-object/from16 v6, v20

    .line 1323
    .line 1324
    move-object/from16 v19, v7

    .line 1325
    .line 1326
    move-object/from16 v53, v27

    .line 1327
    .line 1328
    move-object/from16 v7, v18

    .line 1329
    .line 1330
    move-object/from16 v54, v22

    .line 1331
    .line 1332
    move/from16 v8, v34

    .line 1333
    .line 1334
    move-object/from16 v55, v32

    .line 1335
    .line 1336
    move-object/from16 v56, v10

    .line 1337
    .line 1338
    move-object/from16 v10, v52

    .line 1339
    .line 1340
    move-object/from16 v34, v11

    .line 1341
    .line 1342
    move-object/from16 v57, v23

    .line 1343
    .line 1344
    move-object/from16 v32, v39

    .line 1345
    .line 1346
    move-object/from16 v11, v16

    .line 1347
    .line 1348
    move-object/from16 v39, v12

    .line 1349
    .line 1350
    move-object/from16 v58, v17

    .line 1351
    .line 1352
    move v12, v14

    .line 1353
    move-object/from16 v14, v19

    .line 1354
    .line 1355
    move-object/from16 v59, v14

    .line 1356
    .line 1357
    move/from16 v14, v37

    .line 1358
    .line 1359
    move/from16 v15, v48

    .line 1360
    .line 1361
    move/from16 v16, v49

    .line 1362
    .line 1363
    move/from16 v17, v36

    .line 1364
    .line 1365
    move/from16 v18, v51

    .line 1366
    .line 1367
    move/from16 v19, v31

    .line 1368
    .line 1369
    move/from16 v20, v30

    .line 1370
    .line 1371
    move/from16 v21, v45

    .line 1372
    .line 1373
    move/from16 v22, v42

    .line 1374
    .line 1375
    move/from16 v23, v41

    .line 1376
    .line 1377
    move/from16 v27, v44

    .line 1378
    .line 1379
    invoke-virtual/range {v0 .. v27}, Lq/d;->e(Lo/d;ZZZZLo/i;Lo/i;IZLq/c;Lq/c;IIIIFZZZZZIIIIFZ)V

    .line 1380
    .line 1381
    .line 1382
    :goto_29
    if-eqz p2, :cond_48

    .line 1383
    .line 1384
    move-object/from16 v15, p0

    .line 1385
    .line 1386
    iget-object v0, v15, Lq/d;->e:Lr/m;

    .line 1387
    .line 1388
    if-eqz v0, :cond_47

    .line 1389
    .line 1390
    iget-object v1, v0, Lr/p;->h:Lr/f;

    .line 1391
    .line 1392
    iget-boolean v2, v1, Lr/f;->j:Z

    .line 1393
    .line 1394
    if-eqz v2, :cond_47

    .line 1395
    .line 1396
    iget-object v0, v0, Lr/p;->i:Lr/f;

    .line 1397
    .line 1398
    iget-boolean v0, v0, Lr/f;->j:Z

    .line 1399
    .line 1400
    if-eqz v0, :cond_47

    .line 1401
    .line 1402
    iget v0, v1, Lr/f;->g:I

    .line 1403
    .line 1404
    move-object/from16 v14, p1

    .line 1405
    .line 1406
    move-object/from16 v13, v57

    .line 1407
    .line 1408
    invoke-virtual {v14, v13, v0}, Lo/d;->d(Lo/i;I)V

    .line 1409
    .line 1410
    .line 1411
    iget-object v0, v15, Lq/d;->e:Lr/m;

    .line 1412
    .line 1413
    iget-object v0, v0, Lr/p;->i:Lr/f;

    .line 1414
    .line 1415
    iget v0, v0, Lr/f;->g:I

    .line 1416
    .line 1417
    move-object/from16 v12, v55

    .line 1418
    .line 1419
    invoke-virtual {v14, v12, v0}, Lo/d;->d(Lo/i;I)V

    .line 1420
    .line 1421
    .line 1422
    iget-object v0, v15, Lq/d;->e:Lr/m;

    .line 1423
    .line 1424
    iget-object v0, v0, Lr/m;->k:Lr/f;

    .line 1425
    .line 1426
    iget v0, v0, Lr/f;->g:I

    .line 1427
    .line 1428
    move-object/from16 v1, v53

    .line 1429
    .line 1430
    invoke-virtual {v14, v1, v0}, Lo/d;->d(Lo/i;I)V

    .line 1431
    .line 1432
    .line 1433
    iget-object v0, v15, Lq/d;->T:Lq/d;

    .line 1434
    .line 1435
    if-eqz v0, :cond_46

    .line 1436
    .line 1437
    if-nez v30, :cond_46

    .line 1438
    .line 1439
    if-eqz v28, :cond_46

    .line 1440
    .line 1441
    const/4 v11, 0x1

    .line 1442
    aget-boolean v2, v33, v11

    .line 1443
    .line 1444
    if-eqz v2, :cond_45

    .line 1445
    .line 1446
    iget-object v0, v0, Lq/d;->L:Lq/c;

    .line 1447
    .line 1448
    invoke-virtual {v14, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1449
    .line 1450
    .line 1451
    move-result-object v0

    .line 1452
    const/16 v2, 0x8

    .line 1453
    .line 1454
    const/4 v10, 0x0

    .line 1455
    invoke-virtual {v14, v0, v12, v10, v2}, Lo/d;->f(Lo/i;Lo/i;II)V

    .line 1456
    .line 1457
    .line 1458
    goto :goto_2a

    .line 1459
    :cond_45
    const/16 v2, 0x8

    .line 1460
    .line 1461
    const/4 v10, 0x0

    .line 1462
    goto :goto_2a

    .line 1463
    :cond_46
    const/16 v2, 0x8

    .line 1464
    .line 1465
    const/4 v10, 0x0

    .line 1466
    const/4 v11, 0x1

    .line 1467
    :goto_2a
    move v4, v10

    .line 1468
    goto :goto_2c

    .line 1469
    :cond_47
    move-object/from16 v14, p1

    .line 1470
    .line 1471
    move-object/from16 v1, v53

    .line 1472
    .line 1473
    move-object/from16 v12, v55

    .line 1474
    .line 1475
    move-object/from16 v13, v57

    .line 1476
    .line 1477
    const/16 v2, 0x8

    .line 1478
    .line 1479
    const/4 v10, 0x0

    .line 1480
    const/4 v11, 0x1

    .line 1481
    goto :goto_2b

    .line 1482
    :cond_48
    const/16 v2, 0x8

    .line 1483
    .line 1484
    const/4 v10, 0x0

    .line 1485
    const/4 v11, 0x1

    .line 1486
    move-object/from16 v15, p0

    .line 1487
    .line 1488
    move-object/from16 v14, p1

    .line 1489
    .line 1490
    move-object/from16 v1, v53

    .line 1491
    .line 1492
    move-object/from16 v12, v55

    .line 1493
    .line 1494
    move-object/from16 v13, v57

    .line 1495
    .line 1496
    :goto_2b
    move v4, v11

    .line 1497
    :goto_2c
    iget v0, v15, Lq/d;->p:I

    .line 1498
    .line 1499
    const/4 v9, 0x5

    .line 1500
    const/4 v8, 0x2

    .line 1501
    if-ne v0, v8, :cond_49

    .line 1502
    .line 1503
    goto/16 :goto_32

    .line 1504
    .line 1505
    :cond_49
    if-eqz v4, :cond_54

    .line 1506
    .line 1507
    iget-boolean v0, v15, Lq/d;->l:Z

    .line 1508
    .line 1509
    if-nez v0, :cond_54

    .line 1510
    .line 1511
    aget v0, v32, v11

    .line 1512
    .line 1513
    if-ne v0, v8, :cond_4a

    .line 1514
    .line 1515
    instance-of v0, v15, Lq/e;

    .line 1516
    .line 1517
    if-eqz v0, :cond_4a

    .line 1518
    .line 1519
    move/from16 v16, v11

    .line 1520
    .line 1521
    goto :goto_2d

    .line 1522
    :cond_4a
    move/from16 v16, v10

    .line 1523
    .line 1524
    :goto_2d
    if-eqz v16, :cond_4b

    .line 1525
    .line 1526
    move/from16 v40, v10

    .line 1527
    .line 1528
    :cond_4b
    iget-object v0, v15, Lq/d;->T:Lq/d;

    .line 1529
    .line 1530
    if-eqz v0, :cond_4c

    .line 1531
    .line 1532
    iget-object v0, v0, Lq/d;->L:Lq/c;

    .line 1533
    .line 1534
    invoke-virtual {v14, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1535
    .line 1536
    .line 1537
    move-result-object v0

    .line 1538
    move-object v7, v0

    .line 1539
    goto :goto_2e

    .line 1540
    :cond_4c
    move-object/from16 v7, v47

    .line 1541
    .line 1542
    :goto_2e
    iget-object v0, v15, Lq/d;->T:Lq/d;

    .line 1543
    .line 1544
    if-eqz v0, :cond_4d

    .line 1545
    .line 1546
    iget-object v0, v0, Lq/d;->J:Lq/c;

    .line 1547
    .line 1548
    invoke-virtual {v14, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1549
    .line 1550
    .line 1551
    move-result-object v0

    .line 1552
    move-object v6, v0

    .line 1553
    goto :goto_2f

    .line 1554
    :cond_4d
    move-object/from16 v6, v47

    .line 1555
    .line 1556
    :goto_2f
    iget v0, v15, Lq/d;->a0:I

    .line 1557
    .line 1558
    if-gtz v0, :cond_4e

    .line 1559
    .line 1560
    iget v3, v15, Lq/d;->g0:I

    .line 1561
    .line 1562
    if-ne v3, v2, :cond_52

    .line 1563
    .line 1564
    :cond_4e
    move-object/from16 v3, v54

    .line 1565
    .line 1566
    iget-object v4, v3, Lq/c;->f:Lq/c;

    .line 1567
    .line 1568
    if-eqz v4, :cond_50

    .line 1569
    .line 1570
    invoke-virtual {v14, v1, v13, v0, v2}, Lo/d;->e(Lo/i;Lo/i;II)V

    .line 1571
    .line 1572
    .line 1573
    iget-object v0, v3, Lq/c;->f:Lq/c;

    .line 1574
    .line 1575
    invoke-virtual {v14, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1576
    .line 1577
    .line 1578
    move-result-object v0

    .line 1579
    invoke-virtual {v3}, Lq/c;->e()I

    .line 1580
    .line 1581
    .line 1582
    move-result v3

    .line 1583
    invoke-virtual {v14, v1, v0, v3, v2}, Lo/d;->e(Lo/i;Lo/i;II)V

    .line 1584
    .line 1585
    .line 1586
    if-eqz v28, :cond_4f

    .line 1587
    .line 1588
    move-object/from16 v0, v56

    .line 1589
    .line 1590
    invoke-virtual {v14, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1591
    .line 1592
    .line 1593
    move-result-object v0

    .line 1594
    invoke-virtual {v14, v7, v0, v10, v9}, Lo/d;->f(Lo/i;Lo/i;II)V

    .line 1595
    .line 1596
    .line 1597
    :cond_4f
    move/from16 v27, v10

    .line 1598
    .line 1599
    goto :goto_30

    .line 1600
    :cond_50
    iget v4, v15, Lq/d;->g0:I

    .line 1601
    .line 1602
    if-ne v4, v2, :cond_51

    .line 1603
    .line 1604
    invoke-virtual {v3}, Lq/c;->e()I

    .line 1605
    .line 1606
    .line 1607
    move-result v0

    .line 1608
    :cond_51
    invoke-virtual {v14, v1, v13, v0, v2}, Lo/d;->e(Lo/i;Lo/i;II)V

    .line 1609
    .line 1610
    .line 1611
    :cond_52
    move/from16 v27, v44

    .line 1612
    .line 1613
    :goto_30
    aget-boolean v5, v33, v11

    .line 1614
    .line 1615
    aget v17, v32, v11

    .line 1616
    .line 1617
    iget-object v4, v15, Lq/d;->J:Lq/c;

    .line 1618
    .line 1619
    iget-object v3, v15, Lq/d;->L:Lq/c;

    .line 1620
    .line 1621
    iget v1, v15, Lq/d;->Z:I

    .line 1622
    .line 1623
    iget v0, v15, Lq/d;->c0:I

    .line 1624
    .line 1625
    aget v18, v34, v11

    .line 1626
    .line 1627
    iget v2, v15, Lq/d;->e0:F

    .line 1628
    .line 1629
    aget v8, v32, v10

    .line 1630
    .line 1631
    move/from16 v19, v2

    .line 1632
    .line 1633
    const/4 v2, 0x3

    .line 1634
    if-ne v8, v2, :cond_53

    .line 1635
    .line 1636
    move/from16 v20, v11

    .line 1637
    .line 1638
    goto :goto_31

    .line 1639
    :cond_53
    move/from16 v20, v10

    .line 1640
    .line 1641
    :goto_31
    iget v8, v15, Lq/d;->x:I

    .line 1642
    .line 1643
    move/from16 v24, v8

    .line 1644
    .line 1645
    iget v8, v15, Lq/d;->y:I

    .line 1646
    .line 1647
    move/from16 v25, v8

    .line 1648
    .line 1649
    iget v8, v15, Lq/d;->z:F

    .line 1650
    .line 1651
    move/from16 v26, v8

    .line 1652
    .line 1653
    move/from16 v21, v0

    .line 1654
    .line 1655
    move-object/from16 v0, p0

    .line 1656
    .line 1657
    move/from16 v22, v1

    .line 1658
    .line 1659
    move-object/from16 v1, p1

    .line 1660
    .line 1661
    move v8, v2

    .line 1662
    const/4 v2, 0x0

    .line 1663
    move-object/from16 v23, v3

    .line 1664
    .line 1665
    move/from16 v3, v28

    .line 1666
    .line 1667
    move-object/from16 v28, v4

    .line 1668
    .line 1669
    move/from16 v4, v29

    .line 1670
    .line 1671
    move/from16 v8, v17

    .line 1672
    .line 1673
    move/from16 v9, v16

    .line 1674
    .line 1675
    move-object/from16 v10, v28

    .line 1676
    .line 1677
    move-object/from16 v11, v23

    .line 1678
    .line 1679
    move-object/from16 v60, v12

    .line 1680
    .line 1681
    move/from16 v12, v22

    .line 1682
    .line 1683
    move-object/from16 v61, v13

    .line 1684
    .line 1685
    move/from16 v13, v40

    .line 1686
    .line 1687
    move/from16 v14, v21

    .line 1688
    .line 1689
    move/from16 v15, v18

    .line 1690
    .line 1691
    move/from16 v16, v19

    .line 1692
    .line 1693
    move/from16 v17, v43

    .line 1694
    .line 1695
    move/from16 v18, v20

    .line 1696
    .line 1697
    move/from16 v19, v30

    .line 1698
    .line 1699
    move/from16 v20, v31

    .line 1700
    .line 1701
    move/from16 v21, v46

    .line 1702
    .line 1703
    move/from16 v22, v41

    .line 1704
    .line 1705
    move/from16 v23, v42

    .line 1706
    .line 1707
    invoke-virtual/range {v0 .. v27}, Lq/d;->e(Lo/d;ZZZZLo/i;Lo/i;IZLq/c;Lq/c;IIIIFZZZZZIIIIFZ)V

    .line 1708
    .line 1709
    .line 1710
    goto :goto_33

    .line 1711
    :cond_54
    :goto_32
    move-object/from16 v60, v12

    .line 1712
    .line 1713
    move-object/from16 v61, v13

    .line 1714
    .line 1715
    :goto_33
    move-object/from16 v0, p0

    .line 1716
    .line 1717
    if-eqz v38, :cond_56

    .line 1718
    .line 1719
    iget v1, v0, Lq/d;->A:I

    .line 1720
    .line 1721
    const/high16 v2, -0x40800000    # -1.0f

    .line 1722
    .line 1723
    const/4 v3, 0x1

    .line 1724
    if-ne v1, v3, :cond_55

    .line 1725
    .line 1726
    iget v1, v0, Lq/d;->B:F

    .line 1727
    .line 1728
    invoke-virtual/range {p1 .. p1}, Lo/d;->l()Lo/c;

    .line 1729
    .line 1730
    .line 1731
    move-result-object v3

    .line 1732
    iget-object v4, v3, Lo/c;->d:Lo/b;

    .line 1733
    .line 1734
    move-object/from16 v5, v60

    .line 1735
    .line 1736
    invoke-interface {v4, v5, v2}, Lo/b;->e(Lo/i;F)V

    .line 1737
    .line 1738
    .line 1739
    iget-object v2, v3, Lo/c;->d:Lo/b;

    .line 1740
    .line 1741
    move-object/from16 v4, v61

    .line 1742
    .line 1743
    const/high16 v6, 0x3f800000    # 1.0f

    .line 1744
    .line 1745
    invoke-interface {v2, v4, v6}, Lo/b;->e(Lo/i;F)V

    .line 1746
    .line 1747
    .line 1748
    iget-object v2, v3, Lo/c;->d:Lo/b;

    .line 1749
    .line 1750
    move-object/from16 v7, v58

    .line 1751
    .line 1752
    invoke-interface {v2, v7, v1}, Lo/b;->e(Lo/i;F)V

    .line 1753
    .line 1754
    .line 1755
    iget-object v2, v3, Lo/c;->d:Lo/b;

    .line 1756
    .line 1757
    neg-float v1, v1

    .line 1758
    move-object/from16 v8, v59

    .line 1759
    .line 1760
    invoke-interface {v2, v8, v1}, Lo/b;->e(Lo/i;F)V

    .line 1761
    .line 1762
    .line 1763
    move-object/from16 v1, p1

    .line 1764
    .line 1765
    invoke-virtual {v1, v3}, Lo/d;->c(Lo/c;)V

    .line 1766
    .line 1767
    .line 1768
    goto :goto_34

    .line 1769
    :cond_55
    move-object/from16 v1, p1

    .line 1770
    .line 1771
    move-object/from16 v7, v58

    .line 1772
    .line 1773
    move-object/from16 v8, v59

    .line 1774
    .line 1775
    move-object/from16 v5, v60

    .line 1776
    .line 1777
    move-object/from16 v4, v61

    .line 1778
    .line 1779
    const/high16 v6, 0x3f800000    # 1.0f

    .line 1780
    .line 1781
    iget v3, v0, Lq/d;->B:F

    .line 1782
    .line 1783
    invoke-virtual/range {p1 .. p1}, Lo/d;->l()Lo/c;

    .line 1784
    .line 1785
    .line 1786
    move-result-object v9

    .line 1787
    iget-object v10, v9, Lo/c;->d:Lo/b;

    .line 1788
    .line 1789
    invoke-interface {v10, v7, v2}, Lo/b;->e(Lo/i;F)V

    .line 1790
    .line 1791
    .line 1792
    iget-object v2, v9, Lo/c;->d:Lo/b;

    .line 1793
    .line 1794
    invoke-interface {v2, v8, v6}, Lo/b;->e(Lo/i;F)V

    .line 1795
    .line 1796
    .line 1797
    iget-object v2, v9, Lo/c;->d:Lo/b;

    .line 1798
    .line 1799
    invoke-interface {v2, v5, v3}, Lo/b;->e(Lo/i;F)V

    .line 1800
    .line 1801
    .line 1802
    iget-object v2, v9, Lo/c;->d:Lo/b;

    .line 1803
    .line 1804
    neg-float v3, v3

    .line 1805
    invoke-interface {v2, v4, v3}, Lo/b;->e(Lo/i;F)V

    .line 1806
    .line 1807
    .line 1808
    invoke-virtual {v1, v9}, Lo/d;->c(Lo/c;)V

    .line 1809
    .line 1810
    .line 1811
    goto :goto_34

    .line 1812
    :cond_56
    move-object/from16 v1, p1

    .line 1813
    .line 1814
    :goto_34
    invoke-virtual/range {v39 .. v39}, Lq/c;->h()Z

    .line 1815
    .line 1816
    .line 1817
    move-result v2

    .line 1818
    if-eqz v2, :cond_57

    .line 1819
    .line 1820
    move-object/from16 v2, v39

    .line 1821
    .line 1822
    iget-object v3, v2, Lq/c;->f:Lq/c;

    .line 1823
    .line 1824
    iget-object v3, v3, Lq/c;->d:Lq/d;

    .line 1825
    .line 1826
    iget v4, v0, Lq/d;->D:F

    .line 1827
    .line 1828
    const/high16 v5, 0x42b40000    # 90.0f

    .line 1829
    .line 1830
    add-float/2addr v4, v5

    .line 1831
    float-to-double v4, v4

    .line 1832
    invoke-static {v4, v5}, Ljava/lang/Math;->toRadians(D)D

    .line 1833
    .line 1834
    .line 1835
    move-result-wide v4

    .line 1836
    double-to-float v4, v4

    .line 1837
    invoke-virtual {v2}, Lq/c;->e()I

    .line 1838
    .line 1839
    .line 1840
    move-result v2

    .line 1841
    const/4 v5, 0x2

    .line 1842
    invoke-virtual {v0, v5}, Lq/d;->j(I)Lq/c;

    .line 1843
    .line 1844
    .line 1845
    move-result-object v6

    .line 1846
    invoke-virtual {v1, v6}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1847
    .line 1848
    .line 1849
    move-result-object v6

    .line 1850
    const/4 v7, 0x3

    .line 1851
    invoke-virtual {v0, v7}, Lq/d;->j(I)Lq/c;

    .line 1852
    .line 1853
    .line 1854
    move-result-object v8

    .line 1855
    invoke-virtual {v1, v8}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1856
    .line 1857
    .line 1858
    move-result-object v8

    .line 1859
    const/4 v9, 0x4

    .line 1860
    invoke-virtual {v0, v9}, Lq/d;->j(I)Lq/c;

    .line 1861
    .line 1862
    .line 1863
    move-result-object v10

    .line 1864
    invoke-virtual {v1, v10}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1865
    .line 1866
    .line 1867
    move-result-object v10

    .line 1868
    const/4 v11, 0x5

    .line 1869
    invoke-virtual {v0, v11}, Lq/d;->j(I)Lq/c;

    .line 1870
    .line 1871
    .line 1872
    move-result-object v12

    .line 1873
    invoke-virtual {v1, v12}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1874
    .line 1875
    .line 1876
    move-result-object v12

    .line 1877
    invoke-virtual {v3, v5}, Lq/d;->j(I)Lq/c;

    .line 1878
    .line 1879
    .line 1880
    move-result-object v5

    .line 1881
    invoke-virtual {v1, v5}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1882
    .line 1883
    .line 1884
    move-result-object v5

    .line 1885
    invoke-virtual {v3, v7}, Lq/d;->j(I)Lq/c;

    .line 1886
    .line 1887
    .line 1888
    move-result-object v7

    .line 1889
    invoke-virtual {v1, v7}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1890
    .line 1891
    .line 1892
    move-result-object v7

    .line 1893
    invoke-virtual {v3, v9}, Lq/d;->j(I)Lq/c;

    .line 1894
    .line 1895
    .line 1896
    move-result-object v9

    .line 1897
    invoke-virtual {v1, v9}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1898
    .line 1899
    .line 1900
    move-result-object v9

    .line 1901
    invoke-virtual {v3, v11}, Lq/d;->j(I)Lq/c;

    .line 1902
    .line 1903
    .line 1904
    move-result-object v3

    .line 1905
    invoke-virtual {v1, v3}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    .line 1906
    .line 1907
    .line 1908
    move-result-object v3

    .line 1909
    invoke-virtual/range {p1 .. p1}, Lo/d;->l()Lo/c;

    .line 1910
    .line 1911
    .line 1912
    move-result-object v11

    .line 1913
    float-to-double v13, v4

    .line 1914
    invoke-static {v13, v14}, Ljava/lang/Math;->sin(D)D

    .line 1915
    .line 1916
    .line 1917
    move-result-wide v15

    .line 1918
    move-object v4, v9

    .line 1919
    move-object/from16 p2, v10

    .line 1920
    .line 1921
    int-to-double v9, v2

    .line 1922
    move-object/from16 v17, v4

    .line 1923
    .line 1924
    move-object v2, v5

    .line 1925
    mul-double v4, v15, v9

    .line 1926
    .line 1927
    double-to-float v4, v4

    .line 1928
    iget-object v5, v11, Lo/c;->d:Lo/b;

    .line 1929
    .line 1930
    const/high16 v15, 0x3f000000    # 0.5f

    .line 1931
    .line 1932
    invoke-interface {v5, v7, v15}, Lo/b;->e(Lo/i;F)V

    .line 1933
    .line 1934
    .line 1935
    iget-object v5, v11, Lo/c;->d:Lo/b;

    .line 1936
    .line 1937
    invoke-interface {v5, v3, v15}, Lo/b;->e(Lo/i;F)V

    .line 1938
    .line 1939
    .line 1940
    iget-object v3, v11, Lo/c;->d:Lo/b;

    .line 1941
    .line 1942
    const/high16 v5, -0x41000000    # -0.5f

    .line 1943
    .line 1944
    invoke-interface {v3, v8, v5}, Lo/b;->e(Lo/i;F)V

    .line 1945
    .line 1946
    .line 1947
    iget-object v3, v11, Lo/c;->d:Lo/b;

    .line 1948
    .line 1949
    invoke-interface {v3, v12, v5}, Lo/b;->e(Lo/i;F)V

    .line 1950
    .line 1951
    .line 1952
    neg-float v3, v4

    .line 1953
    iput v3, v11, Lo/c;->b:F

    .line 1954
    .line 1955
    invoke-virtual {v1, v11}, Lo/d;->c(Lo/c;)V

    .line 1956
    .line 1957
    .line 1958
    invoke-virtual/range {p1 .. p1}, Lo/d;->l()Lo/c;

    .line 1959
    .line 1960
    .line 1961
    move-result-object v3

    .line 1962
    invoke-static {v13, v14}, Ljava/lang/Math;->cos(D)D

    .line 1963
    .line 1964
    .line 1965
    move-result-wide v7

    .line 1966
    mul-double/2addr v7, v9

    .line 1967
    double-to-float v4, v7

    .line 1968
    iget-object v7, v3, Lo/c;->d:Lo/b;

    .line 1969
    .line 1970
    invoke-interface {v7, v2, v15}, Lo/b;->e(Lo/i;F)V

    .line 1971
    .line 1972
    .line 1973
    iget-object v2, v3, Lo/c;->d:Lo/b;

    .line 1974
    .line 1975
    move-object/from16 v7, v17

    .line 1976
    .line 1977
    invoke-interface {v2, v7, v15}, Lo/b;->e(Lo/i;F)V

    .line 1978
    .line 1979
    .line 1980
    iget-object v2, v3, Lo/c;->d:Lo/b;

    .line 1981
    .line 1982
    invoke-interface {v2, v6, v5}, Lo/b;->e(Lo/i;F)V

    .line 1983
    .line 1984
    .line 1985
    iget-object v2, v3, Lo/c;->d:Lo/b;

    .line 1986
    .line 1987
    move-object/from16 v6, p2

    .line 1988
    .line 1989
    invoke-interface {v2, v6, v5}, Lo/b;->e(Lo/i;F)V

    .line 1990
    .line 1991
    .line 1992
    neg-float v2, v4

    .line 1993
    iput v2, v3, Lo/c;->b:F

    .line 1994
    .line 1995
    invoke-virtual {v1, v3}, Lo/d;->c(Lo/c;)V

    .line 1996
    .line 1997
    .line 1998
    :cond_57
    const/4 v1, 0x0

    .line 1999
    iput-boolean v1, v0, Lq/d;->k:Z

    .line 2000
    .line 2001
    iput-boolean v1, v0, Lq/d;->l:Z

    .line 2002
    .line 2003
    return-void
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
.end method

.method public d()Z
    .locals 2

    .line 1
    iget v0, p0, Lq/d;->g0:I

    const/16 v1, 0x8

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final e(Lo/d;ZZZZLo/i;Lo/i;IZLq/c;Lq/c;IIIIFZZZZZIIIIFZ)V
    .locals 28

    move-object/from16 v0, p0

    move-object/from16 v10, p1

    move-object/from16 v11, p6

    move-object/from16 v12, p7

    move-object/from16 v13, p10

    move-object/from16 v14, p11

    move/from16 v15, p14

    move/from16 v1, p15

    move/from16 v2, p23

    move/from16 v3, p24

    move/from16 v4, p25

    move/from16 v5, p26

    invoke-virtual {v10, v13}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    move-result-object v9

    invoke-virtual {v10, v14}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    move-result-object v8

    .line 1
    iget-object v6, v13, Lq/c;->f:Lq/c;

    .line 2
    invoke-virtual {v10, v6}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    move-result-object v7

    .line 3
    iget-object v6, v14, Lq/c;->f:Lq/c;

    .line 4
    invoke-virtual {v10, v6}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    move-result-object v6

    invoke-virtual/range {p10 .. p10}, Lq/c;->h()Z

    move-result v16

    invoke-virtual/range {p11 .. p11}, Lq/c;->h()Z

    move-result v17

    iget-object v12, v0, Lq/d;->P:Lq/c;

    invoke-virtual {v12}, Lq/c;->h()Z

    move-result v12

    if-eqz v17, :cond_0

    add-int/lit8 v18, v16, 0x1

    goto :goto_0

    :cond_0
    move/from16 v18, v16

    :goto_0
    if-eqz v12, :cond_1

    add-int/lit8 v18, v18, 0x1

    :cond_1
    move/from16 v2, v18

    if-eqz p17, :cond_2

    const/4 v14, 0x3

    goto :goto_1

    :cond_2
    move/from16 v14, p22

    :goto_1
    if-eqz p8, :cond_5f

    const/4 v11, 0x1

    move-object/from16 v19, v6

    add-int/lit8 v6, p8, -0x1

    if-eqz v6, :cond_3

    const/4 v11, 0x1

    if-eq v6, v11, :cond_3

    const/4 v11, 0x2

    if-eq v6, v11, :cond_4

    :cond_3
    const/4 v6, 0x0

    goto :goto_2

    :cond_4
    const/4 v6, 0x4

    if-eq v14, v6, :cond_3

    const/4 v6, 0x1

    :goto_2
    iget v11, v0, Lq/d;->h:I

    move/from16 v21, v6

    const/4 v6, -0x1

    if-eq v11, v6, :cond_5

    if-eqz p2, :cond_5

    iput v6, v0, Lq/d;->h:I

    move/from16 p13, v11

    const/16 v21, 0x0

    :cond_5
    iget v11, v0, Lq/d;->i:I

    if-eq v11, v6, :cond_6

    if-nez p2, :cond_6

    iput v6, v0, Lq/d;->i:I

    const/16 v21, 0x0

    goto :goto_3

    :cond_6
    move/from16 v11, p13

    :goto_3
    iget v6, v0, Lq/d;->g0:I

    move/from16 p13, v11

    const/16 v11, 0x8

    if-ne v6, v11, :cond_7

    const/4 v6, 0x0

    const/16 v21, 0x0

    goto :goto_4

    :cond_7
    move/from16 v6, p13

    :goto_4
    if-eqz p27, :cond_a

    if-nez v16, :cond_9

    if-nez v17, :cond_9

    if-nez v12, :cond_9

    move/from16 v11, p12

    invoke-virtual {v10, v9, v11}, Lo/d;->d(Lo/i;I)V

    :cond_8
    move/from16 v23, v12

    const/16 v12, 0x8

    goto :goto_5

    :cond_9
    if-eqz v16, :cond_8

    if-nez v17, :cond_8

    invoke-virtual/range {p10 .. p10}, Lq/c;->e()I

    move-result v11

    move/from16 v23, v12

    const/16 v12, 0x8

    invoke-virtual {v10, v9, v7, v11, v12}, Lo/d;->e(Lo/i;Lo/i;II)V

    goto :goto_5

    :cond_a
    move/from16 v23, v12

    move v12, v11

    :goto_5
    if-nez v21, :cond_e

    if-eqz p9, :cond_c

    const/4 v5, 0x3

    const/4 v11, 0x0

    invoke-virtual {v10, v8, v9, v11, v5}, Lo/d;->e(Lo/i;Lo/i;II)V

    if-lez v15, :cond_b

    invoke-virtual {v10, v8, v9, v15, v12}, Lo/d;->f(Lo/i;Lo/i;II)V

    :cond_b
    const v5, 0x7fffffff

    if-ge v1, v5, :cond_d

    invoke-virtual {v10, v8, v9, v1, v12}, Lo/d;->g(Lo/i;Lo/i;II)V

    goto :goto_6

    :cond_c
    invoke-virtual {v10, v8, v9, v6, v12}, Lo/d;->e(Lo/i;Lo/i;II)V

    :cond_d
    :goto_6
    move/from16 v11, p5

    move/from16 v24, v2

    :goto_7
    move v12, v3

    goto/16 :goto_b

    :cond_e
    const/4 v1, 0x2

    if-eq v2, v1, :cond_11

    if-nez p17, :cond_11

    const/4 v1, 0x1

    if-eq v14, v1, :cond_f

    if-nez v14, :cond_11

    :cond_f
    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    move-result v1

    if-lez v4, :cond_10

    invoke-static {v4, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    :cond_10
    const/16 v5, 0x8

    invoke-virtual {v10, v8, v9, v1, v5}, Lo/d;->e(Lo/i;Lo/i;II)V

    move/from16 v11, p5

    move/from16 v24, v2

    move v12, v3

    const/16 v21, 0x0

    goto/16 :goto_b

    :cond_11
    const/4 v1, -0x2

    if-ne v3, v1, :cond_12

    move v3, v6

    :cond_12
    if-ne v4, v1, :cond_13

    move v4, v6

    :cond_13
    if-lez v6, :cond_14

    const/4 v1, 0x1

    if-eq v14, v1, :cond_14

    const/4 v6, 0x0

    :cond_14
    const/16 v1, 0x8

    if-lez v3, :cond_15

    invoke-virtual {v10, v8, v9, v3, v1}, Lo/d;->f(Lo/i;Lo/i;II)V

    invoke-static {v6, v3}, Ljava/lang/Math;->max(II)I

    move-result v6

    :cond_15
    const/4 v11, 0x1

    if-lez v4, :cond_17

    if-eqz p3, :cond_16

    if-ne v14, v11, :cond_16

    goto :goto_8

    :cond_16
    invoke-virtual {v10, v8, v9, v4, v1}, Lo/d;->g(Lo/i;Lo/i;II)V

    :goto_8
    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    move-result v6

    :cond_17
    if-ne v14, v11, :cond_19

    if-eqz p3, :cond_18

    invoke-virtual {v10, v8, v9, v6, v1}, Lo/d;->e(Lo/i;Lo/i;II)V

    const/4 v12, 0x5

    goto :goto_6

    :cond_18
    const/4 v12, 0x5

    invoke-virtual {v10, v8, v9, v6, v12}, Lo/d;->e(Lo/i;Lo/i;II)V

    invoke-virtual {v10, v8, v9, v6, v1}, Lo/d;->g(Lo/i;Lo/i;II)V

    goto :goto_6

    :cond_19
    const/4 v1, 0x2

    const/4 v12, 0x5

    if-ne v14, v1, :cond_1d

    iget v6, v13, Lq/c;->e:I

    const/4 v11, 0x3

    if-eq v6, v11, :cond_1a

    if-ne v6, v12, :cond_1b

    :cond_1a
    const/4 v11, 0x4

    goto :goto_9

    :cond_1b
    iget-object v6, v0, Lq/d;->T:Lq/d;

    invoke-virtual {v6, v1}, Lq/d;->j(I)Lq/c;

    move-result-object v6

    invoke-virtual {v10, v6}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    move-result-object v1

    iget-object v6, v0, Lq/d;->T:Lq/d;

    const/4 v11, 0x4

    invoke-virtual {v6, v11}, Lq/d;->j(I)Lq/c;

    move-result-object v6

    invoke-virtual {v10, v6}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    move-result-object v6

    goto :goto_a

    :goto_9
    iget-object v1, v0, Lq/d;->T:Lq/d;

    const/4 v6, 0x3

    invoke-virtual {v1, v6}, Lq/d;->j(I)Lq/c;

    move-result-object v1

    invoke-virtual {v10, v1}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    move-result-object v1

    iget-object v12, v0, Lq/d;->T:Lq/d;

    const/4 v6, 0x5

    invoke-virtual {v12, v6}, Lq/d;->j(I)Lq/c;

    move-result-object v12

    invoke-virtual {v10, v12}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    move-result-object v6

    :goto_a
    invoke-virtual/range {p1 .. p1}, Lo/d;->l()Lo/c;

    move-result-object v12

    .line 5
    iget-object v11, v12, Lo/c;->d:Lo/b;

    move/from16 v24, v2

    const/high16 v2, -0x40800000    # -1.0f

    invoke-interface {v11, v8, v2}, Lo/b;->e(Lo/i;F)V

    iget-object v2, v12, Lo/c;->d:Lo/b;

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-interface {v2, v9, v11}, Lo/b;->e(Lo/i;F)V

    iget-object v2, v12, Lo/c;->d:Lo/b;

    invoke-interface {v2, v6, v5}, Lo/b;->e(Lo/i;F)V

    iget-object v2, v12, Lo/c;->d:Lo/b;

    neg-float v5, v5

    invoke-interface {v2, v1, v5}, Lo/b;->e(Lo/i;F)V

    .line 6
    invoke-virtual {v10, v12}, Lo/d;->c(Lo/c;)V

    if-eqz p3, :cond_1c

    const/16 v21, 0x0

    :cond_1c
    move/from16 v11, p5

    goto/16 :goto_7

    :cond_1d
    move/from16 v24, v2

    move v12, v3

    const/4 v11, 0x1

    :goto_b
    if-eqz p27, :cond_5a

    if-eqz p19, :cond_1e

    move-object/from16 v2, p6

    move-object/from16 v4, p7

    move-object v3, v8

    move-object v13, v9

    move/from16 p5, v11

    move/from16 v1, v24

    const/4 v5, 0x2

    const/16 v27, 0x1

    goto/16 :goto_2b

    :cond_1e
    if-nez v16, :cond_1f

    if-nez v17, :cond_1f

    if-nez v23, :cond_1f

    move-object/from16 v15, p11

    move-object v3, v8

    move/from16 p5, v11

    move-object/from16 v1, v19

    :goto_c
    const/4 v4, 0x5

    goto/16 :goto_28

    :cond_1f
    if-eqz v16, :cond_21

    if-nez v17, :cond_21

    iget-object v1, v13, Lq/c;->f:Lq/c;

    iget-object v1, v1, Lq/c;->d:Lq/d;

    if-eqz p3, :cond_20

    instance-of v1, v1, Lq/a;

    if-eqz v1, :cond_20

    const/16 v1, 0x8

    goto :goto_d

    :cond_20
    const/4 v1, 0x5

    :goto_d
    move/from16 v18, p3

    move-object/from16 v15, p11

    move-object v3, v8

    move/from16 p5, v11

    move v11, v1

    move-object/from16 v1, v19

    goto/16 :goto_29

    :cond_21
    if-nez v16, :cond_23

    if-eqz v17, :cond_23

    invoke-virtual/range {p11 .. p11}, Lq/c;->e()I

    move-result v1

    neg-int v1, v1

    move-object/from16 v6, v19

    const/16 v2, 0x8

    invoke-virtual {v10, v8, v6, v1, v2}, Lo/d;->e(Lo/i;Lo/i;II)V

    if-eqz p3, :cond_22

    move-object/from16 v5, p6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v10, v9, v5, v1, v2}, Lo/d;->f(Lo/i;Lo/i;II)V

    move-object/from16 v15, p11

    move v4, v2

    move-object v1, v6

    move-object v3, v8

    move/from16 p5, v11

    goto/16 :goto_28

    :cond_22
    move-object/from16 v15, p11

    move-object v1, v6

    move-object v3, v8

    move/from16 p5, v11

    goto :goto_c

    :cond_23
    move-object/from16 v5, p6

    move-object/from16 v6, v19

    const/4 v3, 0x1

    if-eqz v16, :cond_22

    if-eqz v17, :cond_22

    iget-object v1, v13, Lq/c;->f:Lq/c;

    iget-object v2, v1, Lq/c;->d:Lq/d;

    move-object/from16 v1, p11

    iget-object v3, v1, Lq/c;->f:Lq/c;

    iget-object v3, v3, Lq/c;->d:Lq/d;

    iget-object v13, v0, Lq/d;->T:Lq/d;

    const/16 v16, 0x6

    if-eqz v21, :cond_38

    if-nez v14, :cond_28

    if-nez v4, :cond_25

    if-nez v12, :cond_25

    iget-boolean v4, v7, Lo/i;->l:Z

    if-eqz v4, :cond_24

    iget-boolean v4, v6, Lo/i;->l:Z

    if-eqz v4, :cond_24

    invoke-virtual/range {p10 .. p10}, Lq/c;->e()I

    move-result v2

    const/16 v3, 0x8

    invoke-virtual {v10, v9, v7, v2, v3}, Lo/d;->e(Lo/i;Lo/i;II)V

    invoke-virtual/range {p11 .. p11}, Lq/c;->e()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {v10, v8, v6, v1, v3}, Lo/d;->e(Lo/i;Lo/i;II)V

    return-void

    :cond_24
    const/16 p2, 0x8

    const/16 v17, 0x8

    const/16 v18, 0x0

    const/16 v19, 0x1

    const/16 v20, 0x0

    goto :goto_e

    :cond_25
    const/16 p2, 0x5

    const/16 v17, 0x5

    const/16 v18, 0x1

    const/16 v19, 0x0

    const/16 v20, 0x1

    :goto_e
    instance-of v4, v2, Lq/a;

    if-nez v4, :cond_27

    instance-of v4, v3, Lq/a;

    if-eqz v4, :cond_26

    goto :goto_10

    :cond_26
    move/from16 v4, p2

    move/from16 v22, v18

    move/from16 v23, v19

    const/4 v15, 0x1

    move/from16 v18, v16

    move/from16 v19, v17

    move/from16 v17, v14

    :goto_f
    move-object/from16 v14, p7

    goto/16 :goto_1b

    :cond_27
    :goto_10
    move/from16 v4, p2

    move/from16 v17, v14

    move/from16 v22, v18

    move/from16 v23, v19

    const/4 v15, 0x1

    const/16 v19, 0x4

    move-object/from16 v14, p7

    move/from16 v18, v16

    goto/16 :goto_1b

    :cond_28
    const/4 v15, 0x2

    if-ne v14, v15, :cond_2b

    instance-of v4, v2, Lq/a;

    if-nez v4, :cond_2a

    instance-of v4, v3, Lq/a;

    if-eqz v4, :cond_29

    goto :goto_12

    :cond_29
    move/from16 v17, v14

    move/from16 v18, v16

    const/4 v4, 0x5

    const/4 v15, 0x1

    const/16 v19, 0x5

    :goto_11
    const/16 v20, 0x1

    const/16 v22, 0x1

    const/16 v23, 0x0

    goto :goto_f

    :cond_2a
    :goto_12
    move/from16 v17, v14

    move/from16 v18, v16

    const/4 v4, 0x5

    :goto_13
    const/4 v15, 0x1

    const/16 v19, 0x4

    goto :goto_11

    :cond_2b
    const/4 v15, 0x1

    if-ne v14, v15, :cond_2c

    move/from16 v17, v14

    move/from16 v18, v16

    const/16 v4, 0x8

    goto :goto_13

    :cond_2c
    const/4 v15, 0x3

    if-ne v14, v15, :cond_37

    iget v15, v0, Lq/d;->A:I

    move/from16 v17, v14

    const/4 v14, -0x1

    if-ne v15, v14, :cond_2f

    move-object/from16 v14, p7

    const/16 v4, 0x8

    const/4 v15, 0x1

    if-eqz p20, :cond_2e

    if-eqz p3, :cond_2d

    const/16 v18, 0x5

    :goto_14
    const/16 v19, 0x5

    const/16 v20, 0x1

    const/16 v22, 0x1

    const/16 v23, 0x1

    goto/16 :goto_1b

    :cond_2d
    const/16 v18, 0x4

    goto :goto_14

    :cond_2e
    const/16 v18, 0x8

    goto :goto_14

    :cond_2f
    if-eqz p17, :cond_32

    move/from16 v14, p23

    const/4 v15, 0x2

    if-eq v14, v15, :cond_31

    const/4 v15, 0x1

    if-ne v14, v15, :cond_30

    goto :goto_15

    :cond_30
    const/16 v4, 0x8

    const/4 v14, 0x5

    goto :goto_16

    :cond_31
    const/4 v15, 0x1

    :goto_15
    const/4 v4, 0x5

    const/4 v14, 0x4

    :goto_16
    move/from16 v19, v14

    move/from16 v20, v15

    move/from16 v22, v20

    move/from16 v23, v22

    move/from16 v18, v16

    goto/16 :goto_f

    :cond_32
    const/4 v15, 0x1

    if-lez v4, :cond_33

    move-object/from16 v14, p7

    move/from16 v20, v15

    move/from16 v22, v20

    move/from16 v23, v22

    move/from16 v18, v16

    const/4 v4, 0x5

    const/16 v19, 0x5

    goto/16 :goto_1b

    :cond_33
    if-nez v4, :cond_36

    if-nez v12, :cond_36

    if-nez p20, :cond_34

    move-object/from16 v14, p7

    move/from16 v20, v15

    move/from16 v22, v20

    move/from16 v23, v22

    move/from16 v18, v16

    const/4 v4, 0x5

    const/16 v19, 0x8

    goto/16 :goto_1b

    :cond_34
    if-eq v2, v13, :cond_35

    if-eq v3, v13, :cond_35

    const/4 v4, 0x4

    goto :goto_17

    :cond_35
    const/4 v4, 0x5

    :goto_17
    move-object/from16 v14, p7

    move/from16 v20, v15

    move/from16 v22, v20

    move/from16 v23, v22

    move/from16 v18, v16

    :goto_18
    const/16 v19, 0x4

    goto/16 :goto_1b

    :cond_36
    move-object/from16 v14, p7

    move/from16 v20, v15

    move/from16 v22, v20

    move/from16 v23, v22

    move/from16 v18, v16

    const/4 v4, 0x5

    goto :goto_18

    :cond_37
    move/from16 v17, v14

    const/4 v15, 0x1

    move-object/from16 v14, p7

    move/from16 v18, v16

    const/4 v4, 0x5

    const/16 v19, 0x4

    const/16 v20, 0x0

    const/16 v22, 0x0

    :goto_19
    const/16 v23, 0x0

    goto :goto_1b

    :cond_38
    move/from16 v17, v14

    const/4 v15, 0x1

    iget-boolean v4, v7, Lo/i;->l:Z

    if-eqz v4, :cond_3b

    iget-boolean v4, v6, Lo/i;->l:Z

    if-eqz v4, :cond_3b

    invoke-virtual/range {p10 .. p10}, Lq/c;->e()I

    move-result v2

    invoke-virtual/range {p11 .. p11}, Lq/c;->e()I

    move-result v3

    const/16 v4, 0x8

    move-object/from16 p17, p1

    move-object/from16 p18, v9

    move-object/from16 p19, v7

    move/from16 p20, v2

    move/from16 p21, p16

    move-object/from16 p22, v6

    move-object/from16 p23, v8

    move/from16 p24, v3

    move/from16 p25, v4

    invoke-virtual/range {p17 .. p25}, Lo/d;->b(Lo/i;Lo/i;IFLo/i;Lo/i;II)V

    if-eqz p3, :cond_3a

    if-eqz v11, :cond_3a

    iget-object v2, v1, Lq/c;->f:Lq/c;

    if-eqz v2, :cond_39

    invoke-virtual/range {p11 .. p11}, Lq/c;->e()I

    move-result v11

    move-object/from16 v14, p7

    goto :goto_1a

    :cond_39
    move-object/from16 v14, p7

    const/4 v11, 0x0

    :goto_1a
    if-eq v6, v14, :cond_3a

    const/4 v1, 0x5

    invoke-virtual {v10, v14, v8, v11, v1}, Lo/d;->f(Lo/i;Lo/i;II)V

    :cond_3a
    return-void

    :cond_3b
    move-object/from16 v14, p7

    move/from16 v20, v15

    move/from16 v22, v20

    move/from16 v18, v16

    const/4 v4, 0x5

    const/16 v19, 0x4

    goto :goto_19

    :goto_1b
    if-eqz v20, :cond_3c

    if-ne v7, v6, :cond_3c

    if-eq v2, v13, :cond_3c

    const/16 v20, 0x0

    const/16 v24, 0x0

    goto :goto_1c

    :cond_3c
    move/from16 v24, v20

    move/from16 v20, v15

    :goto_1c
    if-eqz v22, :cond_3e

    if-nez v21, :cond_3d

    if-nez p18, :cond_3d

    if-nez p20, :cond_3d

    if-ne v7, v5, :cond_3d

    if-ne v6, v14, :cond_3d

    const/16 v18, 0x0

    const/16 v20, 0x8

    const/16 v22, 0x8

    const/16 v25, 0x0

    goto :goto_1d

    :cond_3d
    move/from16 v22, v18

    move/from16 v25, v20

    move/from16 v18, p3

    move/from16 v20, v4

    :goto_1d
    invoke-virtual/range {p10 .. p10}, Lq/c;->e()I

    move-result v4

    invoke-virtual/range {p11 .. p11}, Lq/c;->e()I

    move-result v26

    move-object v15, v1

    move-object/from16 v1, p1

    move-object v14, v2

    move-object v2, v9

    move/from16 p5, v11

    const/16 v27, 0x1

    move-object v11, v3

    move-object v3, v7

    move/from16 p9, v12

    move-object v12, v5

    move/from16 v5, p16

    move-object/from16 p2, v6

    move-object v12, v7

    move-object v7, v8

    move-object/from16 p15, v13

    move-object v13, v8

    move/from16 v8, v26

    move-object/from16 v26, v13

    move-object v13, v9

    move/from16 v9, v22

    invoke-virtual/range {v1 .. v9}, Lo/d;->b(Lo/i;Lo/i;IFLo/i;Lo/i;II)V

    move/from16 v4, v20

    move/from16 v20, v25

    goto :goto_1e

    :cond_3e
    move-object v14, v2

    move-object/from16 p2, v6

    move-object/from16 v26, v8

    move/from16 p5, v11

    move/from16 p9, v12

    move-object/from16 p15, v13

    move/from16 v27, v15

    move-object v15, v1

    move-object v11, v3

    move-object v12, v7

    move-object v13, v9

    move/from16 v18, p3

    :goto_1e
    iget v1, v0, Lq/d;->g0:I

    const/16 v2, 0x8

    if-ne v1, v2, :cond_41

    .line 7
    iget-object v1, v15, Lq/c;->a:Ljava/util/HashSet;

    if-nez v1, :cond_3f

    goto :goto_1f

    :cond_3f
    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    move-result v1

    if-lez v1, :cond_40

    goto :goto_20

    :cond_40
    :goto_1f
    return-void

    :cond_41
    :goto_20
    move-object/from16 v1, p2

    if-eqz v24, :cond_44

    if-eqz v18, :cond_43

    if-eq v12, v1, :cond_43

    if-nez v21, :cond_43

    .line 8
    instance-of v2, v14, Lq/a;

    if-nez v2, :cond_42

    instance-of v2, v11, Lq/a;

    if-eqz v2, :cond_43

    :cond_42
    move/from16 v4, v16

    :cond_43
    invoke-virtual/range {p10 .. p10}, Lq/c;->e()I

    move-result v2

    invoke-virtual {v10, v13, v12, v2, v4}, Lo/d;->f(Lo/i;Lo/i;II)V

    invoke-virtual/range {p11 .. p11}, Lq/c;->e()I

    move-result v2

    neg-int v2, v2

    move-object/from16 v3, v26

    invoke-virtual {v10, v3, v1, v2, v4}, Lo/d;->g(Lo/i;Lo/i;II)V

    goto :goto_21

    :cond_44
    move-object/from16 v3, v26

    :goto_21
    if-eqz v18, :cond_45

    if-eqz p21, :cond_45

    instance-of v2, v14, Lq/a;

    if-nez v2, :cond_45

    instance-of v2, v11, Lq/a;

    if-nez v2, :cond_45

    move-object/from16 v2, p15

    if-eq v11, v2, :cond_46

    move/from16 v4, v16

    move v5, v4

    move/from16 v20, v27

    goto :goto_22

    :cond_45
    move-object/from16 v2, p15

    :cond_46
    move/from16 v5, v19

    :goto_22
    if-eqz v20, :cond_53

    if-eqz v23, :cond_4f

    if-eqz p20, :cond_47

    if-eqz p4, :cond_4f

    :cond_47
    if-eq v14, v2, :cond_49

    if-ne v11, v2, :cond_48

    goto :goto_23

    :cond_48
    move/from16 v16, v5

    :cond_49
    :goto_23
    instance-of v6, v14, Lq/h;

    if-nez v6, :cond_4a

    instance-of v6, v11, Lq/h;

    if-eqz v6, :cond_4b

    :cond_4a
    const/16 v16, 0x5

    :cond_4b
    instance-of v6, v14, Lq/a;

    if-nez v6, :cond_4c

    instance-of v6, v11, Lq/a;

    if-eqz v6, :cond_4d

    :cond_4c
    const/16 v16, 0x5

    :cond_4d
    if-eqz p20, :cond_4e

    const/4 v6, 0x5

    goto :goto_24

    :cond_4e
    move/from16 v6, v16

    :goto_24
    invoke-static {v6, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    :cond_4f
    if-eqz v18, :cond_52

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    if-eqz p17, :cond_51

    if-nez p20, :cond_51

    if-eq v14, v2, :cond_50

    if-ne v11, v2, :cond_51

    :cond_50
    const/4 v11, 0x4

    goto :goto_25

    :cond_51
    move v11, v4

    goto :goto_25

    :cond_52
    move v11, v5

    :goto_25
    invoke-virtual/range {p10 .. p10}, Lq/c;->e()I

    move-result v2

    invoke-virtual {v10, v13, v12, v2, v11}, Lo/d;->e(Lo/i;Lo/i;II)V

    invoke-virtual/range {p11 .. p11}, Lq/c;->e()I

    move-result v2

    neg-int v2, v2

    invoke-virtual {v10, v3, v1, v2, v11}, Lo/d;->e(Lo/i;Lo/i;II)V

    :cond_53
    if-eqz v18, :cond_55

    move-object/from16 v2, p6

    move-object v4, v12

    if-ne v2, v4, :cond_54

    invoke-virtual/range {p10 .. p10}, Lq/c;->e()I

    move-result v5

    goto :goto_26

    :cond_54
    const/4 v5, 0x0

    :goto_26
    if-eq v4, v2, :cond_55

    const/4 v4, 0x5

    invoke-virtual {v10, v13, v2, v5, v4}, Lo/d;->f(Lo/i;Lo/i;II)V

    :cond_55
    if-eqz v18, :cond_56

    if-eqz v21, :cond_56

    if-nez p14, :cond_56

    if-nez p9, :cond_56

    if-eqz v21, :cond_57

    move/from16 v14, v17

    const/4 v2, 0x3

    if-ne v14, v2, :cond_57

    const/4 v2, 0x0

    const/16 v4, 0x8

    invoke-virtual {v10, v3, v13, v2, v4}, Lo/d;->f(Lo/i;Lo/i;II)V

    :cond_56
    const/4 v4, 0x5

    goto :goto_27

    :cond_57
    const/4 v2, 0x0

    const/4 v4, 0x5

    invoke-virtual {v10, v3, v13, v2, v4}, Lo/d;->f(Lo/i;Lo/i;II)V

    :goto_27
    move v11, v4

    goto :goto_29

    :goto_28
    move/from16 v18, p3

    goto :goto_27

    :goto_29
    if-eqz v18, :cond_59

    if-eqz p5, :cond_59

    iget-object v2, v15, Lq/c;->f:Lq/c;

    if-eqz v2, :cond_58

    invoke-virtual/range {p11 .. p11}, Lq/c;->e()I

    move-result v2

    move-object/from16 v4, p7

    goto :goto_2a

    :cond_58
    move-object/from16 v4, p7

    const/4 v2, 0x0

    :goto_2a
    if-eq v1, v4, :cond_59

    invoke-virtual {v10, v4, v3, v2, v11}, Lo/d;->f(Lo/i;Lo/i;II)V

    :cond_59
    return-void

    :cond_5a
    move-object/from16 v2, p6

    move-object/from16 v4, p7

    move-object v3, v8

    move-object v13, v9

    move/from16 p5, v11

    move/from16 v1, v24

    const/16 v27, 0x1

    const/4 v5, 0x2

    :goto_2b
    if-ge v1, v5, :cond_5e

    if-eqz p3, :cond_5e

    if-eqz p5, :cond_5e

    const/4 v1, 0x0

    const/16 v5, 0x8

    invoke-virtual {v10, v13, v2, v1, v5}, Lo/d;->f(Lo/i;Lo/i;II)V

    iget-object v1, v0, Lq/d;->M:Lq/c;

    if-nez p2, :cond_5c

    iget-object v2, v1, Lq/c;->f:Lq/c;

    if-nez v2, :cond_5b

    goto :goto_2c

    :cond_5b
    const/4 v11, 0x0

    goto :goto_2d

    :cond_5c
    :goto_2c
    move/from16 v11, v27

    :goto_2d
    if-nez p2, :cond_5d

    iget-object v1, v1, Lq/c;->f:Lq/c;

    if-eqz v1, :cond_5d

    iget-object v1, v1, Lq/c;->d:Lq/d;

    iget v2, v1, Lq/d;->W:F

    const/4 v5, 0x0

    cmpl-float v2, v2, v5

    if-eqz v2, :cond_5e

    iget-object v1, v1, Lq/d;->p0:[I

    const/4 v2, 0x0

    aget v5, v1, v2

    const/4 v2, 0x3

    if-ne v5, v2, :cond_5e

    aget v1, v1, v27

    if-ne v1, v2, :cond_5e

    :goto_2e
    const/4 v1, 0x0

    const/16 v2, 0x8

    goto :goto_2f

    :cond_5d
    if-eqz v11, :cond_5e

    goto :goto_2e

    :goto_2f
    invoke-virtual {v10, v4, v3, v1, v2}, Lo/d;->f(Lo/i;Lo/i;II)V

    :cond_5e
    return-void

    :cond_5f
    const/4 v1, 0x0

    throw v1
.end method

.method public final f(ILq/d;II)V
    .locals 10

    .line 1
    const/4 v0, 0x7

    .line 2
    const/16 v1, 0x9

    .line 3
    .line 4
    const/16 v2, 0x8

    .line 5
    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v4, 0x3

    .line 8
    const/4 v5, 0x4

    .line 9
    const/4 v6, 0x5

    .line 10
    const/4 v7, 0x0

    .line 11
    if-ne p1, v0, :cond_c

    .line 12
    .line 13
    if-ne p3, v0, :cond_8

    .line 14
    .line 15
    invoke-virtual {p0, v3}, Lq/d;->j(I)Lq/c;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p0, v5}, Lq/d;->j(I)Lq/c;

    .line 20
    .line 21
    .line 22
    move-result-object p3

    .line 23
    invoke-virtual {p0, v4}, Lq/d;->j(I)Lq/c;

    .line 24
    .line 25
    .line 26
    move-result-object p4

    .line 27
    invoke-virtual {p0, v6}, Lq/d;->j(I)Lq/c;

    .line 28
    .line 29
    .line 30
    move-result-object v8

    .line 31
    const/4 v9, 0x1

    .line 32
    if-eqz p1, :cond_0

    .line 33
    .line 34
    invoke-virtual {p1}, Lq/c;->h()Z

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    if-nez p1, :cond_1

    .line 39
    .line 40
    :cond_0
    if-eqz p3, :cond_2

    .line 41
    .line 42
    invoke-virtual {p3}, Lq/c;->h()Z

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    if-eqz p1, :cond_2

    .line 47
    .line 48
    :cond_1
    move p1, v7

    .line 49
    goto :goto_0

    .line 50
    :cond_2
    invoke-virtual {p0, v3, p2, v3, v7}, Lq/d;->f(ILq/d;II)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p0, v5, p2, v5, v7}, Lq/d;->f(ILq/d;II)V

    .line 54
    .line 55
    .line 56
    move p1, v9

    .line 57
    :goto_0
    if-eqz p4, :cond_3

    .line 58
    .line 59
    invoke-virtual {p4}, Lq/c;->h()Z

    .line 60
    .line 61
    .line 62
    move-result p3

    .line 63
    if-nez p3, :cond_4

    .line 64
    .line 65
    :cond_3
    if-eqz v8, :cond_5

    .line 66
    .line 67
    invoke-virtual {v8}, Lq/c;->h()Z

    .line 68
    .line 69
    .line 70
    move-result p3

    .line 71
    if-eqz p3, :cond_5

    .line 72
    .line 73
    :cond_4
    move v9, v7

    .line 74
    goto :goto_1

    .line 75
    :cond_5
    invoke-virtual {p0, v4, p2, v4, v7}, Lq/d;->f(ILq/d;II)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p0, v6, p2, v6, v7}, Lq/d;->f(ILq/d;II)V

    .line 79
    .line 80
    .line 81
    :goto_1
    if-eqz p1, :cond_6

    .line 82
    .line 83
    if-eqz v9, :cond_6

    .line 84
    .line 85
    invoke-virtual {p0, v0}, Lq/d;->j(I)Lq/c;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    invoke-virtual {p2, v0}, Lq/d;->j(I)Lq/c;

    .line 90
    .line 91
    .line 92
    move-result-object p2

    .line 93
    goto :goto_4

    .line 94
    :cond_6
    if-eqz p1, :cond_7

    .line 95
    .line 96
    invoke-virtual {p0, v2}, Lq/d;->j(I)Lq/c;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-virtual {p2, v2}, Lq/d;->j(I)Lq/c;

    .line 101
    .line 102
    .line 103
    move-result-object p2

    .line 104
    goto :goto_4

    .line 105
    :cond_7
    if-eqz v9, :cond_1c

    .line 106
    .line 107
    invoke-virtual {p0, v1}, Lq/d;->j(I)Lq/c;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    invoke-virtual {p2, v1}, Lq/d;->j(I)Lq/c;

    .line 112
    .line 113
    .line 114
    move-result-object p2

    .line 115
    goto :goto_4

    .line 116
    :cond_8
    if-eq p3, v3, :cond_b

    .line 117
    .line 118
    if-ne p3, v5, :cond_9

    .line 119
    .line 120
    goto :goto_5

    .line 121
    :cond_9
    if-eq p3, v4, :cond_a

    .line 122
    .line 123
    if-ne p3, v6, :cond_1c

    .line 124
    .line 125
    :cond_a
    invoke-virtual {p0, v4, p2, p3, v7}, Lq/d;->f(ILq/d;II)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {p0, v6, p2, p3, v7}, Lq/d;->f(ILq/d;II)V

    .line 129
    .line 130
    .line 131
    :goto_2
    invoke-virtual {p0, v0}, Lq/d;->j(I)Lq/c;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    :goto_3
    invoke-virtual {p2, p3}, Lq/d;->j(I)Lq/c;

    .line 136
    .line 137
    .line 138
    move-result-object p2

    .line 139
    :goto_4
    invoke-virtual {p1, p2, v7}, Lq/c;->a(Lq/c;I)V

    .line 140
    .line 141
    .line 142
    goto/16 :goto_9

    .line 143
    .line 144
    :cond_b
    :goto_5
    invoke-virtual {p0, v3, p2, p3, v7}, Lq/d;->f(ILq/d;II)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p0, v5, p2, p3, v7}, Lq/d;->f(ILq/d;II)V

    .line 148
    .line 149
    .line 150
    goto :goto_2

    .line 151
    :cond_c
    if-ne p1, v2, :cond_e

    .line 152
    .line 153
    if-eq p3, v3, :cond_d

    .line 154
    .line 155
    if-ne p3, v5, :cond_e

    .line 156
    .line 157
    :cond_d
    invoke-virtual {p0, v3}, Lq/d;->j(I)Lq/c;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    invoke-virtual {p2, p3}, Lq/d;->j(I)Lq/c;

    .line 162
    .line 163
    .line 164
    move-result-object p2

    .line 165
    invoke-virtual {p0, v5}, Lq/d;->j(I)Lq/c;

    .line 166
    .line 167
    .line 168
    move-result-object p3

    .line 169
    invoke-virtual {p1, p2, v7}, Lq/c;->a(Lq/c;I)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {p3, p2, v7}, Lq/c;->a(Lq/c;I)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {p0, v2}, Lq/d;->j(I)Lq/c;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    goto :goto_4

    .line 180
    :cond_e
    if-ne p1, v1, :cond_10

    .line 181
    .line 182
    if-eq p3, v4, :cond_f

    .line 183
    .line 184
    if-ne p3, v6, :cond_10

    .line 185
    .line 186
    :cond_f
    invoke-virtual {p2, p3}, Lq/d;->j(I)Lq/c;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    invoke-virtual {p0, v4}, Lq/d;->j(I)Lq/c;

    .line 191
    .line 192
    .line 193
    move-result-object p2

    .line 194
    invoke-virtual {p2, p1, v7}, Lq/c;->a(Lq/c;I)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {p0, v6}, Lq/d;->j(I)Lq/c;

    .line 198
    .line 199
    .line 200
    move-result-object p2

    .line 201
    invoke-virtual {p2, p1, v7}, Lq/c;->a(Lq/c;I)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {p0, v1}, Lq/d;->j(I)Lq/c;

    .line 205
    .line 206
    .line 207
    move-result-object p2

    .line 208
    invoke-virtual {p2, p1, v7}, Lq/c;->a(Lq/c;I)V

    .line 209
    .line 210
    .line 211
    goto/16 :goto_9

    .line 212
    .line 213
    :cond_10
    if-ne p1, v2, :cond_11

    .line 214
    .line 215
    if-ne p3, v2, :cond_11

    .line 216
    .line 217
    invoke-virtual {p0, v3}, Lq/d;->j(I)Lq/c;

    .line 218
    .line 219
    .line 220
    move-result-object p1

    .line 221
    invoke-virtual {p2, v3}, Lq/d;->j(I)Lq/c;

    .line 222
    .line 223
    .line 224
    move-result-object p4

    .line 225
    invoke-virtual {p1, p4, v7}, Lq/c;->a(Lq/c;I)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {p0, v5}, Lq/d;->j(I)Lq/c;

    .line 229
    .line 230
    .line 231
    move-result-object p1

    .line 232
    invoke-virtual {p2, v5}, Lq/d;->j(I)Lq/c;

    .line 233
    .line 234
    .line 235
    move-result-object p4

    .line 236
    invoke-virtual {p1, p4, v7}, Lq/c;->a(Lq/c;I)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {p0, v2}, Lq/d;->j(I)Lq/c;

    .line 240
    .line 241
    .line 242
    move-result-object p1

    .line 243
    goto :goto_3

    .line 244
    :cond_11
    if-ne p1, v1, :cond_12

    .line 245
    .line 246
    if-ne p3, v1, :cond_12

    .line 247
    .line 248
    invoke-virtual {p0, v4}, Lq/d;->j(I)Lq/c;

    .line 249
    .line 250
    .line 251
    move-result-object p1

    .line 252
    invoke-virtual {p2, v4}, Lq/d;->j(I)Lq/c;

    .line 253
    .line 254
    .line 255
    move-result-object p4

    .line 256
    invoke-virtual {p1, p4, v7}, Lq/c;->a(Lq/c;I)V

    .line 257
    .line 258
    .line 259
    invoke-virtual {p0, v6}, Lq/d;->j(I)Lq/c;

    .line 260
    .line 261
    .line 262
    move-result-object p1

    .line 263
    invoke-virtual {p2, v6}, Lq/d;->j(I)Lq/c;

    .line 264
    .line 265
    .line 266
    move-result-object p4

    .line 267
    invoke-virtual {p1, p4, v7}, Lq/c;->a(Lq/c;I)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {p0, v1}, Lq/d;->j(I)Lq/c;

    .line 271
    .line 272
    .line 273
    move-result-object p1

    .line 274
    goto/16 :goto_3

    .line 275
    .line 276
    :cond_12
    invoke-virtual {p0, p1}, Lq/d;->j(I)Lq/c;

    .line 277
    .line 278
    .line 279
    move-result-object v7

    .line 280
    invoke-virtual {p2, p3}, Lq/d;->j(I)Lq/c;

    .line 281
    .line 282
    .line 283
    move-result-object p2

    .line 284
    invoke-virtual {v7, p2}, Lq/c;->i(Lq/c;)Z

    .line 285
    .line 286
    .line 287
    move-result p3

    .line 288
    if-eqz p3, :cond_1c

    .line 289
    .line 290
    const/4 p3, 0x6

    .line 291
    if-ne p1, p3, :cond_14

    .line 292
    .line 293
    invoke-virtual {p0, v4}, Lq/d;->j(I)Lq/c;

    .line 294
    .line 295
    .line 296
    move-result-object p1

    .line 297
    invoke-virtual {p0, v6}, Lq/d;->j(I)Lq/c;

    .line 298
    .line 299
    .line 300
    move-result-object p3

    .line 301
    if-eqz p1, :cond_13

    .line 302
    .line 303
    invoke-virtual {p1}, Lq/c;->j()V

    .line 304
    .line 305
    .line 306
    :cond_13
    if-eqz p3, :cond_1b

    .line 307
    .line 308
    invoke-virtual {p3}, Lq/c;->j()V

    .line 309
    .line 310
    .line 311
    goto :goto_8

    .line 312
    :cond_14
    if-eq p1, v4, :cond_18

    .line 313
    .line 314
    if-ne p1, v6, :cond_15

    .line 315
    .line 316
    goto :goto_7

    .line 317
    :cond_15
    if-eq p1, v3, :cond_16

    .line 318
    .line 319
    if-ne p1, v5, :cond_1b

    .line 320
    .line 321
    :cond_16
    invoke-virtual {p0, v0}, Lq/d;->j(I)Lq/c;

    .line 322
    .line 323
    .line 324
    move-result-object p3

    .line 325
    iget-object v0, p3, Lq/c;->f:Lq/c;

    .line 326
    .line 327
    if-eq v0, p2, :cond_17

    .line 328
    .line 329
    invoke-virtual {p3}, Lq/c;->j()V

    .line 330
    .line 331
    .line 332
    :cond_17
    invoke-virtual {p0, p1}, Lq/d;->j(I)Lq/c;

    .line 333
    .line 334
    .line 335
    move-result-object p1

    .line 336
    invoke-virtual {p1}, Lq/c;->f()Lq/c;

    .line 337
    .line 338
    .line 339
    move-result-object p1

    .line 340
    invoke-virtual {p0, v2}, Lq/d;->j(I)Lq/c;

    .line 341
    .line 342
    .line 343
    move-result-object p3

    .line 344
    invoke-virtual {p3}, Lq/c;->h()Z

    .line 345
    .line 346
    .line 347
    move-result v0

    .line 348
    if-eqz v0, :cond_1b

    .line 349
    .line 350
    :goto_6
    invoke-virtual {p1}, Lq/c;->j()V

    .line 351
    .line 352
    .line 353
    invoke-virtual {p3}, Lq/c;->j()V

    .line 354
    .line 355
    .line 356
    goto :goto_8

    .line 357
    :cond_18
    :goto_7
    invoke-virtual {p0, p3}, Lq/d;->j(I)Lq/c;

    .line 358
    .line 359
    .line 360
    move-result-object p3

    .line 361
    if-eqz p3, :cond_19

    .line 362
    .line 363
    invoke-virtual {p3}, Lq/c;->j()V

    .line 364
    .line 365
    .line 366
    :cond_19
    invoke-virtual {p0, v0}, Lq/d;->j(I)Lq/c;

    .line 367
    .line 368
    .line 369
    move-result-object p3

    .line 370
    iget-object v0, p3, Lq/c;->f:Lq/c;

    .line 371
    .line 372
    if-eq v0, p2, :cond_1a

    .line 373
    .line 374
    invoke-virtual {p3}, Lq/c;->j()V

    .line 375
    .line 376
    .line 377
    :cond_1a
    invoke-virtual {p0, p1}, Lq/d;->j(I)Lq/c;

    .line 378
    .line 379
    .line 380
    move-result-object p1

    .line 381
    invoke-virtual {p1}, Lq/c;->f()Lq/c;

    .line 382
    .line 383
    .line 384
    move-result-object p1

    .line 385
    invoke-virtual {p0, v1}, Lq/d;->j(I)Lq/c;

    .line 386
    .line 387
    .line 388
    move-result-object p3

    .line 389
    invoke-virtual {p3}, Lq/c;->h()Z

    .line 390
    .line 391
    .line 392
    move-result v0

    .line 393
    if-eqz v0, :cond_1b

    .line 394
    .line 395
    goto :goto_6

    .line 396
    :cond_1b
    :goto_8
    invoke-virtual {v7, p2, p4}, Lq/c;->a(Lq/c;I)V

    .line 397
    .line 398
    .line 399
    :cond_1c
    :goto_9
    return-void
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
.end method

.method public final g(Lq/c;Lq/c;I)V
    .locals 1

    .line 1
    iget-object v0, p1, Lq/c;->d:Lq/d;

    .line 2
    .line 3
    if-ne v0, p0, :cond_0

    .line 4
    .line 5
    iget-object v0, p2, Lq/c;->d:Lq/d;

    .line 6
    .line 7
    iget p1, p1, Lq/c;->e:I

    .line 8
    .line 9
    iget p2, p2, Lq/c;->e:I

    .line 10
    .line 11
    invoke-virtual {p0, p1, v0, p2, p3}, Lq/d;->f(ILq/d;II)V

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method

.method public final h(Lo/d;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lq/d;->I:Lq/c;

    invoke-virtual {p1, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    iget-object v0, p0, Lq/d;->J:Lq/c;

    invoke-virtual {p1, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    iget-object v0, p0, Lq/d;->K:Lq/c;

    invoke-virtual {p1, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    iget-object v0, p0, Lq/d;->L:Lq/c;

    invoke-virtual {p1, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    iget v0, p0, Lq/d;->a0:I

    if-lez v0, :cond_0

    iget-object v0, p0, Lq/d;->M:Lq/c;

    invoke-virtual {p1, v0}, Lo/d;->k(Ljava/lang/Object;)Lo/i;

    :cond_0
    return-void
.end method

.method public final i()V
    .locals 4

    .line 1
    iget-object v0, p0, Lq/d;->d:Lr/k;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lr/k;

    .line 6
    .line 7
    invoke-direct {v0, p0}, Lr/p;-><init>(Lq/d;)V

    .line 8
    .line 9
    .line 10
    iget-object v1, v0, Lr/p;->h:Lr/f;

    .line 11
    .line 12
    const/4 v2, 0x4

    .line 13
    iput v2, v1, Lr/f;->e:I

    .line 14
    .line 15
    iget-object v1, v0, Lr/p;->i:Lr/f;

    .line 16
    .line 17
    const/4 v2, 0x5

    .line 18
    iput v2, v1, Lr/f;->e:I

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    iput v1, v0, Lr/p;->f:I

    .line 22
    .line 23
    iput-object v0, p0, Lq/d;->d:Lr/k;

    .line 24
    .line 25
    :cond_0
    iget-object v0, p0, Lq/d;->e:Lr/m;

    .line 26
    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    new-instance v0, Lr/m;

    .line 30
    .line 31
    invoke-direct {v0, p0}, Lr/p;-><init>(Lq/d;)V

    .line 32
    .line 33
    .line 34
    new-instance v1, Lr/f;

    .line 35
    .line 36
    invoke-direct {v1, v0}, Lr/f;-><init>(Lr/p;)V

    .line 37
    .line 38
    .line 39
    iput-object v1, v0, Lr/m;->k:Lr/f;

    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    iput-object v2, v0, Lr/m;->l:Lr/a;

    .line 43
    .line 44
    iget-object v2, v0, Lr/p;->h:Lr/f;

    .line 45
    .line 46
    const/4 v3, 0x6

    .line 47
    iput v3, v2, Lr/f;->e:I

    .line 48
    .line 49
    iget-object v2, v0, Lr/p;->i:Lr/f;

    .line 50
    .line 51
    const/4 v3, 0x7

    .line 52
    iput v3, v2, Lr/f;->e:I

    .line 53
    .line 54
    const/16 v2, 0x8

    .line 55
    .line 56
    iput v2, v1, Lr/f;->e:I

    .line 57
    .line 58
    const/4 v1, 0x1

    .line 59
    iput v1, v0, Lr/p;->f:I

    .line 60
    .line 61
    iput-object v0, p0, Lq/d;->e:Lr/m;

    .line 62
    .line 63
    :cond_1
    return-void
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public j(I)Lq/c;
    .locals 2

    .line 1
    const/4 v0, 0x0

    if-eqz p1, :cond_0

    add-int/lit8 v1, p1, -0x1

    packed-switch v1, :pswitch_data_0

    new-instance v0, Ljava/lang/AssertionError;

    invoke-static {p1}, Landroidx/fragment/app/e1;->s(I)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0

    :pswitch_0
    iget-object p1, p0, Lq/d;->O:Lq/c;

    return-object p1

    :pswitch_1
    iget-object p1, p0, Lq/d;->N:Lq/c;

    return-object p1

    :pswitch_2
    iget-object p1, p0, Lq/d;->P:Lq/c;

    return-object p1

    :pswitch_3
    iget-object p1, p0, Lq/d;->M:Lq/c;

    return-object p1

    :pswitch_4
    iget-object p1, p0, Lq/d;->L:Lq/c;

    return-object p1

    :pswitch_5
    iget-object p1, p0, Lq/d;->K:Lq/c;

    return-object p1

    :pswitch_6
    iget-object p1, p0, Lq/d;->J:Lq/c;

    return-object p1

    :pswitch_7
    iget-object p1, p0, Lq/d;->I:Lq/c;

    return-object p1

    :pswitch_8
    return-object v0

    :cond_0
    throw v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final k(I)I
    .locals 3

    .line 1
    iget-object v0, p0, Lq/d;->p0:[I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez p1, :cond_0

    .line 5
    .line 6
    aget p1, v0, v1

    .line 7
    .line 8
    return p1

    .line 9
    :cond_0
    const/4 v2, 0x1

    .line 10
    if-ne p1, v2, :cond_1

    .line 11
    .line 12
    aget p1, v0, v2

    .line 13
    .line 14
    return p1

    .line 15
    :cond_1
    return v1
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
.end method

.method public final l()I
    .locals 2

    .line 1
    iget v0, p0, Lq/d;->g0:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Lq/d;->V:I

    return v0
.end method

.method public final m(I)Lq/d;
    .locals 2

    .line 1
    if-nez p1, :cond_0

    iget-object p1, p0, Lq/d;->K:Lq/c;

    iget-object v0, p1, Lq/c;->f:Lq/c;

    if-eqz v0, :cond_1

    iget-object v1, v0, Lq/c;->f:Lq/c;

    if-ne v1, p1, :cond_1

    iget-object p1, v0, Lq/c;->d:Lq/d;

    return-object p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lq/d;->L:Lq/c;

    iget-object v0, p1, Lq/c;->f:Lq/c;

    if-eqz v0, :cond_1

    iget-object v1, v0, Lq/c;->f:Lq/c;

    if-ne v1, p1, :cond_1

    iget-object p1, v0, Lq/c;->d:Lq/d;

    return-object p1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public final n(I)Lq/d;
    .locals 2

    .line 1
    if-nez p1, :cond_0

    iget-object p1, p0, Lq/d;->I:Lq/c;

    iget-object v0, p1, Lq/c;->f:Lq/c;

    if-eqz v0, :cond_1

    iget-object v1, v0, Lq/c;->f:Lq/c;

    if-ne v1, p1, :cond_1

    iget-object p1, v0, Lq/c;->d:Lq/d;

    return-object p1

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lq/d;->J:Lq/c;

    iget-object v0, p1, Lq/c;->f:Lq/c;

    if-eqz v0, :cond_1

    iget-object v1, v0, Lq/c;->f:Lq/c;

    if-ne v1, p1, :cond_1

    iget-object p1, v0, Lq/c;->d:Lq/d;

    return-object p1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public o(Ljava/lang/StringBuilder;)V
    .locals 11

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "  "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lq/d;->j:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ":{\n"

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    new-instance v0, Ljava/lang/StringBuilder;

    .line 26
    .line 27
    const-string v1, "    actualWidth:"

    .line 28
    .line 29
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    iget v1, p0, Lq/d;->U:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    const-string v0, "\n"

    .line 45
    .line 46
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    new-instance v1, Ljava/lang/StringBuilder;

    .line 50
    .line 51
    const-string v2, "    actualHeight:"

    .line 52
    .line 53
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    iget v2, p0, Lq/d;->V:I

    .line 57
    .line 58
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    new-instance v1, Ljava/lang/StringBuilder;

    .line 72
    .line 73
    const-string v2, "    actualLeft:"

    .line 74
    .line 75
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    iget v2, p0, Lq/d;->Y:I

    .line 79
    .line 80
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    new-instance v1, Ljava/lang/StringBuilder;

    .line 94
    .line 95
    const-string v2, "    actualTop:"

    .line 96
    .line 97
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    iget v2, p0, Lq/d;->Z:I

    .line 101
    .line 102
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 103
    .line 104
    .line 105
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 113
    .line 114
    .line 115
    const-string v0, "left"

    .line 116
    .line 117
    iget-object v1, p0, Lq/d;->I:Lq/c;

    .line 118
    .line 119
    invoke-static {p1, v0, v1}, Lq/d;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lq/c;)V

    .line 120
    .line 121
    .line 122
    const-string v0, "top"

    .line 123
    .line 124
    iget-object v1, p0, Lq/d;->J:Lq/c;

    .line 125
    .line 126
    invoke-static {p1, v0, v1}, Lq/d;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lq/c;)V

    .line 127
    .line 128
    .line 129
    const-string v0, "right"

    .line 130
    .line 131
    iget-object v1, p0, Lq/d;->K:Lq/c;

    .line 132
    .line 133
    invoke-static {p1, v0, v1}, Lq/d;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lq/c;)V

    .line 134
    .line 135
    .line 136
    const-string v0, "bottom"

    .line 137
    .line 138
    iget-object v1, p0, Lq/d;->L:Lq/c;

    .line 139
    .line 140
    invoke-static {p1, v0, v1}, Lq/d;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lq/c;)V

    .line 141
    .line 142
    .line 143
    const-string v0, "baseline"

    .line 144
    .line 145
    iget-object v1, p0, Lq/d;->M:Lq/c;

    .line 146
    .line 147
    invoke-static {p1, v0, v1}, Lq/d;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lq/c;)V

    .line 148
    .line 149
    .line 150
    const-string v0, "centerX"

    .line 151
    .line 152
    iget-object v1, p0, Lq/d;->N:Lq/c;

    .line 153
    .line 154
    invoke-static {p1, v0, v1}, Lq/d;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lq/c;)V

    .line 155
    .line 156
    .line 157
    const-string v0, "centerY"

    .line 158
    .line 159
    iget-object v1, p0, Lq/d;->O:Lq/c;

    .line 160
    .line 161
    invoke-static {p1, v0, v1}, Lq/d;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Lq/c;)V

    .line 162
    .line 163
    .line 164
    const-string v1, "    width"

    .line 165
    .line 166
    iget v2, p0, Lq/d;->U:I

    .line 167
    .line 168
    iget v3, p0, Lq/d;->b0:I

    .line 169
    .line 170
    iget-object v8, p0, Lq/d;->C:[I

    .line 171
    .line 172
    const/4 v9, 0x0

    .line 173
    aget v4, v8, v9

    .line 174
    .line 175
    iget v5, p0, Lq/d;->u:I

    .line 176
    .line 177
    iget v6, p0, Lq/d;->r:I

    .line 178
    .line 179
    iget v7, p0, Lq/d;->w:F

    .line 180
    .line 181
    iget-object v10, p0, Lq/d;->k0:[F

    .line 182
    .line 183
    aget v0, v10, v9

    .line 184
    .line 185
    move-object v0, p1

    .line 186
    invoke-static/range {v0 .. v7}, Lq/d;->p(Ljava/lang/StringBuilder;Ljava/lang/String;IIIIIF)V

    .line 187
    .line 188
    .line 189
    const-string v1, "    height"

    .line 190
    .line 191
    iget v2, p0, Lq/d;->V:I

    .line 192
    .line 193
    iget v3, p0, Lq/d;->c0:I

    .line 194
    .line 195
    const/4 v0, 0x1

    .line 196
    aget v4, v8, v0

    .line 197
    .line 198
    iget v5, p0, Lq/d;->x:I

    .line 199
    .line 200
    iget v6, p0, Lq/d;->s:I

    .line 201
    .line 202
    iget v7, p0, Lq/d;->z:F

    .line 203
    .line 204
    aget v0, v10, v0

    .line 205
    .line 206
    move-object v0, p1

    .line 207
    invoke-static/range {v0 .. v7}, Lq/d;->p(Ljava/lang/StringBuilder;Ljava/lang/String;IIIIIF)V

    .line 208
    .line 209
    .line 210
    iget v0, p0, Lq/d;->W:F

    .line 211
    .line 212
    iget v1, p0, Lq/d;->X:I

    .line 213
    .line 214
    const/4 v2, 0x0

    .line 215
    cmpl-float v2, v0, v2

    .line 216
    .line 217
    if-nez v2, :cond_0

    .line 218
    .line 219
    goto :goto_0

    .line 220
    :cond_0
    const-string v2, "    dimensionRatio"

    .line 221
    .line 222
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 223
    .line 224
    .line 225
    const-string v2, " :  ["

    .line 226
    .line 227
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 228
    .line 229
    .line 230
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 231
    .line 232
    .line 233
    const-string v0, ","

    .line 234
    .line 235
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 236
    .line 237
    .line 238
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 239
    .line 240
    .line 241
    const-string v0, ""

    .line 242
    .line 243
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 244
    .line 245
    .line 246
    const-string v0, "],\n"

    .line 247
    .line 248
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 249
    .line 250
    .line 251
    :goto_0
    iget v0, p0, Lq/d;->d0:F

    .line 252
    .line 253
    const-string v1, "    horizontalBias"

    .line 254
    .line 255
    const/high16 v2, 0x3f000000    # 0.5f

    .line 256
    .line 257
    invoke-static {p1, v1, v0, v2}, Lq/d;->I(Ljava/lang/StringBuilder;Ljava/lang/String;FF)V

    .line 258
    .line 259
    .line 260
    const-string v0, "    verticalBias"

    .line 261
    .line 262
    iget v1, p0, Lq/d;->e0:F

    .line 263
    .line 264
    invoke-static {p1, v0, v1, v2}, Lq/d;->I(Ljava/lang/StringBuilder;Ljava/lang/String;FF)V

    .line 265
    .line 266
    .line 267
    const-string v0, "    horizontalChainStyle"

    .line 268
    .line 269
    iget v1, p0, Lq/d;->i0:I

    .line 270
    .line 271
    invoke-static {v1, v9, v0, p1}, Lq/d;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 272
    .line 273
    .line 274
    const-string v0, "    verticalChainStyle"

    .line 275
    .line 276
    iget v1, p0, Lq/d;->j0:I

    .line 277
    .line 278
    invoke-static {v1, v9, v0, p1}, Lq/d;->H(IILjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 279
    .line 280
    .line 281
    const-string v0, "  }"

    .line 282
    .line 283
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 284
    .line 285
    .line 286
    return-void
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
.end method

.method public final r()I
    .locals 2

    .line 1
    iget v0, p0, Lq/d;->g0:I

    const/16 v1, 0x8

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget v0, p0, Lq/d;->U:I

    return v0
.end method

.method public final s()I
    .locals 2

    .line 1
    iget-object v0, p0, Lq/d;->T:Lq/d;

    if-eqz v0, :cond_0

    instance-of v1, v0, Lq/e;

    if-eqz v1, :cond_0

    check-cast v0, Lq/e;

    iget v0, v0, Lq/e;->x0:I

    iget v1, p0, Lq/d;->Y:I

    add-int/2addr v0, v1

    return v0

    :cond_0
    iget v0, p0, Lq/d;->Y:I

    return v0
.end method

.method public final t()I
    .locals 2

    .line 1
    iget-object v0, p0, Lq/d;->T:Lq/d;

    if-eqz v0, :cond_0

    instance-of v1, v0, Lq/e;

    if-eqz v1, :cond_0

    check-cast v0, Lq/e;

    iget v0, v0, Lq/e;->y0:I

    iget v1, p0, Lq/d;->Z:I

    add-int/2addr v0, v1

    return v0

    :cond_0
    iget v0, p0, Lq/d;->Z:I

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, ""

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    iget-object v2, p0, Lq/d;->h0:Ljava/lang/String;

    .line 12
    .line 13
    if-eqz v2, :cond_0

    .line 14
    .line 15
    new-instance v1, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v2, "id: "

    .line 18
    .line 19
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v2, p0, Lq/d;->h0:Ljava/lang/String;

    .line 23
    .line 24
    const-string v3, " "

    .line 25
    .line 26
    invoke-static {v1, v2, v3}, Landroidx/fragment/app/e1;->g(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    :cond_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const-string v1, "("

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    iget v1, p0, Lq/d;->Y:I

    .line 39
    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v1, ", "

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    iget v1, p0, Lq/d;->Z:I

    .line 49
    .line 50
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    const-string v1, ") - ("

    .line 54
    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    iget v1, p0, Lq/d;->U:I

    .line 59
    .line 60
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string v1, " x "

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    iget v1, p0, Lq/d;->V:I

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    const-string v1, ")"

    .line 74
    .line 75
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    return-object v0
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
.end method

.method public final u(I)Z
    .locals 4

    .line 1
    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez p1, :cond_3

    iget-object p1, p0, Lq/d;->I:Lq/c;

    iget-object p1, p1, Lq/c;->f:Lq/c;

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_0

    :cond_0
    move p1, v1

    :goto_0
    iget-object v3, p0, Lq/d;->K:Lq/c;

    iget-object v3, v3, Lq/c;->f:Lq/c;

    if-eqz v3, :cond_1

    move v3, v2

    goto :goto_1

    :cond_1
    move v3, v1

    :goto_1
    add-int/2addr p1, v3

    if-ge p1, v0, :cond_2

    move v1, v2

    :cond_2
    return v1

    :cond_3
    iget-object p1, p0, Lq/d;->J:Lq/c;

    iget-object p1, p1, Lq/c;->f:Lq/c;

    if-eqz p1, :cond_4

    move p1, v2

    goto :goto_2

    :cond_4
    move p1, v1

    :goto_2
    iget-object v3, p0, Lq/d;->L:Lq/c;

    iget-object v3, v3, Lq/c;->f:Lq/c;

    if-eqz v3, :cond_5

    move v3, v2

    goto :goto_3

    :cond_5
    move v3, v1

    :goto_3
    add-int/2addr p1, v3

    iget-object v3, p0, Lq/d;->M:Lq/c;

    iget-object v3, v3, Lq/c;->f:Lq/c;

    if-eqz v3, :cond_6

    move v3, v2

    goto :goto_4

    :cond_6
    move v3, v1

    :goto_4
    add-int/2addr p1, v3

    if-ge p1, v0, :cond_7

    move v1, v2

    :cond_7
    return v1
.end method

.method public final v(II)Z
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    if-nez p1, :cond_1

    .line 4
    .line 5
    iget-object p1, p0, Lq/d;->I:Lq/c;

    .line 6
    .line 7
    iget-object v2, p1, Lq/c;->f:Lq/c;

    .line 8
    .line 9
    if-eqz v2, :cond_3

    .line 10
    .line 11
    iget-boolean v2, v2, Lq/c;->c:Z

    .line 12
    .line 13
    if-eqz v2, :cond_3

    .line 14
    .line 15
    iget-object v2, p0, Lq/d;->K:Lq/c;

    .line 16
    .line 17
    iget-object v3, v2, Lq/c;->f:Lq/c;

    .line 18
    .line 19
    if-eqz v3, :cond_3

    .line 20
    .line 21
    iget-boolean v4, v3, Lq/c;->c:Z

    .line 22
    .line 23
    if-eqz v4, :cond_3

    .line 24
    .line 25
    invoke-virtual {v3}, Lq/c;->d()I

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    invoke-virtual {v2}, Lq/c;->e()I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    sub-int/2addr v3, v2

    .line 34
    iget-object v2, p1, Lq/c;->f:Lq/c;

    .line 35
    .line 36
    invoke-virtual {v2}, Lq/c;->d()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-virtual {p1}, Lq/c;->e()I

    .line 41
    .line 42
    .line 43
    move-result p1

    .line 44
    add-int/2addr p1, v2

    .line 45
    sub-int/2addr v3, p1

    .line 46
    if-lt v3, p2, :cond_0

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_0
    move v0, v1

    .line 50
    :goto_0
    return v0

    .line 51
    :cond_1
    iget-object p1, p0, Lq/d;->J:Lq/c;

    .line 52
    .line 53
    iget-object v2, p1, Lq/c;->f:Lq/c;

    .line 54
    .line 55
    if-eqz v2, :cond_3

    .line 56
    .line 57
    iget-boolean v2, v2, Lq/c;->c:Z

    .line 58
    .line 59
    if-eqz v2, :cond_3

    .line 60
    .line 61
    iget-object v2, p0, Lq/d;->L:Lq/c;

    .line 62
    .line 63
    iget-object v3, v2, Lq/c;->f:Lq/c;

    .line 64
    .line 65
    if-eqz v3, :cond_3

    .line 66
    .line 67
    iget-boolean v4, v3, Lq/c;->c:Z

    .line 68
    .line 69
    if-eqz v4, :cond_3

    .line 70
    .line 71
    invoke-virtual {v3}, Lq/c;->d()I

    .line 72
    .line 73
    .line 74
    move-result v3

    .line 75
    invoke-virtual {v2}, Lq/c;->e()I

    .line 76
    .line 77
    .line 78
    move-result v2

    .line 79
    sub-int/2addr v3, v2

    .line 80
    iget-object v2, p1, Lq/c;->f:Lq/c;

    .line 81
    .line 82
    invoke-virtual {v2}, Lq/c;->d()I

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    invoke-virtual {p1}, Lq/c;->e()I

    .line 87
    .line 88
    .line 89
    move-result p1

    .line 90
    add-int/2addr p1, v2

    .line 91
    sub-int/2addr v3, p1

    .line 92
    if-lt v3, p2, :cond_2

    .line 93
    .line 94
    goto :goto_1

    .line 95
    :cond_2
    move v0, v1

    .line 96
    :goto_1
    return v0

    .line 97
    :cond_3
    return v1
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
.end method

.method public final w(ILq/d;III)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lq/d;->j(I)Lq/c;

    move-result-object p1

    invoke-virtual {p2, p3}, Lq/d;->j(I)Lq/c;

    move-result-object p2

    const/4 p3, 0x1

    invoke-virtual {p1, p2, p4, p5, p3}, Lq/c;->b(Lq/c;IIZ)Z

    return-void
.end method

.method public final x(I)Z
    .locals 3

    .line 1
    mul-int/lit8 p1, p1, 0x2

    iget-object v0, p0, Lq/d;->Q:[Lq/c;

    aget-object v1, v0, p1

    iget-object v2, v1, Lq/c;->f:Lq/c;

    if-eqz v2, :cond_0

    iget-object v2, v2, Lq/c;->f:Lq/c;

    if-eq v2, v1, :cond_0

    const/4 v1, 0x1

    add-int/2addr p1, v1

    aget-object p1, v0, p1

    iget-object v0, p1, Lq/c;->f:Lq/c;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lq/c;->f:Lq/c;

    if-ne v0, p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final y()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lq/d;->I:Lq/c;

    iget-object v1, v0, Lq/c;->f:Lq/c;

    if-eqz v1, :cond_0

    iget-object v1, v1, Lq/c;->f:Lq/c;

    if-eq v1, v0, :cond_1

    :cond_0
    iget-object v0, p0, Lq/d;->K:Lq/c;

    iget-object v1, v0, Lq/c;->f:Lq/c;

    if-eqz v1, :cond_2

    iget-object v1, v1, Lq/c;->f:Lq/c;

    if-ne v1, v0, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method

.method public final z()Z
    .locals 2

    .line 1
    iget-object v0, p0, Lq/d;->J:Lq/c;

    iget-object v1, v0, Lq/c;->f:Lq/c;

    if-eqz v1, :cond_0

    iget-object v1, v1, Lq/c;->f:Lq/c;

    if-eq v1, v0, :cond_1

    :cond_0
    iget-object v0, p0, Lq/d;->L:Lq/c;

    iget-object v1, v0, Lq/c;->f:Lq/c;

    if-eqz v1, :cond_2

    iget-object v1, v1, Lq/c;->f:Lq/c;

    if-ne v1, v0, :cond_2

    :cond_1
    const/4 v0, 0x1

    return v0

    :cond_2
    const/4 v0, 0x0

    return v0
.end method
