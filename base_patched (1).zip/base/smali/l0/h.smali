.class public interface abstract Ll0/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()Landroid/net/Uri;
.end method

.method public abstract c()Landroid/content/ClipDescription;
.end method

.method public abstract d()Ljava/lang/Object;
.end method

.method public abstract e()Landroid/net/Uri;
.end method
