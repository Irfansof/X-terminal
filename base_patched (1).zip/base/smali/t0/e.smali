.class public abstract Lt0/e;
.super Ljava/lang/RuntimeException;
.source "SourceFile"


# instance fields
.field public final g:Landroidx/fragment/app/v;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/v;Ljava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "fragment"

    invoke-static {p1, v0}, Le2/m;->y(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lt0/e;->g:Landroidx/fragment/app/v;

    return-void
.end method
