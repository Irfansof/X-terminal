.class public final Lw0/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/v0;


# virtual methods
.method public final a(Ljava/lang/Class;)Landroidx/lifecycle/r0;
    .locals 0

    .line 1
    new-instance p1, Lw0/b;

    invoke-direct {p1}, Lw0/b;-><init>()V

    return-object p1
.end method
