.class public final Lo1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final g:Landroid/view/View;

.field public final h:Z

.field public final synthetic i:Lcom/google/android/material/behavior/SwipeDismissBehavior;


# direct methods
.method public constructor <init>(Lcom/google/android/material/behavior/SwipeDismissBehavior;Landroid/view/View;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lo1/d;->i:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    iput-object p2, p0, Lo1/d;->g:Landroid/view/View;

    iput-boolean p3, p0, Lo1/d;->h:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget-object v0, p0, Lo1/d;->i:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    iget-object v1, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a:Lo0/e;

    iget-object v2, p0, Lo1/d;->g:Landroid/view/View;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lo0/e;->f()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v2, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    goto :goto_0

    :cond_0
    iget-boolean v1, p0, Lo1/d;->h:Z

    if-eqz v1, :cond_1

    iget-object v0, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b:Lg2/f;

    if-eqz v0, :cond_1

    invoke-virtual {v0, v2}, Lg2/f;->b(Landroid/view/View;)V

    :cond_1
    :goto_0
    return-void
.end method
