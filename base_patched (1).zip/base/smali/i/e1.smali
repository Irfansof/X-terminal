.class public Li/e1;
.super Le/n0;
.source "SourceFile"


# instance fields
.field public final synthetic d:Li/g1;


# direct methods
.method public constructor <init>(Li/g1;)V
    .locals 1

    .line 1
    iput-object p1, p0, Li/e1;->d:Li/g1;

    const/4 v0, 0x6

    invoke-direct {p0, v0, p1}, Le/n0;-><init>(ILjava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final n(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Li/e1;->d:Li/g1;

    invoke-static {v0, p1}, Li/g1;->e(Li/g1;I)V

    return-void
.end method

.method public final o(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Li/e1;->d:Li/g1;

    invoke-static {v0, p1}, Li/g1;->d(Li/g1;I)V

    return-void
.end method
