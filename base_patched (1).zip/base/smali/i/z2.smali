.class public abstract Li/z2;
.super Li/r2;
.source "SourceFile"
