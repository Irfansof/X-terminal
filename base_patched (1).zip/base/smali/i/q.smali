.class public interface abstract Li/q;
.super Ljava/lang/Object;
.source "SourceFile"
