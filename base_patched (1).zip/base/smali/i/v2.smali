.class public abstract Li/v2;
.super Li/b2;
.source "SourceFile"

# interfaces
.implements Lg/d;
