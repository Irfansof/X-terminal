.class public Li/a2;
.super Landroid/widget/LinearLayout$LayoutParams;
.source "SourceFile"
