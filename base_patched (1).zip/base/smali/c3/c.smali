.class public interface abstract Lc3/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc3/a;
