.class public final Lp0/j;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:D

.field public b:D

.field public c:Z

.field public d:D

.field public e:D

.field public f:D

.field public g:D

.field public h:D

.field public i:D

.field public final j:Lp0/g;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide v0, 0x4097700000000000L    # 1500.0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    iput-wide v0, p0, Lp0/j;->a:D

    const-wide/high16 v0, 0x3fe0000000000000L    # 0.5

    iput-wide v0, p0, Lp0/j;->b:D

    const/4 v0, 0x0

    iput-boolean v0, p0, Lp0/j;->c:Z

    const-wide v0, 0x7fefffffffffffffL    # Double.MAX_VALUE

    iput-wide v0, p0, Lp0/j;->i:D

    new-instance v0, Lp0/g;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lp0/j;->j:Lp0/g;

    return-void
.end method

.method public constructor <init>(F)V
    .locals 2

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide v0, 0x4097700000000000L    # 1500.0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    iput-wide v0, p0, Lp0/j;->a:D

    const-wide/high16 v0, 0x3fe0000000000000L    # 0.5

    iput-wide v0, p0, Lp0/j;->b:D

    const/4 v0, 0x0

    iput-boolean v0, p0, Lp0/j;->c:Z

    new-instance v0, Lp0/g;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lp0/j;->j:Lp0/g;

    float-to-double v0, p1

    iput-wide v0, p0, Lp0/j;->i:D

    return-void
.end method


# virtual methods
.method public final a(DDJ)Lp0/g;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-boolean v1, v0, Lp0/j;->c:Z

    .line 4
    .line 5
    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    :goto_0
    move-wide/from16 v4, p5

    .line 10
    .line 11
    goto :goto_2

    .line 12
    :cond_0
    iget-wide v4, v0, Lp0/j;->i:D

    .line 13
    .line 14
    const-wide v6, 0x7fefffffffffffffL    # Double.MAX_VALUE

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    cmpl-double v1, v4, v6

    .line 20
    .line 21
    if-eqz v1, :cond_5

    .line 22
    .line 23
    iget-wide v4, v0, Lp0/j;->b:D

    .line 24
    .line 25
    cmpl-double v1, v4, v2

    .line 26
    .line 27
    if-lez v1, :cond_1

    .line 28
    .line 29
    neg-double v6, v4

    .line 30
    iget-wide v8, v0, Lp0/j;->a:D

    .line 31
    .line 32
    mul-double/2addr v6, v8

    .line 33
    mul-double/2addr v4, v4

    .line 34
    sub-double/2addr v4, v2

    .line 35
    invoke-static {v4, v5}, Ljava/lang/Math;->sqrt(D)D

    .line 36
    .line 37
    .line 38
    move-result-wide v4

    .line 39
    mul-double/2addr v4, v8

    .line 40
    add-double/2addr v4, v6

    .line 41
    iput-wide v4, v0, Lp0/j;->f:D

    .line 42
    .line 43
    iget-wide v4, v0, Lp0/j;->b:D

    .line 44
    .line 45
    neg-double v6, v4

    .line 46
    iget-wide v8, v0, Lp0/j;->a:D

    .line 47
    .line 48
    mul-double/2addr v6, v8

    .line 49
    mul-double/2addr v4, v4

    .line 50
    sub-double/2addr v4, v2

    .line 51
    invoke-static {v4, v5}, Ljava/lang/Math;->sqrt(D)D

    .line 52
    .line 53
    .line 54
    move-result-wide v4

    .line 55
    mul-double/2addr v4, v8

    .line 56
    sub-double/2addr v6, v4

    .line 57
    iput-wide v6, v0, Lp0/j;->g:D

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_1
    const-wide/16 v6, 0x0

    .line 61
    .line 62
    cmpl-double v1, v4, v6

    .line 63
    .line 64
    if-ltz v1, :cond_2

    .line 65
    .line 66
    cmpg-double v1, v4, v2

    .line 67
    .line 68
    if-gez v1, :cond_2

    .line 69
    .line 70
    iget-wide v6, v0, Lp0/j;->a:D

    .line 71
    .line 72
    mul-double/2addr v4, v4

    .line 73
    sub-double v4, v2, v4

    .line 74
    .line 75
    invoke-static {v4, v5}, Ljava/lang/Math;->sqrt(D)D

    .line 76
    .line 77
    .line 78
    move-result-wide v4

    .line 79
    mul-double/2addr v4, v6

    .line 80
    iput-wide v4, v0, Lp0/j;->h:D

    .line 81
    .line 82
    :cond_2
    :goto_1
    const/4 v1, 0x1

    .line 83
    iput-boolean v1, v0, Lp0/j;->c:Z

    .line 84
    .line 85
    goto :goto_0

    .line 86
    :goto_2
    long-to-double v4, v4

    .line 87
    const-wide v6, 0x408f400000000000L    # 1000.0

    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    div-double/2addr v4, v6

    .line 93
    iget-wide v6, v0, Lp0/j;->i:D

    .line 94
    .line 95
    sub-double v6, p1, v6

    .line 96
    .line 97
    iget-wide v8, v0, Lp0/j;->b:D

    .line 98
    .line 99
    cmpl-double v1, v8, v2

    .line 100
    .line 101
    const-wide v10, 0x4005bf0a8b145769L    # Math.E

    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    if-lez v1, :cond_3

    .line 107
    .line 108
    iget-wide v1, v0, Lp0/j;->g:D

    .line 109
    .line 110
    mul-double v8, v1, v6

    .line 111
    .line 112
    sub-double v8, v8, p3

    .line 113
    .line 114
    iget-wide v12, v0, Lp0/j;->f:D

    .line 115
    .line 116
    sub-double v14, v1, v12

    .line 117
    .line 118
    div-double/2addr v8, v14

    .line 119
    sub-double v8, v6, v8

    .line 120
    .line 121
    mul-double/2addr v6, v1

    .line 122
    sub-double v6, v6, p3

    .line 123
    .line 124
    sub-double v12, v1, v12

    .line 125
    .line 126
    div-double/2addr v6, v12

    .line 127
    mul-double/2addr v1, v4

    .line 128
    invoke-static {v10, v11, v1, v2}, Ljava/lang/Math;->pow(DD)D

    .line 129
    .line 130
    .line 131
    move-result-wide v1

    .line 132
    mul-double/2addr v1, v8

    .line 133
    iget-wide v12, v0, Lp0/j;->f:D

    .line 134
    .line 135
    mul-double/2addr v12, v4

    .line 136
    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->pow(DD)D

    .line 137
    .line 138
    .line 139
    move-result-wide v12

    .line 140
    mul-double/2addr v12, v6

    .line 141
    add-double/2addr v12, v1

    .line 142
    iget-wide v1, v0, Lp0/j;->g:D

    .line 143
    .line 144
    mul-double/2addr v8, v1

    .line 145
    mul-double/2addr v1, v4

    .line 146
    invoke-static {v10, v11, v1, v2}, Ljava/lang/Math;->pow(DD)D

    .line 147
    .line 148
    .line 149
    move-result-wide v1

    .line 150
    mul-double/2addr v1, v8

    .line 151
    iget-wide v8, v0, Lp0/j;->f:D

    .line 152
    .line 153
    mul-double/2addr v6, v8

    .line 154
    mul-double/2addr v8, v4

    .line 155
    invoke-static {v10, v11, v8, v9}, Ljava/lang/Math;->pow(DD)D

    .line 156
    .line 157
    .line 158
    move-result-wide v3

    .line 159
    mul-double/2addr v3, v6

    .line 160
    add-double/2addr v3, v1

    .line 161
    goto/16 :goto_3

    .line 162
    .line 163
    :cond_3
    cmpl-double v1, v8, v2

    .line 164
    .line 165
    if-nez v1, :cond_4

    .line 166
    .line 167
    iget-wide v1, v0, Lp0/j;->a:D

    .line 168
    .line 169
    mul-double v8, v1, v6

    .line 170
    .line 171
    add-double v8, v8, p3

    .line 172
    .line 173
    mul-double v12, v8, v4

    .line 174
    .line 175
    add-double/2addr v12, v6

    .line 176
    neg-double v1, v1

    .line 177
    mul-double/2addr v1, v4

    .line 178
    invoke-static {v10, v11, v1, v2}, Ljava/lang/Math;->pow(DD)D

    .line 179
    .line 180
    .line 181
    move-result-wide v1

    .line 182
    mul-double/2addr v1, v12

    .line 183
    iget-wide v6, v0, Lp0/j;->a:D

    .line 184
    .line 185
    neg-double v6, v6

    .line 186
    mul-double/2addr v6, v4

    .line 187
    invoke-static {v10, v11, v6, v7}, Ljava/lang/Math;->pow(DD)D

    .line 188
    .line 189
    .line 190
    move-result-wide v6

    .line 191
    mul-double/2addr v6, v12

    .line 192
    iget-wide v12, v0, Lp0/j;->a:D

    .line 193
    .line 194
    neg-double v14, v12

    .line 195
    mul-double/2addr v6, v14

    .line 196
    neg-double v12, v12

    .line 197
    mul-double/2addr v12, v4

    .line 198
    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->pow(DD)D

    .line 199
    .line 200
    .line 201
    move-result-wide v3

    .line 202
    mul-double/2addr v3, v8

    .line 203
    add-double/2addr v3, v6

    .line 204
    move-wide v12, v1

    .line 205
    goto :goto_3

    .line 206
    :cond_4
    iget-wide v12, v0, Lp0/j;->h:D

    .line 207
    .line 208
    div-double/2addr v2, v12

    .line 209
    iget-wide v12, v0, Lp0/j;->a:D

    .line 210
    .line 211
    mul-double v14, v8, v12

    .line 212
    .line 213
    mul-double/2addr v14, v6

    .line 214
    add-double v14, v14, p3

    .line 215
    .line 216
    mul-double/2addr v14, v2

    .line 217
    neg-double v1, v8

    .line 218
    mul-double/2addr v1, v12

    .line 219
    mul-double/2addr v1, v4

    .line 220
    invoke-static {v10, v11, v1, v2}, Ljava/lang/Math;->pow(DD)D

    .line 221
    .line 222
    .line 223
    move-result-wide v1

    .line 224
    iget-wide v8, v0, Lp0/j;->h:D

    .line 225
    .line 226
    mul-double/2addr v8, v4

    .line 227
    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    .line 228
    .line 229
    .line 230
    move-result-wide v8

    .line 231
    mul-double/2addr v8, v6

    .line 232
    iget-wide v12, v0, Lp0/j;->h:D

    .line 233
    .line 234
    mul-double/2addr v12, v4

    .line 235
    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    .line 236
    .line 237
    .line 238
    move-result-wide v12

    .line 239
    mul-double/2addr v12, v14

    .line 240
    add-double/2addr v12, v8

    .line 241
    mul-double/2addr v12, v1

    .line 242
    iget-wide v1, v0, Lp0/j;->a:D

    .line 243
    .line 244
    neg-double v8, v1

    .line 245
    mul-double/2addr v8, v12

    .line 246
    iget-wide v10, v0, Lp0/j;->b:D

    .line 247
    .line 248
    mul-double/2addr v8, v10

    .line 249
    neg-double v10, v10

    .line 250
    mul-double/2addr v10, v1

    .line 251
    mul-double/2addr v10, v4

    .line 252
    const-wide v1, 0x4005bf0a8b145769L    # Math.E

    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    invoke-static {v1, v2, v10, v11}, Ljava/lang/Math;->pow(DD)D

    .line 258
    .line 259
    .line 260
    move-result-wide v1

    .line 261
    iget-wide v10, v0, Lp0/j;->h:D

    .line 262
    .line 263
    move-wide/from16 p1, v12

    .line 264
    .line 265
    neg-double v12, v10

    .line 266
    mul-double/2addr v12, v6

    .line 267
    mul-double/2addr v10, v4

    .line 268
    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    .line 269
    .line 270
    .line 271
    move-result-wide v6

    .line 272
    mul-double/2addr v6, v12

    .line 273
    iget-wide v10, v0, Lp0/j;->h:D

    .line 274
    .line 275
    mul-double/2addr v14, v10

    .line 276
    mul-double/2addr v10, v4

    .line 277
    invoke-static {v10, v11}, Ljava/lang/Math;->cos(D)D

    .line 278
    .line 279
    .line 280
    move-result-wide v3

    .line 281
    mul-double/2addr v3, v14

    .line 282
    add-double/2addr v3, v6

    .line 283
    mul-double/2addr v3, v1

    .line 284
    add-double/2addr v3, v8

    .line 285
    move-wide/from16 v12, p1

    .line 286
    .line 287
    :goto_3
    iget-wide v1, v0, Lp0/j;->i:D

    .line 288
    .line 289
    add-double/2addr v12, v1

    .line 290
    double-to-float v1, v12

    .line 291
    iget-object v2, v0, Lp0/j;->j:Lp0/g;

    .line 292
    .line 293
    iput v1, v2, Lp0/g;->a:F

    .line 294
    .line 295
    double-to-float v1, v3

    .line 296
    iput v1, v2, Lp0/g;->b:F

    .line 297
    .line 298
    return-object v2

    .line 299
    :cond_5
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 300
    .line 301
    const-string v2, "Error: Final position of the spring must be set before the animation starts"

    .line 302
    .line 303
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    throw v1
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
.end method
