.class public interface abstract Lz0/w0;
.super Ljava/lang/Object;
.source "SourceFile"
