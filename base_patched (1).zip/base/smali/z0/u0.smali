.class public final Lz0/u0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroid/util/SparseArray;

.field public b:I


# virtual methods
.method public final a(I)Lz0/t0;
    .locals 2

    .line 1
    iget-object v0, p0, Lz0/u0;->a:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lz0/t0;

    if-nez v1, :cond_0

    new-instance v1, Lz0/t0;

    invoke-direct {v1}, Lz0/t0;-><init>()V

    invoke-virtual {v0, p1, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_0
    return-object v1
.end method
