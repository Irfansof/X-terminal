.class public final Lz0/t;
.super Lz0/p0;
.source "SourceFile"


# instance fields
.field public e:I

.field public f:I


# direct methods
.method public constructor <init>(II)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lz0/p0;-><init>(II)V

    const/4 p1, -0x1

    iput p1, p0, Lz0/t;->e:I

    const/4 p1, 0x0

    iput p1, p0, Lz0/t;->f:I

    return-void
.end method
